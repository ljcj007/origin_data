from pathlib import Path
import subprocess,sys,os
R=Path(__file__).resolve().parent
env=os.environ.copy();env.update(MPLBACKEND='Agg',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
commands=[['code/plot_joint_figures.py','--only','current'],['code/plot_bond_control.py'],
 ['code/plot_seven_orbital_predict.py']]+[[f'seven_orbital_reproduction/code/plots/plot_fig{n}.py','--reuse-source'] for n in [1,2,4,5]]
for args in commands:subprocess.run([sys.executable,*args],cwd=R,env=env,check=True)
