"""Figure 1: physical honeycomb-vacancy coordinates, seven-site motif and local A rhombus.
Generated from exact positions and integer hoppings."""

from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, FancyArrowPatch
from matplotlib.lines import Line2D
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'code'))
import c3n4_verified as cv

HERE =ROOT.parents[1]/'figures'/'PRB'
DATA=ROOT/'source_data'
META=ROOT/'metadata'
PURPLE, GREEN, CRIMSON = '#7A5195', '#3B8E5A', '#B54A50'
DARK, BOND, GHOST, VACANCY = '#333333', '#888888', '#D0D0D0', '#BEBEBE'
SQRT3 = np.sqrt(3.)
CART = np.array([[1., 0.], [-.5, SQRT3/2]])
CANONICAL = np.array([[0., 0.], [1/3, 1/6], [.5, 0.], [5/6, 1/6],
                      [0., .5], [5/6, 2/3], [.5, .5], [1/3, 2/3]])
SHIFTS = np.zeros((8, 2), dtype=int)
SHIFTS[4] = [1, 0]
RING = CANONICAL + SHIFTS
AB = ((0,1,0,0), (0,3,-1,0), (0,5,-1,-1), (1,2,0,0),
      (1,6,0,0), (2,3,0,0), (3,4,1,0), (4,5,-1,0), (5,6,0,0))
AA = ((0,2,0,0), (2,4,1,0), (4,6,-1,0), (6,0,0,0))
A = {0,2,4,6}
CELL_FRAC = np.array([[0.,0.], [1.,0.], [1.,1.], [0.,1.]])

mpl.rcParams.update({
    'font.family':'serif', 'font.serif':['Times New Roman','DejaVu Serif'],
    'font.size':7.5, 'axes.titlesize':7.5, 'legend.fontsize':7,
    'mathtext.fontset':'stix', 'pdf.fonttype':42, 'ps.fonttype':42,
    'svg.fonttype':'none', 'figure.facecolor':'white', 'axes.facecolor':'white',
    'savefig.facecolor':'white', 'lines.solid_capstyle':'round',
    'text.color':DARK, 'axes.labelcolor':DARK,
})


def xy(key):
    """A lattice key is (cell_x, cell_y, original orbital index)."""
    x, y, i = key
    return (CANONICAL[i] + [x,y]) @ CART


def cell_patch(ax, origin, fill=True, lw=1.0):
    vertices = (CELL_FRAC + origin) @ CART
    if fill:
        ax.add_patch(Polygon(vertices, closed=True, facecolor=PURPLE,
                             edgecolor='none', alpha=.045, zorder=.1))
    ax.add_patch(Polygon(vertices, closed=True, facecolor='none', edgecolor=PURPLE,
                         linewidth=lw, zorder=3))


def line(ax, first, second, color, lw, alpha=1., zorder=1, ls='-'):
    p, q = xy(first), xy(second)
    ax.plot([p[0],q[0]], [p[1],q[1]], color=color, lw=lw, alpha=alpha,
            linestyle=ls, zorder=zorder, clip_on=True)


def site(ax, key, size, ghost=False, zorder=5):
    p = xy(key)
    if key[2] == 7:
        ax.plot(p[0],p[1], marker='x', ms=size+.6, mew=.75,
                color=VACANCY, alpha=.80, zorder=zorder, clip_on=True)
    else:
        color = GHOST if ghost else DARK
        ax.plot(p[0],p[1], marker='o', ms=size, mec=color, mew=.75,
                mfc=color if key[2] in A else 'white', zorder=zorder,
                clip_on=True)


def all_edges(cells):
    result = []
    for cx,cy in cells:
        for i,j,rx,ry in AB:
            result.append(((cx,cy,i),(cx+rx,cy+ry,j),'t' if i==0 else 't1'))
    return result


def build_panels():
    fig = plt.figure(figsize=(174/25.4,76/25.4))
    ax_a = fig.add_axes([.035,.18,.448,.71])
    ax_b = fig.add_axes([.535,.18,.435,.71])
    for ax in (ax_a,ax_b):
        ax.set_aspect('equal')
        ax.axis('off')
    # A finite view of the infinite periodic graph, without extra parent sites.
    ax_a.set_xlim(-.90,2.30)
    ax_a.set_ylim(-.20,2.20)
    cells = [(x,y) for x in range(-3,6) for y in range(-3,6)]
    edges = all_edges(cells)
    for p,q,kind in edges:
        line(ax_a,p,q,GREEN if kind=='t' else BOND,.65,
             alpha=.78 if kind=='t' else .80)
    for x,y in cells:
        for i in range(8):
            site(ax_a,(x,y,i),2.2 if i!=7 else 2.1,zorder=2.5)
    cell_patch(ax_a,np.array([1.,1.]),fill=True,lw=1.15)
    fig.text(.04,.925,'a',fontweight='bold',fontsize=8)
    fig.text(.068,.925,'Vacancy honeycomb lattice',fontsize=7.5)

    # The ring representative of 4 belongs to the cell translated by +a1.
    # Other grey sites are genuine periodic neighbours, not extra orbitals.
    selected = {(int(SHIFTS[i,0]),int(SHIFTS[i,1]),i) for i in range(7)}
    context_edges = [(p,q,kind) for p,q,kind in edges if p in selected or q in selected]
    ghosts = {p for p,q,kind in context_edges if p not in selected}
    ghosts |= {q for p,q,kind in context_edges if q not in selected}
    # These two boundary images make the periodic supercell boundary explicit.
    ghosts |= {(0,0,4),(0,1,2)}
    ax_b.set_xlim(-.60,1.22)
    ax_b.set_ylim(-.36,1.05)
    cell_patch(ax_b,np.array([0.,0.]),fill=False,lw=.90)
    for p,q,kind in context_edges:
        inside = p in selected and q in selected
        line(ax_b,p,q,GREEN if kind=='t' else BOND,1.20 if inside else .80,
             alpha=1. if inside else .45,zorder=2)
    for key in sorted(ghosts):
        site(ax_b,key,3.3,ghost=True,zorder=4)
    for i,j,rx,ry in AA:
        p = (int(SHIFTS[i,0]),int(SHIFTS[i,1]),i)
        q = (int(SHIFTS[j,0]),int(SHIFTS[j,1]),j)
        line(ax_b,p,q,CRIMSON,1.30,zorder=3.5,ls=(0,(2.3,2.0)))
    for key in sorted(selected):
        site(ax_b,key,4.1,zorder=6)
    site(ax_b,(0,0,7),4.4,zorder=6)
    offsets = {0:(-.032,-.068),1:(-.055,.043),2:(.005,-.067),
               3:(.053,-.020),4:(.055,.022),5:(.010,.053),6:(-.065,.020)}
    for key in sorted(selected):
        p=xy(key); dx,dy=offsets[key[2]]
        ax_b.text(p[0]+dx,p[1]+dy,str(key[2]),fontsize=7.5,
                  ha='center',va='center',color=DARK,zorder=8,
                  bbox={'facecolor':'white','edgecolor':'none','pad':.10,'alpha':.86})
    deleted = xy((0,0,7))
    ax_b.text(deleted[0]-.030,deleted[1]+.070,'7 (removed)',fontsize=6.5,
              ha='center',color='#888888',zorder=8)
    # Direct amplitude labels refer to A-B bonds only.
    ax_b.text(.100,.080,r'$t$',color=GREEN,fontsize=8,zorder=8,
              bbox={'facecolor':'white','edgecolor':'none','pad':.15,'alpha':.94})
    ax_b.text(.365,.548,r'$t_1$',color='#777777',fontsize=8,zorder=8,
              bbox={'facecolor':'white','edgecolor':'none','pad':.15,'alpha':.94})
    # Correct non-orthogonal supercell basis, in a clear corner of panel b.
    origin=np.array([.895,.775]); scale=.245
    for vec,label,labelpos in [(np.array([1.,0.]),r'$\mathbf{a}_1$',(1.095,.740)),
                              (np.array([-.5,SQRT3/2]),r'$\mathbf{a}_2$',(.720,.984))]:
        end=origin+scale*vec
        ax_b.add_patch(FancyArrowPatch(origin,end,arrowstyle='-|>',
                                      mutation_scale=5.5,color=DARK,lw=.7,zorder=8))
        ax_b.text(*labelpos,label,fontsize=7,color=DARK,zorder=8)
    fig.text(.54,.925,'b',fontweight='bold',fontsize=8)
    fig.text(.568,.925,'Seven-orbital motif and local A loop',fontsize=7.5)

    handles=[Line2D([],[],marker='o',ms=4,mec=DARK,mfc=DARK,lw=0,label='A'),
             Line2D([],[],marker='o',ms=4,mec=DARK,mfc='white',lw=0,label='B'),
             Line2D([],[],marker='x',ms=4.4,color=VACANCY,lw=0,label='Vacancy'),
             Line2D([],[],color=GREEN,lw=1.2,label=r'$t$'),
             Line2D([],[],color=BOND,lw=1.2,label=r'$t_1$'),
             Line2D([],[],color=PURPLE,lw=.95,label='Supercell'),
             Line2D([],[],color=CRIMSON,lw=1.3,ls=(0,(2.3,2.0)),label='Local A loop')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.065),ncol=7,
               frameon=False,handlelength=1.4,handletextpad=.50,columnspacing=1.2,
               borderaxespad=0,fontsize=7)
    fig.text(.50,.034,'Coordinates in supercell units; grey sites in b are periodic neighbours.',
             ha='center',fontsize=6.5,color='#777777')
    return fig,cells,context_edges,selected,ghosts


def verify_geometry():
    if AB!=cv.HONEYCOMB_AB:
        raise ValueError('Plotting bond list disagrees with the verified physical model')
    if np.max(abs(CANONICAL-cv.HONEYCOMB_ORBITALS))>1e-14:
        raise ValueError('Plotting orbital coordinates disagree with the verified model')
    ab_displacements=[(CANONICAL[j]+[rx,ry]-CANONICAL[i]) @ CART
                      for i,j,rx,ry in AB]
    aa_displacements=[(CANONICAL[j]+[rx,ry]-CANONICAL[i]) @ CART
                      for i,j,rx,ry in AA]
    ring_cart=RING[1:7] @ CART
    ring_center=ring_cart.mean(axis=0)
    radius=np.linalg.norm(ring_cart-ring_center,axis=1)
    edges=np.linalg.norm(np.roll(ring_cart,-1,axis=0)-ring_cart,axis=1)
    # Convex CCW hexagon containment: 0 lies strictly outside one edge.
    p0=RING[0] @ CART
    delta=np.roll(ring_cart,-1,axis=0)-ring_cart
    cross=delta[:,0]*(p0[1]-ring_cart[:,1])-delta[:,1]*(p0[0]-ring_cart[:,0])
    if not (cross.min()<-1e-12 and cross.max()>1e-12):
        raise ValueError('Orbital 0 is not geometrically outside the intact ring')
    # Local AA endpoint keys must implement the canonical translations exactly.
    for i,j,rx,ry in AA:
        if not np.array_equal(SHIFTS[j]-SHIFTS[i],[rx,ry]):
            raise ValueError('AA geometry and its canonical translation disagree')
    return {
        'AB_lengths':np.linalg.norm(ab_displacements,axis=1).tolist(),
        'AB_expected_length':SQRT3/6,
        'AB_max_length_error':float(np.max(abs(np.linalg.norm(ab_displacements,axis=1)-SQRT3/6))),
        'AA_lengths':np.linalg.norm(aa_displacements,axis=1).tolist(),
        'AA_max_length_error':float(np.max(abs(np.linalg.norm(aa_displacements,axis=1)-.5))),
        'ring_center_cartesian':ring_center.tolist(),
        'ring_radius_spread':float(np.ptp(radius)),
        'ring_edge_length_spread':float(np.ptp(edges)),
        'orbital0_outside_hexagon':True,
        'orbital0_distance_from_ring_center':float(np.linalg.norm(p0-ring_center)),
        'ring_radius':float(radius.mean()),
        'seven_active_orbitals':list(range(7)),
        'deleted_orbital':7,
        'AA_has_no_direction_arrows':True,
        'AA_represents':'physical nearest-A rhombus with local displacement phases',
        'geometry_matches_verified_module':True,
    }


def main(reuse_source=False):
    geometry_checks=verify_geometry()
    fig,cells,context_edges,selected,ghosts=build_panels()
    # Record text extents before export to catch accidental page clipping.
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    canvas=fig.bbox
    text_bounds=[]
    for artist in fig.findobj(mpl.text.Text):
        if not artist.get_visible() or not artist.get_text():
            continue
        box=artist.get_window_extent(renderer)
        text_bounds.append({'text':artist.get_text(),'inside_page':bool(
            box.x0>=canvas.x0-1 and box.y0>=canvas.y0-1 and
            box.x1<=canvas.x1+1 and box.y1<=canvas.y1+1)})
    if not all(item['inside_page'] for item in text_bounds):
        raise ValueError('A figure text element lies outside the page')
    name=HERE/'fig1_geometry'
    fig.savefig(name.with_suffix('.pdf'))
    fig.savefig(name.with_suffix('.svg'))
    fig.savefig(name.with_suffix('.png'),dpi=180)
    fig.savefig(name.with_suffix('.tiff'),dpi=600,
                pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)
    source={
        'figure_contract':__doc__,
        'coordinate_convention':'row fractional coordinate f maps to Cartesian f @ basis_rows',
        'basis_rows':CART.tolist(),
        'canonical_orbitals':CANONICAL.tolist(),
        'display_representatives':RING[:7].tolist(),
        'representative_cell_shifts':SHIFTS[:7].tolist(),
        'deleted7_representative':CANONICAL[7].tolist(),
        'hamiltonian_convention':'H_ij(k)=h_ij(R) exp(+i k.R), delta=R+r_j-r_i',
        'AB_directed_hoppings':[{'i':i,'j':j,'R':[rx,ry],'amplitude':'-t' if i==0 else '-t1'}
                               for i,j,rx,ry in AB],
        'AA_directed_hoppings':[{'i':i,'j':j,'R':[rx,ry],'amplitude':'t_A exp(+i phi)'}
                               for i,j,rx,ry in AA],
        'AA_embedded_phase_coefficients':[(CANONICAL[j]+[rx,ry]-CANONICAL[i]).tolist()
                                          for i,j,rx,ry in AA],
        'panel_a':{'finite_view_only':True,'drawn_cells':[list(c) for c in cells],
                   'highlighted_supercell_origin':[1,1],
                   'display_limits_cartesian':[[-.90,2.30],[-.20,2.20]]},
        'panel_b':{'selected_keys':[list(c) for c in sorted(selected)],
                   'ghost_keys':[list(c) for c in sorted(ghosts)],
                   'AB_context_edges':[{'first':list(p),'second':list(q),'kind':kind}
                                       for p,q,kind in context_edges],
                   'supercell_origin':[0,0],
                   'display_limits_cartesian':[[-.60,1.22],[-.36,1.05]]},
        'units':'a1 and a2 have unit length; parent NN distance sqrt(3)/6; AA distance 1/2',
        'statistics':'not applicable: deterministic lattice schematic',
        'image_integrity':'all elements generated from verified coordinates; no source-raster edits',
    }
    if not reuse_source:
        (DATA/'fig1_source.json').write_text(json.dumps(source,indent=2),encoding='utf-8')
    svg=ET.parse(name.with_suffix('.svg'))
    editable_text_count=len(svg.findall('.//{http://www.w3.org/2000/svg}text'))
    with Image.open(name.with_suffix('.png')) as png:
        png_size=list(png.size)
    with Image.open(name.with_suffix('.tiff')) as tiff:
        tiff_size=list(tiff.size)
        tiff_dpi=[float(v) for v in tiff.info['dpi']]
    checks={
        'style':{'palette':{'supercell':PURPLE,'t':GREEN,'t1':BOND,'local_A_loop':CRIMSON,
                            'active_sites':DARK,'ghost_sites':GHOST,'vacancy':VACANCY},
                 'font_family':'Times New Roman / DejaVu Serif','math_font':'STIX',
                 'data_reused':bool(reuse_source),'scientific_content_changed':False},
        'geometry':geometry_checks,
        'export':{'width_mm':174,'height_mm':76,'font':'Times New Roman / DejaVu Serif; STIX math',
                  'body_font_pt':7.5,'minimum_font_pt':6.5,'panel_label_pt':8,
                  'pdf_fonttype':42,'pdf_fonts_independently_inspected':'five embedded CID TrueType subsets; no Type 3',
                  'svg_editable_text_elements':editable_text_count,
                  'png_dpi':180,'png_pixels':png_size,'tiff_dpi':tiff_dpi,
                  'tiff_pixels':tiff_size,'white_background':True},
        'text_extent_checks':text_bounds,
        'visual_QA':{'status':'passed',
                     'inspection':'180-dpi complete PNG and enlarged panel-b crop viewed after export',
                     'findings':'Seven numbers visible; 0 outside ring; 7 is a cross; no label/bond overlap or cropping; purple boundary and ghost images consistent',
                     'review_risks':['orbital0 placement','ring4 image','vacancy distinction',
                                     'cell boundary','label overlap','cross-panel color consistency']},
        'caption':'Honeycomb vacancy geometry. (a) Periodic vacancy lattice with '
                  'one supercell outlined in purple. Green and grey bonds have amplitudes t '
                  'and t1. Filled and open circles denote A and B orbitals, respectively; '
                  'crosses mark removed B sites. (b) Enlarged seven-orbital motif, with '
                  'orbital 0 outside the intact 1–6 ring. Orbital 4 is displayed in the '
                  'neighbouring-cell representative r4+a1. Grey sites are periodic '
                  'neighbours. The crimson dashed rhombus denotes the spatially consistent '
                  'local A loop; no particle-current direction is indicated. '
                  'The intracell-loop model uses a separate hopping graph.',
    }
    (META/'fig1_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    print(json.dumps({'files':[f.name for f in HERE.glob('fig1*')],
                      'AB_length_error':geometry_checks['AB_max_length_error'],
                      'AA_length_error':geometry_checks['AA_max_length_error'],
                      'SVG_text_elements':editable_text_count},indent=2))


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reuse-source',action='store_true')
    main(parser.parse_args().reuse_source)
