"""Figure 5: clean honeycomb-vacancy NNN strip spectrum and edge localization.
Exact integer hoppings; no lead-transmission calculation is included."""
from pathlib import Path
import os
for _thread_name in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:
    os.environ[_thread_name]='1'
import sys
import json
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
from scipy.optimize import brentq
from scipy.linalg import eigh
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'code'))
import c3n4_verified as cv

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT.parents[1]/'figures'/'PRB'
DATA=ROOT/'source_data'
META=ROOT/'metadata'
MODEL='honeycomb_haldane'
PARAMS=dict(t=1.,t1=1.,t_NNN=.5,nnn_phi=np.pi/2,mass=0.)
EF=-.6046566848957441
GREEN='#3B8E5A'; CRIMSON='#B54A50'; CYAN='#00A8C6'; GRAY='#888888'
DARK='#333333'; PALE_AXIS='#F5F5F5'; GRID='#DADADA'
mpl.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
    'mathtext.fontset':'stix','text.color':DARK,'axes.labelcolor':DARK,
    'font.size':7.5,'axes.labelsize':7.5,'axes.titlesize':8,'xtick.labelsize':7,
    'ytick.labelsize':7,'legend.fontsize':7,'pdf.fonttype':42,'svg.fonttype':'none',
    'axes.spines.right':True,'axes.spines.top':True,'axes.linewidth':.6,
    'axes.edgecolor':'#777777','axes.facecolor':PALE_AXIS,
    'xtick.direction':'in','ytick.direction':'in','xtick.color':DARK,'ytick.color':DARK,
    'grid.color':GRID,'grid.linewidth':.45,'grid.alpha':.65,
    'lines.linewidth':.8,'savefig.facecolor':'white','figure.facecolor':'white',
    'legend.frameon':False,'text.usetex':False,'xtick.major.size':2.5,'ytick.major.size':2.5})


def strip(x,width,derivative=False):
    return cv.strip_hamiltonian(x,width,MODEL,return_derivative=derivative,**PARAMS)


def spectral_data(axis,width,subset=False):
    energies=[]; lower=[]; upper=[]
    limits=(3*width-2,3*width+2) if subset else None
    for x in axis:
        E,V=eigh(strip(x,width),subset_by_index=limits,check_finite=False)
        weights=cv.edge_weights(V,width,edge_cells=4)
        energies.append(E); lower.append(weights[0]); upper.append(weights[1])
    return np.array(energies),np.array(lower),np.array(upper)


def crossing_data(width,Nk=1025):
    axis=np.linspace(-np.pi,np.pi,Nk)
    # Only bands adjacent to the rank3 lower gap can cross this EF. Use seven
    # exact dense-matrix eigenvalues, not a truncated hopping Hamiltonian.
    lo=3*width-3; hi=3*width+3
    energies=np.array([eigh(strip(x,width),eigvals_only=True,
        subset_by_index=(lo,hi),check_finite=False) for x in axis])
    crossings=[]
    for j in range(hi-lo+1):
        for ix in range(Nk-1):
            if (energies[ix,j]-EF)*(energies[ix+1,j]-EF)>=0:continue
            def value(x):
                return eigh(strip(x,width),eigvals_only=True,
                    subset_by_index=(lo+j,lo+j),check_finite=False)[0]-EF
            root=brentq(value,axis[ix],axis[ix+1],xtol=1e-12)
            H,D=strip(root,width,True)
            E,V=eigh(H,subset_by_index=(lo+j,lo+j),check_finite=False)
            u=V[:,0]
            probability=np.sum(abs(u.reshape(width,7))**2,axis=1)
            lower=float(probability[:4].sum()); upper=float(probability[-4:].sum())
            velocity=float(np.real(u.conj()@D@u))
            eps=1e-5
            fd=(value(root+eps)-value(root-eps))/(2*eps)
            crossings.append({'kx':float(root),'energy':float(E[0]),
                'fermi_residual':float(E[0]-EF),'band_index':int(lo+j),
                'velocity':velocity,'finite_difference_velocity':float(fd),
                'velocity_residual':float(abs(velocity-fd)),
                'lower_fourcell_weight':lower,'upper_fourcell_weight':upper,
                'edge':'lower_y' if lower>upper else 'upper_y',
                'probability':probability,'eigenvector':u})
    return axis,energies,crossings


def main(reuse_source=False):
    if reuse_source:
        checks=json.loads((META/'fig5_checks.json').read_text(encoding='utf-8'))
        with np.load(DATA/'fig5_source.npz',allow_pickle=False) as archive:
            assert json.loads(str(archive['parameters']))==PARAMS
            assert float(archive['fermi_energy'])==EF
            global_axis=archive['strip_kx'].copy(); E=archive['strip_energies'].copy()
            L=archive['strip_lower_weights'].copy(); U=archive['strip_upper_weights'].copy()
            zoom_axis=archive['zoom_kx'].copy(); ZE=archive['zoom_energies'].copy()
            ZL=archive['zoom_lower_weights'].copy(); ZU=archive['zoom_upper_weights'].copy()
            all_cross={}
            for width in [20,36,48]:
                all_cross[width]=[]
                for item in checks['crossings'][str(width)]:
                    edge=item['edge']; copy=dict(item)
                    copy['probability']=archive[f'crossing_probability_W{width}_{edge}'].copy()
                    copy['eigenvector']=archive[f'crossing_eigenvector_W{width}_{edge}'].copy()
                    all_cross[width].append(copy)
    else:
        data={}; checks={'model':MODEL,'parameters':PARAMS,'width_spectrum':36,
            'fermi_energy':EF,'filling':'3 particles per seven-orbital cell (3/7)',
            'boundary':'x periodic, y open; canonical integer hopping translations',
            'edge_display_threshold':.6,'edge_probability_window_cells':4,
            'claim_limit':'Single-particle clean edge spectrum only; no transport, disorder or FCI claim.',
            'crossings':{},'periodic_strip_checks':[],
            'probability_plot_lower_limit':1e-12,'source_retains_full_probabilities':True}
        bulk=cv.evaluate(MODEL,N=192,refine=True,nstarts=8,**PARAMS)
        checks['bulk']=cv.concise(bulk); checks['bulk_local_extrema']=bulk['refined']
        global_axis=np.linspace(-np.pi,np.pi,513)
        E,L,U=spectral_data(global_axis,36)
        data.update(strip_kx=global_axis,strip_energies=E,strip_lower_weights=L,strip_upper_weights=U)
        zoom_axis=np.linspace(.865,.963,801)
        ZE,ZL,ZU=spectral_data(zoom_axis,36,subset=True)
        data.update(zoom_kx=zoom_axis,zoom_energies=ZE,zoom_lower_weights=ZL,zoom_upper_weights=ZU,
            zoom_global_band_indices=np.arange(106,111))
        all_cross={}
        for width in [20,36,48]:
            axis,values,cross=crossing_data(width)
            data[f'crossing_bracket_kx_W{width}']=axis
            data[f'crossing_bracket_energies_W{width}']=values
            all_cross[width]=cross
            checks['crossings'][str(width)]=[]
            for item in cross:
                edge=item['edge']
                data[f'crossing_probability_W{width}_{edge}']=item['probability']
                data[f'crossing_eigenvector_W{width}_{edge}']=item['eigenvector']
                data[f'crossing_kx_W{width}_{edge}']=np.array(item['kx'])
                checks['crossings'][str(width)].append({k:v for k,v in item.items()
                    if k not in ['probability','eigenvector']})
            checks['periodic_strip_checks'].append(cv.periodic_strip_check(MODEL,width=width,
                x=.371,**PARAMS))
            print('crossing width',width,checks['crossings'][str(width)],flush=True)
        # The crossing bracketing mesh and the local zoom independently resolve
        # both roots. At width48 additionally double the global bracketing mesh.
        axis,values,extra=crossing_data(48,Nk=2049)
        data['crossing_refined_kx_W48']=axis; data['crossing_refined_energies_W48']=values
        checks['finer_bracketing_width48']=[{k:v for k,v in z.items()
            if k not in ['probability','eigenvector']} for z in extra]
        checks['width_convergence_maximum_kx_change']=float(max(
            abs(next(z['kx'] for z in all_cross[20] if z['edge']==edge)-
                next(z['kx'] for z in all_cross[48] if z['edge']==edge))
            for edge in ['lower_y','upper_y']))
        checks['bracketing_mesh_change_maximum_kx']=float(max(abs(
            next(z['kx'] for z in all_cross[48] if z['edge']==edge)-
            next(z['kx'] for z in extra if z['edge']==edge)) for edge in ['lower_y','upper_y']))
        data['parameters']=np.array(json.dumps(PARAMS)); data['fermi_energy']=np.array(EF)
        np.savez_compressed(DATA/'fig5_source.npz',**data)

    fig=plt.figure(figsize=(6.85,3.18))
    grid=fig.add_gridspec(1,3,left=.07,right=.973,bottom=.255,top=.755,
        width_ratios=[1.24,.97,1.04],wspace=.48)
    axes=[fig.add_subplot(grid[0,i]) for i in range(3)]
    fig.text(.5,.953,'Different Haldane parameters: chiral edges of a 3/7 Chern insulator',
        ha='center',va='center',fontsize=8)
    fig.text(.5,.889,r'$t=t_1=1,\ t_N=0.50,\ \theta=\pi/2,\ m=0$'
        rf'$\quad C_3=0,\ C_{{\mathrm{{occ}},3}}=-1,\ E_F={EF:.3g}$',
        ha='center',va='center',fontsize=7.5)
    for letter,ax,title in zip('abc',axes,['Exact strip, width 36','Resolved Fermi crossings','Edge-state localization']):
        ax.text(-.18,1.11,letter,transform=ax.transAxes,fontweight='bold',fontsize=8)
        ax.set_title(title,pad=5)
        ax.set_axisbelow(True); ax.grid()
    ax=axes[0]
    for n in range(E.shape[1]):
        if E[:,n].max()>=-1.4 and E[:,n].min()<=.35:
            ax.plot(global_axis,E[:,n],color=GRAY,lw=.35,alpha=.72,rasterized=True,zorder=1)
    X=np.broadcast_to(global_axis[:,None],E.shape)
    for weight,other,color,marker in [(L,U,GREEN,'o'),(U,L,CRIMSON,'^')]:
        mask=(weight>.6)&(weight>other)&(E>=-1.4)&(E<=.35)
        ax.scatter(X[mask],E[mask],s=2.5,color=color,marker=marker,linewidths=0,rasterized=True,zorder=3)
    ax.axhline(EF,color=CYAN,ls='--',lw=.85,zorder=2)
    ax.set_xlim(-np.pi,np.pi); ax.set_ylim(-1.4,.35)
    ax.set_xticks([-np.pi,0,np.pi],[r'$-\pi$','0',r'$\pi$'])
    ax.set_yticks([-1.0,-.5,0]); ax.set_xlabel(r'$k_x$'); ax.set_ylabel(r'$E/t_1$')
    handles=[Line2D([],[],color=GREEN,lw=1.2,marker='o',markersize=2.8,label='Lower y edge'),
        Line2D([],[],color=CRIMSON,lw=1.2,marker='^',markersize=3.2,label='Upper y edge'),
        Line2D([],[],color=GRAY,lw=.8,label='Bulk')]
    ax.legend(handles=handles,loc='lower left',fontsize=7,
        facecolor='white',frameon=True,framealpha=.9,edgecolor='none',handlelength=1.2,borderpad=.3)
    ax=axes[1]
    ZX=np.broadcast_to(zoom_axis[:,None],ZE.shape)
    for weight,other,color,marker in [(ZL,ZU,GREEN,'o'),(ZU,ZL,CRIMSON,'^')]:
        mask=(weight>.6)&(weight>other)
        ax.scatter(ZX[mask],ZE[mask],s=2,color=color,marker=marker,linewidths=0,zorder=3,rasterized=True)
    ax.axhline(EF,color=CYAN,ls='--',lw=.85)
    for item in all_cross[36]:
        color=GREEN if item['edge']=='lower_y' else CRIMSON
        marker='o' if item['edge']=='lower_y' else '^'
        ax.scatter(item['kx'],EF,s=18,marker=marker,facecolor='white',edgecolor=color,lw=.9,zorder=4)
    ax.text(.03,.96,r'$v_x=-0.650$',color=GREEN,transform=ax.transAxes,va='top',fontsize=7)
    ax.text(.97,.05,r'$v_x=+0.238$',color=CRIMSON,transform=ax.transAxes,ha='right',fontsize=7)
    ax.set_xlim(.865,.963); ax.set_ylim(EF-.035,EF+.035)
    ax.set_xticks([.88,.90,.92,.94,.96]); ax.tick_params(axis='x',labelsize=7)
    ax.set_xlabel(r'$k_x$'); ax.set_ylabel(r'$E/t_1$')
    ax=axes[2]
    styles={20:':',36:'--',48:'-'}
    for width in [20,36,48]:
        for item in all_cross[width]:
            probability=item['probability'] if item['edge']=='lower_y' else item['probability'][::-1]
            color=GREEN if item['edge']=='lower_y' else CRIMSON
            ax.semilogy(np.arange(width),probability,color=color,ls=styles[width],lw=1.05)
    ax.set_xlim(0,24); ax.set_ylim(1e-12,1)
    ax.set_xticks([0,10,20]); ax.set_yticks([1,1e-4,1e-8,1e-12]); ax.minorticks_off()
    ax.set_xlabel('Distance from own edge (cells)'); ax.set_ylabel('Cell probability')
    width_handles=[Line2D([],[],color=DARK,ls=styles[w],lw=.9,label=f'Width {w}')for w in [20,36,48]]
    ax.legend(handles=width_handles,loc='upper right',fontsize=7,handlelength=1.6,borderpad=.2)
    ax.text(.04,.05,r'$P_{4\,\mathrm{cells}}>0.998$',transform=ax.transAxes,fontsize=7,
        bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':1.2})
    fig.text(.5,.079,'Lower / upper y edges: green circles / crimson triangles. Velocities are dE/dkx; probability stops at '+r'$10^{-12}$.',
        ha='center',fontsize=7)
    fig.text(.5,.033,'Exact integer hopping assembly; opposite edge propagation does not by itself establish transport quantization.',
        ha='center',fontsize=7)
    fig.canvas.draw(); renderer=fig.canvas.get_renderer(); canvas=fig.bbox; clipped=[]
    for obj in fig.findobj(mpl.text.Text):
        if obj.get_visible() and obj.get_text():
            bb=obj.get_window_extent(renderer)
            if bb.x0 < -1 or bb.y0 < -1 or bb.x1 > canvas.width+1 or bb.y1 > canvas.height+1:
                clipped.append(obj.get_text())
    checks['export_qa']={'width_inches':6.85,'height_inches':3.18,'tiff_dpi':600,'png_dpi':180,
        'pdf_fonttype':42,'svg_fonttype':'none','outside_canvas_text':clipped,
        'render_source':'deposited arrays' if reuse_source else 'model recomputation',
        'style':{'font':'Times New Roman / DejaVu Serif','mathtext':'STIX',
            'lower_edge':{'color':GREEN,'marker':'o'},'upper_edge':{'color':CRIMSON,'marker':'^'},
            'fermi_line':CYAN,'bulk':GRAY,'width_linestyles':styles,
            'axes':'boxed fine gray, inward ticks, pale gray background'},
        'reporting_precision':'3 significant figures; conservative three-digit strict probability bound',
        'visual_QA':'PNG must be viewed after export, all panels assessed.'}
    for ext in ['pdf','svg','tiff','png']:
        kwargs={'dpi':600 if ext=='tiff' else 180 if ext=='png' else 300}
        if ext=='tiff':kwargs['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig(OUT/f'fig5_honeycomb_edges.{ext}',**kwargs)
    with Image.open(OUT/'fig5_honeycomb_edges.tiff') as raster:
        rgb=raster.convert('RGB')
    rgb.save(OUT/'fig5_honeycomb_edges.tiff',compression='tiff_lzw',dpi=(600,600))
    plt.close(fig)
    (META/'fig5_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    print('Saved Figure 5; QA',checks['export_qa'],flush=True)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reuse-source',action='store_true')
    main(parser.parse_args().reuse_source)
