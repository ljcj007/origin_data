"""Figure 4: honeycomb-vacancy NNN band and its specified orbital-convention geometry."""
from pathlib import Path
import os
for _thread_name in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:
    os.environ[_thread_name]='1'
import sys
import json
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'code'))
import c3n4_verified as cv

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT.parents[1]/'figures'/'PRB'
DATA=ROOT/'source_data'
META=ROOT/'metadata'
PARAMS=dict(t=1.,t1=1.,t_NNN=.35,nnn_phi=5*np.pi/6,mass=.5)
PURPLE='#7A5195'; GREEN='#3B8E5A'; CYAN='#00A8C6'; GRAY='#888888'
DARK='#333333'; PALE_AXIS='#F5F5F5'; GRID='#DADADA'
DET_J=np.sqrt(3)/2
mpl.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
    'mathtext.fontset':'stix','text.color':DARK,'axes.labelcolor':DARK,
    'font.size':7.5,'axes.labelsize':7.5,'axes.titlesize':8,'xtick.labelsize':7,
    'ytick.labelsize':7,'legend.fontsize':7,'pdf.fonttype':42,'svg.fonttype':'none',
    'axes.spines.right':True,'axes.spines.top':True,'axes.linewidth':.6,
    'axes.edgecolor':'#777777','axes.facecolor':PALE_AXIS,
    'xtick.direction':'in','ytick.direction':'in','xtick.color':DARK,'ytick.color':DARK,
    'grid.color':GRID,'grid.linewidth':.45,'grid.alpha':.65,
    'lines.linewidth':.8,'savefig.facecolor':'white','figure.facecolor':'white',
    'legend.frameon':False,'text.usetex':False,'xtick.major.size':2.5,'ytick.major.size':2.5})


def derivatives(x,y,embedded=False):
    """Analytic matrix derivatives in canonical momentum covectors.

    If embedded=True, apply dH-i[r,H], which uses actual orbital positions.
    The display instead fixes the canonical periodic orbital convention.
    """
    x,y=np.broadcast_arrays(x,y)
    H=cv.hamiltonian(x,y,'honeycomb_haldane',**PARAMS)
    Dx=np.zeros_like(H); Dy=np.zeros_like(H)
    for i,j,rx,ry,a in cv.hoppings('honeycomb_haldane',**PARAMS):
        v=a*np.exp(1j*(rx*x+ry*y))
        Dx[...,i,j]+=1j*rx*v
        Dy[...,i,j]+=1j*ry*v
    if embedded:
        r=cv.HONEYCOMB_ORBITALS[:7]
        Dx-=1j*(r[:,0,None]-r[None,:,0])*H
        Dy-=1j*(r[:,1,None]-r[None,:,1])*H
    return H,Dx,Dy


def qgt(x,y,embedded=False):
    """Interband QGT of band3; Cartesian trace, FHS curvature sign.

    p=(kx,ky)=((1,0).K,(-1/2,sqrt(3)/2).K). Thus derivative_KX
    is derivative_kx-.5*derivative_ky and derivative_KY=sqrt(3)/2*derivative_ky.
    T_ab=sum_m <n|d_a H|m><m|d_b H|n>/(En-Em)^2.
    Omega=+2 Im T_XY matches the positive FHS overlap-plaquette convention.
    """
    H,Dx,Dy=derivatives(x,y,embedded)
    E,V=np.linalg.eigh(H)
    u=V[...,3]
    Ax=np.einsum('...a,...ab,...bm->...m',u.conj(),Dx,V)
    Ay=np.einsum('...a,...ab,...bm->...m',u.conj(),Dy,V)
    delta=E[...,3,None]-E
    denominator=np.where(abs(delta)>1e-12,delta**2,np.inf)
    A_X=Ax-.5*Ay; A_Y=DET_J*Ay
    Txx=np.sum(abs(A_X)**2/denominator,axis=-1)
    Tyy=np.sum(abs(A_Y)**2/denominator,axis=-1)
    Txy=np.sum(A_X*A_Y.conj()/denominator,axis=-1)
    omega=2*np.imag(Txy)
    trace=np.real(Txx+Tyy)
    return {'omega_cart':omega,'trace_metric_cart':trace,
        'gxx_cart':np.real(Txx),'gyy_cart':np.real(Tyy),'gxy_cart':np.real(Txy),
        'trace_deficit':trace-abs(omega),
        'normalized_trace_deficit':(trace-abs(omega))/np.maximum(trace+abs(omega),1e-15)}


def curvature(V):
    u=V[...,3]
    Ux=np.sum(u.conj()*np.roll(u,-1,axis=0),axis=-1)
    Uy=np.sum(u.conj()*np.roll(u,-1,axis=1),axis=-1)
    minimum=float(min(abs(Ux).min(),abs(Uy).min()))
    Ux/=abs(Ux); Uy/=abs(Uy)
    phase=np.angle(Ux*np.roll(Uy,-1,axis=0)*np.roll(Ux,-1,axis=1).conj()*Uy.conj())
    N=len(V); step=2*np.pi/N
    return phase,DET_J*phase/step**2,minimum


def stats(g):
    omega=g['omega_cart']; trace=g['trace_metric_cart']
    mean=float(omega.mean())
    return {'integrated_chern':float(mean*(2*np.pi)/DET_J),
        'mean_omega_cart':mean,'omega_cart_min':float(omega.min()),
        'omega_cart_max':float(omega.max()),
        'relative_curvature_RMS':float(omega.std()/abs(mean)),
        'opposite_mean_sign_area_fraction':float(np.mean(omega*mean<0)),
        'mean_trace_metric_cart':float(trace.mean()),
        'mean_trace_deficit':float(g['trace_deficit'].mean()),
        'mean_normalized_trace_deficit':float(g['normalized_trace_deficit'].mean()),
        'minimum_trace_deficit':float(g['trace_deficit'].min()),
        'integrated_trace_metric_over_2pi':float(trace.mean()*2*np.pi/DET_J)}


def formula_checks():
    out=[]; eps=1e-5
    for x,y in [(.371,-.629),(-1.2,.7),(2.1,-2.4)]:
        H,Dx,Dy=derivatives(x,y)
        dxf=(cv.hamiltonian(x+eps,y,'honeycomb_haldane',**PARAMS)-
             cv.hamiltonian(x-eps,y,'honeycomb_haldane',**PARAMS))/(2*eps)
        dyf=(cv.hamiltonian(x,y+eps,'honeycomb_haldane',**PARAMS)-
             cv.hamiltonian(x,y-eps,'honeycomb_haldane',**PARAMS))/(2*eps)
        def projector(a,b):
            _,v=np.linalg.eigh(cv.hamiltonian(a,b,'honeycomb_haldane',**PARAMS))
            u=v[:,3]; return np.outer(u,u.conj())
        P=projector(x,y)
        Px=(projector(x+eps,y)-projector(x-eps,y))/(2*eps)
        Py=(projector(x,y+eps)-projector(x,y-eps))/(2*eps)
        PX=Px-.5*Py; PY=DET_J*Py
        trace_fd=np.real(np.trace(P@PX@PX)+np.trace(P@PY@PY))
        omega_fd=2*np.imag(np.trace(P@PX@PY))
        g=qgt(x,y)
        def embedded_projector(a,b):
            phase=np.exp(-1j*(a*cv.HONEYCOMB_ORBITALS[:7,0]+b*cv.HONEYCOMB_ORBITALS[:7,1]))
            return phase[:,None]*projector(a,b)*phase[None,:].conj()
        EP=embedded_projector(x,y)
        EPx=(embedded_projector(x+eps,y)-embedded_projector(x-eps,y))/(2*eps)
        EPy=(embedded_projector(x,y+eps)-embedded_projector(x,y-eps))/(2*eps)
        EPX=EPx-.5*EPy; EPY=DET_J*EPy
        trace_emb_fd=np.real(np.trace(EP@EPX@EPX)+np.trace(EP@EPY@EPY))
        omega_emb_fd=2*np.imag(np.trace(EP@EPX@EPY))
        gemb=qgt(x,y,embedded=True)
        out.append({'momentum':[x,y],
            'derivative_x_residual':float(np.max(abs(Dx-dxf))),
            'derivative_y_residual':float(np.max(abs(Dy-dyf))),
            'projector_trace_metric_residual':float(abs(trace_fd-g['trace_metric_cart'])),
            'projector_curvature_residual':float(abs(omega_fd-g['omega_cart'])),
            'embedded_projector_trace_metric_residual':float(abs(trace_emb_fd-gemb['trace_metric_cart'])),
            'embedded_projector_curvature_residual':float(abs(omega_emb_fd-gemb['omega_cart']))})
    return out


def band_path(points_per_leg=180):
    vertices=np.array([[0.,0.],[2*np.pi/3,2*np.pi/3],[np.pi,0.],[0.,0.]])
    path=[]; distance=[]; length=0.; nodes=[0.]
    # Cartesian reciprocal distance: KX=kx, KY=(ky+.5*kx)/DET_J.
    def cart(p):return np.array([p[0],(p[1]+.5*p[0])/DET_J])
    for a,b in zip(vertices[:-1],vertices[1:]):
        norm=np.linalg.norm(cart(b)-cart(a))
        f=np.linspace(0,1,points_per_leg,endpoint=False)
        path.extend(a[None,:]+f[:,None]*(b-a)[None,:])
        distance.extend(length+f*norm); length+=norm; nodes.append(length)
    path.append(vertices[-1]); distance.append(length)
    path=np.array(path)
    E=np.linalg.eigvalsh(cv.hamiltonian(path[:,0],path[:,1],'honeycomb_haldane',**PARAMS))
    return path,np.array(distance),np.array(nodes),E


def main(reuse_source=False):
    if reuse_source:
        checks=json.loads((META/'fig4_checks.json').read_text(encoding='utf-8'))
        with np.load(DATA/'fig4_source.npz',allow_pickle=False) as archive:
            assert json.loads(str(archive['parameters']))==PARAMS
            shown_Omega=archive['FHS_Omega_cart_N192'].copy()
            shown_geometry={name:archive[f'{name}_canonical_N192'].copy() for name in
                ['omega_cart','trace_metric_cart','gxx_cart','gyy_cart','gxy_cart','trace_deficit','normalized_trace_deficit']}
            path=archive['path_momenta'].copy(); distance=archive['path_distance'].copy()
            nodes=archive['path_nodes'].copy(); Epath=archive['path_energies'].copy()
            EF=float(archive['displayed_EF'])
    else:
        data={}; checks={'model':'honeycomb_haldane','parameters':PARAMS,
            'fixed_orbital_convention':'canonical periodic, local geometry is convention dependent',
            'canonical_H_convention':'H_ij(k)=sum_R t_ij(R) exp(+i k.R)',
            'orbital_coordinates_oblique_supercell':cv.HONEYCOMB_ORBITALS[:7].tolist(),
            'embedding_transform':'H_embedded=Dg^dagger H_periodic Dg; Dg_aa=exp(+i k.r_a)',
            'embedding_covariant_derivative':'nabla_mu u=partial_mu u-i r_mu u; nabla_mu H=partial_mu H-i[r_mu,H]',
            'covector_from_cartesian_J':[[1.,0.],[-.5,DET_J]],
            'geometry_units':'Omega_XY and g_XY in squared supercell-length units; |a1|=|a2|=1, 120 degree basis; kx,ky dimensionless covectors',
            'cartesian_coordinates':'KX=kx; KY=(ky+kx/2)/(sqrt(3)/2)',
            'curvature_sign':'positive FHS overlap-plaquette; +2 Im T_XY',
            'limit':'single-particle evidence; no FCI, transport, or globally certified gap claim',
            'meshes':{},'formula_checks':formula_checks()}
        for N in [96,192]:
            axis=np.linspace(-np.pi,np.pi,N,endpoint=False); step=2*np.pi/N
            x,y=np.meshgrid(axis,axis,indexing='ij')
            E,V=np.linalg.eigh(cv.hamiltonian(x,y,'honeycomb_haldane',**PARAMS))
            F,Omega,overlap=curvature(V)
            center=axis+step/2; cx,cy=np.meshgrid(center,center,indexing='ij')
            G=qgt(cx,cy); Gemb=qgt(cx,cy,embedded=True)
            result=cv.evaluate('honeycomb_haldane',N=N,**PARAMS)
            checks['meshes'][str(N)]={'spectral_chern':cv.concise(result),
                'canonical_geometry':stats(G),'physical_embedding_geometry':stats(Gemb),
                'fhs_chern':float(F.sum()/(2*np.pi)),
                'minimum_link_overlap':overlap,'maximum_plaquette_phase':float(abs(F).max()),
                'FHS_vs_analytic_cartesian_curvature_RMS':float(np.sqrt(np.mean((Omega-G['omega_cart'])**2))),
                'embedding_curvature_difference_RMS':float(np.sqrt(np.mean((Gemb['omega_cart']-G['omega_cart'])**2)))}
            data[f'axis_N{N}']=axis; data[f'plaquette_center_N{N}']=center
            data[f'energies_N{N}']=E; data[f'FHS_phase_N{N}']=F; data[f'FHS_Omega_cart_N{N}']=Omega
            for key,value in G.items():data[f'{key}_canonical_N{N}']=value
            for key,value in Gemb.items():data[f'{key}_embedded_N{N}']=value
            if N==192:
                reference=result; shown_geometry=G; shown_Omega=Omega; shown_center=center
        checks['local_refinement']=cv.evaluate('honeycomb_haldane',N=192,refine=True,
            nstarts=8,**PARAMS)['refined']
        ref=checks['local_refinement']
        EF=(ref['E3max']['value']+ref['E4min']['value'])/2
        checks['displayed_EF']=EF; checks['filling_at_EF']='4 particles per seven-orbital cell (4/7)'
        path,distance,nodes,Epath=band_path()
        data.update(path_momenta=path,path_distance=distance,path_nodes=nodes,path_energies=Epath,
            displayed_EF=np.array(EF),parameters=np.array(json.dumps(PARAMS)))
        np.savez_compressed(DATA/'fig4_source.npz',**data)
    fig=plt.figure(figsize=(6.85,3.18))
    grid=fig.add_gridspec(1,3,left=.065,right=.965,bottom=.255,top=.755,
        width_ratios=[1.13,1.02,1.06],wspace=.48)
    axes=[fig.add_subplot(grid[0,i]) for i in range(3)]
    fig.text(.5,.952,'Honeycomb Haldane extension: narrow central Chern band',
        ha='center',va='center',fontsize=8)
    fig.text(.5,.889,r'$t=t_1=1,\ t_N=0.35,\ \theta=5\pi/6,\ m=0.5$'
        r'$\quad C_3=-1,\ C_{\mathrm{occ},3}=0,\ C_{\mathrm{occ},4}=-1$',
        ha='center',va='center',fontsize=7.5)
    for letter,ax,title in zip('abc',axes,['Band isolation','Berry curvature','Quantum geometry']):
        ax.text(-.17,1.11,letter,transform=ax.transAxes,fontweight='bold',fontsize=8)
        ax.set_title(title,pad=5)
    ax=axes[0]
    ax.set_axisbelow(True); ax.grid(axis='y')
    for n in range(7):
        ax.plot(distance,Epath[:,n],color=PURPLE if n==3 else GRAY,
            lw=1.35 if n==3 else .65,zorder=3 if n==3 else 1)
    ax.axhline(EF,color=CYAN,ls='--',lw=.8)
    ax.text(.97,EF+.14,r'$E_F$ (4/7)',transform=ax.get_yaxis_transform(),color=CYAN,ha='right',fontsize=7)
    ax.set_xticks(nodes,[r'$\Gamma$',r'$K$',r'$M$',r'$\Gamma$'])
    ax.set_xlim(distance[0],distance[-1]); ax.set_ylim(float(Epath.min())-.1,float(Epath.max())+.15)
    for n in nodes[1:-1]:ax.axvline(n,color=GRID,lw=.5,zorder=0)
    ax.set_ylabel(r'$E/t_1$'); ax.set_xlabel('Supercell symmetry path')
    ax.text(.03,Epath[0,3]-.35,r'$C=-1$',transform=ax.get_yaxis_transform(),color=PURPLE,va='top',fontsize=7)
    ax=axes[1]
    bound=float(abs(shown_Omega).max())
    cmap=LinearSegmentedColormap.from_list('purple_white_green',[PURPLE,'#FFFFFF',GREEN])
    im=ax.imshow(shown_Omega.T,origin='lower',extent=(-1,1,-1,1),cmap=cmap,
        vmin=-bound,vmax=bound,interpolation='nearest',aspect='auto',rasterized=True)
    ax.set_xticks([-1,0,1]); ax.set_yticks([-1,0,1]); ax.set_xlabel(r'$k_x/\pi$'); ax.set_ylabel(r'$k_y/\pi$')
    cb=fig.colorbar(im,ax=ax,fraction=.06,pad=.05,shrink=.95)
    cb.ax.tick_params(labelsize=7,direction='in'); cb.ax.set_title(r'$\Omega_{XY}$',fontsize=7,pad=4)
    cb.set_ticks([-.3,-.15,0,.15,.3])
    ax.text(.03,.97,r'$C=-1$; FHS $192^2$',transform=ax.transAxes,ha='left',va='top',fontsize=7)
    ax=axes[2]
    ax.set_axisbelow(True); ax.grid()
    xx=abs(shown_geometry['omega_cart']).ravel(); yy=shown_geometry['trace_metric_cart'].ravel()
    ax.scatter(xx,yy,s=.8,color=PURPLE,alpha=.15,linewidths=0,rasterized=True)
    maximum=float(max(xx.max(),yy.max()))
    ax.plot([0,maximum],[0,maximum],color=CYAN,ls='--',lw=.8)
    ax.set_xlim(0,float(xx.max())*1.08); ax.set_ylim(0,float(yy.max())*1.08)
    ax.set_xticks([0,.1,.2,.3])
    ax.set_xlabel(r'$|\Omega_{XY}|$'); ax.set_ylabel(r'$\mathrm{tr}\,g_{XY}$')
    s=checks['meshes']['192']['canonical_geometry']
    ax.text(.03,.96,r'$\mathrm{tr}\,g\geq |\Omega|$'+'\n'+
        rf'$\sigma_\Omega/|\bar\Omega|={s["relative_curvature_RMS"]:.3g}$'+'\n'+
        rf'$\langle\mathrm{{tr}}\,g-|\Omega|\rangle={s["mean_trace_deficit"]:.3g}$',
        transform=ax.transAxes,va='top',fontsize=7,bbox={'facecolor':'white','edgecolor':'none','alpha':.86,'pad':1.5})
    fig.text(.5,.079,'Fixed canonical orbital convention; curvature and metric use orthonormal Cartesian momentum.',
        ha='center',fontsize=7)
    fig.text(.5,.033,'Single-particle diagnostics; neither flat dispersion nor band geometry establishes an FCI.',
        ha='center',fontsize=7)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer(); canvas=fig.bbox
    clipped=[]
    for obj in fig.findobj(mpl.text.Text):
        if obj.get_visible() and obj.get_text():
            bb=obj.get_window_extent(renderer)
            if bb.x0 < -1 or bb.y0 < -1 or bb.x1 > canvas.width+1 or bb.y1 > canvas.height+1:
                clipped.append(obj.get_text())
    checks['export_qa']={'width_inches':6.85,'height_inches':3.18,'tiff_dpi':600,'png_dpi':180,
        'pdf_fonttype':42,'svg_fonttype':'none','outside_canvas_text':clipped,
        'render_source':'deposited arrays' if reuse_source else 'model recomputation',
        'style':{'font':'Times New Roman / DejaVu Serif','mathtext':'STIX',
            'central_band':PURPLE,'curvature_colormap':[PURPLE,'#FFFFFF',GREEN],
            'metric_scatter':PURPLE,'reference_line':CYAN,
            'axes':'boxed fine gray, inward ticks, pale gray background'},
        'reporting_precision':'3 significant figures for reported values; full source arrays retained',
        'visual_QA':'PNG must be viewed after export; all three panels and colorbar assessed.'}
    for ext in ['pdf','svg','tiff','png']:
        kwargs={'dpi':600 if ext=='tiff' else 180 if ext=='png' else 300}
        if ext=='tiff':kwargs['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig(OUT/f'fig4_honeycomb_geometry.{ext}',**kwargs)
    with Image.open(OUT/'fig4_honeycomb_geometry.tiff') as raster:
        rgb=raster.convert('RGB')
    rgb.save(OUT/'fig4_honeycomb_geometry.tiff',compression='tiff_lzw',dpi=(600,600))
    plt.close(fig)
    (META/'fig4_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    print(json.dumps({'geometry':s,'FHS_analytic_RMS_N96':checks['meshes']['96']['FHS_vs_analytic_cartesian_curvature_RMS'],
        'FHS_analytic_RMS_N192':checks['meshes']['192']['FHS_vs_analytic_cartesian_curvature_RMS'],
        'export_qa':checks['export_qa']},indent=2),flush=True)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reuse-source',action='store_true')
    main(parser.parse_args().reuse_source)
