"""Figure 2: analytical parent spectra, A-only zero mode and weak intracell-loop dispersion.
All energies use t1 units; source extrema are finite-grid/local-search estimates."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import font_manager
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
DATA=ROOT/'source_data'
META=ROOT/'metadata'
sys.path.insert(0,str(ROOT/'code'))
import c3n4_verified as cv

PURPLE, GREEN, CRIMSON, CYAN = '#7A5195', '#3B8E5A', '#B54A50', '#00A8C6'
OUTER, DARK, GRID, PALE = '#888888', '#333333', '#DADADA', '#F5F5F5'
mpl.rcParams.update({
    'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
    'font.size':7.5,'axes.titlesize':7.5,'axes.labelsize':7.5,
    'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
    'mathtext.fontset':'stix','pdf.fonttype':42,'ps.fonttype':42,
    'svg.fonttype':'none','axes.spines.top':True,'axes.spines.right':True,
    'axes.linewidth':.65,'xtick.major.width':.6,'ytick.major.width':.6,
    'xtick.major.size':2.6,'ytick.major.size':2.6,'legend.frameon':False,
    'xtick.direction':'in','ytick.direction':'in','xtick.top':True,'ytick.right':True,
    'axes.axisbelow':True,'axes.edgecolor':DARK,'text.color':DARK,
    'axes.labelcolor':DARK,'xtick.color':DARK,'ytick.color':DARK,
    'grid.color':GRID,'grid.linewidth':.4,'grid.alpha':.65,
    'figure.facecolor':'white','axes.facecolor':PALE,'savefig.facecolor':'white',
})


def path_data(n_segment=120):
    points = [np.array(cv.HONEYCOMB_HIGH_SYMMETRY[key])
              for key in ['Gamma','K','M','Gamma']]
    k = np.concatenate([np.linspace(points[i],points[i+1],n_segment,endpoint=False)
                        for i in range(3)]+[points[-1][None,:]],axis=0)
    cart = np.array([[1.,-.5],[0.,np.sqrt(3)/2]])
    reciprocal_cart = k @ np.linalg.inv(cart)
    s = np.concatenate([[0.],np.cumsum(np.linalg.norm(np.diff(reciprocal_cart,axis=0),axis=1))])
    ticks = s[[0,n_segment,2*n_segment,3*n_segment]]
    H = cv.hamiltonian(k[:,0],k[:,1],model='honeycomb_loop')
    numerical = np.linalg.eigvalsh(H)
    analytic = cv.literal_parent_spectrum(k[:,0]/2,k[:,1]/2)
    psi = cv.honeycomb_parent_zero_vector(k[:,0],k[:,1])
    residual = np.linalg.norm(np.einsum('...ab,...b->...a',H,psi),axis=-1)
    return k,s,ticks,numerical,analytic,psi,residual


def literal_data(filename):
    source = json.loads(filename.read_text(encoding='utf-8'))
    records = source['periodic_domain_results']
    max_grid = max(row['grid'] for row in records)
    rows = sorted([row for row in records if row['grid']==max_grid
                   and row['tA']<=.5+1e-12],key=lambda row:row['tA'])
    if any('refined_direct_gaps' not in row for row in rows):
        raise ValueError('Panel c requires existing verified local-refinement records')
    tA = np.array([row['tA'] for row in rows])
    widths = np.array([row['refined_energy_max'][3]['value']
                       -row['refined_energy_min'][3]['value'] for row in rows])
    direct_pairs = np.array([[row['refined_direct_gaps'][band]['value']
                             for band in [2,3]] for row in rows])
    central_C = np.array([row['individual_band_fhs']['chern_raw'][3] for row in rows])
    if np.max(abs(central_C))>1e-6 or np.min(direct_pairs)<=0:
        raise ValueError('Stored data do not support the plotted isolated C3=0 band')
    return tA,widths,direct_pairs,central_C,rows,max_grid


def cls_check():
    """A ten-site exact zero-energy CLS from the physical periodic section.

    The Fourier convention is u(k)=sum_n psi_n exp(-i k.n), so a polynomial
    exp(+i k.R) coefficient belongs to cell -R. No artificial finite boundary
    is introduced: H psi is evaluated on every reached infinite-lattice site.
    """
    state = {(0,0,0):2.,(-1,-1,2):1.,(-1,0,2):-1.,(0,0,2):-1.,
             (1,0,4):1.,(0,0,4):-1.,(0,-1,4):-1.,
             (-1,0,6):1.,(-1,-1,6):-1.,(0,0,6):-1.}
    image = {}
    for (cx,cy,orbital), amplitude in state.items():
        for i,j,rx,ry,v in cv.hoppings('honeycomb_loop'):
            if j!=orbital or abs(v)==0:
                continue
            key=(cx-rx,cy-ry,i)
            image[key]=image.get(key,0j)+v*amplitude
    return {'support_sites':len(state),'norm_squared':sum(v*v for v in state.values()),
            'max_infinite_lattice_Hpsi_residual':float(max(abs(v) for v in image.values())),
            'Hpsi_norm':float(np.linalg.norm(list(image.values()))),
            'state':[{'cell':[x,y],'orbital':i,'amplitude':a} for (x,y,i),a in sorted(state.items())],
            'parameters':{'t':1.,'t1':1.,'t_AA':0.},
            'convention':'u(k)=sum_n psi_n exp(-i k.n); no finite-boundary truncation'}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-json',type=Path,default=DATA/'intracell_weak_loop_records.json')
    parser.add_argument('--reuse-source',action='store_true')
    args=parser.parse_args()
    directory=ROOT.parents[1]/'figures'/'PRB'
    tA,widths,pairs,central_C,rows,grid=literal_data(args.source_json)
    delta=np.min(pairs,axis=1)
    if args.reuse_source:
        saved=json.loads((META/'fig2_checks.json').read_text(encoding='utf-8'))
        with np.load(DATA/'fig2_source.npz',allow_pickle=False) as archive:
            k=archive['path_k'].copy(); s=archive['path_distance'].copy()
            ticks=archive['path_ticks'].copy(); E=archive['numerical_E'].copy()
            analytic=archive['analytic_E'].copy(); weights=archive['zero_A_weights'].copy()
            B_weight=archive['zero_B_weight'].copy()
            tA=archive['literal_tA'].copy(); widths=archive['literal_bandwidth_refined'].copy()
            pairs=archive['literal_direct_pairs_refined'].copy()
            delta=archive['literal_min_direct_refined'].copy()
            central_C=archive['literal_Ccentral'].copy()
        residual=np.array([saved['maximum_zero_mode_residual']])
    else:
        k,s,ticks,E,analytic,psi,residual=path_data()
        weights=abs(psi[:,cv.A_ORBITALS])**2
        B_weight=np.sum(abs(psi[:,cv.B_ORBITALS])**2,axis=-1)
    metadata={'panel_a':'physical honeycomb vacancy H0(k), t=t1=1, seven orbitals',
              'panel_b':'physical H0(k) periodic analytic zero section',
              'panel_c':'intracell equal-AA loop in periodic q, t=t1=1, phi=pi/2',
              'path':'Gamma-K-M-Gamma, K=(2pi/3,2pi/3), M=(pi,0)',
              'literal_source_grid':grid,'literal_extrema':'existing grid-seeded multistart local refinement, not certified global bounds',
              'units':'energies and tA divided by t1=1; weights dimensionless',
              'statistics':'deterministic Hamiltonian spectra; no random samples, statistical error bars or replicas'}
    if not args.reuse_source:
        np.savez_compressed(DATA/'fig2_source.npz',path_k=k,path_distance=s,path_ticks=ticks,
            numerical_E=E,analytic_E=analytic,zero_A_weights=weights,zero_B_weight=B_weight,
            literal_tA=tA,literal_bandwidth_refined=widths,literal_direct_pairs_refined=pairs,
            literal_min_direct_refined=delta,literal_Ccentral=central_C,
            metadata_json=json.dumps(metadata))
    fig,axes=plt.subplots(1,3,figsize=(174/25.4,62/25.4),
                          gridspec_kw={'width_ratios':[1.22,1.,1.1]})
    fig.subplots_adjust(left=.058,right=.992,bottom=.22,top=.835,wspace=.38)
    titles=[r'Honeycomb vacancy $H_0$ ($\mathbf{k}$)',
            r'$A$-only zero mode ($\mathbf{k}$)',r'Intracell loop ($\mathbf{q}$), $\phi=\pi/2$']
    for i,(ax,title) in enumerate(zip(axes,titles)):
        ax.grid(True)
        ax.set_title(title,pad=7)
        ax.text(-.16,1.115,chr(ord('a')+i),transform=ax.transAxes,
                fontsize=8,fontweight='bold',va='bottom',ha='left')
    a,b,c=axes
    for band in [0,1,5,6]:
        a.plot(s,E[:,band],color=OUTER,lw=.85,zorder=1)
    for band,color in [(2,PURPLE),(3,PURPLE),(4,PURPLE)]:
        a.plot(s,E[:,band],color=color,lw=1.2,zorder=2)
    marker_index=np.unique(np.concatenate([np.arange(0,len(s),36),[len(s)-1]]))
    for band in range(7):
        a.plot(s[marker_index],analytic[marker_index,band],ls='none',marker='o',
               ms=2.6,mew=.55,mfc='white',mec=DARK,zorder=3)
    a.legend(handles=[Line2D([0],[0],color=OUTER,lw=1.,label='Numerical'),
                      Line2D([0],[0],ls='none',marker='o',ms=2.6,mew=.55,
                             mfc='white',mec=DARK,label='Analytic')],
             loc='upper center',bbox_to_anchor=(.5,.985),ncol=2,
             columnspacing=.7,handlelength=1.1,handletextpad=.35,borderaxespad=0)
    a.set_ylabel(r'Energy / $t_1$')
    a.set_ylim(-3.15,3.65)
    a.set_yticks([-3,-2,-1,0,1,2,3])
    a.text(.045,.525,r'$t=t_1=1$',transform=a.transAxes,fontsize=7,color=DARK)
    a.text(s[-1]*.83,.14,r'$E=0$',color=PURPLE,fontsize=7)
    a.text(s[-1]*.81,1.12,r'$+t_1$',color=PURPLE,fontsize=7)
    a.text(s[-1]*.81,-1.32,r'$-t_1$',color=PURPLE,fontsize=7)
    styles=[(GREEN,'-','o'),(PURPLE,'--','s'),(CRIMSON,'-.','^'),(CYAN,':','D')]
    for index,(color,ls,marker) in enumerate(styles):
        b.plot(s,weights[:,index],color=color,ls=ls,lw=1.05,
               marker=marker,markevery=(15+index*8,60),ms=2.3,mew=.55,mfc='white',
               label=fr'$A_{cv.A_ORBITALS[index]}$')
    b.legend(loc='upper left',ncol=2,columnspacing=.8,handlelength=1.65,
             handletextpad=.4,borderaxespad=.1)
    b.text(.035,.73,r'$\sum_A w_i=1;\quad w_B=0$',transform=b.transAxes,fontsize=6.8,color=DARK)
    b.set_ylim(-.025,.86)
    b.set_yticks([0,.2,.4,.6,.8])
    b.set_ylabel('Probability')
    for ax in [a,b]:
        ax.set_xlim(s[0],s[-1])
        ax.set_xticks(ticks,[r'$\Gamma$',r'$K$',r'$M$',r'$\Gamma$'])
        for value in ticks[1:-1]:
            ax.axvline(value,color=GRID,lw=.5,zorder=0)
        ax.set_xlabel(r'$\mathbf{k}$ path (supercell)')
    c.axvspan(0,.25,color=PURPLE,alpha=.065,zorder=0)
    c.axvline(.25,color='#B9B9B9',lw=.6,ls='--',zorder=1)
    c.plot(tA,widths,'o-',color=GREEN,lw=1.1,ms=2.6,label=r'$W_3$')
    c.plot(tA,delta,'s--',color=PURPLE,lw=1.1,ms=2.5,label=r'$\Delta_{\mathrm{dir}}$')
    c.legend(loc='upper right',ncol=1,handlelength=1.5,handletextpad=.4,borderaxespad=.15)
    c.text(.015,1.07,r'$t_A<t_1/4$',color=DARK,fontsize=7)
    j=int(np.argmin(abs(tA-.3)))
    c.annotate(r'$t_A=0.3t_1$'+'\n'+r'$C_3=0$',xy=(tA[j],widths[j]),xytext=(.34,.24),
               fontsize=7,ha='left',va='center',
               arrowprops={'arrowstyle':'-','lw':.6,'color':DARK},color=DARK)
    c.set_xlim(0,.515)
    c.set_ylim(-.02,1.17)
    c.set_xticks([0,.1,.2,.3,.4,.5])
    c.set_yticks([0,.25,.5,.75,1.])
    c.set_xlabel(r'$t_A/t_1$')
    c.set_ylabel(r'Energy / $t_1$')
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    outside=[]
    canvas=fig.bbox
    for artist in fig.findobj(mpl.text.Text):
        if not artist.get_visible() or not artist.get_text():
            continue
        bounds=artist.get_window_extent(renderer=renderer)
        if bounds.x0<canvas.x0-.5 or bounds.y0<canvas.y0-.5 or bounds.x1>canvas.x1+.5 or bounds.y1>canvas.y1+.5:
            outside.append(artist.get_text())
    for extension in ['pdf','svg']:
        fig.savefig(directory/f'fig2_parent.{extension}')
    fig.savefig(directory/'fig2_parent.png',dpi=180)
    fig.savefig(directory/'fig2_parent.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)
    checks={'contract':{'conclusion':'Three parent flat bands and an A-only zero section; weak intracell-loop dispersion has C3=0 at phi=pi/2',
                       'archetype':'quantitative grid; parent-spectrum anchor',
                       'backend':'Python/matplotlib exclusively','final_size_mm':[174,62]},
        'style':{'palette':{'flat_bands':PURPLE,'dispersive_bands':OUTER,
                            'A0':GREEN,'A2':PURPLE,'A4':CRIMSON,'A6':CYAN,
                            'bandwidth':GREEN,'direct_gap':PURPLE,'axes_face':PALE,'grid':GRID},
                 'orbital_styles':['circle solid','square dashed','triangle dash-dot','diamond dotted'],
                 'font_family':'Times New Roman / DejaVu Serif','math_font':'STIX',
                 'boxed_axes':True,'inward_ticks':True,
                 'data_reused':bool(args.reuse_source),'scientific_content_changed':False},
        'metadata':metadata,'path_points':len(s),
        'caption_en': 'Algebraic parent flat bands and dispersion without central-band topology. (a) Seven-orbital physical honeycomb-vacancy H0(k) at t=t1=1 along Gamma-K-M-Gamma, with K=(2pi/3,2pi/3) and M=(pi,0). Numerical bands (lines) agree with the closed-form spectrum (open circles); the flat bands are E=0 and E=+/-t1. (b) A-orbital probabilities of the periodic zero mode on the same path. Their sum is one and the B-sublattice probability is zero; overlapping curves reflect equal weights on portions of the path. (c) The intracell-loop model in periodic q at t=t1=1 and phi=pi/2: central-band bandwidth W3 and minimum adjacent direct gap Delta_dir, obtained from the deposited N192 mesh and grid-seeded local extrema. The tA=.3 point has C3=0. Shading marks the sufficient adiabatic-triviality region |tA|<t1/4, not an inferred phase boundary. The local refinements are numerical estimates, not certified global bounds.',
        'maximum_analytic_spectrum_residual':float(np.max(abs(E-analytic))),
        'maximum_zero_mode_residual':float(np.max(residual)),
        'maximum_A_weight_sum_residual':float(np.max(abs(weights.sum(axis=1)-1))),
        'maximum_B_weight':float(np.max(B_weight)),
        'flat_bandwidths_Eminus1_Ezero_Eplus1':np.ptp(E[:,[2,3,4]],axis=0).tolist(),
        'literal_data':{'tA':tA.tolist(),'refined_bandwidth':widths.tolist(),
                        'refined_min_direct_gap':delta.tolist(),'C3':central_C.tolist(),
                        'source_sha256':hashlib.sha256(args.source_json.read_bytes()).hexdigest(),
                        'grid':grid,'new_sweep_performed':False,
                        'tA_point3':{'W3':float(widths[j]),'direct_gap':float(delta[j]),'C3':float(central_C[j])}},
        'small_hopping_bound':{'central_direct_gap_lower_bound':'t1-4*abs(tA)',
                              'guaranteed_isolated_trivial_region':'abs(tA)<abs(t1)/4'},
        'compact_localized_state_check':cls_check(),
        'export':{'pdf_fonttype':42,'svg_fonttype':'none',
                  'font':Path(font_manager.findfont('Times New Roman',fallback_to_default=True)).name,
                  'body_text_points':7.5,'tick_text_points':7,'panel_letters_points':8,
                  'png_dpi':180,'tiff_dpi':600,'out_of_canvas_text':outside,
                  'svg_text_elements':(directory/'fig2_parent.svg').read_text(encoding='utf-8').count('<text')},
        'visual_QA':{'status':'awaiting visual inspection of generated PNG',
                     'notes':'Compare at final size and enlarged; inspect titles, legends, annotations, line-style ties and axis label spacing'},
        'limitations':'Direct minima from stored multistart local searches are numerical evidence, not certified global bounds; no Hall transport or disorder data shown'}
    for extension in ['png','tiff']:
        with Image.open(directory/f'fig2_parent.{extension}') as im:
            checks['export'][extension+'_pixel_size']=list(im.size)
            checks['export'][extension+'_stored_dpi']=[float(value) for value in im.info.get('dpi',[])]
    if outside:
        raise RuntimeError(f'Text outside figure canvas: {outside}')
    if checks['maximum_analytic_spectrum_residual']>1e-12:
        raise RuntimeError('Analytic/numerical spectrum mismatch')
    if checks['compact_localized_state_check']['Hpsi_norm']>1e-12:
        raise RuntimeError('Infinite-lattice CLS is not an exact zero mode')
    (META/'fig2_checks.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False),encoding='utf-8')
    print('Figure2 exported:',directory/'fig2_parent.pdf')
    print('Spectrum residual:',checks['maximum_analytic_spectrum_residual'])
    print('Zero-mode residual:',checks['maximum_zero_mode_residual'])
    print('CLS residual:',checks['compact_localized_state_check']['Hpsi_norm'])
    print('Stored intracell-loop tA=.3:',checks['literal_data']['tA_point3'])


if __name__=='__main__':
    main()
