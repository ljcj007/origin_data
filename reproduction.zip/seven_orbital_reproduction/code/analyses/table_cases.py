"""Reproduce selected weak-loop and intracell band-isolation cases.

The default exports full-precision deposited records to stable dataset files.
table_2_source.csv supplies Figure 2c; it is not a current manuscript table.
table_3_source.csv supplies manuscript Table II (label tab:nonzero).
--recompute evaluates only these cases with the shared Hamiltonian/FHS API.
Finite meshes and multistart local extrema are not global gap certificates.
"""
from pathlib import Path
import argparse
import csv
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'code'))
import c3n4_verified as cv
DATA = ROOT / 'source_data'


def deposited_rows():
    weak = json.loads((DATA / 'intracell_weak_loop_records.json').read_text())['periodic_domain_results']
    table2 = []
    for row in sorted(weak, key=lambda r: r['tA']):
        table2.append({'t_over_t1': 1., 'tA_over_t1': row['tA'], 'phi_over_pi': .5,
            'bandwidth_over_t1': row['refined_energy_max'][3]['value']-row['refined_energy_min'][3]['value'],
            'min_direct_gap_over_t1': min(row['refined_direct_gaps'][2]['value'], row['refined_direct_gaps'][3]['value']),
            'C_band3': int(round(row['individual_band_fhs']['chern_raw'][3])),
            'C_low3': int(round(row['rank3_projector_fhs']['chern_raw'])), 'mesh_N': row['grid']})
    reps = []
    for name in ['intracell_overlap_cases.json', 'intracell_gapped_case.json', 'intracell_second_gapped_case.json']:
        reps.extend(json.loads((DATA / name).read_text())['representatives'])
    table3 = [{'t_over_t1': r.get('t', 1.), 'tA_over_t1': r['tA'], 'phi_over_pi': r['phi_over_pi'],
        'C_band3': r['validated_central_chern'], 'C_low3': r['validated_low3_chern'],
        'C_low4': r['validated_low4_chern'], 'min_direct_gap_over_t1': r['refined_minimum_direct_gap'],
        'min_indirect_gap_over_t1': r['refined_minimum_indirect_gap'],
        'bandwidth_over_t1': r['refined_central_bandwidth']} for r in reps]
    return table2, table3


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--recompute', action='store_true')
    parser.add_argument('--N', type=int, default=192)
    parser.add_argument('--nstarts', type=int, default=8)
    args = parser.parse_args()
    table2, table3 = deposited_rows()
    for number, rows in [(2, table2), (3, table3)]:
        with (DATA / f'table_{number}_source.csv').open('w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
    if args.recompute:
        outputs = []
        for table, rows in [(2, table2), (3, table3)]:
            for row in rows:
                result = cv.evaluate('literal', N=args.N, refine=True, nstarts=args.nstarts,
                    t=row['t_over_t1'], t1=1., t_AA=row['tA_over_t1'], phi=np.pi*row['phi_over_pi'])
                outputs.append({'source_dataset':f'table_{table}_source.csv',
                    'manuscript_use':'Figure 2c' if table==2 else 'tab:nonzero',
                    'parameters':row,'calculation':result})
        (DATA / 'table_case_recalculation.json').write_text(json.dumps({
            'method':'Finite mesh plus multistart grid-seeded local Nelder-Mead; not certified global bounds',
            'results':outputs}, indent=2)+'\n', encoding='utf-8')
    print('Exported weak-loop and band-isolation source rows:', len(table2), len(table3))


if __name__ == '__main__':
    main()
