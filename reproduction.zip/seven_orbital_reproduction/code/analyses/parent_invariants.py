"""Closed-form parent spectra, periodic zero section and weak intracell-loop perturbation.
Momentum coordinates are the intracell periodic q coordinates."""
from pathlib import Path
import sys
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'code'))
from intracell_helpers import hamiltonian, A_ORBITALS, B_ORBITALS


def zero_vector(qx, qy, ratio=1.0):
    """Non-normalized globally periodic cofactor vector on A=(0,2,4,6)."""
    X, Y = np.exp(1j*qx), np.exp(1j*qy)
    return np.array([2., ratio*(X*Y**2-X-1/X),
                     ratio*(1/(X**2*Y)-1/Y-Y),
                     ratio*(X/Y-X*Y-1/(X*Y))], complex)


def spectrum(qx, qy, t=1., t1=1.):
    F = 9.-2.*(np.cos(2*qx)+np.cos(2*qy)+np.cos(2*(qx+qy)))
    total = 3*t*t+5*t1*t1
    product = t1**4*(4+(t/t1)**2*F)
    discriminant = max(0., total**2-4*product)
    lm = (total-np.sqrt(discriminant))/2
    lp = (total+np.sqrt(discriminant))/2
    return np.sort([0., abs(t1), -abs(t1), np.sqrt(lm), -np.sqrt(lm),
                    np.sqrt(lp), -np.sqrt(lp)])


def first_order(qx, qy, tA, phi, t=1., t1=1.):
    u = zero_vector(qx,qy,t/t1)
    norm = np.vdot(u,u).real
    loop = np.vdot(u,np.roll(u,-1))
    return 2*tA*np.real(np.exp(1j*phi)*loop)/norm


def main():
    results = {'conventions':{
        'model':'intracell-loop Hamiltonian in periodic q; auxiliary kappa=2q gauge',
        'F':'9-2*(cos(2qx)+cos(2qy)+cos(2qx+2qy)); range [3,12]',
        'exact_parent_flat_bands':[0,'+abs(t1)','-abs(t1)'],
        'parent_central_gap':'exactly abs(t1), for t1 nonzero',
        'parent_topology':'A-component u0=2 is nonvanishing globally; normalized periodic section proves central Chern zero',
        'perturbation':'E3=tA*2 Re(exp(i phi)*sum(u_j* u_(j+1)))/norm + O(tA^3); second order vanishes by chiral partner cancellation',
        'small_hopping_triviality_bound':'||HA||<=2abs(tA); Weyl gives min adjacent central direct gaps >=abs(t1)-4abs(tA). Hence abs(tA)<abs(t1)/4 guarantees isolation and Ccentral=C_low3=C_low4=0 for every phi by continuous deformation from the parent.',
        'limit':'The perturbation statement assumes small operator norm relative to the parent central gap; numerical scaling is not a global asymptotic error bound.'},
        'identity_checks':[], 'perturbation_checks':[]}
    for t,t1 in [(1.,1.),(.3,1.),(1.8,.7),(-.5,1.2)]:
        for qx,qy in [(0.,0.),(.731,-1.197),(1.1,2.3),(np.pi/3,np.pi/3)]:
            H=hamiltonian(qx,qy,t=t,t1=t1)
            M=H[np.ix_(A_ORBITALS,B_ORBITALS)]
            u=zero_vector(qx,qy,t/t1)
            F=9-2*(np.cos(2*qx)+np.cos(2*qy)+np.cos(2*(qx+qy)))
            results['identity_checks'].append({
                't':t,'t1':t1,'q':[qx,qy],
                'zero_mode_residual':float(np.linalg.norm(M.conj().T@u)),
                'ring_minor_det':{'real':float(np.linalg.det(-M[1:,:]/t1).real),
                                  'imag':float(np.linalg.det(-M[1:,:]/t1).imag)},
                'ring_singular_values':np.linalg.svd(M[1:,:],compute_uv=False).tolist(),
                'normalization_residual':float(abs(np.vdot(u,u).real-(4+(t/t1)**2*F))),
                'closed_form_spectrum_error':float(np.max(np.abs(np.linalg.eigvalsh(H)-spectrum(qx,qy,t,t1))))})
    for phi in [.7,np.pi/2]:
        qx,qy=.731,-1.197
        for tA in [.005,.01,.02,.04,.08]:
            exact=np.linalg.eigvalsh(hamiltonian(qx,qy,tA,phi))[3]
            predicted=first_order(qx,qy,tA,phi)
            results['perturbation_checks'].append({
                'phi':float(phi),'q':[qx,qy],'tA':tA,
                'exact_E3':float(exact),'first_order_E3':float(predicted),
                'error':float(abs(exact-predicted)),
                'error_divided_by_tA3':float(abs(exact-predicted)/tA**3)})
    output=ROOT/'source_data'/'parent_invariants.json'
    output.write_text(json.dumps(results,indent=2),encoding='utf-8')
    print('Maximum parent spectrum residual:',max(x['closed_form_spectrum_error'] for x in results['identity_checks']))
    print('Maximum zero-mode residual:',max(x['zero_mode_residual'] for x in results['identity_checks']))
    for x in results['perturbation_checks']:
        print('phi=%.6f tA=%.4f error=%.3g error/tA^3=%.6f'%(x['phi'],x['tA'],x['error'],x['error_divided_by_tA3']))


if __name__=='__main__':
    main()
