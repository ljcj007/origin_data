"""Independent Schur reduction of the intracell-loop seven-orbital model.

All momenta are the intracell-loop periodic q coordinates, not honeycomb momenta.
No plots or manuscript changes. Output numerical evidence is not a global
gap certificate. Leading effective degeneracies are explicitly diagnosed.
"""
from pathlib import Path
import os
for _name in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:
    os.environ[_name]='1'
import sys,json
import numpy as np
from scipy.optimize import minimize
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'code'))
import c3n4_verified as cv
OUT=Path(__file__).resolve().parents[2]/'source_data'
PHI=3*np.pi/8
PAULI=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)


def blocks(x,y,r=1.,phi=PHI):
    x,y=np.broadcast_arrays(x,y)
    M=np.zeros(x.shape+(4,3),complex)
    Dx=np.zeros_like(M);Dy=np.zeros_like(M)
    M[...,0,:]=-r
    terms=[(1,0,-1,0),(1,1,1,0),(2,1,0,-1),(2,2,0,1),
        (3,0,-1,-1),(3,2,1,1)]
    for i,j,rx,ry in terms:
        v=-np.exp(1j*(rx*x+ry*y))
        M[...,i,j]=v;Dx[...,i,j]=1j*rx*v;Dy[...,i,j]=1j*ry*v
    A=np.zeros((4,4),complex)
    z=np.exp(1j*phi)
    for i,j in [(0,1),(1,2),(2,3),(3,0)]:
        A[i,j]=z;A[j,i]=z.conjugate()
    return A,M,Dx,Dy


def effective(x,y,r=1.,phi=PHI,a=None,kind='leading',derivative=False):
    A,M,Mx,My=blocks(x,y,r,phi)
    Ai=np.linalg.inv(A);Ai2=Ai@Ai
    def form(L,K,R):return np.einsum('...ai,ab,...bj->...ij',L.conj(),K,R)
    h=-form(M,Ai,M);z=form(M,Ai2,M)
    hx=-form(Mx,Ai,M)-form(M,Ai,Mx)
    hy=-form(My,Ai,M)-form(M,Ai,My)
    h3=-.5*(z@h+h@z)
    if kind=='leading':H=h;Dx=hx;Dy=hy
    elif kind=='third':
        if a is None:raise ValueError('a required')
        zx=form(Mx,Ai2,M)+form(M,Ai2,Mx)
        zy=form(My,Ai2,M)+form(M,Ai2,My)
        H=h/a+h3/a**3
        Dx=hx/a-.5*(zx@h+z@hx+hx@z+h@zx)/a**3
        Dy=hy/a-.5*(zy@h+z@hy+hy@z+h@zy)/a**3
    elif kind=='resummed':
        if a is None:raise ValueError('a required')
        G=np.eye(3)+z/a**2
        ge,gv=np.linalg.eigh(G)
        Gi=(gv*ge[...,None,:]**-.5)@gv.conj().swapaxes(-1,-2)
        H=Gi@(h/a)@Gi
        Dx=Dy=None
    else:raise ValueError('unknown kind')
    return (H,Dx,Dy) if derivative else H


def full(x,y,a=10.,r=1.,phi=PHI,derivative=False):
    A,M,Mx,My=blocks(x,y,r,phi)
    H=np.zeros(M.shape[:-2]+(7,7),complex)
    H[...,:4,:4]=a*A;H[...,:4,4:]=M;H[...,4:,:4]=M.conj().swapaxes(-1,-2)
    if not derivative:return H
    derivatives=[]
    for DM in [Mx,My]:
        D=np.zeros_like(H);D[...,:4,4:]=DM;D[...,4:,:4]=DM.conj().swapaxes(-1,-2)
        derivatives.append(D)
    return H,*derivatives


def fhs(V,indices,direct_gap):
    if len(indices)==1:
        v=V[...,indices[0]]
        ux=np.sum(v.conj()*np.roll(v,-1,0),axis=-1)
        uy=np.sum(v.conj()*np.roll(v,-1,1),axis=-1)
    else:
        v=V[...,indices]
        ux=np.linalg.det(np.einsum('...an,...am->...nm',v.conj(),np.roll(v,-1,0)))
        uy=np.linalg.det(np.einsum('...an,...am->...nm',v.conj(),np.roll(v,-1,1)))
    minimum=float(min(abs(ux).min(),abs(uy).min()))
    if minimum<1e-10 or direct_gap<1e-8:
        return {'sampled_valid':False,'chern':None,'minimum_link':minimum,'sampled_direct_gap':float(direct_gap)}
    ux/=abs(ux);uy/=abs(uy)
    F=np.angle(ux*np.roll(uy,-1,0)*np.roll(ux,-1,1).conj()*uy.conj())
    maximum=float(abs(F).max())
    return {'sampled_valid':True,'chern':float(F.sum()/(2*np.pi)),
        'minimum_link':minimum,'maximum_plaquette':maximum,'mesh_warning':maximum>.9*np.pi,
        'sampled_direct_gap':float(direct_gap)}


def qgt(H,Dx,Dy,band):
    E,V=np.linalg.eigh(H);u=V[...,band]
    Ax=np.einsum('...a,...ab,...bm->...m',u.conj(),Dx,V)
    Ay=np.einsum('...a,...ab,...bm->...m',u.conj(),Dy,V)
    delta=E[...,band,None]-E
    denominator=np.where(abs(delta)>1e-14,delta**2,np.inf)
    omega=2*np.imag(np.sum(Ax*Ay.conj()/denominator,axis=-1))
    trace=np.sum((abs(Ax)**2+abs(Ay)**2)/denominator,axis=-1)
    return omega,np.real(trace)


def exact_B_hamiltonian(H):
    """Hermitian B representative of the exact low-three-band cluster.

    Use the unitary polar factor of its B projection; this is valid when the
    cluster projects invertibly onto B. It differs from a nonorthogonal
    energy-dependent Schur matrix and permits a direct signed-mass check.
    """
    E,V=np.linalg.eigh(H);B=V[4:,2:5]
    se,sv=np.linalg.eigh(B.conj().T@B)
    U=B@((sv*se[None,:]**-.5)@sv.conj().T)
    return (U*E[None,2:5])@U.conj().T,float(np.max(abs(U.conj().T@U-np.eye(3))))


def node_find(N=96,nstarts=48):
    axis=np.linspace(-np.pi,np.pi,N,endpoint=False)
    x,y=np.meshgrid(axis,axis,indexing='ij')
    E=np.linalg.eigvalsh(effective(x,y))
    nodes=[]
    for band in [0,1]:
        values=E[...,band+1]-E[...,band]
        found=[]
        def gap(p):
            e=np.linalg.eigvalsh(effective(*p));return e[band+1]-e[band]
        for ix in np.argsort(values.ravel())[:nstarts]:
            i,j=np.unravel_index(ix,x.shape)
            fit=minimize(gap,[axis[i],axis[j]],method='Nelder-Mead',
                options={'xatol':1e-12,'fatol':1e-13,'maxiter':2000})
            p=(fit.x+np.pi)%(2*np.pi)-np.pi
            if gap(p)>1e-8:continue
            if any(np.linalg.norm((p-f+np.pi)%(2*np.pi)-np.pi)<1e-5 for f in found):continue
            found.append(p)
            H,Hx,Hy=effective(*p,derivative=True)
            E0,V=np.linalg.eigh(H);U=V[:,band:band+2]
            A,M,_,_=blocks(*p);Ai=np.linalg.inv(A)
            z=M.conj().T@Ai@Ai@M
            K=-.5*(z@H+H@z)
            def pauli(D):return np.real(.5*np.einsum('iab,ba->i',PAULI,U.conj().T@D@U))
            vx,vy,d3=pauli(Hx),pauli(Hy),pauli(K)
            cross=np.cross(vx,vy);normal=cross/np.linalg.norm(cross)
            mass=float(normal@d3)
            velocities=np.stack([vx,vy],axis=1)
            shift=-np.linalg.lstsq(velocities,d3,rcond=None)[0]
            node={'band_pair':[band,band+1],'q':p.tolist(),'leading_gap':float(gap(p)),
                'leading_contact_energy':float(E0[band:band+2].mean()),
                'velocity_x_pauli':vx.tolist(),'velocity_y_pauli':vy.tolist(),
                'velocity_cross_norm':float(np.linalg.norm(cross)),
                'third_order_pauli':d3.tolist(),'signed_mass_coefficient':mass,
                'predicted_gap_times_a_cubed':2*abs(mass),'q_shift_times_a_squared':shift.tolist(),
                'central_Dirac_charge_prediction':float((1 if band==0 else -1)*np.sign(mass)/2),
                'central_curvature_over_a_fourth_prediction':float((1 if band==0 else -1)*np.sign(mass)*np.linalg.norm(cross)/(2*mass**2)),
                'central_trace_over_a_fourth_prediction':float((np.dot(vx,vx)+np.dot(vy,vy))/(4*mass**2))}
            nodes.append(node)
    return nodes


def node_full_check(node,a,patch_N=121,patch_R=10.):
    band=node['band_pair'][0];p0=np.array(node['q'])
    seed=p0+np.array(node['q_shift_times_a_squared'])/a**2
    def gap(p):
        e=np.linalg.eigvalsh(full(*p,a=a));return e[3+band]-e[2+band]
    fit=minimize(gap,seed,method='Nelder-Mead',
        options={'xatol':1e-12,'fatol':1e-14,'maxiter':2000})
    p=(fit.x+np.pi)%(2*np.pi)-np.pi
    omega,trace=qgt(*full(*p,a=a,derivative=True),3)
    Hb,unitary_error=exact_B_hamiltonian(full(*p0,a=a))
    h=np.linalg.eigh(effective(*p0))[1];U=h[:,band:band+2]
    d=np.real(.5*np.einsum('iab,ba->i',PAULI,U.conj().T@(a*Hb)@U))
    normal=np.cross(node['velocity_x_pauli'],node['velocity_y_pauli']);normal/=np.linalg.norm(normal)
    mass_full=float(a*a*(normal@d))
    # Rescale each local patch by the Dirac mass and the velocity Gram matrix.
    V=np.stack([node['velocity_x_pauli'],node['velocity_y_pauli']],axis=1)
    se,sv=np.linalg.eigh(V.T@V)
    white=(sv*se[None,:]**-.5)@sv.T
    map_q=abs(node['signed_mass_coefficient'])/a**2*white
    axis=np.linspace(-patch_R,patch_R,patch_N)
    du=axis[1]-axis[0];centers=(axis[:-1]+axis[1:])/2
    u,v=np.meshgrid(centers,centers,indexing='ij')
    points=p[None,None,:]+np.einsum('ab,...b->...a',map_q,np.stack([u,v],axis=-1))
    O,T=qgt(*full(points[...,0],points[...,1],a=a,derivative=True),3)
    jacobian=abs(np.linalg.det(map_q))
    analytic_flux=float(O.sum()*du*du*jacobian/(2*np.pi))
    pu,pv=np.meshgrid(axis,axis,indexing='ij')
    ppoints=p[None,None,:]+np.einsum('ab,...b->...a',map_q,np.stack([pu,pv],axis=-1))
    _,VV=np.linalg.eigh(full(ppoints[...,0],ppoints[...,1],a=a));uu=VV[...,3]
    ux=np.sum(uu[:-1].conj()*uu[1:],axis=-1)
    uy=np.sum(uu[:,:-1].conj()*uu[:,1:],axis=-1)
    ux/=abs(ux);uy/=abs(uy)
    F=np.angle(ux[:,:-1]*uy[1:]*ux[:,1:].conj()*uy[:-1].conj())
    return {'a':a,'band_pair':node['band_pair'],'leading_q':node['q'],
        'refined_q':p.tolist(),'direct_gap':float(gap(p)),
        'direct_gap_times_a_cubed':float(gap(p)*a**3),
        'signed_mass_coefficient_exact_B':mass_full,'exact_B_polar_unitarity_residual':unitary_error,
        'central_curvature_at_gap_minimum':float(omega),'central_curvature_over_a_fourth':float(omega/a**4),
        'central_trace_at_gap_minimum':float(trace),'central_trace_over_a_fourth':float(trace/a**4),
        'patch_grid':patch_N,'patch_dimensionless_halfwidth':patch_R,'patch_q_map':map_q.tolist(),
        'patch_analytic_Berry_flux_over_2pi':analytic_flux,
        'patch_FHS_Berry_flux_over_2pi':float(F.sum()/(2*np.pi)),
        'ideal_local_Dirac_flux_over_2pi':float(node['central_Dirac_charge_prediction']*2*np.arctan(patch_R**2/np.sqrt(1+2*patch_R**2))/np.pi),
        'patch_trace_integral_over_2pi':float(T.sum()*du*du*jacobian/(2*np.pi)),
        'q_shift_prediction_error':float(np.linalg.norm((p-seed+np.pi)%(2*np.pi)-np.pi))}


def spectrum_check(a,N):
    axis=np.linspace(-np.pi,np.pi,N,endpoint=False);x,y=np.meshgrid(axis,axis,indexing='ij')
    H,Hx,Hy=full(x,y,a=a,derivative=True)
    E,V=np.linalg.eigh(H)
    h=effective(x,y);e0,W0=np.linalg.eigh(h)
    e3,W3=np.linalg.eigh(effective(x,y,a=a,kind='third'))
    er,Wr=np.linalg.eigh(effective(x,y,a=a,kind='resummed'))
    direct=np.diff(E,axis=-1).min(axis=(0,1))
    direct3=np.diff(e3,axis=-1).min(axis=(0,1))
    wb=np.sum(abs(V[...,4:,2:5])**2,axis=-2)
    omega,trace=qgt(H,Hx,Hy,3)
    a_scaled_error=float(np.max(abs(a*E[...,2:5]-e0)))
    third_error=float(np.max(abs(E[...,2:5]-e3)))
    result={'a':a,'N':N,'max_scaled_leading_spectrum_error':a_scaled_error,
        'leading_scaled_error_times_a_squared':a_scaled_error*a*a,
        'max_third_order_spectrum_error':third_error,'third_error_times_a_fifth':third_error*a**5,
        'max_resummed_spectrum_error':float(np.max(abs(E[...,2:5]-er))),
        'minimum_B_weight_per_low_band':wb.min(axis=(0,1)).tolist(),
        'mean_B_weight_per_low_band':wb.mean(axis=(0,1)).tolist(),
        'mean_B_leakage_times_a_squared':((1-wb.mean(axis=(0,1)))*a*a).tolist(),
        'full_central_FHS':fhs(V,[3],min(direct[2:4])),
        'full_occupied_low3_FHS':fhs(V,[0,1,2],direct[2]),
        'full_occupied_low4_FHS':fhs(V,[0,1,2,3],direct[3]),
        'middle_low_energy_B_cluster_FHS':fhs(V,[2,3,4],min(direct[1],direct[4])),
        'third_effective_band_FHS':[fhs(W3,[b],min(direct3[max(0,b-1):min(2,b+1)])) for b in range(3)],
        'leading_effective_FHS_sampled_only':[fhs(W0,[b],np.diff(e0,axis=-1).min()) for b in range(3)],
        'leading_effective_isolation_status':'invalid: independently refined band contacts exist at r=1, phi=3pi/8',
        'full_central_bandwidth':float(np.ptp(E[...,3])),
        'full_central_scaled_bandwidth':float(a*np.ptp(E[...,3])),
        'full_lower_indirect_gap':float(E[...,3].min()-E[...,2].max()),
        'uniform_grid_QGT_chern_integral':float(omega.mean()*2*np.pi),
        'uniform_grid_QGT_mean_trace':float(trace.mean()),
        'uniform_grid_QGT_warning':'At strong a, shrinking nodal geometry is unresolved by fixed uniform meshes; do not infer converged geometry from these sums.'}
    return result


def main():
    OUT.mkdir(exist_ok=True)
    result={'model':'intracell-loop model','t':1.,'t1':1.,'phi':PHI,
        'definitions':{'A':'a A1','h':'-Mdagger A1^-1 M','z':'Mdagger A1^-2 M',
            'H_B_third':'h/a - (z h+h z)/(2 a^3)',
            'H_B_resummed':'(I+z/a^2)^-1/2 (h/a) (I+z/a^2)^-1/2',
            'limit':'leading eigenvalues correct to O(a^-3); third/resummed eigenvalues to O(a^-5), away from loss of cluster separation',
            'geometry':'fixed canonical periodic representation, dimensionless abstract q coordinates; not physical honeycomb Cartesian geometry'},
        'pointwise_checks':[],'nodes':node_find(),'spectral_meshes':[],'local_nodes':[]}
    order=np.r_[cv.A_ORBITALS,cv.B_ORBITALS]
    RA=np.diag([1,-1,1,-1])
    for x,y in [(.371,-.629),(-1.2,.7),(2.1,-2.4)]:
        A,M,_,_=blocks(x,y)
        Ai=np.linalg.inv(A);w=(1/np.cos(PHI)+1j/np.sin(PHI))/4
        inverse_explicit=np.zeros((4,4),complex)
        for i,j in [(0,1),(1,2),(2,3),(3,0)]:
            inverse_explicit[i,j]=w;inverse_explicit[j,i]=w.conjugate()
        _,Ms,_,_=blocks(x+np.pi,y)
        other=cv.hamiltonian(x,y,'literal',t_AA=10,phi=PHI)[np.ix_(order,order)]
        result['pointwise_checks'].append({'q':[x,y],
            'full_vs_numerical_module_residual':float(np.max(abs(full(x,y,a=10)-other))),
            'analytic_A_inverse_residual':float(np.max(abs(Ai-inverse_explicit))),
            'M_shift_relation_residual':float(np.max(abs(Ms-RA@M))),
            'leading_shift_antisymmetry_residual':float(np.max(abs(effective(x+np.pi,y)+effective(x,y)))),
            'third_shift_antisymmetry_residual':float(np.max(abs(effective(x+np.pi,y,a=10,kind='third')+effective(x,y,a=10,kind='third'))))})
    for a in [5.,10.,20.,40.]:
        for N in [64,96]:
            z=spectrum_check(a,N);result['spectral_meshes'].append(z)
            print('spectrum',a,N,'C',z['full_central_FHS'],'error',z['max_scaled_leading_spectrum_error'],flush=True)
        # N192 verifies the third-order topology where fixed N64 aliases it.
        result['spectral_meshes'].append(spectrum_check(a,192))
        for node in result['nodes']:
            z=node_full_check(node,a)
            result['local_nodes'].append(z)
            print('node',a,node['band_pair'],z['direct_gap_times_a_cubed'],z['central_curvature_over_a_fourth'],flush=True)
    result['spectral_meshes'].append(spectrum_check(40.,384))
    result['adaptive_patch_refinement']=[node_full_check(node,40.,patch_N=241)for node in result['nodes']]
    (OUT/'strong_loop_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('Saved strong_loop_results.json',flush=True)

if __name__=='__main__':main()
