"""Argument adapter for the intracell-loop analyses and figure scripts.

The numerical API retains the compatibility key "literal". This adapter
exposes the manuscript's intracell-loop model without a second implementation.
"""
import numpy as np
import c3n4_verified as cv
A_ORBITALS=cv.A_ORBITALS
B_ORBITALS=cv.B_ORBITALS
PER_BONDS=cv.LITERAL_AB
def hamiltonian(x,y,tA=0.,phi=np.pi/2,t=1.,t1=1.):
    return cv.hamiltonian(x,y,'literal',t=t,t1=t1,t_AA=tA,phi=phi)
