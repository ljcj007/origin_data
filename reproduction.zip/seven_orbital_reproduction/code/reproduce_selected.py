"""Render selected deposited PRB figures or run explicitly requested analyses.

Default --check verifies saved bytes without running model calculations.
Figure rendering uses deposited source arrays unless --recompute is supplied.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def check():
    manifest = json.loads((ROOT/'metadata/manifest_sha256.json').read_text(encoding='utf-8'))
    for record in manifest['files']:
        path = (ROOT/record['path']).resolve()
        if not path.is_relative_to(ROOT):
            raise ValueError('Manifest path escapes archive')
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
            raise ValueError('Saved snapshot mismatch: '+record['path'])
    print('Saved snapshot verified:', len(manifest['files']), 'files')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='read-only saved-byte verification')
    parser.add_argument('--figures', nargs='+', choices=['1','2','4','5'])
    parser.add_argument('--recompute', action='store_true', help='run figure calculations rather than use saved arrays; Figure 2c still uses deposited weak-loop records')
    parser.add_argument('--analyses', nargs='+', choices=['parent','strong','tables'])
    args = parser.parse_args()
    if args.recompute and not args.figures:
        parser.error('--recompute requires --figures; table recomputation uses table_cases.py directly')
    if args.check or not (args.figures or args.analyses):
        check()
    environment = os.environ.copy()
    environment.update(PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
                       OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    def run(relative, extra=()):
        subprocess.run([sys.executable, str(ROOT/relative), *extra], cwd=ROOT,
                       env=environment, check=True)
    if args.figures:
        (ROOT/'figures').mkdir(exist_ok=True)
        for number in args.figures:
            run(f'code/plots/plot_fig{number}.py', [] if args.recompute else ['--reuse-source'])
    if args.analyses:
        mapping={'parent':'parent_invariants.py','strong':'strong_loop.py','tables':'table_cases.py'}
        for name in args.analyses:
            run('code/analyses/'+mapping[name])


if __name__ == '__main__':
    main()
