"""Auditable seven-orbital models, Chern diagnostics and integer-bond strips.

Dependencies: NumPy and SciPy only (plus the Python standard library).
Self-contained numerical module. No plotting is performed.

Conventions
-----------
H_ij(p) = sum_R h_ij(R) exp(+i p.R), with both Hermitian orientations
listed explicitly. p=(qx,qy) for the intracell-loop model (API key 'literal');
p=(kx,ky) for the two physical honeycomb-vacancy models. All three named
periodic gauges use [-pi,pi)^2. They are DIFFERENT physical models.
FHS uses positive overlap-plaquette phase and the named x-y orientation.
Band indices start at zero. Energies and hopping parameters share units.

Finite meshes and optional multistart local searches are numerical evidence,
not certified global gap bounds. Quantized rank-r Hall response additionally
requires an indirect spectral gap and a chemical potential in that gap.
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import minimize

MODELS = ("literal", "honeycomb_loop", "honeycomb_haldane")
A_ORBITALS = np.array([0, 2, 4, 6])
B_ORBITALS = np.array([1, 3, 5])
HONEYCOMB_METRIC = np.array([[1.0, -0.5], [-0.5, 1.0]])
HONEYCOMB_ORBITALS = np.array([
    [0., 0.], [1/3, 1/6], [.5, 0.], [5/6, 1/6],
    [0., .5], [5/6, 2/3], [.5, .5], [1/3, 2/3]])
HONEYCOMB_RING_ORBITALS = HONEYCOMB_ORBITALS.copy()
HONEYCOMB_RING_ORBITALS[[4, 7], 0] += 1.0
HONEYCOMB_HIGH_SYMMETRY = {
    "Gamma": (0., 0.), "K": (2*np.pi/3, 2*np.pi/3),
    "K_prime": (-2*np.pi/3, -2*np.pi/3), "M": (np.pi, 0.)}
LITERAL_AB = (
    (0,1,0,0), (0,3,0,0), (0,5,0,0), (1,2,1,0),
    (1,6,1,1), (2,3,1,0), (3,4,0,1), (4,5,0,1), (5,6,-1,-1))
HONEYCOMB_AB = (
    (0,1,0,0), (0,3,-1,0), (0,5,-1,-1), (1,2,0,0),
    (1,6,0,0), (2,3,0,0), (3,4,1,0), (4,5,-1,0), (5,6,0,0))
PARENT_EXTRA_AB = ((7,4,0,0), (7,6,0,0), (7,2,0,1))
LOOP = ((0,2), (2,4), (4,6), (6,0))
PHYSICAL_LOOP_R = ((0,0), (1,0), (-1,0), (0,0))
EMBEDDED_AB = (
    (0,1,2,1), (0,3,-1,1), (0,5,-1,-2), (1,2,1,-1),
    (1,6,1,2), (2,3,2,1), (3,4,1,2), (4,5,-1,1), (5,6,-2,-1))


def _haldane_bonds():
    """Enumerate NNN chirality on the full eight-orbital honeycomb parent.

    Delete only hops whose ENDPOINT is orbital 7; retain NNN paths whose
    intermediate parent site is 7. These are independently specified direct
    NNN hops, not effective hoppings obtained by integrating out a vacancy.
    The sign is cross(delta_first, delta_second) in the Cartesian embedding.
    Both directions are present, with opposite signs.
    """
    neighbors = {i: [] for i in range(8)}
    for i, j, rx, ry in HONEYCOMB_AB + PARENT_EXTRA_AB:
        R = np.array([rx, ry], dtype=int)
        neighbors[i].append((j, R))
        neighbors[j].append((i, -R))
    cart = np.array([[1., 0.], [-.5, np.sqrt(3)/2]])
    terms = {}
    for i in range(7):
        for j, R1 in neighbors[i]:
            first = (HONEYCOMB_ORBITALS[j]+R1-HONEYCOMB_ORBITALS[i]) @ cart
            for endpoint, R2 in neighbors[j]:
                R = R1 + R2
                if endpoint == 7 or (endpoint == i and np.all(R == 0)):
                    continue
                second = (HONEYCOMB_ORBITALS[endpoint]+R2-HONEYCOMB_ORBITALS[j]) @ cart
                cross = first[0]*second[1]-first[1]*second[0]
                if abs(cross) < 1e-12:
                    continue
                key = (i, endpoint, int(R[0]), int(R[1]))
                sign = int(np.sign(cross))
                if key in terms and terms[key] != sign:
                    raise ValueError("Ambiguous parent NNN chirality")
                terms[key] = sign
    return tuple((*key, sign) for key, sign in sorted(terms.items()))


HALDANE_NNN = _haldane_bonds()


def model_info(model="literal"):
    if model not in MODELS:
        raise ValueError(f"model must be one of {MODELS}")
    return {
        "model": model,
        "momentum": "intracell-loop periodic q" if model == "literal" else "honeycomb supercell k",
        "torus": "[-pi,pi)^2; integer-translation periodic gauge",
        "description": {
            "literal": "Intracell-loop graph: integer-translation AB hoppings and four intracell AA hoppings; its q torus is distinct from the honeycomb model",
            "honeycomb_loop": "Exact honeycomb-vacancy H0 plus the local nearest-AA rhombus of fig1, with consistent displacement phases",
            "honeycomb_haldane": "Honeycomb-vacancy H0 plus parent-derived direct Haldane NNN bonds and optional staggered A/B mass",
        }[model],
        "units": "all energies, t, t1, t_AA, t_NNN and mass share one chosen energy unit",
        "chern_convention": "positive overlap-plaquette phase, ordered x-y torus",
        "warning": "The three graphs are separate models. In the intracell graph, arbitrary supported AB/AA amplitudes preserve the shifted unitary when mass=0; PxK time reversal requires real AB and purely imaginary AA. Diagonal mass breaks its staggered chiral coloring",
    }


def hoppings(model="literal", t=1., t1=1., t_AA=0., phi=np.pi/2,
             t_NNN=0., nnn_phi=np.pi/2, mass=0.,
             aa_amplitudes=None, aa_phases=None):
    """Return (i,j,Rx,Ry,complex amplitude), including reverse orientations.

    The physical loop is R=(0,+ex,-ex,0) on 02,24,46,60 in the canonical
    motif. The literal loop is R=0 on all four edges in its own q gauge.
    Optional four amplitudes/phases are ordered 02,24,46,60.
    Nonzero mass and unequal AA controls are explicit extra model extensions.
    The supported intracell graph retains its staggered chiral symmetry
    for arbitrary AA strengths/phases when mass=0. Its PxK antiunitary
    symmetry additionally requires real AB and purely imaginary AA.
    """
    model_info(model)
    edges = []
    ab = LITERAL_AB if model == "literal" else HONEYCOMB_AB
    for i, j, rx, ry in ab:
        v = complex(-(t if i == 0 else t1))
        edges.extend([(i,j,rx,ry,v), (j,i,-rx,-ry,v.conjugate())])
    if model == "honeycomb_haldane":
        if aa_amplitudes is not None or aa_phases is not None or t_AA != 0:
            raise ValueError("AA-loop controls belong to the loop models, not honeycomb_haldane")
        for i, j, rx, ry, sign in HALDANE_NNN:
            edges.append((i,j,rx,ry,complex(t_NNN*np.exp(1j*sign*nnn_phi))))
    else:
        if t_NNN != 0:
            raise ValueError("t_NNN belongs to honeycomb_haldane")
        strengths = np.full(4, t_AA) if aa_amplitudes is None else np.asarray(aa_amplitudes)
        phases = np.full(4, phi) if aa_phases is None else np.asarray(aa_phases)
        if strengths.shape != (4,) or phases.shape != (4,):
            raise ValueError("aa_amplitudes and aa_phases each require four entries")
        translations = ((0,0),)*4 if model == "literal" else PHYSICAL_LOOP_R
        for (i,j), (rx,ry), amplitude, angle in zip(LOOP, translations, strengths, phases):
            v = complex(amplitude*np.exp(1j*angle))
            edges.extend([(i,j,rx,ry,v), (j,i,-rx,-ry,v.conjugate())])
    if mass:
        for i in range(7):
            edges.append((i,i,0,0,complex(mass if i in A_ORBITALS else -mass)))
    return edges


def hamiltonian(x, y, model="literal", **parameters):
    """Broadcast x and y; return shape broadcast(x,y).shape + (7,7)."""
    x, y = np.broadcast_arrays(x, y)
    H = np.zeros(x.shape+(7,7), dtype=complex)
    for i, j, rx, ry, amplitude in hoppings(model, **parameters):
        H[...,i,j] += amplitude*np.exp(1j*(rx*x+ry*y))
    return H


def embedded_literal(kx, ky, t=1., t1=1., t_AA=0., phi=np.pi/2):
    """Auxiliary embedded representation with kappa=2q; full graph has 4pi sewing.

    The kx,ky argument names denote kappax,kappay for API compatibility."""
    kx, ky = np.broadcast_arrays(kx, ky)
    H = np.zeros(kx.shape+(7,7), dtype=complex)
    for i, j, dx, dy in EMBEDDED_AB:
        v = -(t if i == 0 else t1)*np.exp(1j*(dx*kx+dy*ky)/6)
        H[...,i,j] += v
        H[...,j,i] += v.conjugate()
    for i, j in LOOP:
        v = t_AA*np.exp(1j*phi)
        H[...,i,j] += v
        H[...,j,i] += np.conjugate(v)
    return H


def honeycomb_parent8(kx, ky, t=1., t1=1., t2=1.):
    """Eight-orbital parent; uniform t=t1=t2 gives pristine honeycomb."""
    kx, ky = np.broadcast_arrays(kx, ky)
    H = np.zeros(kx.shape+(8,8), dtype=complex)
    for i, j, rx, ry in HONEYCOMB_AB + PARENT_EXTRA_AB:
        strength = t2 if i == 7 else t if i == 0 else t1
        v = -strength*np.exp(1j*(rx*kx+ry*ky))
        H[...,i,j] += v
        H[...,j,i] += v.conjugate()
    return H


def literal_parent_spectrum(qx, qy, t=1., t1=1.):
    """Closed-form seven eigenvalues of literal H0, sorted at each q."""
    qx, qy = np.broadcast_arrays(qx, qy)
    F = 9-2*(np.cos(2*qx)+np.cos(2*qy)+np.cos(2*(qx+qy)))
    total = 3*t*t+5*t1*t1
    product = 4*t1**4+t*t*t1*t1*F
    discriminant = np.maximum(0., total**2-4*product)
    lower = np.sqrt(np.maximum(0., (total-np.sqrt(discriminant))/2))
    upper = np.sqrt(np.maximum(0., (total+np.sqrt(discriminant))/2))
    zeros = np.zeros(qx.shape)
    one = np.full(qx.shape, abs(t1))
    return np.sort(np.stack([-upper,-lower,-one,zeros,one,lower,upper], axis=-1), axis=-1)


def literal_parent_zero_vector(qx, qy, t=1., t1=1., normalized=True):
    """Globally periodic zero section with nonzero first A component."""
    if t1 == 0:
        raise ValueError("This analytic section requires t1 nonzero")
    qx, qy = np.broadcast_arrays(qx, qy)
    X, Y = np.exp(1j*qx), np.exp(1j*qy)
    ratio = t/t1
    u = np.stack([np.full(qx.shape,2.), ratio*(X*Y**2-X-1/X),
        ratio*(1/(X**2*Y)-1/Y-Y), ratio*(X/Y-X*Y-1/(X*Y))], axis=-1)
    psi = np.zeros(qx.shape+(7,), dtype=complex)
    psi[...,A_ORBITALS] = u
    if normalized:
        psi /= np.linalg.norm(psi,axis=-1,keepdims=True)
    return psi


def honeycomb_parent_zero_vector(kx, ky, t=1., t1=1., normalized=True):
    """Periodic zero section of the physical vacancy H0 canonical gauge."""
    if t1 == 0:
        raise ValueError("This analytic section requires t1 nonzero")
    kx, ky = np.broadcast_arrays(kx, ky)
    X, Y = np.exp(1j*kx), np.exp(1j*ky)
    ratio = t/t1
    u = np.stack([np.full(kx.shape,2.),ratio*(X*Y-X-1),
                  ratio*(1/X-1-Y),ratio*(X-X*Y-1)],axis=-1)
    psi = np.zeros(kx.shape+(7,),dtype=complex)
    psi[...,A_ORBITALS] = u
    if normalized:
        psi /= np.linalg.norm(psi,axis=-1,keepdims=True)
    return psi


def _fhs(vecs, direct_gap, band=None, rank=None, gap_tol=1e-8, link_tol=1e-10):
    """FHS link diagnostics with invalidity at sampled gap/link failures."""
    if (band is None) == (rank is None):
        raise ValueError("Specify exactly one of band or rank")
    if band is not None:
        v = vecs[...,band]
        ux = np.sum(v.conj()*np.roll(v,-1,axis=0),axis=-1)
        uy = np.sum(v.conj()*np.roll(v,-1,axis=1),axis=-1)
    else:
        v = vecs[...,:rank]
        ux = np.linalg.det(np.einsum('...an,...am->...nm',v.conj(),np.roll(v,-1,axis=0)))
        uy = np.linalg.det(np.einsum('...an,...am->...nm',v.conj(),np.roll(v,-1,axis=1)))
    minimum = float(min(np.min(abs(ux)),np.min(abs(uy))))
    reasons = []
    if direct_gap <= gap_tol:
        reasons.append("sampled direct gap is closed or below gap_tol")
    if minimum <= link_tol or not np.isfinite(minimum):
        reasons.append("link overlap/determinant is zero or below link_tol")
    if reasons:
        return {"valid_on_sampled_grid":False,"chern_raw":None,"chern_integer":None,
                "minimum_link_overlap":minimum,"maximum_plaquette_phase":None,
                "direct_gap":float(direct_gap),"reasons":reasons}
    ux /= abs(ux)
    uy /= abs(uy)
    F = np.angle(ux*np.roll(uy,-1,axis=0)*np.roll(ux,-1,axis=1).conj()*uy.conj())
    C = float(F.sum()/(2*np.pi))
    maximum = float(np.max(abs(F)))
    return {"valid_on_sampled_grid":True,"chern_raw":C,"chern_integer":int(round(C)),
            "integer_deviation":float(abs(C-round(C))),"minimum_link_overlap":minimum,
            "maximum_plaquette_phase":maximum,"direct_gap":float(direct_gap),
            "reasons":[],"mesh_warning":maximum > .9*np.pi}


def evaluate(model="literal", N=48, band=3, gap_tol=1e-8, link_tol=1e-10,
             refine=False, nstarts=8, **parameters):
    """Band/projector Chern and spectral diagnostics on a periodic N*N mesh.

    Only isolated bands/groups have valid sampled-grid Chern values. An
    indirect gap is checked separately before reporting an insulating
    occupied group. 'valid' never establishes full-BZ gap certification.
    """
    if not isinstance(N,(int,np.integer)) or N < 4:
        raise ValueError("N must be an integer >=4")
    if not 0 <= band < 7:
        raise ValueError("band index must lie in 0..6")
    axis = np.linspace(-np.pi,np.pi,N,endpoint=False)
    x, y = np.meshgrid(axis,axis,indexing="ij")
    E, V = np.linalg.eigh(hamiltonian(x,y,model,**parameters))
    gaps = np.diff(E,axis=-1)
    direct = np.min(gaps,axis=(0,1))
    emin, emax = E.min(axis=(0,1)), E.max(axis=(0,1))
    indirect = emin[1:]-emax[:-1]
    adjacent = ([direct[band-1]] if band else [])+([direct[band]] if band<6 else [])
    result = {
        "model":model,"parameters":parameters,"N":int(N),"band":int(band),
        "energy_min":emin.tolist(),"energy_max":emax.tolist(),
        "minimum_direct_gaps":direct.tolist(),"indirect_gaps":indirect.tolist(),
        "central_band_range":[float(emin[3]),float(emax[3])],
        "central_bandwidth":float(emax[3]-emin[3]),
        "direct_lower":float(direct[2]),"direct_upper":float(direct[3]),
        "indirect_lower":float(indirect[2]),"indirect_upper":float(indirect[3]),
        "band_chern":_fhs(V,min(adjacent),band=band,gap_tol=gap_tol,link_tol=link_tol),
        "occupied":{},"gap_tol":gap_tol,"link_tol":link_tol,
        "limitations":"sampled mesh values; convergence and unsampled gap closures need separate checks",
    }
    for rank in (3,4):
        diagnostics = _fhs(V,direct[rank-1],rank=rank,gap_tol=gap_tol,link_tol=link_tol)
        spectral_gap = float(indirect[rank-1])
        diagnostics.update({"rank":rank,"indirect_gap":spectral_gap,
            "insulating_on_sampled_grid":bool(spectral_gap>gap_tol and diagnostics["valid_on_sampled_grid"]),
            "chemical_potential_interval":[float(emax[rank-1]),float(emin[rank])],
            "filling_per_cell":rank})
        result["occupied"][str(rank)] = diagnostics
    if refine:
        result["refined"] = refine_extrema(model,parameters,E,axis,nstarts)
    return result


def refine_extrema(model, parameters, mesh_energies, axis, nstarts=8):
    """Optional multistart Nelder-Mead refinement, not a global certificate."""
    if nstarts < 1:
        raise ValueError("nstarts must be positive")
    tasks = [("direct_lower","gap",2),("direct_upper","gap",3),
             ("E2max","max",2),("E3min","min",3),
             ("E3max","max",3),("E4min","min",4)]
    refined = {}
    for name, kind, band in tasks:
        values = (mesh_energies[...,band+1]-mesh_energies[...,band]
                  if kind=="gap" else mesh_energies[...,band])
        order = np.argsort((-values if kind=="max" else values).ravel())[:nstarts]
        attempts = []
        for index in order:
            ix, iy = np.unravel_index(index,values.shape)
            def objective(momentum):
                energy = np.linalg.eigvalsh(hamiltonian(*momentum,model,**parameters))
                value = energy[band+1]-energy[band] if kind=="gap" else energy[band]
                return -value if kind=="max" else value
            fit = minimize(objective,[axis[ix],axis[iy]],method="Nelder-Mead",
                options={"xatol":1e-10,"fatol":1e-12,"maxiter":1000})
            attempts.append({"value":float(-fit.fun if kind=="max" else fit.fun),
                "momentum":((fit.x+np.pi)%(2*np.pi)-np.pi).tolist(),
                "converged":bool(fit.success)})
        refined[name] = (max if kind=="max" else min)(attempts,key=lambda item:item["value"])
    refined["central_bandwidth"] = refined["E3max"]["value"]-refined["E3min"]["value"]
    refined["indirect_lower"] = refined["E3min"]["value"]-refined["E2max"]["value"]
    refined["indirect_upper"] = refined["E4min"]["value"]-refined["E3max"]["value"]
    refined["method"] = "multistart grid-seeded local Nelder-Mead; not certified global bounds"
    refined["nstarts"] = int(nstarts)
    return refined


def strip_hamiltonian(x, width=12, model="literal", periodic_y=False,
                      return_derivative=False, **parameters):
    """Exact integer-hopping strip, open or periodic in the cell-y direction.

    Row (cell,i), column (cell+Ry,j) contains h_ij(R)*exp(i*x*Rx).
    This is a clean strip. It does not compute transport or disorder averages.
    """
    if not isinstance(width,(int,np.integer)) or width < 1:
        raise ValueError("width must be a positive integer")
    H = np.zeros((7*width,7*width),dtype=complex)
    derivative = np.zeros_like(H)
    for i, j, rx, ry, amplitude in hoppings(model,**parameters):
        value = amplitude*np.exp(1j*x*rx)
        for cell in range(width):
            target = cell+ry
            if periodic_y:
                target %= width
            if 0 <= target < width:
                H[7*cell+i,7*target+j] += value
                derivative[7*cell+i,7*target+j] += 1j*rx*value
    return (H,derivative) if return_derivative else H


def edge_weights(eigenvectors, width, edge_cells=2):
    """Return left/right probability weights for a specified cell count."""
    if not 1 <= edge_cells <= width//2:
        raise ValueError("edge_cells must be >=1 and <=width//2")
    if eigenvectors.shape[0] != 7*width:
        raise ValueError("eigenvector dimension does not match width")
    return np.array([np.sum(abs(eigenvectors[:7*edge_cells])**2,axis=0),
                     np.sum(abs(eigenvectors[-7*edge_cells:])**2,axis=0)])


def periodic_strip_check(model="literal", width=5, x=.713, **parameters):
    """Compare a periodic strip spectrum to exact allowed bulk momenta."""
    strip = strip_hamiltonian(x,width,model,periodic_y=True,**parameters)
    bulk = np.sort(np.concatenate([np.linalg.eigvalsh(hamiltonian(
        x,2*np.pi*j/width,model,**parameters)) for j in range(width)]))
    return {"model":model,"width":width,"x":x,
            "hermiticity_residual":float(np.linalg.norm(strip-strip.conj().T)),
            "periodic_strip_bulk_spectrum_residual":float(np.max(abs(np.linalg.eigvalsh(strip)-bulk)))}


def concise(result):
    """Small report suitable for saved notebook outputs."""
    return {"model":result["model"],"N":result["N"],"band":result["band"],
        "C_selected_band":result["band_chern"]["chern_integer"],
        "selected_band_valid":result["band_chern"]["valid_on_sampled_grid"],
        "C_low3":result["occupied"]["3"]["chern_integer"],
        "C_low4":result["occupied"]["4"]["chern_integer"],
        "bandwidth":result["central_bandwidth"],
        "direct_lower":result["direct_lower"],"direct_upper":result["direct_upper"],
        "indirect_lower":result["indirect_lower"],"indirect_upper":result["indirect_upper"],
        "low3_insulating":result["occupied"]["3"]["insulating_on_sampled_grid"],
        "low4_insulating":result["occupied"]["4"]["insulating_on_sampled_grid"],
        "min_selected_band_link":result["band_chern"]["minimum_link_overlap"],
        "max_selected_band_plaquette":result["band_chern"]["maximum_plaquette_phase"],
        "mesh_warning":result["band_chern"].get("mesh_warning")}
