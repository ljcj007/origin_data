Seven-orbital scientific source data and model programs
The data and analytical model originate in the checked research archive.
Current plot styles were revised on2026-11-14; historical calculation hashes in
metadata/provenance.json identify the earlier inputs, not the current renderer bytes.
Current source hashes are in metadata/manifest_sha256.json and the final package manifest.
Plots use --reuse-source. Outputs are written to ../../figures/PRB relative to this folder.
Run ../render_figures.py from the parent reproduction directory for all eight figures.
No TeX source belongs in this folder; all manuscript TeX is in the final package's TeX folder.
