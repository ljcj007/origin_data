Scientific data and programs for the PRL Letter and PRB Article
Final figure edition: 2026-11-14. All saved numerical input data are retained at full precision.
The current figure rendering uses serif type, a semantic multicolor palette, grayscale context,
and redundant marker/line-style encodings. It does not change model parameters or observables.

Run the figure scripts using Python from this reproduction directory. See render_figures.py.
code/: joint contact-control and strong-loop production programs.
source_data/: joint full-precision forecasts, contacts, topology and stability records.
seven_orbital_reproduction/: seven-orbital Hamiltonian, data arrays and four figure renderers.
The TeX manuscript sources are all in the sibling TeX directory. PDF/SVG/TIFF/PNG outputs
are in the sibling figures directory. FILE_MAP.csv links the eight current figures to inputs.
The repository has not been publicly deposited and no data DOI or license has been assigned.
