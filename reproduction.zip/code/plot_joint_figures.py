"""Publication figures from deposited numerical results; Python backend only.

Figure contract: graph_colors explains the real-space coloring and the
translation of an odd quotient walk; parity_switch shows the analytically
resolved splitting of a paired contact, checked by FHS at representative
points; strong_loop compares the bandwidth and higher-order gap scales.
Vector PDF/SVG, 600 dpi PNG preview, and 600 dpi TIFF are exported. These
are deterministic model calculations, not statistical measurements.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
from matplotlib.colors import TwoSlopeNorm
from matplotlib.ticker import NullFormatter
from independent_model import hamiltonian, upper_contacts

ROOT=Path(__file__).resolve().parents[1]
PURPLE='#7A5195'; GREEN='#3B8E5A'; RED='#B54A50'; CYAN='#00A8C6'
DARK='#333333'; GRAY='#888888'; AXIS_BG='#F5F5F5'; GRID='#DADADA'
# Retained names support the unused legacy parity-switch renderer.
BLUE=CYAN; ORANGE=PURPLE
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
    'mathtext.fontset':'stix','text.color':DARK,'axes.labelcolor':DARK,
    'font.size':8,'axes.labelsize':8,'axes.titlesize':8,'legend.fontsize':7,
    'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':True,
    'axes.spines.right':True,'axes.linewidth':.55,'axes.edgecolor':DARK,
    'axes.facecolor':AXIS_BG,'axes.axisbelow':True,'axes.grid':True,
    'grid.color':GRID,'grid.linewidth':.4,'grid.alpha':.8,
    'xtick.color':DARK,'ytick.color':DARK,'xtick.direction':'in',
    'ytick.direction':'in','xtick.top':True,'ytick.right':True,
    'xtick.major.width':.55,'ytick.major.width':.55,
    'xtick.minor.width':.4,'ytick.minor.width':.4,
    'lines.linewidth':1.1,'legend.frameon':False,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})

def save(fig,project,name):
    folder=ROOT.parent/'figures'/project.upper();folder.mkdir(parents=True,exist_ok=True)
    for ext in ['pdf','svg','png','tiff']:
        fig.savefig(folder/f'{name}.{ext}',dpi=600,
                    bbox_inches='tight',pad_inches=.035)
    plt.close(fig)

def label(ax,s):
    ax.text(-.17,1.06,s,transform=ax.transAxes,weight='bold',fontsize=9,va='top')

def graph_colors():
    fig=plt.figure(figsize=(3.4,3.0),layout='constrained')
    grid=fig.add_gridspec(2,2,height_ratios=[1.7,1])
    ax=fig.add_subplot(grid[0,:]); ax.set_aspect('equal');ax.axis('off')
    ax.add_patch(Rectangle((-.45,.65),2.9,.7,facecolor=AXIS_BG,edgecolor=CYAN,ls='--',lw=.8))
    for x in range(6):
        for y in range(3):
            if x<5:
                ax.plot([x,x+1],[y,y],color=PURPLE if x%3==0 else GRAY,lw=1.6 if x%3==0 else 1)
            if y<2:ax.annotate('',(x,y+.86),(x,y+.14),arrowprops={'arrowstyle':'->','color':GRAY,'lw':.8})
            ax.scatter(x,y,s=29,facecolor=GREEN if (x+y)%2==0 else 'white',edgecolor=GREEN,lw=1,zorder=3)
    for j in range(3):ax.text(j,-.57,str(j),ha='center',fontsize=7)
    for x,s in zip([.5,1.5,2.5],[r'$a$',r'$b$',r'$c$']):ax.text(x,1.16,s,ha='center')
    ax.add_patch(Circle((0,1),.2,facecolor='none',edgecolor=RED,lw=1.5,zorder=4))
    ax.annotate(r'$\mu$ on orbital 0',xy=(.1,1.15),xytext=(3.0,2.85),
                arrowprops={'arrowstyle':'-','color':RED,'lw':.8},color=RED,fontsize=7)
    ax.text(1.0,2.65,'Dashed box: one three-orbital cell',ha='center',fontsize=7,color=CYAN)
    ax.text(4, -.56,r'$-v_j e^{2\pi i j/3}$ along $y$',ha='center',fontsize=7)
    ax.set_xlim(-.6,5.25);ax.set_ylim(-.7,3.1);ax.text(-.5,3.05,'a',weight='bold',fontsize=9)
    left=fig.add_subplot(grid[1,0]);right=fig.add_subplot(grid[1,1])
    for ax in [left,right]:ax.axis('off');ax.set_xlim(-.15,3.2);ax.set_ylim(-.55,1.8)
    for i in range(3):left.annotate('',(i+.85,.8),(i+.15,.8),arrowprops={'arrowstyle':'->','lw':1,'color':GRAY})
    for i,name in enumerate(['0','1','2',r'$0+\mathbf{T}$']):
        left.scatter(i,.8,s=24,facecolor=GREEN if i%2==0 else 'white',edgecolor=GREEN,zorder=3)
        left.text(i,.32,name,ha='center',fontsize=7)
    left.text(1.5,1.6,'Translated odd walk',ha='center',fontsize=7)
    left.text(1.5,-.28,r'$\mathbf{p}\cdot\mathbf{T}=1$',ha='center',fontsize=8)
    coords=np.array([[.55,.25],[1.5,1.2],[2.45,.25]])
    for i in range(3):
        j=(i+1)%3;right.plot(coords[[i,j],0],coords[[i,j],1],color=PURPLE if i==2 else GRAY)
    for i,(x,y) in enumerate(coords):right.scatter(x,y,s=24,facecolor=GREEN if i%2==0 else 'white',edgecolor=GREEN,zorder=3)
    right.text(1.5,1.6,'Local odd loop',ha='center',fontsize=7)
    right.text(1.5,-.28,r'$\mathbf{T}=0$: no coloring',ha='center',fontsize=7)
    left.text(-.12,1.78,'b',weight='bold',fontsize=9)
    save(fig,'prl','graph_colors')

def parity_switch():
    d=np.load(ROOT/'source_data/independent_model_source.npz')
    report=json.loads((ROOT/'source_data/independent_model_results.json').read_text())
    fig=plt.figure(figsize=(7.05,2.55),layout='constrained')
    grid=fig.add_gridspec(1,3,width_ratios=[1.25,1,1])
    ax=fig.add_subplot(grid[0,0]); mu=d['mu'];lo,hi=d['a_critical'].T
    ax.fill_betweenx(mu,2.6,lo,color='#DFEAF2');ax.fill_betweenx(mu,lo,hi,color='#F2D9C5');ax.fill_betweenx(mu,hi,3.7,color='#E8EBED')
    ax.plot(lo,mu,color=BLUE);ax.plot(hi,mu,color=ORANGE)
    ax.axhline(.2,color=GRAY,ls=':',lw=.8)
    for a,c in [(2.9,2),(3.15,1),(3.4,0)]:ax.scatter(a,.2,s=24,facecolor='white',edgecolor='black',zorder=5)
    for a,m,s in [(2.73,.42,r'$C_c=2$'),(3.14,.49,r'$C_c=1$'),(3.58,.42,r'$C_c=0$')]:ax.text(a,m,s,ha='center',fontsize=8)
    ax.set(xlim=(2.6,3.7),ylim=(0,.6),xlabel=r'Bond amplitude $a$',ylabel=r'Onsite offset $\mu$');label(ax,'a')
    ax=fig.add_subplot(grid[0,1]);a0=report['symmetric_upper_critical_a'];
    bounds=[2.8,*d['a_critical'][40],3.5]
    ax.stairs([2,1,0],bounds,color=ORANGE,label=r'$\mu=0.2$',lw=1.5)
    ax.stairs([2,0],[2.8,a0,3.5],color=BLUE,ls='--',label=r'$\mu=0$',lw=1.5)
    ax.set(xlim=(2.8,3.5),ylim=(-.1,2.22),yticks=[0,1,2],xlabel=r'Bond amplitude $a$',ylabel=r'Central-band Chern number $C_c$')
    ax.legend(loc='upper right',bbox_to_anchor=(1,1.06));label(ax,'b')
    ax=fig.add_subplot(grid[0,2]);scan=np.linspace(2.8,3.5,401)
    contacts=upper_contacts(.2)
    ax.axvspan(contacts[0]['a'],contacts[1]['a'],color='#F2D9C5',alpha=.6)
    curves=[]
    for r,col in zip(contacts,[ORANGE,BLUE]):
        levels=np.array([np.linalg.eigvalsh(hamiltonian(r['kx'],r['ky'],a,.2)) for a in scan])
        gap=np.diff(levels,axis=1)[:,r['gap_index']];curves.append(gap)
        title=r'$E_2-E_1$ at $\mathbf{k}_{+}^{*}$' if r['gap_index']==1 else r'$E_1-E_0$ at $\mathbf{k}_{-}^{*}$'
        ax.plot(scan,gap,color=col,label=title)
        ax.scatter(r['a'],0,s=18,color=col,zorder=4)
    np.savetxt(ROOT/'source_data/three_band_contact_gap_curves.csv',np.c_[scan,*curves],delimiter=',',header='a,upper_gap_at_fixed_upper_contact_k,lower_gap_at_fixed_lower_contact_k',comments='')
    ax.set(xlim=(2.8,3.5),ylim=(-.015,.42),xlabel=r'Bond amplitude $a$',ylabel='Gap at contact momentum')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,1.13),fontsize=6.5,frameon=False)
    ax.text(3.15,.35,r'$\mu=0.2$',ha='center',fontsize=7)
    label(ax,'c')
    save(fig,'prl','parity_switch')

def strong_loop():
    d=json.loads((ROOT/'source_data/strong_loop_results.json').read_text())
    spectra=sorted([x for x in d['spectral_meshes'] if x['N']==192],key=lambda x:x['a'])
    aa=np.array([x['a'] for x in spectra]);ww=np.array([x['full_central_bandwidth'] for x in spectra])
    nodes=[next(x for x in d['local_nodes'] if x['a']==a and x['band_pair']==[0,1]) for a in aa]
    gaps=np.array([x['direct_gap'] for x in nodes]);omega=np.array([x['central_curvature_over_a_fourth'] for x in nodes])
    gcoef=d['nodes'][0]['predicted_gap_times_a_cubed'];ocoef=d['nodes'][0]['central_curvature_over_a_fourth_prediction']
    np.savetxt(ROOT/'source_data/strong_loop_plot.csv',np.c_[aa,ww,gaps,gaps*aa**3,omega],delimiter=',',header='a,bandwidth_N192,locally_refined_direct_gap,gap_times_a3,peak_curvature_over_a4',comments='')
    fig,axs=plt.subplots(1,3,figsize=(7.05,2.1),layout='constrained')
    ax=axs[0];q=np.geomspace(4.5,45,100)
    ax.loglog(aa,ww,'o-',color=GREEN,label=r'$w_3$',markersize=3.6);ax.loglog(aa,gaps,'s--',color=PURPLE,label=r'$\delta$',markersize=3.4)
    ax.loglog(q,ww[-1]*aa[-1]/q,ls=':',color=GREEN);ax.loglog(q,gcoef/q**3,ls=':',color=PURPLE)
    ax.text(17,.31,r'$a^{-1}$',color=GREEN);ax.text(14,1.6e-4,r'$a^{-3}$',color=PURPLE)
    ax.set(xlabel=r'$a=t_A/t_1$',ylabel=r'Energy / $t_1$',xticks=aa);ax.set_xticklabels(['5','10','20','40']);ax.xaxis.set_minor_formatter(NullFormatter());ax.legend(frameon=False);label(ax,'a')
    ax=axs[1];ax.plot(aa,aa**3*gaps,'s--',color=PURPLE,markersize=3.4);ax.axhline(gcoef,color=GRAY,ls=':');ax.text(8,.335,r'$2|m_3|=0.333$',fontsize=7)
    ax.set(xlabel=r'$a=t_A/t_1$',ylabel=r'$\delta a^3$',xticks=aa,ylim=(.311,.337));label(ax,'b')
    ax=axs[2];ax.plot(aa,omega,'^-',color=RED,markersize=3.7);ax.axhline(ocoef,color=GRAY,ls=':');ax.text(16,12.89,r'$\mathcal{J}/(2m_3^2)=12.9$',fontsize=7)
    ax.set(xlabel=r'$a=t_A/t_1$',ylabel=r'$\Omega_3(\mathbf{q}_{\rm gap})/a^4$',xticks=aa,ylim=(12.83,13.03));label(ax,'c')
    save(fig,'prb','strong_loop')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--only',choices=['strong','prl','current','all'],default='current');args=p.parse_args()
    if args.only in ['strong','current','all']:strong_loop()
    if args.only == 'current':graph_colors()
    if args.only in ['prl','all']:graph_colors();parity_switch()
    print('Exported figures:',args.only)
