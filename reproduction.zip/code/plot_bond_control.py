"""Matched bond-translation control from deposited analytic/numerical data.

Conclusion: at equal added amplitude, a compatible translation moves the
paired contacts together, while an incompatible translation splits them.
The graph drawing is schematic: its curved 0--2 edge is a length-two
direct hopping between collinear sites, not a finite-area plaquette.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch
from plot_joint_figures import save, label, PURPLE, CYAN, DARK, GRAY, GREEN, AXIS_BG

ROOT = Path(__file__).resolve().parents[1]


def main():
    data = np.load(ROOT / 'source_data/bond_control_source.npz')
    report = json.loads((ROOT / 'source_data/bond_control_results.json').read_text())
    g = data['g']
    lower, upper = data['incompatible_a_critical'].T
    compatible = data['compatible_a_critical'][:, 0]
    np.savetxt(ROOT / 'source_data/bond_control_phase_curves.csv',
               np.c_[g, lower, upper, compatible], delimiter=',', comments='',
               header='g,incompatible_lower_a,incompatible_upper_a,compatible_paired_a')
    fig = plt.figure(figsize=(7.05, 2.55), layout='constrained')
    grid = fig.add_gridspec(1, 3, width_ratios=[1.15, 1, 1.12])
    ax = fig.add_subplot(grid[0, 0])
    ax.axis('off')
    ax.set(xlim=(-1.4, 2.5), ylim=(-.7, 2.8))
    label(ax, 'a')
    for y, title, color, mode in [(1.8, 'Compatible', GREEN, 'compatible'),
                                   (.0, 'Incompatible', PURPLE, 'incompatible')]:
        ax.text(.5, y + .65, title, color=color, ha='center', fontsize=8)
        ax.add_patch(Rectangle((-.28, y-.20), 2.56, .40,
                              facecolor=AXIS_BG, edgecolor=GRAY, ls='--', lw=.6))
        for x in [-1, 0, 1]:
            ax.plot([x, x+1], [y, y], color=GRAY, lw=1)
        for x, name in [(-1, r'$2_{-x}$'), (0, '0'), (1, '1'), (2, '2')]:
            ax.scatter(x, y, s=24, facecolor=CYAN if x % 2 == 0 else 'white',
                       edgecolor=CYAN, lw=.9, zorder=5)
            ax.text(x, y-.40, name, ha='center', fontsize=7)
        if mode == 'compatible':
            ax.plot([-1, 0], [y, y], color=color, lw=2.2, zorder=3)
            ax.text(-.50, y+.21, r'$-g$', color=color, ha='center', fontsize=8)
        else:
            ax.add_patch(FancyArrowPatch((0, y+.03), (2, y+.03),
                         connectionstyle='arc3,rad=-.26', arrowstyle='-',
                         color=color, lw=1.6, zorder=4))
            ax.text(1, y+.38, r'$-g$', color=color, ha='center', fontsize=8)
    ax.text(.5, 1.02, r'$\delta H_{02}=-g e^{-ik_x}$', color=GREEN,
            ha='center', fontsize=8)
    ax.text(.5, -.68, r'$\delta H_{02}=-g$', color=PURPLE,
            ha='center', fontsize=8)

    ax = fig.add_subplot(grid[0, 1])
    ax.fill_betweenx(g, 2.9, lower, color='#EDF1ED', zorder=.1)
    ax.fill_betweenx(g, lower, upper, color='#E9DFEE', zorder=.1)
    ax.fill_betweenx(g, upper, 3.3, color='#ECECEC', zorder=.1)
    ax.plot(lower, g, color=PURPLE, ls='-')
    ax.plot(upper, g, color=PURPLE, ls='--')
    ax.axhline(.1, color=GRAY, ls=':', lw=.75)
    ax.scatter([2.95, 3.12, 3.25], [.1]*3, facecolor='white', edgecolor='black',
               s=17, zorder=5)
    for x, y, value in [(2.95, .065, 2), (3.10, .13, 1), (3.257, .065, 0)]:
        ax.text(x, y, rf'$C_c={value}$', ha='center', fontsize=7)
    ax.set(xlim=(2.9, 3.3), ylim=(0, .15), xlabel=r'Bond amplitude $a$',
           ylabel=r'Added hopping $g$', yticks=[0, .05, .1, .15])
    ax.tick_params(axis='x', labelsize=7)
    label(ax, 'b')

    ax = fig.add_subplot(grid[0, 2])
    # Exact saved contacts are reused; plotting never reruns the model.
    saved = report['analytic_contacts']
    a0 = next(r['a'] for r in saved['incompatible']['0.0'] if r['a'] > 1)
    alo, ahi = [r['a'] for r in saved['incompatible']['0.1'] if r['a'] > 1]
    ac = next(r['a'] for r in saved['compatible']['0.1'] if r['a'] > 1)
    ax.axvspan(alo, ahi, color=PURPLE, alpha=.07, zorder=.1)
    ax.stairs([2, 0], [2.9, a0, 3.3], color=DARK, ls='--', lw=1.1,
              label='Original')
    ax.stairs([2, 0], [2.9, ac, 3.3], color=GREEN, ls='-.', lw=1.2,
              label='Compatible')
    ax.stairs([2, 1, 0], [2.9, alo, ahi, 3.3], color=PURPLE, lw=1.4,
              label='Incompatible')
    ax.axvline(3.12, color=GRAY, ls=':', lw=.65)
    for value, color, marker in [(2, DARK, 'o'), (0, GREEN, 's'), (1, PURPLE, '^')]:
        ax.scatter(3.12, value, s=23, color=color, marker=marker, edgecolor='white', lw=.5,
                   zorder=6)
    ax.set(xlim=(2.9, 3.3), ylim=(-.12, 2.64), yticks=[0, 1, 2],
           xlabel=r'Bond amplitude $a$', ylabel=r'Central Chern number $C_c$')
    ax.legend(loc='upper right', fontsize=6.5, frameon=False,
              handlelength=1.8, labelspacing=.22, borderpad=.1)
    ax.text(2.92, .18, r'$g=0.100$', fontsize=7)
    label(ax, 'c')
    save(fig, 'prl', 'bond_control')
    print('Exported bond_control: PDF, SVG, PNG, TIFF and source CSV')


if __name__ == '__main__':
    main()
