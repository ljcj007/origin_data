"""Export the parent-derived direct NNN table and verify its conventions.

Reconstruct the graph from explicit rational parent coordinates and NN bonds,
then compare the resulting table and Hamiltonian with c3n4_verified.py.
No Brillouin-zone grid, geometry map, or edge spectrum is recalculated.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / 'seven_orbital_reproduction/code/c3n4_verified.py'
sys.path.insert(0, str(MODEL.parent))
import c3n4_verified as cv

# Exact coordinates in a1=(1,0), a2=(-1/2,sqrt(3)/2); rows in units of 1/6.
POSITIONS_SIXTHS = ((0,0),(2,1),(3,0),(5,1),(0,3),(5,4),(3,3),(2,4))
POSITIONS = tuple(tuple(F(c,6) for c in pair) for pair in POSITIONS_SIXTHS)
PARENT_NN = ((0,1,0,0),(0,3,-1,0),(0,5,-1,-1),(1,2,0,0),
             (1,6,0,0),(2,3,0,0),(3,4,1,0),(4,5,-1,0),(5,6,0,0),
             (7,4,0,0),(7,6,0,0),(7,2,0,1))
GAMMA = np.diag([1,-1,1,-1,1,-1,1])


def reverse(key):
    i,j,rx,ry=key
    return j,i,-rx,-ry


def enumerate_parent():
    assert tuple(cv.HONEYCOMB_AB+cv.PARENT_EXTRA_AB)==PARENT_NN
    assert np.max(abs(np.array(POSITIONS,dtype=float)-cv.HONEYCOMB_ORBITALS))<1e-15
    neighbors={i:[] for i in range(8)}
    for i,j,rx,ry in PARENT_NN:
        neighbors[i].append((j,rx,ry));neighbors[j].append((i,-rx,-ry))
    assert all(len(n)==3 for n in neighbors.values())
    cart=np.array([[1.,0.],[-.5,np.sqrt(3)/2]])
    records={}
    maximum_cross_error=0.
    for i in range(8):
        for middle,r1x,r1y in neighbors[i]:
            first=tuple(POSITIONS[middle][q]+(r1x,r1y)[q]-POSITIONS[i][q] for q in range(2))
            for j,r2x,r2y in neighbors[middle]:
                key=(i,j,r1x+r2x,r1y+r2y)
                if j==i and key[2:]==(0,0):continue
                second=tuple(POSITIONS[j][q]+(r2x,r2y)[q]-POSITIONS[middle][q] for q in range(2))
                determinant=first[0]*second[1]-first[1]*second[0]
                if determinant==0:continue
                # det(cart)=sqrt(3)/2. Hence cross/sqrt(3)=det(first,second)/2.
                exact_cross_over_sqrt3=determinant/2
                nu=1 if determinant>0 else -1
                fc=np.array(first,dtype=float)@cart;sc=np.array(second,dtype=float)@cart
                cross=float(fc[0]*sc[1]-fc[1]*sc[0])
                maximum_cross_error=max(maximum_cross_error,abs(cross-float(exact_cross_over_sqrt3)*np.sqrt(3)))
                assert int(np.sign(cross))==nu
                assert abs(np.linalg.norm(fc)-1/np.sqrt(12))<1e-14
                assert abs(np.linalg.norm(sc)-1/np.sqrt(12))<1e-14
                assert abs(exact_cross_over_sqrt3)==F(1,24)
                path={'middle_orbital':middle,'first_cell_translation':[r1x,r1y],
                      'second_cell_translation':[r2x,r2y],
                      'first_displacement_triangular':[str(v) for v in first],
                      'second_displacement_triangular':[str(v) for v in second],
                      'cartesian_cross_over_sqrt3':str(exact_cross_over_sqrt3),
                      'cartesian_cross_numeric':cross,
                      'intermediate_is_removed_orbital':middle==7}
                if key in records:
                    assert records[key]['nu']==nu
                    records[key]['parent_paths'].append(path)
                else:
                    records[key]={'i':i,'j':j,'Rx':key[2],'Ry':key[3],'nu':nu,
                        'retained_after_endpoint_7_deletion':i!=7 and j!=7,
                        'parent_paths':[path]}
    for key,row in records.items():
        assert records[reverse(key)]['nu']==-row['nu']
        assert len(row['parent_paths'])==1
    independent=[row for key,row in sorted(records.items()) if key<reverse(key)]
    retained=[row for row in independent if row['retained_after_endpoint_7_deletion']]
    observed=tuple((*key,row['nu']) for key,row in sorted(records.items())
                   if row['retained_after_endpoint_7_deletion'])
    assert observed==cv.HALDANE_NNN
    assert len(records)==48 and len(independent)==24 and len(retained)==18
    return independent,retained,maximum_cross_error


def from_table(kx,ky,rows,t=1.,t1=1.,t_NNN=.35,nnn_phi=5*np.pi/6,mass=.5):
    kx,ky=np.broadcast_arrays(kx,ky)
    h=np.zeros(kx.shape+(7,7),dtype=complex)
    for i,j,rx,ry in PARENT_NN[:9]:
        value=-(t if i==0 else t1)*np.exp(1j*(rx*kx+ry*ky))
        h[...,i,j]+=value;h[...,j,i]+=value.conjugate()
    for row in rows:
        i,j=row['i'],row['j']
        value=t_NNN*np.exp(1j*(row['nu']*nnn_phi+row['Rx']*kx+row['Ry']*ky))
        h[...,i,j]+=value;h[...,j,i]+=value.conjugate()
    h+=mass*GAMMA
    return h


def numerical_checks(rows):
    rng=np.random.default_rng(20261112)
    k=rng.uniform(-np.pi,np.pi,size=(41,2))
    cases={'figure4':dict(t=1.,t1=1.,t_NNN=.35,nnn_phi=5*np.pi/6,mass=.5),
           'figure5':dict(t=1.,t1=1.,t_NNN=.5,nnn_phi=np.pi/2,mass=0.),
           'generic_nonuniform_NN':dict(t=.73,t1=1.19,t_NNN=.41,nnn_phi=.37,mass=-.27)}
    comparisons={}
    for name,pars in cases.items():
        actual=cv.hamiltonian(k[:,0],k[:,1],'honeycomb_haldane',**pars)
        table=from_table(k[:,0],k[:,1],rows,**pars)
        difference=float(np.max(abs(actual-table)))
        assert difference<2e-14
        comparisons[name]={'parameters':pars,'maximum_Hamiltonian_difference':difference,
                          'maximum_hermiticity_residual':float(np.max(abs(table-table.conj().swapaxes(-1,-2))))}
    # Verify the coefficient-level identity Gamma H(k)* Gamma + H(-k)
    # =2[t_NNN cos(theta) T(-k)+m Gamma], where T has unit real NNN amplitudes.
    sym=[]
    for theta,mass in ((np.pi/2,0.),(5*np.pi/6,0.),(5*np.pi/6,.5),(np.pi/2,.5)):
        pars=dict(t=1.,t1=1.,t_NNN=.35,nnn_phi=theta,mass=mass)
        h=from_table(k[:,0],k[:,1],rows,**pars)
        hm=from_table(-k[:,0],-k[:,1],rows,**pars)
        lhs=GAMMA@h.conj()@GAMMA+hm
        T=from_table(-k[:,0],-k[:,1],rows,t=0.,t1=0.,t_NNN=1.,nnn_phi=0.,mass=0.)
        rhs=2*(.35*np.cos(theta)*T+mass*GAMMA)
        residual=float(np.max(abs(lhs-rhs)))
        assert residual<2e-14
        sym.append({'theta_over_pi':float(theta/np.pi),'mass':mass,
                    'Gamma_K_particle_hole_residual':float(np.max(abs(lhs))),
                    'analytic_residual_formula_error':residual})
    return {'momentum_samples':len(k),'random_seed':20261112,
            'sampling_domain':'[-pi,pi)^2; random points, not a BZ convergence grid',
            'table_vs_production':comparisons,'particle_hole_identity':sym,
            'new_Chern_or_large_grid_calculations':False}


def write_csv(path,rows):
    fields=['i','j','Rx','Ry','nu','middle_orbital','R1x','R1y','R2x','R2y',
            'retained_after_endpoint_7_deletion','intermediate_is_removed_orbital',
            'cartesian_cross_over_sqrt3','first_delta_x_triangular','first_delta_y_triangular',
            'second_delta_x_triangular','second_delta_y_triangular']
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for row in rows:
            p=row['parent_paths'][0]
            writer.writerow({**{k:row[k] for k in ('i','j','Rx','Ry','nu')},
                'middle_orbital':p['middle_orbital'],'R1x':p['first_cell_translation'][0],
                'R1y':p['first_cell_translation'][1],'R2x':p['second_cell_translation'][0],
                'R2y':p['second_cell_translation'][1],
                'retained_after_endpoint_7_deletion':row['retained_after_endpoint_7_deletion'],
                'intermediate_is_removed_orbital':p['intermediate_is_removed_orbital'],
                'cartesian_cross_over_sqrt3':p['cartesian_cross_over_sqrt3'],
                'first_delta_x_triangular':p['first_displacement_triangular'][0],
                'first_delta_y_triangular':p['first_displacement_triangular'][1],
                'second_delta_x_triangular':p['second_displacement_triangular'][0],
                'second_delta_y_triangular':p['second_displacement_triangular'][1]})


def tex_table(rows):
    text=[r'% REVTeX table fragment; ruledtabular is provided by REVTeX.',
          r'\begin{table*}[t]',r'\caption{Independent directed NNN terms of the honeycomb-vacancy model.',
          r'Each row contributes $t_2e^{i\nu\theta}e^{i\mathbf k\cdot\mathbf R}$ to $H_{ij}$,',
          r'and the Hermitian reverse $(j,i,-\mathbf R,-\nu)$ is included once.',
          r'The parent path is $(i,\mathbf0)\to(\ell,\mathbf R_1)\to(j,\mathbf R_1+\mathbf R_2)$,',
          r'with $\mathbf R=\mathbf R_1+\mathbf R_2$. The Cartesian cross product of its two',
          r'nearest-neighbor displacements is $\nu\sqrt{3}/24$ for $|\mathbf a_1|=|\mathbf a_2|=1$.',
          r'The dagger marks an enumerating path through the removed parent orbital;',
          r'the resulting direct NNN hopping is retained because neither endpoint is removed.}',
          r'\label{tab:nnn_complete}',r'\begin{ruledtabular}',
          r'\begin{tabular}{ccccccc}',
          r'$i$ & $j$ & $(R_x,R_y)$ & $\nu$ & $\ell$ & $(R_{1x},R_{1y})$ & $(R_{2x},R_{2y})$ \\']
    for row in rows:
        p=row['parent_paths'][0];middle=str(p['middle_orbital'])+(r'^{\dagger}' if p['middle_orbital']==7 else '')
        pair=lambda v:f'({v[0]},{v[1]})'
        text.append(f"${row['i']}$ & ${row['j']}$ & ${pair((row['Rx'],row['Ry']))}$ & ${row['nu']:+d}$ & ${middle}$ & ${pair(p['first_cell_translation'])}$ & ${pair(p['second_cell_translation'])}$ "+r'\\')
    text.extend([r'\end{tabular}',r'\end{ruledtabular}',r'\end{table*}',''])
    return '\n'.join(text)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=ROOT/'source_data')
    parser.add_argument('--notes-dir',type=Path,default=ROOT/'research')
    parser.add_argument('--overwrite',action='store_true',help='explicitly replace these derived export files')
    args=parser.parse_args()
    args.output_dir.mkdir(parents=True,exist_ok=True);args.notes_dir.mkdir(parents=True,exist_ok=True)
    targets=[args.output_dir/n for n in ('honeycomb_nnn_bonds.csv','honeycomb_nnn_bonds.json','honeycomb_parent_nnn_bonds.csv')]
    targets+=[args.notes_dir/'revision5_nnn_table.tex',args.notes_dir/'revision5_nnn_definition.txt']
    if not args.overwrite and any(p.exists() for p in targets):
        parser.error('Derived output exists; choose new directories or explicitly pass --overwrite.')
    parent,retained,cross_error=enumerate_parent()
    report={'model':'honeycomb_haldane','periodic_gauge':'H_ij(k)=sum_R h_ij(R) exp(+i k.R)',
        'representative_convention':'Choose lexicographically smaller (i,j,Rx,Ry) of each pair with (j,i,-Rx,-Ry); reverse nu changes sign. No additional reverse should be added to an already expanded directed list.',
        'path_convention':'(i,0) -> (ell,R1) -> (j,R1+R2). Delta1=r_ell+R1-r_i; delta2=r_j+R2-r_ell. The path labels the H_ij coefficient convention explicitly.',
        'cartesian_basis':[[1.,0.],[-.5,float(np.sqrt(3)/2)]],
        'parent_fractional_coordinates_sixths':POSITIONS_SIXTHS,
        'parent_NN_independent_bonds':PARENT_NN,
        'nu_definition':'sign(delta1_x delta2_y - delta1_y delta2_x); exact cross=nu*sqrt(3)/24 in the stated Cartesian basis.',
        'vacancy_rule':'Delete NNN edges only if endpoint i or j is orbital 7. Retain direct edges enumerated through intermediate orbital 7; this is not a virtual-hop approximation.',
        'counts':{'parent_independent':len(parent),'parent_directed':2*len(parent),
                  'retained_independent':len(retained),'retained_directed':2*len(retained),
                  'discarded_endpoint_independent':len(parent)-len(retained),
                  'retained_via_removed_middle_independent':sum(p['parent_paths'][0]['middle_orbital']==7 for p in retained)},
        'retained_bonds':retained,'parent_independent_bonds':parent,
        'checks':{'exact_table_equals_production_HALDANE_NNN':True,
                  'maximum_exact_vs_cartesian_cross_error':cross_error,**numerical_checks(retained)},
        'particle_hole_algebra':{
            'Gamma':'diag(+1,-1,+1,-1,+1,-1,+1)',
            'T_definition':'Dimensionless NNN adjacency with unit real amplitudes for all retained terms and their Hermitian reverses.',
            'identity':'Gamma H(k)* Gamma + H(-k) = 2[t_NNN cos(theta) T(-k) + m Gamma]',
            'consequence':'For nonzero t_NNN, this Gamma K particle-hole relation holds at m=0 and cos(theta)=0. If the central band is isolated it is mapped to itself under orientation-preserving k -> -k and C3=-C3=0.',
            'scope':'At theta=5*pi/6, the real NNN part already breaks this particle-hole relation even at m=0. The algebra alone does not assign a Chern number there; the separately recorded single-point control supplies numerical evidence.',
            'separate_m_zero_control':'source_data/honeycomb_fig4_m0_check.json: at t=t1=1, t_NNN=0.35, theta=5*pi/6, m=0, both N=48 and N=96 give C3=-1 with positive adjacent indirect-gap estimates. Only N=96 receives eight-start local refinement.',
            'causality':'The m=0 control shows that a staggered onsite term is not necessary for C3=-1 at this NNN parameter choice. The existing Figure 4 m=0.5 example has narrower bandwidth and larger relative isolation. These endpoint results do not establish a gap-preserving interpolation in m.'},
        'source_sha256':{'code/export_honeycomb_nnn.py':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                         'seven_orbital_reproduction/code/c3n4_verified.py':hashlib.sha256(MODEL.read_bytes()).hexdigest()}}
    write_csv(targets[0],retained)
    targets[1].write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    write_csv(targets[2],parent)
    targets[3].write_text(tex_table(retained),encoding='utf-8')
    note='''Complete NNN definition and the role of the onsite term

The 12 independent nearest-neighbor bonds of the eight-orbital parent are
enumerated from the explicit rational coordinates in units of one sixth.
Every site has three neighbors. Non-returning two-step paths produce 48
directed NNN terms, or 24 Hermitian-independent representatives. Deleting
only endpoint 7 leaves 36 directed terms (18 independent representatives).
Three retained independent AA terms have intermediate parent orbital 7;
these are direct NNN hoppings, not propagation through an existing site 7.

honeycomb_nnn_bonds.csv contains the 18 model terms. The companion
honeycomb_parent_nnn_bonds.csv contains all 24 parent representatives and
an explicit retained-after-deletion field. The JSON preserves both lists,
exact rational path displacements, chirality, source hashes, and checks.

For each pair choose the lexicographically smaller (i,j,Rx,Ry), relative to
(j,i,-Rx,-Ry). The table row contributes t2 exp(i nu theta) exp(i k.R) to
H_ij and its conjugate to H_ji. The path used to define this coefficient is
(i,0) -> (ell,R1) -> (j,R1+R2). The second displacement is local to the
intermediate cell: delta2=r_j+R2-r_ell. With a1=(1,0) and
a2=(-1/2,sqrt(3)/2), Cartesian cross(delta1,delta2)=nu sqrt(3)/24.
This sign was derived by exact rational determinants and independently
checked after Cartesian conversion. Reversing the representative changes
both R and nu signs. The expanded list exactly equals the production table.

The Hamiltonian reconstructed directly from the table was compared with
the full production Hamiltonian at 41 deterministic random momenta for
the Figure 4 and Figure 5 parameters and a nonuniform-NN test. These are
implementation comparisons, not new Brillouin-zone convergence calculations.
Detailed residuals are in honeycomb_nnn_bonds.json.

Let Gamma=diag(+1,-1,+1,-1,+1,-1,+1), and T(k) be the real unit-amplitude
NNN adjacency. Real AB hoppings change sign under conjugation by Gamma;
same-sublattice NNN and the staggered onsite term commute with Gamma.
Consequently, coefficient by coefficient,
  Gamma H(k)* Gamma + H(-k) = 2[t2 cos(theta) T(-k) + m Gamma].
For nonzero t2, the Gamma K particle-hole relation therefore holds when
cos(theta)=0 and m=0. Its antiunitarity reverses Berry curvature, while
k -> -k preserves the orientation of the two-dimensional Brillouin torus.
An isolated middle band maps to itself and must have C3=0. The occupied
lower group instead maps to the upper group; its Chern number may be nonzero.
This explains the allowed Figure 5 lower-group topology at theta=pi/2,m=0.

At theta=5*pi/6, a real NNN component already violates this relation at
m=0. A separately requested single-point numerical control now checks
t2=0.35, theta=5*pi/6, m=0 at t=t1=1. Both N=48 and N=96 give C3=-1,
C_low3=0, and C_low4=-1. Only N=96 receives eight-start local refinement:
the indirect gaps are 0.393578946 and 0.563752959, with bandwidth
0.742022607. Thus the onsite term is not needed to obtain this odd central
Chern number. The existing m=0.5 Figure 4 result has a narrower bandwidth,
0.272664094, and larger relative isolation, 2.41 rather than 0.530.
The two endpoints do not establish a gap-preserving interpolation in m.
No parameter sweep or figure replacement was performed. Details and the
two-point table are in revision5_m0_control.txt and revision5_m0_table.tex;
the new numerical record is source_data/honeycomb_fig4_m0_check.json.

Suggested manuscript wording:
"The physical NNN network removes the intracell even-Chern constraint.
Its purely imaginary, unstaggered limit retains particle-hole conjugation,
which forces an isolated central band to have C3=0. A real NNN component
breaks this relation: at t2=0.35 and theta=5pi/6, the m=0 network already
has C3=-1 and positive indirect gaps. The m=0.5 case shown in Fig. 4
illustrates a narrower band with larger relative spectral isolation."

Reproduce without overwriting saved files:
  python code/export_honeycomb_nnn.py --output-dir source_data/nnn_rerun --notes-dir nnn_notes_rerun
Only this export program, NumPy, SciPy, and the included canonical
c3n4_verified.py module are needed. No manuscript or plotting program is
required. Existing source files and manuscript figures are unchanged.
'''
    targets[4].write_text(note,encoding='utf-8')
    print(json.dumps({'counts':report['counts'],'checks':report['checks'],
                      'outputs':[str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p) for p in targets]},indent=2))


if __name__=='__main__':main()
