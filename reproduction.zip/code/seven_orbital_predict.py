"""Parent-only forecasts and full-matrix tests for a seven-orbital contact pair.

Run --predict first to recompute the parent projection without finite-epsilon
data. Run --validate to reproduce the saved contact, topology, and gap checks.
The original, unmodified pre-validation forecast is stored separately in
source_data/seven_orbital_prediction_frozen.json. This consolidated reproducer
was prepared after those calculations; its code is not retrospectively claimed
to be the original executed driver.

Model: canonical intracell-loop ("literal") graph, t/t1=0.4, t1=1,
phi=13*pi/32; a=t_A/t1. Added H01=epsilon*(c+b*exp(i*qx)), H10 its
Hermitian conjugate. The compatible, breaking, mixed controls use (c,b)=
(1,0),(0,1),(1,1). The physical periodic q torus is [-pi,pi)^2.

Mesh and multistart extrema checks provide numerical evidence, not rigorous
global interval bounds. No interacting phase is inferred from these data.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import sys

for _name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ.setdefault(_name,'1')

import numpy as np
from scipy.optimize import minimize

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'seven_orbital_reproduction/code'))
import c3n4_verified as cv

T_RATIO=.4
PHI=13*np.pi/32
U=np.diag([1,-1,-1,-1,1,-1,-1])
PAULI=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)
CASES={'compatible':(1,0),'breaking':(0,1),'mixed':(1,1)}
EPSILONS=(-.04,-.02,-.01,-.005,-.0025,-.00125,-.000625,
           .000625,.00125,.0025,.005,.01,.02,.04)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pauli(frame,matrix):
    return np.einsum('iab,ba->i',PAULI,frame.conj().T@matrix@frame).real/2


def parent_matrices(z):
    """Exact full Hamiltonian and its qx,qy,a derivatives in orbital order 0..6."""
    x,y,a=z
    h=np.zeros((7,7),complex)
    derivatives=np.zeros((3,7,7),complex)
    for i,j,rx,ry,value in cv.hoppings('literal',t=T_RATIO,t1=1.,t_AA=a,phi=PHI):
        term=value*np.exp(1j*(rx*x+ry*y))
        h[i,j]+=term
        derivatives[0,i,j]+=1j*rx*term
        derivatives[1,i,j]+=1j*ry*term
    for i,j,rx,ry,value in cv.hoppings('literal',t=0.,t1=0.,t_AA=1.,phi=PHI):
        derivatives[2,i,j]+=value
    return h,derivatives


def model(x,y,a,epsilon=0.,case='mixed',derivative=False):
    x,y=np.broadcast_arrays(x,y)
    h=cv.hamiltonian(x,y,'literal',t=T_RATIO,t1=1.,t_AA=a,phi=PHI)
    c,b=CASES[case]
    term=epsilon*(c+b*np.exp(1j*x))
    h[...,0,1]+=term
    h[...,1,0]+=term.conjugate()
    if not derivative:
        return h
    if x.ndim:
        raise ValueError('Derivatives are evaluated at one contact at a time.')
    _,derivatives=parent_matrices([float(x),float(y),a])
    term=1j*epsilon*b*np.exp(1j*x)
    derivatives[0,0,1]+=term
    derivatives[0,1,0]+=term.conjugate()
    return h,derivatives


def perturbation(x,case):
    c,b=CASES[case]
    v=np.zeros((7,7),complex)
    v[0,1]=c+b*np.exp(1j*x)
    v[1,0]=v[0,1].conjugate()
    return v


def refine_contact(z,index,epsilon=0.,case='mixed'):
    """Newton correction using the current full seven-band eigenspace.

    This repeatedly diagonalizes the full perturbed Hamiltonian, rather than
    fitting or extrapolating the parent two-level effective Hamiltonian.
    """
    z=np.array(z,dtype=float)
    for iteration in range(25):
        h,derivatives=model(*z,epsilon,case,True)
        energies,vectors=np.linalg.eigh(h)
        frame=vectors[:,index:index+2]
        d=pauli(frame,h)
        jac=np.array([pauli(frame,m) for m in derivatives]).T
        if np.linalg.norm(d)<2e-14:
            break
        step=np.linalg.solve(jac,d)
        if np.linalg.norm(step)>1:
            raise RuntimeError('Newton step left the chosen local neighborhood.')
        z-=step
    z[:2]=(z[:2]+np.pi)%(2*np.pi)-np.pi
    energies=np.linalg.eigvalsh(model(*z,epsilon,case))
    gap=float(energies[index+1]-energies[index])
    if gap>1e-11:
        raise RuntimeError('The full-matrix contact did not converge.')
    return {'q':z[:2].tolist(),'a':float(z[2]),'gap':gap,
            'energy':float((energies[index]+energies[index+1])/2),
            'iterations':iteration+1,
            'spectator_separations':[float(energies[index]-energies[index-1]),
                                     float(energies[index+2]-energies[index+1])]}


def projected_shift(z,index,case):
    h,derivatives=model(*z,0.,case,True)
    energies,vectors=np.linalg.eigh(h)
    frame=vectors[:,index:index+2]
    jac=np.array([pauli(frame,d) for d in derivatives]).T
    source=pauli(frame,perturbation(z[0],case))
    return -np.linalg.solve(jac,source),float(np.linalg.det(jac)),energies


def forecast():
    # This seed locates the parent pair only; it contains no perturbed roots.
    contact=refine_contact([1.30,-2.60,1.27],2,0.,'compatible')
    z=np.array([*contact['q'],contact['a']])
    partner=z.copy()
    partner[0]=(z[0]+2*np.pi)%(2*np.pi)-np.pi
    controls={}
    for case in CASES:
        lower,dl,_=projected_shift(z,2,case)
        upper,du,_=projected_shift(partner,3,case)
        controls[case]={'lower_contact_shift':lower.tolist(),
                        'upper_contact_shift':upper.tolist(),
                        'width_coefficient':float(abs(lower[2]-upper[2])),
                        'mean_shift':float((lower[2]+upper[2])/2),
                        'simple_contact_determinants':[dl,du]}
    return {'kind':'Recomputed parent-only forecast, produced by the consolidated reproducer',
            'time_utc':datetime.now(timezone.utc).isoformat(),
            'original_prevalidation_forecast':'source_data/seven_orbital_prediction_frozen.json',
            'parent':{'r':T_RATIO,'phi':PHI,'contact':contact},
            'perturbation':'H01 += epsilon*(c+b*exp(i*qx)), H10 Hermitian conjugate',
            'predictions':controls,'canonical_source_sha256':sha(cv.__file__)}


def topology(a,epsilon,case,n,offset=(0.,0.)):
    axis=-np.pi+2*np.pi*np.arange(n)/n
    x,y=np.meshgrid(axis+offset[0]*2*np.pi/n,axis+offset[1]*2*np.pi/n,indexing='ij')
    energies,vectors=np.linalg.eigh(model(x,y,a,epsilon,case))
    dl=float((energies[...,3]-energies[...,2]).min())
    du=float((energies[...,4]-energies[...,3]).min())
    return {'a':float(a),'epsilon':epsilon,'case':case,'N':n,'offset':list(offset),
            'central':cv._fhs(vectors,min(dl,du),band=3),
            'lower_three_occupied_group':cv._fhs(vectors,dl,rank=3),
            'lower_four_occupied_group':cv._fhs(vectors,du,rank=4),
            'sampled_direct_gaps':[dl,du],
            'sampled_indirect_gaps':[float(energies[...,3].min()-energies[...,2].max()),
                                     float(energies[...,4].min()-energies[...,3].max())]}


def periodic_distance(p,q):
    return np.linalg.norm((p-q+np.pi)%(2*np.pi)-np.pi)


def extrema(a,epsilon,case,n=64):
    axis=np.linspace(-np.pi,np.pi,n,endpoint=False)
    x,y=np.meshgrid(axis,axis,indexing='ij')
    e=np.linalg.eigvalsh(model(x,y,a,epsilon,case))
    jobs={'direct_lower':(e[...,3]-e[...,2],lambda w:w[3]-w[2]),
          'direct_upper':(e[...,4]-e[...,3],lambda w:w[4]-w[3]),
          'min_central':(e[...,3],lambda w:w[3]),
          'max_central':(-e[...,3],lambda w:-w[3]),
          'max_band2':(-e[...,2],lambda w:-w[2]),
          'min_band4':(e[...,4],lambda w:w[4])}
    out={}
    for name,(grid,fun) in jobs.items():
        seeds=[]
        for flat in np.argsort(grid.ravel()):
            i,j=np.unravel_index(flat,grid.shape)
            p=np.array([x[i,j],y[i,j]])
            if not any(periodic_distance(p,q)<.4 for q in seeds):
                seeds.append(p)
            if len(seeds)==12:
                break
        values=[]
        for p in seeds:
            def objective(q):
                return fun(np.linalg.eigvalsh(model(*q,a,epsilon,case)))
            result=minimize(objective,p,method='Nelder-Mead',
                            options={'xatol':2e-11,'fatol':1e-14,'maxiter':500})
            q=(result.x+np.pi)%(2*np.pi)-np.pi
            if not any(periodic_distance(q,np.array(r['q']))<1e-6 for r in values):
                values.append({'value':float(result.fun),'q':q.tolist(),'success':bool(result.success)})
        values.sort(key=lambda d:d['value'])
        out[name]=values
    out['refined_indirect_gaps']=[out['min_central'][0]['value']+out['max_band2'][0]['value'],
                                   out['min_band4'][0]['value']+out['max_central'][0]['value']]
    out['scope']='64x64 seed grid, 12 separated seeds per extremum; numerical evidence, not an interval-certified global bound'
    return out


def validate(prediction,prediction_sha):
    original=prediction['parent']['contact']
    z=np.array([*original['q'],original['a']])
    partner=z.copy()
    partner[0]=(z[0]+2*np.pi)%(2*np.pi)-np.pi
    controls=prediction['predictions']
    contacts=[]
    for case in CASES:
        c=controls[case]
        # Recalculate invariant slopes from the full parent as an input check.
        for index,point,key in [(2,z,'lower_contact_shift'),(3,partner,'upper_contact_shift')]:
            current,_,_=projected_shift(point,index,case)
            if not np.allclose(current,c[key],atol=2e-12,rtol=2e-12):
                raise ValueError('Forecast does not match the included parent Hamiltonian.')
        for epsilon in EPSILONS:
            lower=refine_contact(z+epsilon*np.array(c['lower_contact_shift']),2,epsilon,case)
            upper=refine_contact(partner+epsilon*np.array(c['upper_contact_shift']),3,epsilon,case)
            contacts.append({'case':case,'epsilon':epsilon,'lower':lower,'upper':upper,
                             'width':abs(lower['a']-upper['a']),
                             'width_prediction':abs(epsilon)*c['width_coefficient'],
                             'mean':(lower['a']+upper['a'])/2,
                             'mean_prediction':z[2]+c['mean_shift']*epsilon})
    records=[]
    additional=[]
    arrays={}
    for case in ['breaking','mixed']:
        for epsilon in [.02,.04]:
            row=next(r for r in contacts if r['case']==case and r['epsilon']==epsilon)
            lo=min(row['lower']['a'],row['upper']['a'])
            hi=max(row['lower']['a'],row['upper']['a'])
            width=hi-lo
            for a,position in [(lo-.4*width,'below'),((lo+hi)/2,'inside'),(hi+.4*width,'above')]:
                for n in [96,192]:
                    item=topology(a,epsilon,case,n)
                    item['position']=position
                    records.append(item)
        row=next(r for r in contacts if r['case']==case and r['epsilon']==.02)
        a=row['mean']
        item=topology(a,.02,case,192,offset=(.37,.23))
        item['extrema']=extrema(a,.02,case)
        additional.append(item)
        axis=np.linspace(-np.pi,np.pi,192,endpoint=False)
        x,y=np.meshgrid(axis,axis,indexing='ij')
        e,w=np.linalg.eigh(model(x,y,a,.02,case))
        central=w[...,3]
        ux=np.sum(central.conj()*np.roll(central,-1,0),axis=-1)
        uy=np.sum(central.conj()*np.roll(central,-1,1),axis=-1)
        ux/=abs(ux)
        uy/=abs(uy)
        flux=np.angle(ux*np.roll(uy,-1,0)*np.roll(ux,-1,1).conj()*uy.conj())
        arrays[case+'_eigenvalues']=e
        arrays[case+'_central_plaquette_flux']=flux
        arrays[case+'_parameters']=np.array([T_RATIO,PHI,a,.02])
        arrays['axis']=axis
    for a in [z[2]-.04,z[2]+.04]:
        item=topology(a,0.,'compatible',192,offset=(.37,.23))
        item['position']='parent'
        additional.append(item)
    common=next(r for r in contacts if r['case']=='compatible' and r['epsilon']==.02)
    for a in [common['mean']-.025,common['mean']+.025]:
        item=topology(a,.02,'compatible',192,offset=(.37,.23))
        item['position']='compatible-sides'
        additional.append(item)
    return ({'forecast_sha256':prediction_sha,'contact_method':'Full seven-band eigenspace Newton correction','records':contacts},
            {'forecast_sha256':prediction_sha,'chern_convention':'positive overlap plaquette, qx then qy; central index3; lower_three/lower_four are lowest occupied groups',
             'records':records,'additional_checks':additional},arrays)


def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--predict',action='store_true')
    mode.add_argument('--validate',action='store_true')
    parser.add_argument('--prediction',type=Path,default=ROOT/'source_data/seven_orbital_prediction_frozen.json')
    parser.add_argument('--output-prefix',type=Path,default=ROOT/'source_data/seven_orbital_predict_recomputed')
    args=parser.parse_args()
    prefix=args.output_prefix
    if args.predict:
        result=forecast()
        path=Path(str(prefix)+'_prediction.json')
        write_json(path,result)
        print(json.dumps({'prediction_file':str(path),'sha256':sha(path),'finite_epsilon_calculation':False}))
    else:
        prediction=json.loads(args.prediction.read_text(encoding='utf-8'))
        if prediction['canonical_source_sha256']!=sha(cv.__file__):
            raise ValueError('The canonical Hamiltonian source differs from the forecast record.')
        paths=[Path(str(prefix)+suffix) for suffix in ('_contacts.json','_topology.json','_grids.npz','_provenance.json')]
        if any(p.exists() for p in paths):
            raise FileExistsError('Choose an unused output prefix to preserve prior results.')
        # Pin the actual forecast bytes before any finite-epsilon validation.
        provenance={'forecast_path':str(args.prediction),'forecast_sha256':sha(args.prediction),
                    'source_sha256':sha(__file__),'canonical_source_sha256':sha(cv.__file__),
                    'started_utc':datetime.now(timezone.utc).isoformat(),
                    'status':'full-matrix validation started'}
        write_json(paths[3],provenance)
        contacts,topology_data,arrays=validate(prediction,provenance['forecast_sha256'])
        write_json(paths[0],contacts)
        write_json(paths[1],topology_data)
        np.savez_compressed(paths[2],**arrays)
        provenance['status']='completed'
        provenance['completed_utc']=datetime.now(timezone.utc).isoformat()
        provenance['outputs']={p.name:sha(p) for p in paths[:3]}
        paths[3].write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'records':len(contacts['records']),'topology_points':len(topology_data['records'])+len(topology_data['additional_checks']),
                          'forecast_sha256':provenance['forecast_sha256'],'outputs':[str(p) for p in paths]}))


if __name__=='__main__':
    main()
