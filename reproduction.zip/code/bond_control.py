"""One-bond translation control in the three-orbital Hofstadter deformation.

No onsite offset is used. All parent parameters are held fixed except a,
the horizontal control bond. A real amplitude -g is added between orbitals
0 and 2, either on R=(-1,0) (compatible; c -> c+g) or on R=(0,0)
(incompatible; a zero-translation odd cycle). The Hermitian reverse is included.

The analytic contact equation is complete for a,b,c>0 and |g|<c. The
production calculation checks representative phases, not contacts, with
FHS and locally refined direct/indirect gaps. Existing files are unchanged.
"""
from pathlib import Path
import argparse
import json
import numpy as np
from scipy.optimize import minimize
from independent_model import (hamiltonian as parent_hamiltonian,
                               contact_vectors, derivatives, _link,
                               DEFAULT_V, B, C, U_SHIFT)

ROOT = Path(__file__).resolve().parents[1]


def hamiltonian(kx, ky, a=1.0, g=0.0, mode='incompatible',
                v=DEFAULT_V, b=B, c=C):
    """Return broadcast H(kx,ky); mode chooses only the added bond translation."""
    if mode not in ('incompatible', 'compatible'):
        raise ValueError('mode must be incompatible or compatible')
    h = parent_hamiltonian(kx, ky, a=a, mu=0.0, v=v, b=b, c=c)
    phase = 1.0 if mode == 'incompatible' else np.exp(-1j*np.asarray(kx))
    h[..., 0, 2] -= g*phase
    h[..., 2, 0] -= g*np.conj(phase)
    return h


def all_contacts(g=0.0, mode='incompatible', v=DEFAULT_V, b=B, c=C):
    """All positive-a contacts; sigma=-1/+1 denotes kx=0/pi.

    At a double eigenvalue, sin(kx)=0 and H-EI has rank one. Its diagonal
    entries are sigma*(a*c_sigma/b, a*b/c_sigma, b*c_sigma/a), where
    c_sigma=c-sigma*g for the incompatible bond, c+g for the compatible one.
    The unit trigonometric vector gives a quadratic in a**2.
    """
    if not (b > 0 and c > abs(g)):
        raise ValueError('This contact formula requires b>0 and |g|<c')
    if mode not in ('incompatible', 'compatible'):
        raise ValueError('Unknown mode')
    out = []
    for sigma in (-1, 1):
        ce = c-sigma*g if mode == 'incompatible' else c+g
        _, u, z = contact_vectors(v, b, ce)
        coef = [float(u@u), float(2*u@z-1), float(z@z)]
        for aa in np.roots(coef):
            if abs(aa.imag) > 1e-10 or aa.real <= 0:
                continue
            a = float(np.sqrt(aa.real))
            xy = sigma*(a*u+z/a)
            kx = 0.0 if sigma == -1 else float(np.pi)
            ky = float(np.arctan2(xy[1], xy[0]))
            e, states = np.linalg.eigh(hamiltonian(kx, ky, a, g, mode, v, b, c))
            gi = int(np.argmin(np.diff(e)))
            frame = states[:, gi:gi+2]
            pauli = []
            for dh in derivatives(kx, ky, a, 0., v, b,
                                  c if mode == 'incompatible' else c+g):
                p = frame.conj().T@dh@frame
                pauli.append([p[0,1].real, -p[0,1].imag,
                              (p[0,0].real-p[1,1].real)/2])
            out.append({'a':a, 'g':float(g), 'mode':mode, 'sigma':sigma,
                        'effective_c':float(ce), 'kx':kx, 'ky':ky,
                        'energy':float(np.mean(e[gi:gi+2])), 'gap_index':gi,
                        'gap_residual':float(e[gi+1]-e[gi]),
                        'trigonometric_norm_residual':float(abs(xy@xy-1)),
                        'pauli_velocity_determinant_kx_ky_a':float(np.linalg.det(np.array(pauli).T)),
                        'quadratic_in_a_squared':coef})
    return sorted(out,key=lambda r:(r['a'],r['sigma']))


def upper_contacts(g=0.0, mode='incompatible'):
    """The two contacts near a=3, sorted by a (both retained when degenerate)."""
    out = [r for r in all_contacts(g,mode) if r['a']>1]
    if len(out)!=2:
        raise ValueError('Expected two high-a contacts')
    return out


def contact_slopes():
    """Analytic da*/dc and da_sigma/dg at g=0; no finite-difference fitting."""
    a = upper_contacts(0)[0]['a']
    _, u, z = contact_vectors()
    v0,v1,v2 = DEFAULT_V
    d = np.array([[2*v0+v1,np.sqrt(3)*v1],[v1-v2,np.sqrt(3)*(v1+v2)]])
    du = np.linalg.solve(d,[-1/B-B/C**2,-B/C**2])
    dz = np.linalg.solve(d,[0.,-B])
    r = a*u+z/a
    da_dc = float(-(r@(a*du+dz/a))/(r@(u-z/a**2)))
    return {'a_star':a, 'da_star_dc':da_dc,
            'incompatible_da_dg_by_sigma':{str(s):-s*da_dc for s in (-1,1)},
            'compatible_da_dg_both_branches':da_dc,
            'odd_interval_linear_width':2*abs(da_dc)}


def chern_mesh(a, g, n=96, mode='incompatible', return_arrays=False):
    """Positive overlap-plaquette orientation; band and occupied-group indices."""
    k = np.linspace(-np.pi,np.pi,n,endpoint=False)
    x,y = np.meshgrid(k,k,indexing='ij')
    e,u = np.linalg.eigh(hamiltonian(x,y,a,g,mode))
    lx,ox = _link(u,0);ly,oy = _link(u,1)
    f = np.angle(lx*np.roll(ly,-1,0)*np.conj(np.roll(lx,-1,1))*np.conj(ly))
    groups=[]
    for rank in (1,2):
        q=u[...,:rank]
        wx=np.einsum('...ia,...ib->...ab',q.conj(),np.roll(q,-1,0))
        wy=np.einsum('...ia,...ib->...ab',q.conj(),np.roll(q,-1,1))
        ux,uy=np.linalg.det(wx),np.linalg.det(wy)
        if min(np.min(np.abs(ux)),np.min(np.abs(uy)))<1e-12:
            raise ValueError('Unresolved occupied-subspace overlap')
        ux,uy=ux/np.abs(ux),uy/np.abs(uy)
        ff=np.angle(ux*np.roll(uy,-1,0)*np.conj(np.roll(ux,-1,1))*np.conj(uy))
        groups.append(float(ff.sum()/(2*np.pi)))
    result={'N':n,'chern':(f.sum(axis=(0,1))/(2*np.pi)).tolist(),
            'occupied_group_chern':groups,
            'direct_gaps_mesh':np.diff(e,axis=-1).min(axis=(0,1)).tolist(),
            'indirect_gaps_mesh':(e[...,1:].min(axis=(0,1))-e[...,:-1].max(axis=(0,1))).tolist(),
            'minimum_neighbor_overlap':float(min(ox,oy)),
            'maximum_absolute_plaquette_phase':np.max(np.abs(f),axis=(0,1)).tolist()}
    if return_arrays:
        return result,{'k':k,'energies':e,'plaquette_flux':f}
    return result


def refine_spectrum(a,g,mode='incompatible',n=64,nstarts=12):
    """Periodic multistart extrema; these numerical estimates are not global certificates."""
    k=np.linspace(-np.pi,np.pi,n,endpoint=False);x,y=np.meshgrid(k,k,indexing='ij')
    e=np.linalg.eigvalsh(hamiltonian(x,y,a,g,mode))
    def refine(score,objective):
        fits=[]
        for flat in np.argsort(score.ravel())[:nstarts]:
            i,j=np.unravel_index(flat,score.shape)
            fits.append(minimize(objective,[k[i],k[j]],method='Nelder-Mead',
                                 options={'xatol':2e-11,'fatol':2e-13,'maxiter':700}))
        best=min(fits,key=lambda fit:fit.fun)
        return {'value':float(best.fun),'k':((best.x+np.pi)%(2*np.pi)-np.pi).tolist(),
                'optimizer_success':bool(best.success)}
    def levels(q):return np.linalg.eigvalsh(hamiltonian(q[0],q[1],a,g,mode))
    gaps=[]
    for band in range(2):
        r=refine(e[...,band+1]-e[...,band],lambda q:float(np.diff(levels(q))[band]))
        r['gap_index']=band;gaps.append(r)
    minima,maxima=[],[]
    for band in range(3):
        for sign,values in [(1,minima),(-1,maxima)]:
            r=refine(sign*e[...,band],lambda q:sign*float(levels(q)[band]))
            r['value']*=sign;values.append(r)
    mins=np.array([r['value'] for r in minima]);maxs=np.array([r['value'] for r in maxima])
    return {'direct_gaps':gaps,'band_minima':minima,'band_maxima':maxima,
            'indirect_gaps':(mins[1:]-maxs[:-1]).tolist(),
            'bandwidths':(maxs-mins).tolist(),
            'method':'Multistart local refinement of periodic grid extrema; not a global certificate.'}


def coloring_solutions(mode='incompatible',g=.1):
    """Enumerate the finite binary test, fixing the global color flip by s0=0."""
    edges=[(0,1,(0,0)),(1,2,(0,0)),(2,0,(1,0))]
    edges += [(j,j,(0,1)) for j in range(3)]
    if g!=0 and mode=='incompatible':edges.append((0,2,(0,0)))
    out=[]
    for px in (0,1):
        for py in (0,1):
            for s1 in (0,1):
                for s2 in (0,1):
                    s=(0,s1,s2)
                    if all((s[i]+s[j]+px*r[0]+py*r[1])%2==1 for i,j,r in edges):
                        out.append({'p':[px,py],'s':list(s)})
    return out


def symmetry_residual(a,g,mode):
    k=np.linspace(-np.pi,np.pi,17,endpoint=False);x,y=np.meshgrid(k,k,indexing='ij')
    h=hamiltonian(x,y,a,g,mode);hq=hamiltonian(x+np.pi,y+np.pi,a,g,mode)
    return float(np.max(np.abs(U_SHIFT@hq@U_SHIFT+h)))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'source_data')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    cases=[]
    plans=[('parent_at_fixed_a',3.12,0.,'incompatible',[-1,2,-1])]
    for mode in ('compatible','incompatible'):
        for a in (2.95,3.10,3.25):
            expected=([-1,2,-1] if a==2.95 else [0,0,0])
            if mode=='incompatible' and a==3.10:expected=[-1,1,0]
            plans.append((f'{mode}_a{a:.2f}',a,.1,mode,expected))
    plans += [('compatible_at_fixed_a',3.12,.1,'compatible',[0,0,0]),
              ('incompatible_at_fixed_a',3.12,.1,'incompatible',[-1,1,0]),
              ('incompatible_larger_g',3.,.2,'incompatible',[-1,1,0])]
    for name,a,g,mode,expected in plans:
        grids=[chern_mesh(a,g,n,mode) for n in (48,96,192)]
        for r in grids:
            assert np.max(np.abs(np.array(r['chern'])-expected))<1e-8
            assert np.max(np.abs(np.array(r['occupied_group_chern'])-np.cumsum(expected)[:2]))<1e-8
        spectrum=refine_spectrum(a,g,mode)
        assert min(r['value'] for r in spectrum['direct_gaps'])>0.01
        cases.append({'name':name,'a':a,'g':g,'mode':mode,'expected_chern':expected,
                      'grid_convergence':grids,'refined_spectrum':spectrum,
                      'same_parameter_symmetry_residual':symmetry_residual(a,g,mode)})
    gs=np.linspace(0,.15,101)
    bc=[upper_contacts(g) for g in gs]
    cc=[upper_contacts(g,'compatible') for g in gs]
    _,arrays=chern_mesh(3.12,.1,192,return_arrays=True)
    np.savez_compressed(args.output/'bond_control_source.npz',
                        g=gs,incompatible_a_critical=np.array([[r['a'] for r in rs] for rs in bc]),
                        compatible_a_critical=np.array([[r['a'] for r in rs] for rs in cc]),
                        incompatible_kx=np.array([[r['kx'] for r in rs] for rs in bc]),
                        incompatible_ky=np.array([[r['ky'] for r in rs] for rs in bc]),
                        odd_a=3.12,odd_g=.1,odd_k=arrays['k'],
                        odd_energies=arrays['energies'],odd_plaquette_flux=arrays['plaquette_flux'])
    report={'model':'One added bond with two alternative cell translations in the fixed three-orbital parent',
            'parameters':{'b':B,'c':C,'v':DEFAULT_V.tolist(),'mu':0.,'onsite_offset_used':False},
            'two_variants':{'compatible':'H02 += -g exp(-i kx), R=(-1,0); all else unchanged',
                            'incompatible':'H02 += -g, R=(0,0); all else unchanged',
                            'reverse':'Hermitian reverse added in both variants'},
            'graph':{'parent':coloring_solutions(g=0),
                     'compatible':coloring_solutions('compatible'),
                     'incompatible':coloring_solutions('incompatible'),
                     'obstruction':'The added intracell 0-2 bond closes the local three-edge walk 0-1-2-0; the compatible added bond has the same endpoints but a translated endpoint.'},
            'exact_relation':'U H_g(k+Q) U = -H_-g(k), Q=(pi,pi), for the incompatible family; compatible retains the same-g relation.',
            'contact_equation':'(u(c_sigma).u(c_sigma))*a^4 + (2*u(c_sigma).z(c_sigma)-1)*a^2 + z(c_sigma).z(c_sigma)=0, c_sigma=c-sigma*g (incompatible) or c+g (compatible)',
            'contact_formula_scope':'a,b,c>0, |g|<c; all finite positive-a double degeneracies are included. Main figure selects the a>1 pair.',
            'slopes':contact_slopes(),
            'analytic_contacts':{mode:{str(g):all_contacts(g,mode) for g in (0.,.05,.1,.15,.2)}
                                 for mode in ('compatible','incompatible')},
            'cases':cases,
            'interpretation':'With the same endpoints and added real amplitude, the translated bond preserves paired even transfer; the intracell bond splits it and yields a directly isolated odd-Chern phase. Representative odd phases have positive indirect gaps.',
            'novelty_scope':'New controlled calculation relative to this manuscript; no claim of a new symmetry class or established literature priority.',
            'accuracy':'Full precision retained. Chern grids 48,96,192; direct and indirect extrema refined locally. Analytic contact equations provide phase boundaries; positive indirect gaps quoted are numerical estimates.'}
    path=args.output/'bond_control_results.json';path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'cases':len(cases),'slopes':report['slopes'],
                      'g_01_incompatible_contacts':upper_contacts(.1),
                      'odd_representative':cases[-2]},indent=2))


if __name__=='__main__':main()
