"""Check only the existing Figure 4 NNN parameters with m set to zero.

No parameter sweep or figure replacement is performed. Local extrema are
numerical estimates, not certificates of global gaps.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
MODEL=ROOT/'seven_orbital_reproduction/code/c3n4_verified.py'
sys.path.insert(0,str(MODEL.parent))
import c3n4_verified as cv


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'source_data/honeycomb_fig4_m0_check.json')
    args=parser.parse_args()
    if args.output.exists():parser.error('Output exists; use --output with a new path.')
    parameters=dict(t=1.,t1=1.,t_NNN=.35,nnn_phi=5*np.pi/6,mass=0.)
    results=[]
    for n in (48,96):
        results.append(cv.evaluate('honeycomb_haldane',N=n,refine=(n==96),nstarts=8,**parameters))
    report={'scope':'Single m=0 control at existing Figure 4 NNN parameters; no parameter search.',
            'model':'honeycomb_haldane','parameters':parameters,
            'meshes':[48,96],'local_refinement':'N=96 grid seeds, nstarts=8, canonical refine_extrema.',
            'results':results,
            'limitations':'Only this one parameter set is evaluated. Finite meshes and multistart local extrema are numerical evidence; they do not establish a global gap certificate or necessity of nonzero m elsewhere.',
            'source_sha256':{'code/check_honeycomb_m0.py':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                             'seven_orbital_reproduction/code/c3n4_verified.py':hashlib.sha256(MODEL.read_bytes()).hexdigest()}}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(args.output),'meshes':[
        {'N':r['N'],'central_FHS':r['band_chern'],'occupied':r['occupied'],
         'direct_lower':r['direct_lower'],'direct_upper':r['direct_upper'],
         'indirect_lower':r['indirect_lower'],'indirect_upper':r['indirect_upper'],
         'refined':r.get('refined')} for r in results]},indent=2))


if __name__=='__main__':main()
