"""Direct Berry-curvature quadrature of the full seven-orbital strong-loop band.

No FHS/link flux enters these integrals. Four periodic vertical cells cover one
complete torus. Inside each cell, the saved local velocity Gram matrix sets an
anisotropic polar map, followed by r=sinh(u). Finite ellipses and their exact
cell complements are integrated separately; their sum does not discard tails.
Existing output is never overwritten (use --output-prefix for a repeat run).
"""
from __future__ import annotations

import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_key] = "1"

import argparse
import csv
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path
import sys

import numpy as np
import scipy
from numpy.polynomial.legendre import leggauss

ROOT = Path(__file__).resolve().parents[1]
MODEL_CODE = ROOT / "seven_orbital_reproduction" / "code"
SOURCE = ROOT / "source_data" / "strong_loop_results.json"
sys.path.insert(0, str(MODEL_CODE))
import c3n4_verified as cv
_spec = importlib.util.spec_from_file_location("strong_loop_source", MODEL_CODE / "analyses" / "strong_loop.py")
sl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sl)
PHI = 3 * np.pi / 8
ORDER = np.r_[cv.A_ORBITALS, cv.B_ORBITALS]


def curvature(q, a):
    """Analytic velocity sum for band 3, evaluated only in full 7x7 matrices."""
    shape = q.shape[:-1]
    points = q.reshape(-1, 2)
    values = np.empty(len(points))
    for start in range(0, len(points), 4096):
        p = points[start:start + 4096]
        values[start:start + len(p)] = sl.qgt(*sl.full(p[:, 0], p[:, 1], a=a, phi=PHI, derivative=True), 3)[0]
    return values.reshape(shape)


def nodes_and_cells(source, a):
    nodes = []
    for index, node in enumerate(source["nodes"]):
        local = min((r for r in source["local_nodes"] if r["a"] == a),
                    key=lambda r: np.linalg.norm(np.asarray(r["leading_q"]) - node["q"]))
        center = np.array(local["refined_q"])
        velocity = np.stack([node["velocity_x_pauli"], node["velocity_y_pauli"]], axis=1)
        eigenvalues, eigenvectors = np.linalg.eigh(velocity.T @ velocity)
        transform = abs(node["signed_mass_coefficient"]) / a**2 * (eigenvectors * eigenvalues[None, :]**-.5) @ eigenvectors.T
        nodes.append({"index": index, "center": center, "B": transform,
                      "source_node": node, "source_local": local})
    order = np.argsort([node["center"][0] for node in nodes])
    sorted_x = np.array([nodes[i]["center"][0] for i in order])
    boundaries = np.r_[(sorted_x[-1] - 2*np.pi + sorted_x[0])/2,
                       (sorted_x[:-1] + sorted_x[1:])/2,
                       (sorted_x[-1] + sorted_x[0] + 2*np.pi)/2]
    for j, i in enumerate(order):
        nodes[i]["bounds"] = np.array([[boundaries[j], boundaries[j + 1]],
                                       [-np.pi/3 - np.pi, -np.pi/3 + np.pi]])
    return nodes


def integrate_node(node, a, radius, order):
    center, transform, bounds = node["center"], node["B"], node["bounds"]
    # Angular sectors end at transformed rectangle corners, making the
    # identity of the limiting cell edge smooth inside each sector.
    corners = np.array([[x, y] for x in bounds[0] for y in bounds[1]])
    mapped = np.linalg.solve(transform, (corners - center).T).T
    cuts = np.r_[0., np.sort(np.mod(np.arctan2(mapped[:, 1], mapped[:, 0]), 2*np.pi)), 2*np.pi]
    abscissa, weight = leggauss(order)
    theta = np.concatenate([(left + right)/2 + (right - left)/2*abscissa for left, right in zip(cuts[:-1], cuts[1:])])
    theta_weight = np.concatenate([(right - left)/2*weight for left, right in zip(cuts[:-1], cuts[1:])])
    directions = np.stack([np.cos(theta), np.sin(theta)], axis=1) @ transform.T
    ray_max = np.full(theta.shape, np.inf)
    inscribed_radius = np.inf
    for dim in (0, 1):
        positive_distance = bounds[dim, 1] - center[dim]
        negative_distance = bounds[dim, 0] - center[dim]
        ray_max = np.minimum(ray_max, np.where(directions[:, dim] > 0,
                              positive_distance/directions[:, dim], negative_distance/directions[:, dim]))
        inscribed_radius = min(inscribed_radius, positive_distance/np.linalg.norm(transform[dim]), -negative_distance/np.linalg.norm(transform[dim]))
    if radius >= inscribed_radius:
        raise ValueError("Requested ellipse leaves its disjoint cell")
    determinant = abs(np.linalg.det(transform))

    def radial_integral(u_start, u_end):
        u_start, u_end = np.broadcast_arrays(u_start, u_end)
        u = (u_start + u_end)[None, :]/2 + (u_end - u_start)[None, :]/2*abscissa[:, None]
        radial = np.sinh(u)
        q = center + radial[..., None]*directions[None, :, :]
        omega = curvature(q, a)
        jacobian = determinant * radial * np.cosh(u)
        weights = weight[:, None] * (u_end - u_start)[None, :]/2 * theta_weight[None, :]
        return float(np.sum(omega * jacobian * weights)/(2*np.pi))

    u_cut = np.full(theta.shape, np.arcsinh(radius))
    local_flux = radial_integral(np.zeros_like(u_cut), u_cut)
    background_flux = radial_integral(u_cut, np.arcsinh(ray_max))
    charge = node["source_node"]["central_Dirac_charge_prediction"]
    return {"a": a, "node_index": node["index"], "band_pair_low_cluster": node["source_node"]["band_pair"],
            "full_band_contact_pair": [2 + b for b in node["source_node"]["band_pair"]],
            "center_q": center.tolist(), "cell_bounds": bounds.tolist(), "map_B": transform.tolist(),
            "map_singular_values": np.linalg.svd(transform, compute_uv=False).tolist(),
            "signed_mass_coefficient": node["source_node"]["signed_mass_coefficient"],
            "analytic_half_infinite_flux": charge, "dimensionless_patch_radius": radius,
            "gauss_order_radial_and_per_angular_sector": order, "angular_points": len(theta),
            "points_total_patch_plus_background": 2*order*len(theta),
            "max_patch_semiaxis_q": float(radius*np.linalg.svd(transform, compute_uv=False).max()),
            "largest_inscribed_dimensionless_radius": float(inscribed_radius),
            "direct_curvature_patch_flux_over_2pi": local_flux,
            "ideal_linear_Dirac_same_ellipse_flux_over_2pi": charge*(1 - 1/np.sqrt(1 + radius**2)),
            "direct_curvature_background_cell_flux_over_2pi": background_flux,
            "direct_curvature_whole_cell_flux_over_2pi": local_flux + background_flux}


def consistency_checks(nodes, a):
    checks = []
    for q in [np.array([.371, -.629]), *(node["center"] for node in nodes)]:
        h, dx, dy = sl.full(*q, a=a, phi=PHI, derivative=True)
        independent = [np.zeros((7, 7), complex) for _ in range(3)]
        for i, j, rx, ry, amp in cv.hoppings("literal", t=1., t1=1., t_AA=a, phi=PHI):
            val = amp*np.exp(1j*(rx*q[0] + ry*q[1]))
            independent[0][i, j] += val
            independent[1][i, j] += 1j*rx*val
            independent[2][i, j] += 1j*ry*val
        residuals = [float(np.max(abs(value - other[np.ix_(ORDER, ORDER)]))) for value, other in zip((h, dx, dy), independent)]
        step = 1e-5
        fd = [(sl.full(*(q + step*np.eye(2)[axis]), a=a, phi=PHI) - sl.full(*(q - step*np.eye(2)[axis]), a=a, phi=PHI))/(2*step) for axis in range(2)]
        checks.append({"a": a, "q": q.tolist(), "H_Dx_Dy_vs_integer_bond_implementation_max_abs_residuals": residuals,
                       "analytic_Dx_Dy_vs_central_difference_max_abs_residuals": [float(np.max(abs(d - f))) for d, f in zip((dx, dy), fd)],
                       "finite_difference_step": step, "central_curvature": float(sl.qgt(h, dx, dy, 3)[0])})
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-prefix", type=Path, default=ROOT/"source_data"/"strong_loop_local_flux")
    parser.add_argument("--orders", type=int, nargs="+", default=[32, 64, 128])
    parser.add_argument("--amplitudes", type=float, nargs="+", default=[20., 40.])
    parser.add_argument("--radii", type=float, nargs="+", default=[10., 30., 100., 300.])
    args = parser.parse_args()
    paths = [args.output_prefix.with_suffix(suffix) for suffix in (".json", ".csv")]
    if any(path.exists() for path in paths):
        parser.error("Output exists; supply a new --output-prefix")
    source = json.loads(SOURCE.read_text(encoding="utf-8-sig"))
    records, totals, checks, baseline = [], [], [], []
    for a in args.amplitudes:
        nodes = nodes_and_cells(source, a)
        checks.extend(consistency_checks(nodes, a))
        for node in nodes:
            row = node["source_local"]
            baseline.append({"a": a, "node_index": node["index"], "source_file": str(SOURCE.relative_to(ROOT)),
                             "existing_square_patch_halfwidth": row["patch_dimensionless_halfwidth"],
                             "existing_square_patch_grid": row["patch_grid"],
                             "existing_direct_midpoint_flux": row["patch_analytic_Berry_flux_over_2pi"],
                             "existing_ideal_square_patch_flux": row["ideal_local_Dirac_flux_over_2pi"]})
        # Full order convergence at R=30; the finest order also varies radius.
        cases = [(order, 30.) for order in args.orders]
        cases += [(max(args.orders), radius) for radius in args.radii if radius != 30.]
        for order, radius in cases:
            rows = [integrate_node(node, a, radius, order) for node in nodes]
            records.extend(rows)
            total = {"a": a, "order": order, "radius": radius,
                     "patch_sum": sum(r["direct_curvature_patch_flux_over_2pi"] for r in rows),
                     "background_sum": sum(r["direct_curvature_background_cell_flux_over_2pi"] for r in rows),
                     "whole_torus_direct_curvature_integral_over_2pi": sum(r["direct_curvature_whole_cell_flux_over_2pi"] for r in rows)}
            totals.append(total)
            print(json.dumps(total), flush=True)
    files = [Path(__file__).resolve(), MODEL_CODE/"c3n4_verified.py", MODEL_CODE/"analyses"/"strong_loop.py", SOURCE]
    output = {"created_utc": datetime.now(timezone.utc).isoformat(),
              "model": "full 7x7 intracell-loop Hamiltonian, central band index 3; t=t1=1, phi=3pi/8",
              "integrand": "Omega3=2 Im sum_{m != 3} <u3|d_x H|um><um|d_y H|u3>/(E3-Em)^2, evaluated with full matrix and analytic derivatives; integrated as Omega3 dqx dqy/(2pi). No FHS quantities enter.",
              "domain": "One complete 2pi by 2pi periodic q torus, with y in [-pi/3-pi,-pi/3+pi]. Four adjacent nonoverlapping vertical cells have boundaries at cyclic midpoints of refined node qx coordinates.",
              "map": "q=qnode+B r(cos(theta),sin(theta)); B=|m3| a^-2 (V^T V)^-1/2, V=(vx,vy), r=sinh(u). Angular intervals split at mapped rectangle corners; radial integrals split exactly at r=R. Gauss-Legendre rules are used in u and each angular sector.",
              "interpretation": "Finite ellipse flux differs from the ideal linear-Dirac value and need not equal 1/2. Its separately integrated cell complement retains tails and smooth background. Quadrature refinement differences are convergence evidence, not rigorous error bounds. No value is rounded or normalized to an integer.",
              "environment": {"python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__, "linear_algebra_threads": 1},
              "source_sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
              "model_and_derivative_checks": checks, "existing_direct_integral_baseline": baseline,
              "records": records, "whole_torus_totals": totals}
    paths[0].parent.mkdir(parents=True, exist_ok=True)
    with paths[0].open("x", encoding="utf-8") as handle:
        json.dump(output, handle, indent=2)
        handle.write("\n")
    with paths[1].open("x", encoding="utf-8", newline="") as handle:
        fields = ["a", "node_index", "full_band_contact_pair", "dimensionless_patch_radius", "gauss_order_radial_and_per_angular_sector", "direct_curvature_patch_flux_over_2pi", "ideal_linear_Dirac_same_ellipse_flux_over_2pi", "direct_curvature_background_cell_flux_over_2pi", "direct_curvature_whole_cell_flux_over_2pi"]
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)
    print("Saved " + " and ".join(map(str, paths)), flush=True)


if __name__ == "__main__":
    main()
