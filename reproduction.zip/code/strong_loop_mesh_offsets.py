"""Full-seven-band FHS offset checks on the intracell-loop periodic q torus.

Run from any directory with NumPy and SciPy installed. Outputs are new files;
existing evidence is never overwritten. Offsets are fractions of one mesh step.
Finite sampled offsets do not guarantee convergence for every translated mesh.
"""
from __future__ import annotations

import os
for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_key] = "1"

import argparse
import csv
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path
import sys

import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
MODEL_CODE = ROOT / "seven_orbital_reproduction" / "code"
sys.path.insert(0, str(MODEL_CODE))
import c3n4_verified as cv

_spec = importlib.util.spec_from_file_location("strong_loop_source", MODEL_CODE / "analyses" / "strong_loop.py")
sl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sl)
PHI = 3 * np.pi / 8
ORDER = np.r_[cv.A_ORBITALS, cv.B_ORBITALS]


def check_grid(n: int, offset: tuple[float, float]) -> dict:
    axes = [-np.pi + 2 * np.pi * (np.arange(n) + s) / n for s in offset]
    x, y = np.meshgrid(*axes, indexing="ij")
    h = sl.full(x, y, a=40., r=1., phi=PHI)
    # Compare every sampled 7x7 matrix with the translation-labelled bond
    # implementation, using chunks to avoid retaining a second whole grid.
    residual = 0.
    for start in range(0, n, 16):
        end = min(start + 16, n)
        bond_h = cv.hamiltonian(x[start:end], y[start:end], "literal",
                               t=1., t1=1., t_AA=40., phi=PHI)
        bond_h = bond_h[..., ORDER, :][..., :, ORDER]
        residual = max(residual, float(np.max(abs(h[start:end] - bond_h))))
    if residual > 1e-12:
        raise RuntimeError(f"Full model consistency failed: {residual}")
    hermitian = float(np.max(abs(h - h.conj().swapaxes(-1, -2))))
    e, v = np.linalg.eigh(h)
    gaps = np.diff(e, axis=-1)
    direct = gaps.min(axis=(0, 1))
    adjacent_gap = float(min(direct[2:4]))
    fhs = cv._fhs(v, adjacent_gap, band=3)
    source_fhs = sl.fhs(v, [3], adjacent_gap)
    if fhs["chern_raw"] is None or source_fhs["chern"] is None:
        fhs_residual = None
    else:
        fhs_residual = abs(fhs["chern_raw"] - source_fhs["chern"])
        if fhs_residual > 1e-12:
            raise RuntimeError("The two source FHS implementations disagree")
    sampled_q = []
    for band in (2, 3):
        i, j = np.unravel_index(np.argmin(gaps[..., band]), (n, n))
        sampled_q.append([float(axes[0][i]), float(axes[1][j])])
    return {
        "N": n, "offset_in_grid_steps": list(offset),
        "central_band_index_zero_based": 3,
        "central_FHS": fhs,
        "sampled_direct_gaps_all_six": direct.tolist(),
        "sampled_adjacent_direct_gaps_lower_upper": direct[2:4].tolist(),
        "sampled_adjacent_gap_minimizer_q_lower_upper": sampled_q,
        "matrix_comparison_points": n * n,
        "full_vs_bond_module_max_abs_residual": residual,
        "hermiticity_max_abs_residual": hermitian,
        "source_FHS_implementation_chern_residual": fhs_residual,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[96, 192, 384])
    parser.add_argument("--offsets", nargs="+", default=["0,0", "0.5,0", "0,0.5", "0.5,0.5", "0.25,0.25"])
    parser.add_argument("--output-prefix", type=Path, default=ROOT / "source_data" / "strong_loop_mesh_offsets")
    args = parser.parse_args()
    offsets = [tuple(map(float, item.split(","))) for item in args.offsets]
    if any(n < 4 for n in args.sizes) or any(len(s) != 2 or any(x < 0 or x >= 1 for x in s) for s in offsets):
        parser.error("Require N>=4 and each offset component in [0,1)")
    paths = [args.output_prefix.with_suffix(ext) for ext in (".json", ".csv")]
    if any(path.exists() for path in paths):
        parser.error("Output already exists; supply a new --output-prefix to preserve existing data")

    periodic_checks = []
    for q in [(.371, -.629), (-1.2, .7), (2.1, -2.4), (-np.pi, np.pi)]:
        h = sl.full(*q, a=40., phi=PHI)
        periodic_checks.append({"q": list(q), "period_2pi_x_residual": float(np.max(abs(sl.full(q[0] + 2*np.pi, q[1], a=40., phi=PHI) - h))),
                                "period_2pi_y_residual": float(np.max(abs(sl.full(q[0], q[1] + 2*np.pi, a=40., phi=PHI) - h)))})
    records = []
    for n in args.sizes:
        for offset in offsets:
            row = check_grid(n, offset)
            records.append(row)
            f = row["central_FHS"]
            print(f"N={n} offset={offset} C={f['chern_raw']:.15g} min_link={f['minimum_link_overlap']:.9g} max_phase={f['maximum_plaquette_phase']:.9g} sampled_gap={f['direct_gap']:.9g}", flush=True)
    sources = [Path(__file__).resolve(), MODEL_CODE / "c3n4_verified.py", MODEL_CODE / "analyses" / "strong_loop.py"]
    output = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "model": "full 7x7 intracell-loop model; no effective-Hamiltonian substitution",
        "parameters": {"t": 1., "t1": 1., "t_AA": 40., "phi": PHI, "phi_exact": "3*pi/8"},
        "torus": "Complete periodic q torus [-pi,pi)^2; each direction has period 2*pi; no reduced or physical-honeycomb torus is used.",
        "mesh": "q_mu=-pi+2*pi*(j+s_mu)/N for j=0,...,N-1, with periodic wrap links; s is in units of one grid step.",
        "chern_convention": "Positive oriented overlap-plaquette phase, qx then qy; central band index 3, eigenvalues in increasing order.",
        "limitations": "Only listed finite mesh offsets are tested. An integer FHS value and sampled nonzero gaps do not prove arbitrary-offset convergence, resolve curvature peaks, or certify a global direct/indirect gap.",
        "environment": {"python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__, "linear_algebra_threads": 1},
        "source_sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
        "periodicity_checks": periodic_checks, "records": records,
        "summary_by_N": {str(n): {"offset_count": sum(row["N"] == n for row in records),
                                  "observed_Chern_integers": sorted({row["central_FHS"]["chern_integer"] for row in records if row["N"] == n}),
                                  "all_listed_offsets_return_C2": all(row["central_FHS"]["chern_integer"] == 2 for row in records if row["N"] == n)} for n in args.sizes},
    }
    paths[0].parent.mkdir(parents=True, exist_ok=True)
    with paths[0].open("x", encoding="utf-8") as handle:
        json.dump(output, handle, indent=2)
        handle.write("\n")
    with paths[1].open("x", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["N", "offset_x_grid_steps", "offset_y_grid_steps", "chern_raw", "chern_integer", "minimum_link_overlap", "maximum_plaquette_phase_radians", "sampled_lower_direct_gap", "sampled_upper_direct_gap", "matrix_max_abs_residual", "FHS_implementation_residual"])
        for row in records:
            f = row["central_FHS"]
            writer.writerow([row["N"], *row["offset_in_grid_steps"], f["chern_raw"], f["chern_integer"], f["minimum_link_overlap"], f["maximum_plaquette_phase"], *row["sampled_adjacent_direct_gaps_lower_upper"], row["full_vs_bond_module_max_abs_residual"], row["source_FHS_implementation_chern_residual"]])
    print(json.dumps(output["summary_by_N"], indent=2), flush=True)
    print("Saved " + " and ".join(map(str, paths)), flush=True)


if __name__ == "__main__":
    main()
