"""Forecast from an unperturbed contact, then test the full seven-band matrices."""
from pathlib import Path
from datetime import datetime,timezone
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
import json,sys,hashlib
import numpy as np
from scipy.optimize import minimize
import revision8_numeric_contacts as parent

ROOT=parent.ROOT
cv=parent.cv
CASES={'compatible':(1,0),'breaking':(0,1),'mixed':(1,1)}

def model(x,y,a,eps=0,case='mixed',derivative=False):
    x,y=np.broadcast_arrays(x,y)
    H=cv.hamiltonian(x,y,'literal',t=parent.R,t1=1.,t_AA=a,phi=parent.PHI)
    c,b=CASES[case]
    val=eps*(c+b*np.exp(1j*x));H[...,0,1]+=val;H[...,1,0]+=val.conjugate()
    if not derivative:return H
    assert x.ndim==0
    _,D=parent.matrices([float(x),float(y),a])
    v=1j*eps*b*np.exp(1j*x);D[0,0,1]+=v;D[0,1,0]+=v.conjugate()
    return H,D

def perturb(x,case):
    c,b=CASES[case];V=np.zeros((7,7),complex);V[0,1]=c+b*np.exp(1j*x);V[1,0]=V[0,1].conjugate()
    return V

def projected(z,index,case):
    H,D=model(*z,0,case,True);E,V=np.linalg.eigh(H);W=V[:,index:index+2]
    J=np.array([parent.pauli(W,d) for d in D]).T
    v=parent.pauli(W,perturb(z[0],case));shift=-np.linalg.solve(J,v)
    return shift,np.linalg.det(J),E

def refine(z,index,eps,case):
    z=np.array(z,dtype=float)
    for iteration in range(25):
        H,D=model(*z,eps,case,True);E,V=np.linalg.eigh(H);W=V[:,index:index+2]
        d=parent.pauli(W,H);J=np.array([parent.pauli(W,m) for m in D]).T
        if np.linalg.norm(d)<2e-14:break
        step=np.linalg.solve(J,d);z-=step
        if np.linalg.norm(step)>1:raise RuntimeError('Newton left local neighborhood')
    z[:2]=(z[:2]+np.pi)%(2*np.pi)-np.pi
    assert E[index+1]-E[index]<1e-11
    return {'q':z[:2].tolist(),'a':float(z[2]),'gap':float(E[index+1]-E[index]),'energy':float((E[index]+E[index+1])/2),'iterations':iteration+1,
            'spectator_separations':[float(E[index]-E[index-1]),float(E[index+2]-E[index+1])]}

def topology(a,eps,case,N,offset=(0,0)):
    axis=-np.pi+2*np.pi*np.arange(N)/N
    x,y=np.meshgrid(axis+offset[0]*2*np.pi/N,axis+offset[1]*2*np.pi/N,indexing='ij')
    E,V=np.linalg.eigh(model(x,y,a,eps,case))
    dl=float((E[...,3]-E[...,2]).min());du=float((E[...,4]-E[...,3]).min())
    f=cv._fhs(V,min(dl,du),band=3)
    lower=cv._fhs(V,dl,rank=3);upper=cv._fhs(V,du,rank=4)
    return {'a':a,'epsilon':eps,'case':case,'N':N,'offset':list(offset),'central':f,'lower_group':lower,'upper_group':upper,
            'sampled_direct_gaps':[dl,du],
            'sampled_indirect_gaps':[float(E[...,3].min()-E[...,2].max()),float(E[...,4].min()-E[...,3].max())]}

def run():
    contact=json.loads((ROOT/'research/revision8_numeric_parent_contacts.json').read_text())['contacts'][0]
    z=np.array([*contact['q'],contact['a']]);zp=z.copy();zp[0]=(zp[0]+np.pi+np.pi)%(2*np.pi)-np.pi
    preds={}
    for case in CASES:
        l,detl,El=projected(z,2,case);u,detu,Eu=projected(zp,3,case)
        preds[case]={'lower_contact_shift':l.tolist(),'upper_contact_shift':u.tolist(),'width_coefficient':abs(l[2]-u[2]),'mean_shift':(l[2]+u[2])/2,'simple_contact_determinants':[detl,detu]}
    prediction={'stage':'Saved before any finite-epsilon full-matrix validation in this study',
                'time_utc':datetime.now(timezone.utc).isoformat(),'parent':{'r':parent.R,'phi':parent.PHI,'contact':contact},
                'perturbation':'H01 += epsilon*(c+b*exp(i*qx)), H10 Hermitian conjugate; compatible(c,b)=(1,0), breaking=(0,1),mixed=(1,1)',
                'predictions':preds,'canonical_source_sha256':hashlib.sha256(Path(cv.__file__).read_bytes()).hexdigest()}
    predpath=ROOT/'research/revision8_numeric_frozen_prediction.json'
    if predpath.exists():
        previous=json.loads(predpath.read_text());assert previous['predictions']==preds
    else:predpath.write_text(json.dumps(prediction,indent=2),encoding='utf-8')
    print(json.dumps({'prediction_saved':str(predpath),'predictions':preds}),flush=True)
    contacts=[]
    for case in CASES:
      for eps in [-.04,-.02,-.01,-.005,-.0025,.0025,.005,.01,.02,.04]:
        lo=refine(z+eps*np.array(preds[case]['lower_contact_shift']),2,eps,case)
        up=refine(zp+eps*np.array(preds[case]['upper_contact_shift']),3,eps,case)
        width=abs(lo['a']-up['a']);mean=(lo['a']+up['a'])/2
        rec={'case':case,'epsilon':eps,'lower':lo,'upper':up,'width':width,'width_prediction':preds[case]['width_coefficient']*eps,'mean':mean,'mean_prediction':z[2]+preds[case]['mean_shift']*eps}
        contacts.append(rec);print(json.dumps(rec),flush=True)
    (ROOT/'research/revision8_numeric_finite_contacts.json').write_text(json.dumps(contacts,indent=2),encoding='utf-8')
    checks=[]
    for case in ['breaking','mixed']:
      for eps in [.02,.04]:
        rec=next(r for r in contacts if r['case']==case and r['epsilon']==eps)
        lo=min(rec['lower']['a'],rec['upper']['a']);hi=max(rec['lower']['a'],rec['upper']['a']);w=hi-lo
        for a,position in [(lo-.4*w,'below'),((lo+hi)/2,'inside'),(hi+.4*w,'above')]:
          for N in [96,192]:
            t=topology(a,eps,case,N);t['position']=position;checks.append(t)
            print(json.dumps(t),flush=True)
    (ROOT/'research/revision8_numeric_topology.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')

if __name__=='__main__':run()
