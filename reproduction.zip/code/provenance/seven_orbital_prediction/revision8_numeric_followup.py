"""Additional local-limit and global-grid checks of the frozen forecast."""
import json
import numpy as np
from scipy.optimize import minimize
import revision8_numeric_validate as v
ROOT=v.ROOT

def periodic_distance(p,q):
    d=(p-q+np.pi)%(2*np.pi)-np.pi
    return np.linalg.norm(d)

def extrema(a,eps,case,N=64):
    axis=np.linspace(-np.pi,np.pi,N,endpoint=False)
    x,y=np.meshgrid(axis,axis,indexing='ij')
    E=np.linalg.eigvalsh(v.model(x,y,a,eps,case))
    jobs={
        'direct_lower':(E[...,3]-E[...,2],lambda e:e[3]-e[2]),
        'direct_upper':(E[...,4]-E[...,3],lambda e:e[4]-e[3]),
        'min_central':(E[...,3],lambda e:e[3]),
        'max_central':(-E[...,3],lambda e:-e[3]),
        'max_band2':(-E[...,2],lambda e:-e[2]),
        'min_band4':(E[...,4],lambda e:e[4]),
    }
    out={}
    for name,(grid,fun) in jobs.items():
        seeds=[]
        for flat in np.argsort(grid.ravel()):
            i,j=np.unravel_index(flat,grid.shape);p=np.array([x[i,j],y[i,j]])
            if not any(periodic_distance(p,q)<.4 for q in seeds):seeds.append(p)
            if len(seeds)==12:break
        values=[]
        for p in seeds:
            def objective(q):return fun(np.linalg.eigvalsh(v.model(*q,a,eps,case)))
            opt=minimize(objective,p,method='Nelder-Mead',options={'xatol':2e-11,'fatol':1e-14,'maxiter':500})
            q=(opt.x+np.pi)%(2*np.pi)-np.pi
            if not any(periodic_distance(q,np.array(r['q']))<1e-6 for r in values):
                values.append({'value':float(opt.fun),'q':q.tolist(),'success':bool(opt.success)})
        values.sort(key=lambda d:d['value']);out[name]=values
    out['refined_indirect_gaps']=[out['min_central'][0]['value']+out['max_band2'][0]['value'],out['min_band4'][0]['value']+out['max_central'][0]['value']]
    out['scope']='64x64 seed grid, 12 separated seeds per scalar extremum; numerical search, not an interval-certified global bound'
    return out

def run():
    pred=json.loads((ROOT/'research/revision8_numeric_frozen_prediction.json').read_text())
    contact=pred['parent']['contact'];z=np.array([*contact['q'],contact['a']]);zp=z.copy();zp[0]=(z[0]+2*np.pi)%(2*np.pi)-np.pi
    finer=[]
    for case in v.CASES:
      p=pred['predictions'][case]
      for eps in [-.00125,-.000625,.000625,.00125]:
        lo=v.refine(z+eps*np.array(p['lower_contact_shift']),2,eps,case)
        up=v.refine(zp+eps*np.array(p['upper_contact_shift']),3,eps,case)
        finer.append({'case':case,'epsilon':eps,'lower':lo,'upper':up,'width':abs(lo['a']-up['a']),'width_prediction':abs(eps)*p['width_coefficient'],
                      'mean':(lo['a']+up['a'])/2,'mean_prediction':z[2]+p['mean_shift']*eps})
    (ROOT/'research/revision8_numeric_asymptotic_contacts.json').write_text(json.dumps(finer,indent=2),encoding='utf-8')
    records=json.loads((ROOT/'research/revision8_numeric_finite_contacts.json').read_text())
    checks=[]
    for case in ['breaking','mixed']:
        row=next(r for r in records if r['case']==case and r['epsilon']==.02)
        a=row['mean'];t=v.topology(a,.02,case,192,offset=(.37,.23));t['extrema']=extrema(a,.02,case);checks.append(t)
    for a in [z[2]-.04,z[2]+.04]:
        t=v.topology(a,0,'compatible',192,offset=(.37,.23));t['position']='parent';checks.append(t)
    compatible=next(r for r in records if r['case']=='compatible' and r['epsilon']==.02)
    for a in [compatible['mean']-.025,compatible['mean']+.025]:
        t=v.topology(a,.02,'compatible',192,offset=(.37,.23));t['position']='compatible-sides';checks.append(t)
    (ROOT/'research/revision8_numeric_additional_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    initial={'epsilon':.08,'case':'compatible','event':'Direct Newton step initialized at first-order parent prediction exceeded the local radius of 1; stopped rather than asserting a continued root.',
             'interpretation':'Not a proof of a phase-boundary termination. Finite-epsilon validation range restricted to abs(epsilon)<=.04; explicit small-epsilon checks also performed.',
             'selection':'Real 01 bond selected from unperturbed projected masses before finite-epsilon spectra; parent-only candidate table retained.'}
    (ROOT/'research/revision8_numeric_scope_record.json').write_text(json.dumps(initial,indent=2),encoding='utf-8')
    # Retain full-grid eigenvalues and central-band plaquette curvature for the
    # representative epsilon=.02 slice; eigenvectors are reproducible from H.
    arrays={}
    for case in ['breaking','mixed']:
        row=next(r for r in records if r['case']==case and r['epsilon']==.02)
        N=192;axis=np.linspace(-np.pi,np.pi,N,endpoint=False);x,y=np.meshgrid(axis,axis,indexing='ij')
        E,V=np.linalg.eigh(v.model(x,y,row['mean'],.02,case));u=V[...,3]
        ux=np.sum(u.conj()*np.roll(u,-1,0),axis=-1);uy=np.sum(u.conj()*np.roll(u,-1,1),axis=-1)
        ux/=abs(ux);uy/=abs(uy);flux=np.angle(ux*np.roll(uy,-1,0)*np.roll(ux,-1,1).conj()*uy.conj())
        arrays[case+'_eigenvalues']=E;arrays[case+'_central_plaquette_flux']=flux
        arrays[case+'_parameters']=np.array([v.parent.R,v.parent.PHI,row['mean'],.02]);arrays['axis']=axis
    np.savez_compressed(ROOT/'research/revision8_numeric_representative_grids.npz',**arrays)
    print(json.dumps({'additional_points':len(checks),'small_epsilon_contacts':len(finer),'refined_inside_gaps':[{ 'case':r['case'],'direct':[r['extrema']['direct_lower'][0]['value'],r['extrema']['direct_upper'][0]['value']],'indirect':r['extrema']['refined_indirect_gaps']} for r in checks if 'extrema' in r]}))

if __name__=='__main__':run()
