from pathlib import Path
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[name]='1'
import sys,json
import numpy as np
from scipy.optimize import minimize
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'seven_orbital_reproduction/code'))
import c3n4_verified as cv

def run():
    records=[]
    for r in [1.,.4]:
      phi=3*np.pi/8 if r==1 else 13*np.pi/32
      for a in [.2,.5,.8,1.,1.2,1.5,1.8,2.,2.5,3.,4.]:
        d=cv.evaluate('literal',N=32,t=r,t1=1.,t_AA=a,phi=phi)
        v=cv.concise(d)
        records.append({'r':r,'phi':phi,'a':a,'result':v})
        print(json.dumps(records[-1]),flush=True)
    (ROOT/'research/revision8_numeric_parent_scan.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
if __name__=='__main__':run()
