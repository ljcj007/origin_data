from pathlib import Path
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[name]='1'
import sys,json
import numpy as np
from scipy.optimize import minimize
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'seven_orbital_reproduction/code'))
import c3n4_verified as cv
R=.4
PHI=13*np.pi/32
U=np.diag([1,-1,-1,-1,1,-1,-1])
PAULI=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)

def matrices(z):
    x,y,a=z
    H=np.zeros((7,7),complex);D=np.zeros((3,7,7),complex)
    for i,j,rx,ry,v in cv.hoppings('literal',t=R,t_AA=a,phi=PHI):
        term=v*np.exp(1j*(rx*x+ry*y));H[i,j]+=term
        D[0,i,j]+=1j*rx*term;D[1,i,j]+=1j*ry*term
    for i,j,rx,ry,v in cv.hoppings('literal',t=0,t1=0,t_AA=1,phi=PHI):D[2,i,j]+=v
    return H,D

def pauli(W,A):return np.einsum('iab,ba->i',PAULI,W.conj().T@A@W).real/2

def refine(z,index=2):
    z=np.array(z,dtype=float)
    for _ in range(12):
        H,D=matrices(z);E,V=np.linalg.eigh(H);W=V[:,index:index+2]
        d=pauli(W,H);vel=np.array([pauli(W,m) for m in D]).T
        if np.linalg.norm(d)<2e-15:break
        z-=np.linalg.solve(vel,d)
    z[:2]=(z[:2]+np.pi)%(2*np.pi)-np.pi
    return z

def run():
    axis=np.linspace(-np.pi,np.pi,30,endpoint=False)
    xx,yy=np.meshgrid(axis,axis,indexing='ij')
    seeds=[]
    for a in [1.15,1.25,1.35,1.45]:
        E=np.linalg.eigvalsh(cv.hamiltonian(xx,yy,'literal',t=R,t_AA=a,phi=PHI))
        gap=E[...,3]-E[...,2]
        for flat in np.argsort(gap.ravel())[:8]:
            i,j=np.unravel_index(flat,gap.shape);seeds.append([xx[i,j],yy[i,j],a])
    unique=[]
    for start in seeds:
        def objective(z):
            E=np.linalg.eigvalsh(matrices(z)[0]);return (E[3]-E[2])**2
        o=minimize(objective,start,method='L-BFGS-B',bounds=[(None,None),(None,None),(1.,1.6)],options={'ftol':1e-30,'gtol':1e-12,'maxiter':300})
        if o.fun>1e-12:continue
        z=refine(o.x)
        if not any(np.linalg.norm(z-zold)<1e-6 for zold in unique):unique.append(z)
    records=[]
    for z in unique:
        H,D=matrices(z);E,V=np.linalg.eigh(H);W=V[:,2:4]
        vx,vy,va=[pauli(W,m) for m in D];n=np.cross(vx,vy);den=n@va
        x,y,a=z
        Vc=np.zeros((7,7),complex);Vc[0,2]=Vc[2,0]=1
        Vb=np.zeros((7,7),complex);Vb[0,2]=np.exp(1j*x);Vb[2,0]=np.exp(-1j*x)
        alpha=-(n@pauli(W,Vc))/den;beta=-(n@pauli(W,Vb))/den
        rec={'q':z[:2].tolist(),'a':a,'energy':(E[2]+E[3])/2,'gap':E[3]-E[2],
             'spectrum':E.tolist(),'D':den,'velocities':[vx.tolist(),vy.tolist(),va.tolist()],
             'alpha_for_Vc_02_R0':alpha,'beta_for_Vb_02_R10':beta,
             'prediction_status':'parent-only; no finite-epsilon spectrum calculated yet'}
        records.append(rec);print(json.dumps(rec),flush=True)
    (ROOT/'research/revision8_numeric_parent_contacts.json').write_text(json.dumps({'r':R,'phi':PHI,'contacts':records},indent=2),encoding='utf-8')
if __name__=='__main__':run()
