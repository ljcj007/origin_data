"""Render the seven-orbital prediction test from saved, full-precision results."""
from pathlib import Path
import csv
import hashlib
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from plot_joint_figures import PURPLE, GREEN, RED, GRAY, DARK

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'source_data'
plt.rcParams.update({'legend.fontsize':6.5,'lines.linewidth':1.0})

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    inputs=['seven_orbital_prediction_frozen.json','seven_orbital_contacts.json','seven_orbital_topology.json']
    forecast=json.loads((DATA/inputs[0]).read_text(encoding='utf-8'))
    contacts=json.loads((DATA/inputs[1]).read_text(encoding='utf-8'))
    topology=json.loads((DATA/inputs[2]).read_text(encoding='utf-8'))
    actual_hash=digest(DATA/inputs[0])
    assert contacts['forecast_sha256']==topology['forecast_sha256']==actual_hash
    records=contacts['records']; a0=forecast['parent']['contact']['a']
    pred=forecast['predictions']['mixed']
    lower_slope=pred['lower_contact_shift'][2]
    upper_slope=pred['upper_contact_shift'][2]
    width_slope=pred['width_coefficient']
    fig,axs=plt.subplots(1,3,figsize=(7.05,2.50),layout='constrained',
                         gridspec_kw={'width_ratios':[1.12,1,1]})
    ax=axs[0]
    selected=sorted([r for r in records if r['case']=='mixed' and abs(r['epsilon'])<=.02000001],key=lambda r:r['epsilon'])
    ee=np.array([r['epsilon'] for r in selected])
    axis=np.linspace(-.020,.020,200)
    for branch,marker,slope,style in [('lower','o',lower_slope,'-'),('upper','^',upper_slope,':')]:
        values=np.array([r[branch]['a'] for r in selected])
        ax.plot(axis,a0+slope*axis,'--',color=GRAY,lw=.9,
                label='Parent prediction' if branch=='lower' else None)
        ax.plot(ee,values,color=RED,lw=.7,alpha=.8,ls=style)
        ax.scatter(ee,values,s=12,marker=marker,facecolor='white',edgecolor=RED,
                   linewidth=.9,zorder=3,label='Full seven-band contacts' if branch=='lower' else None)
    ax.scatter([0],[a0],s=15,color=GRAY,zorder=4)
    ax.set(xlabel=r'Perturbation $\epsilon$',ylabel=r'Critical loop amplitude $a$',
           xlim=(-.0215,.0215),ylim=(1.16,1.40),xticks=[-.02,0,.02],
           title=r'Mixed control $V_{\rm c}+V_{\rm b}$')
    ax.legend(loc='upper left',handlelength=1.5,borderaxespad=.2)

    ax=axs[1]
    for case,name,color,marker,style in [('compatible','Compatible',GREEN,'s','-.'),
                                  ('breaking','Breaking',PURPLE,'o','-'),
                                  ('mixed','Mixed',RED,'^','--')]:
        selected=sorted([r for r in records if r['case']==case and r['epsilon']>0],key=lambda r:r['epsilon'])
        eps=np.array([r['epsilon'] for r in selected])
        values=np.array([r['width']/r['epsilon'] for r in selected])
        ax.plot(eps,values,marker=marker,markersize=3,color=color,label=name,ls=style)
    ax.axhline(width_slope,color=DARK,ls=':',lw=.8,zorder=1)
    ax.text(.00067,2.14,r'$2|\beta|=1.94$',fontsize=7)
    ax.set(xscale='log',xlabel=r'Perturbation $\epsilon>0$',ylabel=r'Width $\Delta a/\epsilon$',
           xlim=(.0005,.052),ylim=(-.14,3.66),title='Width prediction')
    ax.legend(loc='upper left',bbox_to_anchor=(.02,1.0),ncol=1,handlelength=1.3,
              fontsize=6.3,labelspacing=.18,borderaxespad=.1)

    ax=axs[2]
    csv_rows=[]
    for case,name,color,marker,style in [('breaking','Breaking',PURPLE,'o','-'),('mixed','Mixed',RED,'^','--')]:
        data=sorted([r for r in topology['records'] if r['case']==case and
                     r['epsilon']==.02 and r['N']==192 and r['offset']==[0,0]],key=lambda r:r['a'])
        assert [r['central']['chern_integer'] for r in data]==[0,1,2]
        cr=next(r for r in records if r['case']==case and r['epsilon']==.02)
        left,right=sorted([cr['lower']['a'],cr['upper']['a']])
        ax.plot([data[0]['a'],left,left,right,right,data[-1]['a']],
                [0,0,1,1,2,2],color=color,lw=1.0,ls=style)
        ax.axvspan(left,right,color=color,alpha=.07,lw=0,zorder=.1)
        ax.scatter([r['a'] for r in data],[r['central']['chern_raw'] for r in data],
                   marker=marker,s=18,color=color,zorder=3,label=name)
        csv_rows.extend({'case':case,'epsilon':r['epsilon'],'a':r['a'],
                         'N':r['N'],'chern_raw':r['central']['chern_raw'],
                         'contact_lower_a':left,'contact_upper_a':right} for r in data)
    ax.set(xlabel=r'Loop amplitude $a$',ylabel=r'Central Chern number $C_c$',
           xlim=(1.22,1.405),ylim=(-.15,2.55),yticks=[0,1,2],xticks=[1.24,1.32,1.40],
           title=r'Full-band topology, $\epsilon=0.0200$')
    ax.legend(loc='upper left',fontsize=6.5,handlelength=1,borderaxespad=.1)
    for ax,lab in zip(axs,'abc'):
        ax.text(-.21,1.10,lab,transform=ax.transAxes,fontweight='bold',fontsize=9,va='top')
    out=ROOT.parent/'figures'/'PRL';out.mkdir(exist_ok=True)
    for ext in ['pdf','svg','png','tiff']:
        fig.savefig(out/f'seven_orbital_predict.{ext}',dpi=600,
                    bbox_inches='tight',pad_inches=.04)
    plt.close(fig)
    with (DATA/'seven_orbital_plot_points.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(csv_rows[0]));writer.writeheader();writer.writerows(csv_rows)
    metadata={'figure':'PRL Figure 3','inputs':{n:digest(DATA/n) for n in inputs},
              'render_source_sha256':digest(Path(__file__)),
              'shared_style_source_sha256':digest(Path(__file__).with_name('plot_joint_figures.py')),
              'semantic_colors':{'compatible':GREEN,'breaking':PURPLE,'mixed':RED,'parent_prediction':GRAY},
              'predicted_slopes':[lower_slope,upper_slope],'predicted_width_slope':width_slope,
              'fit_to_finite_epsilon_results':False,
              'panel_c_note':'Symbols are sampled raw FHS values. Step guides follow the independently continued contacts over the sampled interval.',
              'outputs':{f'seven_orbital_predict.{e}':digest(out/f'seven_orbital_predict.{e}') for e in ['pdf','svg','png','tiff']}}
    (DATA/'seven_orbital_figure_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'figure':'seven_orbital_predict','width_slope':width_slope,'source_hashes_verified':True}))

if __name__=='__main__':
    main()
