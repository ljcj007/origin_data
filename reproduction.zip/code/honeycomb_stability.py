"""Uniform local stability bounds for the manuscript honeycomb parameter point.

No production source is modified. The parameter box and mesh are fixed before
evaluating its spectrum. A hopping-row norm bound covers the complete momentum
torus and parameter box. Finite-precision spectra use an explicit 1e-10 energy
guard; this is not an interval-arithmetic/machine-certified computation.
Corner FHS and local extrema are numerical cross-checks, not the basis for
covering the box. Units are t1=t=1; band indices start at zero.
"""
from pathlib import Path
from itertools import product
import argparse
import csv
import hashlib
import json
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
CANONICAL = ROOT/'seven_orbital_reproduction/code/c3n4_verified.py'
sys.path.insert(0,str(CANONICAL.parent))
import c3n4_verified as cv

BASE = dict(t=1.,t1=1.,t_NNN=.35,nnn_phi=5*np.pi/6,mass=.5)
HALF = dict(t_NNN=.01,nnn_phi=.01,mass=.01)
N = 768
GUARD = 1e-10

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

def row_bounds():
    rows = np.zeros(7)
    for i,j,rx,ry,amp in cv.hoppings('honeycomb_haldane',**BASE):
        rows[i] += abs(amp)*(abs(rx)+abs(ry))
    counts = np.bincount([i for i,j,rx,ry,sgn in cv.HALDANE_NNN],minlength=7)
    changes = [np.sqrt((t-BASE['t_NNN'])**2 + 4*t*BASE['t_NNN']*np.sin(HALF['nnn_phi']/2)**2)
               for t in (BASE['t_NNN']-HALF['t_NNN'],BASE['t_NNN']+HALF['t_NNN'])]
    dz = float(max(changes))
    parameter_rows = counts*dz+HALF['mass']
    return rows, counts, dz, parameter_rows

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-prefix',type=Path,default=ROOT/'source_data/honeycomb_stability_recomputed')
    args = parser.parse_args()
    prefix = args.output_prefix
    prefix.parent.mkdir(parents=True,exist_ok=True)
    out = prefix.with_suffix('.json')
    assert not out.exists(), 'Choose a new output prefix to preserve prior results.'
    rows,counts,dz,parameter_rows = row_bounds()
    plan = {'model':'honeycomb_haldane','base_parameters':BASE,'parameter_halfwidths':HALF,
            'fixed_N':N,'energy_roundoff_guard':GUARD,'momentum_row_norms':rows.tolist(),
            'NNN_terms_per_row':counts.tolist(),'max_NNN_amplitude_change':dz,
            'parameter_row_norms':parameter_rows.tolist(),
            'corner_meshes':[48,96],'corner_local_refinement':'96^2 grid, four starts for each extremum',
            'source_sha256':{str(CANONICAL.relative_to(ROOT)).replace('\\','/'):digest(CANONICAL),
                             str(Path(__file__).relative_to(ROOT)).replace('\\','/'):digest(Path(__file__))},
            'timing_scope':'Plan written before any spectra in this run.'}
    save(prefix.with_name(prefix.name+'_plan.json'),plan)
    start=time.monotonic()
    axis=np.linspace(-np.pi,np.pi,N,endpoint=False)
    emin=np.full(7,np.inf); emax=np.full(7,-np.inf); direct=np.full(6,np.inf)
    # Streaming eigvalsh avoids retaining a full 768^2 x 7 x 7 complex array.
    for offset in range(0,N,32):
        H=cv.hamiltonian(axis[offset:offset+32,None],axis[None,:],'honeycomb_haldane',**BASE)
        energies=np.linalg.eigvalsh(H)
        emin=np.minimum(emin,energies.min(axis=(0,1)))
        emax=np.maximum(emax,energies.max(axis=(0,1)))
        direct=np.minimum(direct,np.diff(energies,axis=-1).min(axis=(0,1)))
    eta_k=float(rows.max()*np.pi/N)
    eta_p=float(parameter_rows.max())
    eta=eta_k+eta_p+GUARD
    width=float(emax[3]-emin[3]); lower=float(emin[3]-emax[2]); upper=float(emin[4]-emax[3])
    bound_lower=lower-2*eta; bound_upper=upper-2*eta; bound_width=width+2*eta
    bounds={'center_mesh_energy_min':emin.tolist(),'center_mesh_energy_max':emax.tolist(),
            'center_mesh_direct_gaps':direct.tolist(),'center_mesh_bandwidth':width,
            'center_mesh_indirect_lower':lower,'center_mesh_indirect_upper':upper,
            'momentum_cover_norm':eta_k,'parameter_box_norm':eta_p,'total_energy_uncertainty':eta,
            'uniform_indirect_lower_bound':bound_lower,'uniform_indirect_upper_bound':bound_upper,
            'uniform_bandwidth_upper_bound':bound_width,
            'uniform_min_gap_to_bandwidth_lower_bound':min(bound_lower,bound_upper)/bound_width,
            'uniform_gap_minus_bandwidth_lower_bound':min(bound_lower,bound_upper)-bound_width,
            'both_indirect_gaps_positive':bool(min(bound_lower,bound_upper)>0),
            'min_indirect_gap_greater_than_bandwidth':bool(min(bound_lower,bound_upper)>bound_width)}
    print(json.dumps({'stage':'uniform bounds complete','elapsed_seconds':time.monotonic()-start,'bounds':bounds}),flush=True)
    cases=[]
    signs=[(0,0,0),*product((-1,1),repeat=3)]
    for case_index,sgns in enumerate(signs):
        params=dict(BASE)
        for name,sign in zip(('t_NNN','nnn_phi','mass'),sgns):params[name]+=sign*HALF[name]
        results=[cv.evaluate('honeycomb_haldane',N=n,refine=(n==96),nstarts=4,**params) for n in (48,96)]
        record={'case':'center' if case_index==0 else f'corner_{case_index}',
                'parameter_signs':list(sgns),'parameters':params,'results':results}
        cases.append(record)
        refined=results[-1]['refined']
        f=min(refined['indirect_lower'],refined['indirect_upper'])/refined['central_bandwidth']
        print(json.dumps({'stage':record['case'],'elapsed_seconds':time.monotonic()-start,
                          'chern':[r['band_chern'] for r in results],
                          'refined_indirect':[refined['indirect_lower'],refined['indirect_upper']],
                          'refined_bandwidth':refined['central_bandwidth'],'refined_ratio':f}),flush=True)
    report={'plan':plan,'uniform_spectral_bounds':bounds,'cases':cases,
            'topology_inference':'The positive uniform indirect gaps imply both adjacent direct gaps remain open throughout the connected parameter box. The central-band Chern number is consequently constant, equal to the numerically established center value -1. The norm bound does not by itself compute that center integer.',
            'mathematical_bound':'For every k, use the nearest periodic mesh node k_j: ||H_0(k)-H_0(k_j)|| <= pi/N max_i sum_edges |h_ij(R)| (|Rx|+|Ry|). For every parameter in the fixed box, ||H(k)-H_0(k)|| <= max_i d_i max|t2 exp(i theta)-t20 exp(i theta0)|+|m-m0|. Weyl shifts each energy by no more than the sum. Each indirect gap decreases by at most twice that sum; bandwidth increases by at most twice it.',
            'numerical_limit':'The continuous-domain covering inequalities are analytic. Finite-grid eigenvalues are computed in ordinary double precision with a declared 1e-10 energy guard; no directed-rounding interval eigensolver is used. Corner FHS and multistart local extrema are numerical checks and do not certify extrema in parameter space.',
            'no_many_body_claim':True,'author_independent_verification_claimed':False,
            'elapsed_seconds':time.monotonic()-start}
    save(out,report)
    with prefix.with_suffix('.csv').open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['case','t2','theta','m','C_48','C_96','indirect_lower_refined','indirect_upper_refined','bandwidth_refined','min_gap_to_bandwidth_refined'])
        writer.writeheader()
        for c in cases:
            r=c['results'][-1]['refined']
            writer.writerow({'case':c['case'],'t2':c['parameters']['t_NNN'],'theta':c['parameters']['nnn_phi'],'m':c['parameters']['mass'],
                             'C_48':c['results'][0]['band_chern']['chern_integer'],'C_96':c['results'][1]['band_chern']['chern_integer'],
                             'indirect_lower_refined':r['indirect_lower'],'indirect_upper_refined':r['indirect_upper'],
                             'bandwidth_refined':r['central_bandwidth'],
                             'min_gap_to_bandwidth_refined':min(r['indirect_lower'],r['indirect_upper'])/r['central_bandwidth']})
    print(json.dumps({'output':str(out),'elapsed_seconds':time.monotonic()-start}),flush=True)

if __name__=='__main__':main()
