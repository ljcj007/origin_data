"""Three-orbital Hofstadter-derived test of a broken shifted-chiral constraint.

This is a controlled deformation of a known square-lattice Hofstadter model,
not a claim of a new symmetry class.  The magnetic/structural unit cell has
three inequivalent orbitals.  All Fourier translations are integers on the
primitive (kx,ky) torus [-pi,pi)^2.  Its physical x momentum is kx/3 when
the underlying square-lattice spacing is one.

H_jj=-2 v_j cos(ky+2 pi j/3)+mu delta_j0,
H_01=-a, H_12=-b, H_20=-c exp(i kx), with Hermitian reverses.
At mu=0, U H(k+(pi,pi)) U = -H(k), U=diag(1,-1,1).
The onsite mu term breaks this relation and splits a simultaneous pair of
band contacts under the symmetry-preserving control a.

Only NumPy and SciPy are required.  Running the script writes the small
JSON evidence table and NPZ plotting arrays.  No plotting is performed.
"""
from pathlib import Path
import argparse
import json
import numpy as np
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_V = np.array([1.0, 1.05, 0.95])
B, C = 0.95, 1.05
U_SHIFT = np.diag([1.0, -1.0, 1.0])


def hamiltonian(kx, ky, a=1.0, mu=0.0, v=DEFAULT_V, b=B, c=C):
    """Broadcast momenta; return shape (...,3,3), with energies in t=1 units."""
    kx, ky = np.broadcast_arrays(kx, ky)
    h = np.zeros(kx.shape+(3, 3), dtype=complex)
    for j in range(3):
        h[..., j, j] = -2*v[j]*np.cos(ky+2*np.pi*j/3)
    h[..., 0, 0] += mu
    h[..., 0, 1] = h[..., 1, 0] = -a
    h[..., 1, 2] = h[..., 2, 1] = -b
    h[..., 2, 0] = -c*np.exp(1j*kx)
    h[..., 0, 2] = -c*np.exp(-1j*kx)
    return h


def derivatives(kx, ky, a=1.0, mu=0.0, v=DEFAULT_V, b=B, c=C):
    dx, dy, da = (np.zeros((3, 3), complex) for _ in range(3))
    dx[2, 0] = -1j*c*np.exp(1j*kx)
    dx[0, 2] = 1j*c*np.exp(-1j*kx)
    dy[np.diag_indices(3)] = 2*np.asarray(v)*np.sin(ky+2*np.pi*np.arange(3)/3)
    da[0, 1] = da[1, 0] = -1
    return dx, dy, da


def _link(u, axis):
    overlap = np.einsum('...in,...in->...n', u.conj(), np.roll(u, -1, axis))
    minimum = float(np.min(np.abs(overlap)))
    if minimum < 1e-12:
        raise ValueError('Unresolved zero individual-band overlap')
    return overlap/np.abs(overlap), minimum


def chern_mesh(a, mu, n=96, return_arrays=False):
    """Positive overlap-plaquette convention, matching the original project."""
    k = np.linspace(-np.pi, np.pi, n, endpoint=False)
    x, y = np.meshgrid(k, k, indexing='ij')
    e, u = np.linalg.eigh(hamiltonian(x, y, a, mu))
    lx, ox = _link(u, 0)
    ly, oy = _link(u, 1)
    f = np.angle(lx*np.roll(ly, -1, 0)*np.conj(np.roll(lx, -1, 1))*np.conj(ly))
    ch = f.sum(axis=(0, 1))/(2*np.pi)
    group_cherns = []
    for rank in (1, 2):
        selected = u[..., :rank]
        wx = np.einsum('...ia,...ib->...ab', selected.conj(), np.roll(selected, -1, 0))
        wy = np.einsum('...ia,...ib->...ab', selected.conj(), np.roll(selected, -1, 1))
        ux, uy = np.linalg.det(wx), np.linalg.det(wy)
        ux, uy = ux/np.abs(ux), uy/np.abs(uy)
        flux = np.angle(ux*np.roll(uy, -1, 0)*np.conj(np.roll(ux, -1, 1))*np.conj(uy))
        group_cherns.append(float(flux.sum()/(2*np.pi)))
    gap = np.diff(e, axis=-1)
    result = {
        'N': int(n), 'chern': ch.tolist(),
        'occupied_group_chern': group_cherns,
        'minimum_direct_gaps_mesh': gap.min(axis=(0, 1)).tolist(),
        'minimum_neighbor_overlap': min(ox, oy),
        'maximum_absolute_plaquette_phase': np.max(np.abs(f), axis=(0, 1)).tolist(),
        'indirect_gaps_mesh': (e[..., 1:].min(axis=(0, 1))-e[..., :-1].max(axis=(0, 1))).tolist(),
        'bandwidths_mesh': np.ptp(e, axis=(0, 1)).tolist(),
    }
    if return_arrays:
        return result, {'k': k, 'energies': e, 'plaquette_flux': f}
    return result


def refine_gaps(a, mu, n=64, nstarts=12):
    """Periodic multistart local refinement, not a global optimization proof."""
    k = np.linspace(-np.pi, np.pi, n, endpoint=False)
    x, y = np.meshgrid(k, k, indexing='ij')
    e = np.linalg.eigvalsh(hamiltonian(x, y, a, mu))
    result = []
    for gap_index in range(2):
        gap = np.diff(e, axis=-1)[..., gap_index]
        candidates = np.argsort(gap.ravel())[:nstarts]
        solutions = []
        for flat in candidates:
            i, j = np.unravel_index(flat, gap.shape)
            def objective(q):
                levels = np.linalg.eigvalsh(hamiltonian(q[0], q[1], a, mu))
                return float(levels[gap_index+1]-levels[gap_index])
            fit = minimize(objective, [k[i], k[j]], method='Nelder-Mead',
                           options={'xatol': 2e-11, 'fatol': 2e-13, 'maxiter': 700})
            solutions.append(fit)
        best = min(solutions, key=lambda fit: fit.fun)
        result.append({'gap_index': gap_index, 'direct_gap': float(best.fun),
                       'k': ((best.x+np.pi) % (2*np.pi)-np.pi).tolist(),
                       'optimizer_success': bool(best.success)})
    return result


def refine_band_extrema(a, mu, n=64, nstarts=8):
    """Refine each energy range independently before forming indirect gaps."""
    k = np.linspace(-np.pi, np.pi, n, endpoint=False)
    x, y = np.meshgrid(k, k, indexing='ij')
    e = np.linalg.eigvalsh(hamiltonian(x, y, a, mu))
    minima, maxima = [], []
    for band in range(3):
        for sign, output in [(1, minima), (-1, maxima)]:
            score = sign*e[..., band]
            fits = []
            for flat in np.argsort(score.ravel())[:nstarts]:
                i, j = np.unravel_index(flat, score.shape)
                def objective(q):
                    return sign*float(np.linalg.eigvalsh(hamiltonian(q[0],q[1],a,mu))[band])
                fits.append(minimize(objective,[k[i],k[j]],method='Nelder-Mead',
                                     options={'xatol':2e-11,'fatol':2e-13,'maxiter':700}))
            best = min(fits,key=lambda fit:fit.fun)
            output.append(sign*float(best.fun))
    return {'energy_minima':minima, 'energy_maxima':maxima,
            'indirect_gaps':(np.array(minima)[1:]-np.array(maxima)[:-1]).tolist(),
            'bandwidths':(np.array(maxima)-np.array(minima)).tolist(),
            'method':'Periodic multistart local extrema, not a global optimization certificate.'}


def contact_vectors(v=DEFAULT_V, b=B, c=C):
    """Analytic rank-one condition: (cos y,sin y)=mu*w+sigma*(a*u+z/a)."""
    v0, v1, v2 = v
    matrix = np.array([[2*v0+v1, np.sqrt(3)*v1],
                       [v1-v2, np.sqrt(3)*(v1+v2)]])
    w = np.linalg.solve(matrix, [1., 0.])
    u = np.linalg.solve(matrix, [-(c/b-b/c), b/c])
    z = np.linalg.solve(matrix, [0., -b*c])
    return w, u, z


def all_contacts(mu, v=DEFAULT_V, b=B, c=C):
    """All finite positive-a double-band contacts, obtained from a quartic.

    Off-diagonal products force sin(kx)=0 at a double eigenvalue.  The matrix
    H-EI then has rank one, so its diagonal entries are sigma*(ac/b,ab/c,bc/a).
    The remaining condition cos(ky)^2+sin(ky)^2=1 is the quartic below.
    sigma=-1 corresponds to kx=0 and +1 to kx=pi.
    """
    w, u, z = contact_vectors(v, b, c)
    contacts = []
    for sigma in (-1, 1):
        coefficients = [u@u, 2*mu*sigma*(w@u), mu*mu*(w@w)+2*(u@z)-1,
                        2*mu*sigma*(w@z), z@z]
        for root in np.roots(coefficients):
            if abs(root.imag) > 1e-9 or root.real <= 0:
                continue
            a = float(root.real)
            xy = mu*w+sigma*(a*u+z/a)
            ky = float(np.arctan2(xy[1], xy[0]))
            kx = 0.0 if sigma == -1 else float(np.pi)
            e, states = np.linalg.eigh(hamiltonian(kx, ky, a, mu, v, b, c))
            index = int(np.argmin(np.diff(e)))
            basis = states[:, index:index+2]
            pauli = []
            for dh in derivatives(kx, ky, a, mu, v, b, c):
                p = basis.conj().T@dh@basis
                pauli.append([p[0, 1].real, -p[0, 1].imag, (p[0, 0].real-p[1, 1].real)/2])
            jac = np.array(pauli).T
            contacts.append({
                'a': a, 'mu': float(mu), 'sigma': sigma, 'kx': kx, 'ky': ky,
                'energy': float(np.mean(e[index:index+2])), 'gap_index': index,
                'eigenvalue_gap_residual': float(e[index+1]-e[index]),
                'trigonometric_norm_residual': float(abs(xy@xy-1)),
                'pauli_velocity_determinant_kx_ky_a': float(np.linalg.det(jac)),
                'quartic_coefficients_descending': [float(x) for x in coefficients],
            })
    return sorted(contacts, key=lambda row: (row['a'], row['sigma']))


def upper_contacts(mu):
    """The two contacts near a=3, sorted by the amplitude a."""
    selected = [row for row in all_contacts(mu) if row['a'] > 1]
    if len(selected) != 2:
        raise ValueError('Expected two upper-branch contacts')
    return selected


def symmetry_residual(a=1.0, mu=0.0):
    k = np.linspace(-np.pi, np.pi, 17, endpoint=False)
    x, y = np.meshgrid(k, k, indexing='ij')
    h = hamiltonian(x, y, a, mu)
    hs = hamiltonian(x+np.pi, y+np.pi, a, mu)
    return float(np.max(np.abs(U_SHIFT@hs@U_SHIFT+h)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'source_data')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    named_cases = [
        ('known_phase_deformed', 1.0, 0.0, [-1, 2, -1]),
        ('symmetric_before', 2.9, 0.0, [-1, 2, -1]),
        ('symmetric_after', 3.4, 0.0, [0, 0, 0]),
        ('broken_before', 2.9, 0.2, [-1, 2, -1]),
        ('broken_odd', 3.15, 0.2, [-1, 1, 0]),
        ('broken_after', 3.4, 0.2, [0, 0, 0]),
        ('broken_odd_larger_mu', 3.15, 0.5, [-1, 1, 0]),
    ]
    cases = []
    for name, a, mu, expected in named_cases:
        grids = [chern_mesh(a, mu, n) for n in (48, 96, 192)]
        for row in grids:
            assert np.max(np.abs(np.array(row['chern'])-expected)) < 1e-8
            assert np.max(np.abs(np.array(row['occupied_group_chern'])-np.cumsum(expected)[:2])) < 1e-8
        refined = refine_gaps(a, mu)
        assert min(row['direct_gap'] for row in refined) > 0.01
        cases.append({'name': name, 'a': a, 'mu': mu, 'expected_chern': expected,
                      'grid_convergence': grids, 'refined_gaps': refined,
                      'refined_energy_ranges': refine_band_extrema(a, mu),
                      'shifted_chiral_matrix_residual': symmetry_residual(a, mu)})
    mus = np.linspace(0.0, 0.6, 121)
    contacts = [upper_contacts(mu) for mu in mus]
    ac = np.array([[row['a'] for row in pair] for pair in contacts])
    w, u, z = contact_vectors()
    a0 = upper_contacts(0)[0]['a']
    vector = a0*u+z/a0
    derivative = u-z/a0**2
    slopes = {str(sigma): float(-sigma*(w@vector)/(derivative@vector)) for sigma in (-1, 1)}
    _, arrays = chern_mesh(3.15, 0.2, 192, return_arrays=True)
    q = np.linspace(-np.pi, np.pi, 301)
    path_x = np.concatenate([q, np.full_like(q, np.pi), q[::-1], np.full_like(q, -np.pi)])
    path_y = np.concatenate([np.full_like(q, -np.pi), q, np.full_like(q, np.pi), q[::-1]])
    np.savez_compressed(args.output/'independent_model_source.npz',
                        mu=mus, a_critical=ac,
                        contact_kx=np.array([[r['kx'] for r in pair] for pair in contacts]),
                        contact_ky=np.array([[r['ky'] for r in pair] for pair in contacts]),
                        contact_energy=np.array([[r['energy'] for r in pair] for pair in contacts]),
                        odd_case_a=np.array(3.15), odd_case_mu=np.array(0.2),
                        odd_case_k=arrays['k'], odd_case_energies=arrays['energies'],
                        odd_case_plaquette_flux=arrays['plaquette_flux'],
                        boundary_path_kx=path_x, boundary_path_ky=path_y,
                        boundary_path_energies=np.linalg.eigvalsh(hamiltonian(path_x,path_y,3.15,.2)))
    report = {
        'model': 'Three-orbital bond-modulated square-lattice Hofstadter deformation',
        'novelty_scope': 'Known Hofstadter/class-II baseline; new local calculation demonstrates explicit paired-contact splitting. No priority claim is made.',
        'definition': {'a': 'symmetry-preserving intracell 0-1 bond amplitude', 'b': B, 'c': C,
                       'vertical_amplitudes': DEFAULT_V.tolist(),
                       'vertical_phases': ['0','2*pi/3','4*pi/3'],
                       'onsite': 'mu*diag(1,0,0)', 'shift': ['pi','pi'],
                       'unitary': [1,-1,1], 'BZ': '[-pi,pi)^2; physical px=kx/3, py=ky'},
        'primitive_cell': {
            'real_space_sites': '(3 nx+j, ny), j=0,1,2, with horizontal nearest neighbors',
            'no_repeated_cover': 'Distinct gauge-invariant vertical hopping magnitudes (1,1.05,0.95) prohibit an ordinary or magnetic translation by one or two x sites; unit y translation is primitive. All three orbitals are coupled by nonzero horizontal hoppings.',
            'fourier_periods': 'Diagonal first harmonics force ky period 2*pi. The boundary link exp(i*kx) fixes the x-cell period. Shift (pi,pi) anticommutes, and is not an energy-preserving identification.',
        },
        'homotopy_from_known_Hofstadter': {
            'parameters': 'At a=1 interpolate (b,c,v) from (1,1,[1,1,1]) to specified values.',
            'uniform_direct_and_indirect_gap': float(3-np.sqrt(3)),
            'maximum_operator_norm_perturbation_bound': 0.2,
            'guaranteed_gap_lower_bound': float(3-np.sqrt(3)-0.4),
            'reason': 'Hermitian maximum absolute row sum bounds perturbation norm; Weyl bounds adjacent spectral edges by twice this norm.'},
        'all_contact_equation': '||mu*w+sigma*(a*u+z/a)||^2=1; sigma=-1 at kx=0, +1 at kx=pi',
        'contact_vectors': {'w': w.tolist(),'u': u.tolist(),'z': z.tolist()},
        'symmetric_upper_critical_a': a0,
        'critical_slopes_da_dmu_at_zero_by_sigma': slopes,
        'odd_interval_width_linear_coefficient': float(abs(slopes['1']-slopes['-1'])),
        'analytic_contacts_at_mu_0_02_05': {str(mu): all_contacts(mu) for mu in (0.0,0.2,0.5)},
        'symmetry': {'mu_zero_residual':symmetry_residual(1,0),
                     'mu_02_residual':symmetry_residual(1,.2),
                     'exact_breaking_identity':'U H_mu(k+Q) U + H_mu(k)=2 mu |0><0|'},
        'cases': cases,
        'mesh_convention': 'Positive Arg of Ux(k) Uy(k+x) Ux*(k+y) Uy*(k), matching project FHS convention.',
        'interpretation': 'At mu=0 the upper-branch contacts coincide in a and change the middle Chern by -2. Positive onsite mu splits them: (-1,2,-1) -> (-1,1,0) -> (0,0,0).',
        'qualification': 'FHS and gap minima are numerical checks. The complete degeneracy condition on this specified family is analytic. Direct isolation alone does not establish insulating filling; indirect gaps are separately reported.'}
    (args.output/'independent_model_results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'cases':len(cases),'critical_a_mu0':a0,'linear_width_coefficient':report['odd_interval_width_linear_coefficient'],
                      'critical_a_mu02':[r['a'] for r in upper_contacts(.2)],
                      'critical_a_mu05':[r['a'] for r in upper_contacts(.5)],
                      'odd_case_refined_gaps':cases[4]['refined_gaps']},indent=2))


if __name__ == '__main__':
    main()
