Seven-orbital prediction test: source records and reproduction

The model is the seven-orbital intracell-loop network, with its own periodic
qx,qy torus. It is not the physical honeycomb NNN model and is not a block
embedding of the three-orbital Hofstadter example. All seven bands enter
the contact and Chern calculations.

Fixed parameters: t/t1=0.4, t1=1, phi=13*pi/32. Vary a=t_A/t1.
The perturbation is H01 += epsilon*(c+b*exp(i*qx)), together with its
Hermitian conjugate. The compatible, breaking and mixed cases have
(c,b)=(1,0),(0,1),(1,1), respectively; no onsite terms are added.

Files
- seven_orbital_prediction_frozen.json: the ORIGINAL parent-only forecast,
  copied byte-for-byte with its original time and canonical-source hash.
  Its predictions field concerns the active orbital01 perturbations.
  The two orbital02 coefficients nested under parent.contact are unused
  earlier parent diagnostics, retained solely to preserve the original file.
- seven_orbital_contacts.json: 42 full-matrix contact-pair records for three
  controls and 14 signed perturbations, 0.000625 <= |epsilon| <= 0.04.
  Lower/upper identify the lower-central and central-upper contacts.
  Widths are positive; their first-order predictions use |epsilon|.
- seven_orbital_topology.json: 24 regular-grid FHS records and 6 additional
  shifted-grid records. lower_three_occupied_group and
  lower_four_occupied_group are the lowest rank-three/four projectors,
  not the highest-energy group. The central band uses zero-based index 3.
  The two inside epsilon=0.02 records also contain multistart refined
  direct and indirect gaps. These are numerical estimates, not certified
  global bounds.
  In the raw refined-extremum records, max_central and max_band2 store
  the minimization objective -E in their value fields: negate value to
  recover the maximum energy. The derived gaps already use this sign correctly.
- seven_orbital_grids.npz: representative unshifted 192x192 full spectra
  and central-band plaquette phases for breaking/mixed epsilon=0.02.
  Parameters are ordered (t/t1,phi,a,epsilon); the saved a is the full
  branch midpoint. axis is the periodic q coordinate, energies are ordered
  increasingly, and fluxes in radians sum to 2*pi for both examples.
- seven_orbital_parent_selection.json: exploratory parent-only coarse
  checks and projected candidate bonds, preceding finite-epsilon tests.
  These records are not an exhaustive phase diagram.
- seven_orbital_prediction_metadata.json: source hashes, definitions,
  execution provenance, numerical scope and the original trial limit.

Forecast chronology
The original frozen prediction was written before the finite-epsilon
calculation. Its SHA256 appears in the archived contact/topology records.
The parent Hamiltonian was checked first; the active real orbital01 bond
was selected from parent projections. No slope was fitted to a perturbed
phase diagram. The later mixed-family width has a visible quadratic
correction; it is not represented as equal to its linear prediction at
finite epsilon. A preliminary epsilon=0.08 compatible Newton trial left
the selected local neighborhood and was stopped; no conclusion at that
amplitude is claimed. The reported validation range is |epsilon|<=0.04.

Reproduce from the archive root (Python, NumPy, SciPy):
  python code/seven_orbital_predict.py --predict --output-prefix source_data/seven_orbital_predict_recomputed
  python code/seven_orbital_predict.py --validate --prediction source_data/seven_orbital_prediction_frozen.json --output-prefix source_data/seven_orbital_predict_recomputed

The first command performs only the unperturbed-contact calculation.
The second checks the parent prediction against the included canonical
Hamiltonian, pins its actual bytes, then runs full-matrix contacts, FHS
checks and extrema searches. Existing outputs are not overwritten; choose
a different output prefix to retain multiple runs. The canonical module
is seven_orbital_reproduction/code/c3n4_verified.py.

The consolidated driver was prepared AFTER validation. Its Hamiltonians
and projected slopes match the executed drivers; this is recorded in the
metadata. Exact copies of the original execution drivers are retained in
code/provenance/seven_orbital_prediction/ for provenance only. They retain
their original working-tree assumptions and are not the recommended
standalone commands. This avoids falsely presenting a later refactor as
the original pre-validation code. No new independent author recomputation
is attested by this archive; the new numerical work was AI-assisted.
