"""Read-only checks of values, vector dependencies, dimensions and hashes."""
from pathlib import Path
import csv, json, re, hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'

def check():
    with (OUT/'fig2_energy.csv').open(encoding='utf-8') as stream:
        rows=list(csv.DictReader(stream))
    e0=[float(r['U_over_Estar']) for r in rows if int(r['beta'])==0]
    e1=[float(r['U_over_Estar']) for r in rows if int(r['beta'])==1]
    assert np.allclose(e0,[-18.970562748477136,0,2,14.970562748477136])
    assert np.allclose(e1,[-30.295980196440297,-9.776139002612418,-7.3508179111185585,5.893060008227748])
    assert sum(int(r['state_count']) for r in rows if int(r['beta'])==0)==16
    exports=json.loads((OUT/'export_manifest.json').read_text(encoding='utf-8'))
    assert [r['stem'] for r in exports]==['fig1_lattice_basis','fig2_symmetry_energy','fig3_force_controls']
    for row in exports:
        assert row['vector_formats']==['pdf','svg']
        assert set(row['sha256'])=={'pdf','svg','png'}
        # Matplotlib writes these PDF resource dictionaries without compression.
        # Check the delivered PDF page and every font descriptor, not a preview.
        pdf=(OUT/(row['stem']+'.pdf')).read_bytes()
        assert pdf.startswith(b'%PDF-')
        assert not re.search(rb'/Subtype\s*/Image\b',pdf)
        assert not re.search(rb'/Subtype\s*/Type3\b',pdf)
        objects=re.findall(rb'\d+\s+\d+\s+obj\b(.*?)endobj',pdf,re.S)
        descriptors=[obj for obj in objects if re.search(rb'/Type\s*/FontDescriptor\b',obj)]
        assert descriptors and all(re.search(rb'/FontFile[23]?\s+\d+\s+0\s+R',obj) for obj in descriptors)
        boxes=re.findall(rb'/MediaBox\s*\[\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*\]',pdf)
        assert len(boxes)==1
        x0,y0,x1,y1=map(float,boxes[0])
        assert np.allclose([(x1-x0)*25.4/72,(y1-y0)*25.4/72],
                           [row['width_mm'],row['height_mm']],atol=1e-7)
        svg=(OUT/(row['stem']+'.svg')).read_text(encoding='utf-8')
        assert '<image' not in svg and '<text' in svg
        assert re.search(r'width="425\.19685\d*pt"',svg)
        for ext,digest in row['sha256'].items():
            assert hashlib.sha256((OUT/(row['stem']+'.'+ext)).read_bytes()).hexdigest()==digest
        for folder in ['revision','revision_zh']:
            assert hashlib.sha256((ROOT/folder/'figures'/(row['stem']+'.pdf')).read_bytes()).hexdigest()==row['sha256']['pdf']
    qa=json.loads((OUT/'figure_qa.json').read_text(encoding='utf-8'))
    print(json.dumps({'status':'PASS','mode':'READ_ONLY','all_export_hashes':'PASS',
      'energy_family_values':'PASS','vector_files_no_external_raster':'PASS',
      'pdf_dimensions_and_embedded_fonts':'PASS','pdf_copies_match':'PASS',
      'svg_width_150mm':'PASS','svg_editable_text':'PASS',
      'visual_qa_record':qa['pdf_render_visual_qa']},indent=2))

if __name__=='__main__':
    check()
