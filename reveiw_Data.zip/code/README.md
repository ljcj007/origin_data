# Reproducing the normalized magnetic models

`reproduce_physics.py` is a standalone program for Python 3.10 or later. Its only
external dependency is NumPy; no previous research-cycle programs or data are
loaded. `requirements.txt` records the dependency. The delivered run used Python
3.13.14 and NumPy 2.5.2. No package installation is part of this program.

From the source-package directory containing `code/` and `data/`, run:

```text
python code/reproduce_physics.py --check-only --report
```

The default mode is also a read-only check. It recomputes the model, checks the
generated files against their manifest hashes, and compares every stored number
with the fresh calculation. `--report` prints JSON to standard output; it does
not save or change a file. The check exits with code 0 on success and 1 on a
missing or inconsistent file. To generate or replace the data explicitly:

```text
python code/reproduce_physics.py --generate --report
```

An alternative data directory can be selected with `--output-dir PATH`. To also
check the four rows of a manuscript's `tab:energy` endpoint table, repeat the
`--manuscript` option for each English or Chinese source. From the project root, check both supplied manuscripts:

```text
python code/reproduce_physics.py --check-only --report --manuscript revision/main.tex --manuscript revision_zh/main_zh.tex
```

The table check allows rounding to the six decimal places used in the manuscript.
The rest of the generated data are compared at absolute tolerance 2e-10 and
relative tolerance 2e-11. Manifest hashes independently detect changed bytes.
If the program itself is intentionally edited, regenerate its outputs so the
recorded program hash describes the version that produced them.

## Model and outputs

Coordinates are in units of the nominal sphere-centre pitch `a = 19 mm`. The
counterclockwise rod order is right, top, left, bottom. Their positive tangent
axes are `(0,1,0), (-1,0,0), (0,-1,0), (1,0,0)`. Each prescribed rod moment is
`s_i m0 e_i`, `s_i = +/-1`. All 16 labelled states are retained at each of five
response parameters `beta = 0, 0.25, 0.5, 0.75, 1`.

The dimensionless dipole tensor is `(3 rhat rhat^T - I)/|r/a|^3`.
The induced sphere moments `q = p/m0` solve
`(I - eta Tss) q = eta C s`, where `eta = beta (4/19)^3`.
The program uses `numpy.linalg.solve`, checks positive definiteness, and treats
zero response by setting `q = 0` without constructing `alpha^-1`.
Rod and sphere pairs are counted once and the positive induction cost is
included. Energies are in units `E* = mu0 m0^2/(4 pi a^3)`. The effective
convention is

```text
Ueff/E* = C - ja(s0s1+s1s2+s2s3+s3s0) - jo(s0s2+s1s3).
```

Here `C` is the retained common offset; `ja` and `jo` are dimensionless couplings.

| File in `data/` | Content |
|---|---|
| `square_states.csv` | 80 states, all induced moments, pair/full/eliminated energies, rod/total moments and proper magnetic rotation tests |
| `effective_couplings.csv` | Five response settings, common offset, adjacent/opposite couplings, normalized SPD margin and Picard spectral radius |
| `energy_families.csv` | Four energy families at all five settings, including the isolated-response comparison |
| `rod_rotation_classes.csv` | All 16 states in six proper-rotation orbits |
| `probe_predictions.csv` | 351 normalized force/energy rows for complete-field scaling and fixed-gradient changes of B0, including independent energy-gradient checks |
| `rod_sphere_response.csv` | 12 axial rod--sphere model cases for source polarity and separation; normalized field, induced moment, energy and radial force |
| `model_summary.json` | Geometry, units, conventions, orbit members, symmetry counts, endpoint table, scope and numerical check errors |
| `manifest.json` | SHA-256 hashes of the model files and the generating program |

For the generic probes, use `m0 = alpha B0`, `E0 = m0 B0`, `F0 = m0 G` and
dimensionless coordinates `X = Gx/B0`, `Y = Gy/B0`. Complete-field scaling has
`B/B0 = (c(1+X), -cY, 0)`; a B0-only change has `(q+X, -Y, 0)` with `q > 0`.
The fixed, freely equilibrated permanent and isotropic induced energies are
`-Bx`, `-|B|`, and `-|B|^2/2` in these units. Finite differences of these energies
are compared independently with their predicted force ratios. These are generic
normalized probes; the program assigns no SI polarizability to the iron spheres.
At zero complete field, free orientation is nonunique and force is zero.

For the rod--sphere example, the separation is `q = r/r_ref`, where `r_ref` is
large compared with the component dimensions. The axial reference field is
`B_ref = 2 k m0/r_ref^3`, with `k = mu0/(4 pi)`. The remaining reference scales
are `p_ref = alpha B_ref`, `E_ref = alpha B_ref^2/2` and
`F_ref = 3 alpha B_ref^2/r_ref`. Positive radial force points away from the
rod, so attraction has a negative sign. Reversing the source changes the field
and induced-moment signs, while the energy and force are unchanged. These
normalized predictions assign no calibrated SI moment or polarizability to
the components.

The 38 checks include independent explicit-pair versus quadratic energies,
full induction-cost energy versus eliminated energy, stationarity residuals,
global reversal parity, all state/family/symmetry counts, force gradients,
uniform-field controls, field divergence/curl, and the polarity, separation
scaling and energy gradient of the rod--sphere model.

The outputs are calculations for fixed geometry and ideal response laws. The
high-permeability endpoint is an isolated-sphere ideal limit, not measured iron
behaviour. The point approximation at contact distances is not a finite-body
boundary-value solution, and sign-state minimization does not establish a freely
assembled kit's mechanical or thermal equilibrium. No classroom observations or
learner outcomes are generated.

## Standalone publication figures

`make_figures.py` uses NumPy and Matplotlib to regenerate the three analytical
figures from their saved data and equations:

```text
python code/make_figures.py
```

The outputs in `figures/` are vector PDF and SVG files and 400 dpi PNG previews.
Their widths are 150 mm; their heights are 73, 94 and 74 mm. PDF fonts are
embedded, SVG text remains editable, and no TeX executable is required for
figure generation. `export_manifest.json` records sizes and file hashes.

The two manuscripts use `includegraphics` to read the matching PDFs in each
manuscript's `figures/` folder. After intentionally changing a figure, copy its
regenerated PDF from the root `figures/` folder into both `revision/figures/`
and `revision_zh/figures/`. Then run:

```text
python code/check_figure_exports.py
```

This read-only check verifies the plotted energy values, export hashes, PDF
page dimensions and embedded fonts, absence of raster image objects, editable
SVG text, and identical PDF copies in both manuscript folders. The three
figures describe lattice bases, magnetic symmetry and energy, and magnetic
probe responses. `figure_contract.json` records each figure's claim and
`figure_qa.json` records inspection of the rendered PDF pages.

## Construction photograph preparation

`python code/standardize_photos.py` reads the nine original JPEGs without overwriting them. It applies the same whole-image gamma transform (0.62) to all RGB channels, crops background margins conservatively, and proportionally places each image on a 1000-pixel square white canvas. It exports PNG, lossless LZW TIFF and three PDF plates, and copies the PNG panels into both manuscript figure folders. The output canvas does not add optical detail.

Run `python code/standardize_photos.py --check-only` to verify raw hashes, output hashes, the common processing curve and every output pixel against the source and recorded operations. Crops, padding, effective native resolution and the original clipped boundaries are recorded in `figures/photographs/processing_manifest.json`. The process does not use generative editing, object removal, background substitution, denoising, sharpening or geometric warping.

## Building the final manuscript PDFs

Run `python code/build_final_pdfs.py` from any directory. The program requires XeLaTeX on PATH, or `--engine /path/to/xelatex`. It uses only the Python standard library. Each language compiles in a new directory under `tmp/pdfs/`, with shell escape disabled, until the auxiliary references stabilize. It rejects unresolved references, missing glyphs, oversized floats and overfull boxes before publishing either PDF. Supplied image assets are checked for byte identity.

The outputs are `output/pdf/Magnetic_rod_networks_EN.pdf` and `output/pdf/Magnetic_rod_networks_ZH.pdf`, also copied to `revision/main.pdf` and `revision_zh/main_zh.pdf`. `output/pdf/build_report.json` records the engine, passes, source hashes and PDF hashes. This local build works independently of the desktop preview service. Logs remain under the reported temporary build directory until archived.

## Finite cylindrical sources

`finite_rod_comparison.py` replaces only the four rod source dipoles with uniformly magnetized finite cylinders of equal total moment; sphere response is unchanged. End-disk magnetic-charge quadrature supplies both rod-pair energies and sphere-centre fields. The energy matrices and normalization match `reproduce_physics.py`. No measured field, permeability, magnetization or teaching outcome is supplied.

- `python code/finite_rod_comparison.py`: recompute, perform 15 physical/numerical checks, and compare supplied CSV values.
- `python code/finite_rod_comparison.py --generate`: explicitly write the model data under `data/finite_rods/`.
- `python code/make_finite_rod_figure.py`: regenerate the fourth analytical PDF/SVG/PNG and copy its PDF into both source figure folders.

The model requires NumPy; the figure also requires Matplotlib. The optional task and its solutions are in bilingual S3. S2 defines every integral, the independent axial and volume-energy checks, the point-source contraction limit and the two-mode proof over the continuous response interval. The source-size contraction holds the total moment fixed; it is a mathematical check rather than a fixed-magnetization material path.

## Standalone S2 PDFs

Run `python code/build_supplement_pdfs.py` with XeLaTeX installed. It compiles the English and Chinese projects in `supplements/S2_en/` and `supplements/S2_zh/` in isolated build folders, resolves cross-references, rejects overfull text and missing characters, and publishes both only after both succeed. Sources include one existing vector diagram. The output files are `output/pdf/Supplement_S2_EN.pdf` and `output/pdf/Supplement_S2_ZH.pdf`; `build_supplement_report.json` records source and PDF hashes. The manuscript build command is unchanged.
