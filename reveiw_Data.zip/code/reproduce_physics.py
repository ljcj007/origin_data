#!/usr/bin/env python3
"""Portable normalized EJP model reproduction; standard library and NumPy only.

No previous research-cycle files are read or imported. The default is a read-only
check of already generated data. Use --generate explicitly to write new data.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import sys

import numpy as np


BETA_VALUES = (0.0, 0.25, 0.5, 0.75, 1.0)
ROD_CENTRES = np.array(((0.5, 0, 0), (0, 0.5, 0),
                        (-0.5, 0, 0), (0, -0.5, 0)), dtype=float)
ROD_AXES = np.array(((0, 1, 0), (-1, 0, 0),
                     (0, -1, 0), (1, 0, 0)), dtype=float)
SPHERE_CENTRES = np.array(((0.5, 0.5, 0), (-0.5, 0.5, 0),
                           (-0.5, -0.5, 0), (0.5, -0.5, 0)), dtype=float)
ETA_MAX = (4.0 / 19.0) ** 3
REPRESENTATIVES = ("++++", "+++-", "++--", "+-+-")
FAMILY_NAMES = ("UNIFORM_CIRCULATION", "SINGLE_DIFFERENT_SIGN",
                "CONTIGUOUS_TWO_PLUS", "ALTERNATING")
FAMILY_COUNTS = (2, 8, 4, 2)
ATOL = 2e-10
RTOL = 2e-11


def kernel(displacement):
    """Dimensionless Tbar: B/B* = Tbar times m/m0, at coordinates r/a."""
    r = np.asarray(displacement, dtype=float)
    length = float(np.linalg.norm(r))
    if length == 0:
        raise ValueError("The dipole kernel excludes the source's own position")
    unit = r / length
    return (3 * np.outer(unit, unit) - np.eye(3)) / length**3


def pattern(signs):
    return "".join("+" if value > 0 else "-" for value in signs)


def signs_from_pattern(text):
    return np.array([1.0 if char == "+" else -1.0 for char in text])


def pair_sums(signs):
    adjacent = sum(signs[i] * signs[(i + 1) % 4] for i in range(4))
    opposite = signs[0] * signs[2] + signs[1] * signs[3]
    return int(adjacent), int(opposite)


def family_index(signs):
    return {(4, 2): 0, (0, 0): 1, (0, -2): 2, (-4, 2): 3}[pair_sums(signs)]


def rotation(quarter_turns):
    # Integer rotations avoid introducing roundoff in a geometry/symmetry check.
    r = np.array(((0, -1, 0), (1, 0, 0), (0, 0, 1)), dtype=float)
    return np.linalg.matrix_power(r, quarter_turns)


def preserves_vectors(centres, moments, quarter_turns):
    r = rotation(quarter_turns)
    for centre, moment in zip(centres, moments):
        matches = np.flatnonzero(np.linalg.norm(centres - r @ centre, axis=1) < 1e-12)
        if len(matches) != 1:
            return False
        if not np.allclose(r @ moment, moments[matches[0]], atol=2e-10, rtol=2e-11):
            return False
    return True


def explicit_rod_energy(moments):
    """Pair-once vector calculation, independent of construction of Q."""
    energy = 0.0
    for i in range(4):
        for j in range(i + 1, 4):
            r = ROD_CENTRES[i] - ROD_CENTRES[j]
            distance = np.linalg.norm(r)
            rhat = r / distance
            mi, mj = moments[i], moments[j]
            energy += (np.dot(mi, mj) - 3 * np.dot(mi, rhat) * np.dot(mj, rhat)) / distance**3
    return float(energy)


def explicit_full_energy(moments, sphere_moments, eta, rod_fields):
    """Each rod and sphere pair once, with the positive induction cost."""
    energy = explicit_rod_energy(moments)
    if eta == 0:
        return energy
    energy += float(np.sum(sphere_moments**2) / (2 * eta))
    energy -= float(np.sum(sphere_moments * rod_fields.reshape(4, 3)))
    for i in range(4):
        for j in range(i + 1, 4):
            energy -= float(sphere_moments[i] @ kernel(SPHERE_CENTRES[i] - SPHERE_CENTRES[j]) @ sphere_moments[j])
    return energy


def matrices():
    s_matrix = np.zeros((12, 12))
    c_matrix = np.zeros((12, 4))
    q_matrix = np.zeros((4, 4))
    for i in range(4):
        for j in range(4):
            if i != j:
                s_matrix[3*i:3*i+3, 3*j:3*j+3] = kernel(SPHERE_CENTRES[i] - SPHERE_CENTRES[j])
                q_matrix[i, j] = ROD_AXES[i] @ kernel(ROD_CENTRES[i] - ROD_CENTRES[j]) @ ROD_AXES[j]
            c_matrix[3*i:3*i+3, j] = kernel(SPHERE_CENTRES[i] - ROD_CENTRES[j]) @ ROD_AXES[j]
    return s_matrix, c_matrix, q_matrix


def probe_field(xy, offset, gradient):
    x, y = xy
    return np.array((offset + gradient * x, -gradient * y, 0.0))


def probe_energy(model, xy, offset, gradient, angle=0.0):
    field = probe_field(xy, offset, gradient)
    if model == "FIXED_PERMANENT":
        return -float(np.dot((math.cos(angle), math.sin(angle), 0.0), field))
    if model == "FREE_PERMANENT_EQUILIBRATED":
        return -float(np.linalg.norm(field))
    if model == "INDUCED_LINEAR_ISOTROPIC":
        return -float(np.dot(field, field)) / 2
    raise ValueError(model)


def force_from_energy_difference(model, xy, offset, gradient, angle=0.0):
    step = 1e-5
    result = []
    xy = np.asarray(xy, dtype=float)
    for direction in np.eye(2):
        plus = probe_energy(model, xy + step*direction, offset, gradient, angle)
        minus = probe_energy(model, xy - step*direction, offset, gradient, angle)
        result.append(-(plus - minus) / (2*step))
    return np.array(result)


def build_data():
    s_matrix, c_matrix, q_matrix = matrices()
    all_signs = [np.array(values, dtype=float) for values in itertools.product((-1, 1), repeat=4)]
    errors = {key: 0.0 for key in (
        "rod_pair_vs_quadratic", "full_energy_vs_eliminated", "family_energy_vs_quadratic",
        "stationarity_residual", "reversal_energy", "reversal_sphere_moments",
        "probe_force_finite_gradient", "probe_oblique_finite_gradient",
        "rod_sphere_field_vs_axial", "rod_sphere_force_finite_gradient")}
    checks = {}
    states, couplings, families, symmetry, rotation_rows = [], [], [], [], []
    orbit_members = {}
    for signs in all_signs:
        text = pattern(signs)
        canonical = min(pattern(np.roll(signs, shift)) for shift in range(4))
        orbit_members.setdefault(canonical, []).append(text)
    ordered_orbits = sorted(orbit_members)
    orbit_lookup = {member: index for index, canonical in enumerate(ordered_orbits)
                    for member in orbit_members[canonical]}
    for signs in all_signs:
        text = pattern(signs)
        m = np.sum(signs[:, None] * ROD_AXES, axis=0)
        canonical = ordered_orbits[orbit_lookup[text]]
        rotation_rows.append({"pattern": text, "rotation_orbit": orbit_lookup[text],
                              "canonical_pattern": canonical, "orbit_size": len(orbit_members[canonical]),
                              "Mrod_x_over_m0": float(m[0]), "Mrod_y_over_m0": float(m[1])})
    checks["all16_states_and_six_rotation_orbits"] = len(all_signs) == 16 and sorted(map(len, orbit_members.values())) == [1, 1, 2, 4, 4, 4]
    checks["four_zero_rod_moment_states"] = sum(row["Mrod_x_over_m0"] == row["Mrod_y_over_m0"] == 0 for row in rotation_rows) == 4
    checks["reciprocal_symmetric_matrices"] = bool(np.allclose(s_matrix, s_matrix.T) and np.allclose(q_matrix, q_matrix.T))
    checks["rod_only_couplings"] = bool(np.isclose(q_matrix[0, 1], 3*math.sqrt(2)) and np.isclose(q_matrix[0, 2], 1))
    state_index = {}
    for beta in BETA_VALUES:
        eta = beta * ETA_MAX
        system = np.eye(12) - eta*s_matrix
        eigenvalues = np.linalg.eigvalsh(system)
        if float(eigenvalues[0]) <= 0:
            raise ValueError("The declared parameter is outside the stable quadratic domain")
        # No alpha inverse is constructed at eta = 0.
        response_operator = eta * np.linalg.solve(system, c_matrix) if eta > 0 else np.zeros_like(c_matrix)
        effective = q_matrix + c_matrix.T @ response_operator
        offset = -float(np.trace(effective)) / 2
        ja, jo = float(effective[0, 1]), float(effective[0, 2])
        coupled = {"beta": beta, "eta": eta, "ja": ja, "jo": jo,
                   "common_offset_over_Estar": offset,
                   "SPD_margin_I_minus_etaT": float(eigenvalues[0]),
                   "Picard_spectral_radius": eta*float(np.max(np.abs(np.linalg.eigvalsh(s_matrix))))}
        couplings.append(coupled)
        counts = [0, 0, 0, 0]
        beta_rows = []
        for signs in all_signs:
            text = pattern(signs)
            f_index = family_index(signs)
            counts[f_index] += 1
            rods = signs[:, None] * ROD_AXES
            rod_field = c_matrix @ signs
            spheres = (response_operator @ signs).reshape(4, 3)
            energy_rod = explicit_rod_energy(rods)
            energy_effective = -float(signs @ effective @ signs) / 2
            energy_full = explicit_full_energy(rods, spheres, eta, rod_field)
            energy_isolated = energy_rod - eta*float(rod_field @ rod_field)/2
            a_sum, o_sum = pair_sums(signs)
            energy_family = offset - ja*a_sum - jo*o_sum
            residual = spheres.ravel() - eta*(rod_field + s_matrix @ spheres.ravel())
            errors["rod_pair_vs_quadratic"] = max(errors["rod_pair_vs_quadratic"], abs(energy_rod + float(signs @ q_matrix @ signs)/2))
            errors["full_energy_vs_eliminated"] = max(errors["full_energy_vs_eliminated"], abs(energy_full-energy_effective))
            errors["family_energy_vs_quadratic"] = max(errors["family_energy_vs_quadratic"], abs(energy_family-energy_effective))
            errors["stationarity_residual"] = max(errors["stationarity_residual"], float(np.max(np.abs(residual))))
            mrod = np.sum(rods, axis=0)
            mtotal = mrod + np.sum(spheres, axis=0)
            c2 = preserves_vectors(ROD_CENTRES, rods, 2) and preserves_vectors(SPHERE_CENTRES, spheres, 2)
            c4 = preserves_vectors(ROD_CENTRES, rods, 1) and preserves_vectors(SPHERE_CENTRES, spheres, 1)
            row = {"beta": beta, "eta": eta, "pattern": text, "family": FAMILY_NAMES[f_index],
                   "Urod_over_Estar": energy_rod, "Uisolated_over_Estar": energy_isolated,
                   "Uselfconsistent_over_Estar": energy_effective, "Uexplicit_full_over_Estar": energy_full,
                   "Mrod_x_over_m0": float(mrod[0]), "Mrod_y_over_m0": float(mrod[1]),
                   "Mtotal_x_over_m0": float(mtotal[0]), "Mtotal_y_over_m0": float(mtotal[1]),
                   "Mtotal_z_over_m0": float(mtotal[2]), "joint_C2": int(c2), "joint_C4": int(c4),
                   "rotation_orbit": orbit_lookup[text]}
            for i in range(4):
                for j, name in enumerate(("x", "y", "z")):
                    row[f"p{i}_{name}_over_m0"] = float(spheres[i, j])
            states.append(row)
            beta_rows.append(row)
            state_index[(beta, text)] = row
        checks[f"family_counts_beta_{beta:g}"] = counts == list(FAMILY_COUNTS)
        counts_row = {"beta": beta, "state_count": len(beta_rows),
                      "zero_Mrod_count": sum(abs(row["Mrod_x_over_m0"]) + abs(row["Mrod_y_over_m0"]) < 1e-10 for row in beta_rows),
                      "zero_Mtotal_count": sum(abs(row["Mtotal_x_over_m0"]) + abs(row["Mtotal_y_over_m0"]) + abs(row["Mtotal_z_over_m0"]) < 1e-10 for row in beta_rows),
                      "joint_C2_count": sum(row["joint_C2"] for row in beta_rows),
                      "joint_C4_count": sum(row["joint_C4"] for row in beta_rows)}
        symmetry.append(counts_row)
        checks[f"symmetry_counts_beta_{beta:g}"] = all(counts_row[key] == value for key, value in
                                                        (("state_count", 16), ("zero_Mrod_count", 4),
                                                         ("zero_Mtotal_count", 4), ("joint_C2_count", 4), ("joint_C4_count", 2)))
        checks[f"uniform_C4_alternating_C2_beta_{beta:g}"] = bool(
            state_index[(beta, "++++")]["joint_C4"] and state_index[(beta, "+-+-")]["joint_C2"]
            and not state_index[(beta, "+-+-")]["joint_C4"])
        for signs in all_signs:
            row, reverse = state_index[(beta, pattern(signs))], state_index[(beta, pattern(-signs))]
            errors["reversal_energy"] = max(errors["reversal_energy"], abs(row["Uselfconsistent_over_Estar"]-reverse["Uselfconsistent_over_Estar"]))
            for key in (f"p{i}_{axis}_over_m0" for i in range(4) for axis in ("x", "y", "z")):
                errors["reversal_sphere_moments"] = max(errors["reversal_sphere_moments"], abs(row[key]+reverse[key]))
        for f_index, representative in enumerate(REPRESENTATIVES):
            row = state_index[(beta, representative)]
            families.append({"beta": beta, "eta": eta, "representative": representative,
                             "family": FAMILY_NAMES[f_index], "state_count": counts[f_index],
                             "Urod_over_Estar": row["Urod_over_Estar"],
                             "Uisolated_over_Estar": row["Uisolated_over_Estar"],
                             "Uselfconsistent_over_Estar": row["Uselfconsistent_over_Estar"]})
        minimum = min(row["Uselfconsistent_over_Estar"] for row in beta_rows)
        checks[f"uniform_family_lowest_beta_{beta:g}"] = all(
            row["family"] == "UNIFORM_CIRCULATION" for row in beta_rows
            if abs(row["Uselfconsistent_over_Estar"] - minimum) < 1e-10)

    probe_rows = []
    models = ("FIXED_PERMANENT", "FREE_PERMANENT_EQUILIBRATED", "INDUCED_LINEAR_ISOTROPIC")
    for operation, amplitudes in (("FULL_FIELD_C", np.linspace(-2, 2, 81)),
                                  ("B0_ONLY_Q_GRADIENT_FIXED", np.linspace(0.25, 2, 36))):
        for amplitude in amplitudes:
            value = float(amplitude)
            offset, gradient = (value, value) if operation == "FULL_FIELD_C" else (value, 1.0)
            expected_forces = (value, abs(value), value**2) if operation == "FULL_FIELD_C" else (1.0, 1.0, value)
            for model, expected in zip(models, expected_forces):
                force_fd = force_from_energy_difference(model, (0, 0), offset, gradient)
                errors["probe_force_finite_gradient"] = max(errors["probe_force_finite_gradient"], abs(float(force_fd[0])-expected), abs(float(force_fd[1])))
                probe_rows.append({"operation": operation, "amplitude": value, "model": model,
                                   "U_over_E0": probe_energy(model, (0, 0), offset, gradient),
                                   "Fx_over_F0": expected, "Fy_over_F0": 0.0,
                                   "Fx_from_energy_finite_difference_over_F0": float(force_fd[0]),
                                   "free_orientation_unique": int(not (model == models[1] and offset == 0))})
    for model in models:
        for offset, gradient, xy, angle in ((1.0, 0.7, (0.2, -0.3), math.pi/4),
                                           (-0.8, -0.4, (-0.2, 0.1), -math.pi/3)):
            field = probe_field(xy, offset, gradient)
            if model == models[0]:
                expected = np.array((gradient*math.cos(angle), -gradient*math.sin(angle)))
            elif model == models[1]:
                expected = np.array((gradient*field[0], -gradient*field[1])) / np.linalg.norm(field)
            else:
                expected = np.array((gradient*field[0], -gradient*field[1]))
            calculated = force_from_energy_difference(model, xy, offset, gradient, angle)
            errors["probe_oblique_finite_gradient"] = max(errors["probe_oblique_finite_gradient"], float(np.max(np.abs(expected-calculated))))
    checks["uniform_field_zero_translation_all_probes"] = all(
        np.allclose(force_from_energy_difference(model, (0.2, 0.3), 1.0, 0.0, math.pi/4), 0)
        for model in models)
    point, step = np.array((0.2, -0.3)), 1e-6
    jacobian = np.column_stack([(probe_field(point+step*axis, 0.9, 1.3)-
                                probe_field(point-step*axis, 0.9, 1.3))/(2*step)
                               for axis in np.eye(2)])
    divergence = float(jacobian[0, 0]+jacobian[1, 1])
    curl_z = float(jacobian[1, 0]-jacobian[0, 1])
    checks["local_field_divergence_and_curl_zero"] = abs(divergence) < 1e-9 and abs(curl_z) < 1e-9

    # Independent vector-kernel and energy-gradient evaluation of the axial pair.
    # Here k=alpha=m0=r_ref=1, so B_ref=2, E_ref=2, F_ref=12.
    # r_ref is a chosen far-field reference separation, not a contact distance.
    rod_sphere_rows = []
    pair_index = {}
    for rod_sign in (-1, 1):
        moment = np.array((0.0, 0.0, float(rod_sign)))
        def pair_energy(q):
            field = kernel((0, 0, q)) @ moment
            return -float(field @ field) / 2
        for q in (1.0, 1.25, 1.5, 2.0, 3.0, 4.0):
            field = kernel((0, 0, q)) @ moment
            expected_field = 2*rod_sign/q**3
            errors["rod_sphere_field_vs_axial"] = max(
                errors["rod_sphere_field_vs_axial"], abs(field[2]-expected_field),
                abs(field[0]), abs(field[1]))
            step = 1e-5*q
            force_fd = -(pair_energy(q+step)-pair_energy(q-step))/(2*step)
            expected_force = -12/q**7
            errors["rod_sphere_force_finite_gradient"] = max(
                errors["rod_sphere_force_finite_gradient"], abs((force_fd-expected_force)/12))
            row = {"r_over_rref": q, "rod_sign": rod_sign,
                   "Bz_over_Bref": float(field[2]/2), "pz_over_pref": float(field[2]/2),
                   "U_over_Eref": pair_energy(q)/2, "Fr_over_Fref": expected_force/12,
                   "Fr_finite_difference_over_Fref": force_fd/12}
            rod_sphere_rows.append(row)
            pair_index[(q, rod_sign)] = row
    checks["rod_sphere_pole_reversal"] = all(
        np.allclose([pair_index[(q, 1)]["pz_over_pref"]+pair_index[(q, -1)]["pz_over_pref"],
                     pair_index[(q, 1)]["U_over_Eref"]-pair_index[(q, -1)]["U_over_Eref"],
                     pair_index[(q, 1)]["Fr_over_Fref"]-pair_index[(q, -1)]["Fr_over_Fref"]], 0)
        for q in (1.0, 1.25, 1.5, 2.0, 3.0, 4.0))
    first, doubled = pair_index[(1.0, 1)], pair_index[(2.0, 1)]
    checks["rod_sphere_distance_doubling"] = bool(np.allclose(
        [doubled["pz_over_pref"]/first["pz_over_pref"],
         doubled["U_over_Eref"]/first["U_over_Eref"],
         doubled["Fr_over_Fref"]/first["Fr_over_Fref"]], [1/8, 1/64, 1/128]))
    for name, error in errors.items():
        checks[name] = error < (1e-8 if "finite" in name else 2e-10)
    if not all(checks.values()):
        raise AssertionError(f"Model checks failed: {[key for key, value in checks.items() if not value]}")
    endpoint_rows = [{"representative": text, "state_count": FAMILY_COUNTS[i],
                      "beta0_energy_over_Estar": state_index[(0.0, text)]["Uselfconsistent_over_Estar"],
                      "beta1_energy_over_Estar": state_index[(1.0, text)]["Uselfconsistent_over_Estar"]}
                     for i, text in enumerate(REPRESENTATIVES)]
    summary = {
        "schema_version": "1.1", "evidence_class": "AUTHOR_NORMALIZED_ANALYTIC_MODEL_NOT_MEASURED_HARDWARE_OR_LEARNERS",
        "geometry": {"a_mm": 19, "rod_length_mm": 11, "rod_diameter_mm": 3.3, "sphere_radius_mm": 4,
                     "coordinate_unit": "a", "rod_centres": ROD_CENTRES.tolist(), "rod_axes": ROD_AXES.tolist(),
                     "sphere_centres": SPHERE_CENTRES.tolist(), "rod_order": "0 right, 1 top, 2 left, 3 bottom; counterclockwise"},
        "normalization": {"E_star": "mu0*m0^2/(4*pi*a^3)", "B_star": "mu0*m0/(4*pi*a^3)",
                          "moment_unit": "m0", "eta_max": ETA_MAX,
                          "probe": "m0=alpha*B0; E0=m0*B0; F0=m0*G; X=G*x/B0, Y=G*y/B0",
                          "probe_parameter_scope": "symbolic normalized generic probes; no SI polarizability or sphere calibration",
                          "rod_sphere": "q=r/r_ref; B_ref=2*k*m0/r_ref^3; p_ref=alpha*B_ref; E_ref=alpha*B_ref^2/2; F_ref=3*alpha*B_ref^2/r_ref; k=mu0/(4*pi)",
                          "rod_sphere_parameter_scope": "r_ref is an arbitrary axial separation large compared with both component sizes; no measured SI force or polarizability"},
        "energy_convention": "Ueff/E*=C-ja*(s0s1+s1s2+s2s3+s3s0)-jo*(s0s2+s1s3); each pair once; common offset retained",
        "beta_values": list(BETA_VALUES), "couplings": couplings,
        "rotation_orbits": [{"orbit": i, "canonical": text, "members": sorted(orbit_members[text])}
                            for i, text in enumerate(ordered_orbits)],
        "symmetry_by_beta": symmetry, "manuscript_endpoint_table": endpoint_rows,
        "checks": checks, "maximum_absolute_errors": errors,
        "scope": ["prescribed identical rod magnitudes; fixed positions and axes; zero external field in square model",
                  "identical reversible linear isotropic induced point spheres; no remanence or saturation",
                  "beta=1 is the isolated-sphere high-permeability ideal limit, not a measured Fe parameter",
                  "point approximation at contact distances; not a finite-body boundary-value solution",
                  "uniform circulation minimum concerns constrained signs, not mechanical or thermal assembly equilibrium",
                  "free permanent orientation is nonunique at zero field; the force is zero there",
                  "axial rod--sphere pair: prescribed rod moment and reversible linear response; r is centre-to-centre distance",
                  "axial distance laws require separations large compared with component sizes; no quantitative contact-force claim"]}
    datasets = {"square_states.csv": states, "effective_couplings.csv": couplings,
                "energy_families.csv": families, "rod_rotation_classes.csv": rotation_rows,
                "probe_predictions.csv": probe_rows, "rod_sphere_response.csv": rod_sphere_rows,
                "model_summary.json": summary}
    return datasets


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def formatted(value):
    return format(value, ".17g") if isinstance(value, float) else str(value)


def write_data(directory, datasets):
    directory.mkdir(parents=True, exist_ok=True)
    for name, values in datasets.items():
        path = directory / name
        if name.endswith(".json"):
            path.write_text(json.dumps(values, indent=2, ensure_ascii=False, sort_keys=True)+"\n", encoding="utf-8")
        else:
            with path.open("w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(values[0]))
                writer.writeheader()
                writer.writerows({key: formatted(value) for key, value in row.items()} for row in values)
    manifest = {"schema_version": "1.0", "program_sha256": hash_file(Path(__file__)),
                "files": {name: hash_file(directory/name) for name in sorted(datasets)}}
    (directory/"manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True)+"\n", encoding="utf-8")


def compare(actual, expected, label):
    if isinstance(expected, dict):
        if set(actual) != set(expected):
            raise AssertionError(f"Keys differ in {label}")
        for key in expected:
            compare(actual[key], expected[key], f"{label}.{key}")
    elif isinstance(expected, list):
        if len(actual) != len(expected):
            raise AssertionError(f"Length differs in {label}")
        for index, (a, e) in enumerate(zip(actual, expected)):
            compare(a, e, f"{label}[{index}]")
    elif isinstance(expected, bool):
        if actual is not expected:
            raise AssertionError(f"Boolean differs in {label}")
    elif isinstance(expected, (int, float)):
        if not math.isclose(float(actual), expected, rel_tol=RTOL, abs_tol=ATOL):
            raise AssertionError(f"Numeric mismatch in {label}: {actual} vs {expected}")
    elif actual != expected:
        raise AssertionError(f"Value differs in {label}: {actual} vs {expected}")


def check_data(directory, datasets):
    manifest_path = directory/"manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Generate data first; missing {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if hash_file(Path(__file__)) not in (manifest["program_sha256"], manifest.get("compatible_checker_sha256")):
        raise AssertionError("The program differs from the program recorded when data were generated")
    if set(manifest["files"]) != set(datasets):
        raise AssertionError("The generated manifest has a different model-file set")
    for name, expected in datasets.items():
        path = directory/name
        if hash_file(path) != manifest["files"][name]:
            raise AssertionError(f"Generated file hash mismatch: {name}")
        if name.endswith(".json"):
            actual = json.loads(path.read_text(encoding="utf-8"))
        else:
            with path.open(encoding="utf-8", newline="") as stream:
                reader = csv.DictReader(stream)
                if reader.fieldnames != list(expected[0]):
                    raise AssertionError(f"CSV columns differ in {name}")
                actual = list(reader)
        compare(actual, expected, name)
    return len(datasets)


def check_manuscript(path, endpoint_rows):
    text = path.read_text(encoding="utf-8")
    location = text.find(r"\label{tab:energy}")
    if location < 0:
        raise AssertionError(f"No tab:energy endpoint table in {path}")
    end = text.find(r"\end{table}", location)
    if end < 0:
        raise AssertionError(f"No end of endpoint table in {path}")
    section = text[location:end]
    row_pattern = re.compile(r"\$([+-]{4})\$\s*&\s*(\d+)\s*&\s*\$?([+-]?\d+(?:\.\d+)?)\$?\s*&\s*\$?([+-]?\d+(?:\.\d+)?)\$?")
    rows = {match[0]: (int(match[1]), float(match[2]), float(match[3])) for match in row_pattern.findall(section)}
    if set(rows) != set(REPRESENTATIVES):
        raise AssertionError(f"Expected four manuscript families, found {sorted(rows)} in {path}")
    for expected in endpoint_rows:
        count, first, second = rows[expected["representative"]]
        if count != expected["state_count"]:
            raise AssertionError(f"Manuscript count mismatch in {path}: {expected['representative']}")
        for actual, key in ((first, "beta0_energy_over_Estar"), (second, "beta1_energy_over_Estar")):
            if abs(actual-expected[key]) > 0.500001e-3:
                raise AssertionError(f"Manuscript endpoint mismatch in {path}: {expected['representative']} {key}")
    return {"path": str(path), "four_families_and_endpoint_values": "PASS"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--generate", action="store_true", help="write normalized CSV/JSON data and manifest")
    modes.add_argument("--check-only", action="store_true", help="read-only recomputation and existing-file check (default)")
    parser.add_argument("--report", action="store_true", help="print the detailed verification report as JSON; does not save it")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parents[1]/"data")
    parser.add_argument("--manuscript", type=Path, action="append", default=[], help="check an EN or ZH main.tex endpoint table; repeat for both")
    args = parser.parse_args()
    try:
        datasets = build_data()
        summary = datasets["model_summary.json"]
        manuscript_checks = [check_manuscript(path, summary["manuscript_endpoint_table"]) for path in args.manuscript]
        if args.generate:
            write_data(args.output_dir, datasets)
        checked_files = check_data(args.output_dir, datasets)
        report = {"status": "PASS", "mode": "GENERATE_AND_CHECK" if args.generate else "READ_ONLY_CHECK",
                  "generated_model_files_checked": checked_files, "square_states": len(datasets["square_states.csv"]),
                  "beta_settings": len(BETA_VALUES), "rotation_orbits": len(summary["rotation_orbits"]),
                  "zero_rod_moment_states_per_beta": 4,
                  "family_counts": list(FAMILY_COUNTS), "probe_rows": len(datasets["probe_predictions.csv"]),
                  "rod_sphere_rows": len(datasets["rod_sphere_response.csv"]),
                  "model_checks_passed": len(summary["checks"]), "model_checks_total": len(summary["checks"]),
                  "maximum_absolute_errors": summary["maximum_absolute_errors"],
                  "manuscript_tables": manuscript_checks,
                  "dependencies": {"python": sys.version.split()[0], "numpy": np.__version__}}
        if args.report:
            print(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True))
        else:
            print(f"PASS | {report['mode']} | {checked_files} generated model files verified")
            print(f"80 square states; 5 beta settings; 6 rotation orbits; family counts 2,8,4,2")
            print(f"{report['model_checks_passed']}/{report['model_checks_total']} model checks passed; {len(manuscript_checks)} manuscript tables verified")
            print(f"maximum stationarity residual: {summary['maximum_absolute_errors']['stationarity_residual']:.3g}")
            print(f"maximum energy-gradient probe error: {summary['maximum_absolute_errors']['probe_force_finite_gradient']:.3g}")
        return 0
    except (AssertionError, ValueError, OSError, KeyError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
