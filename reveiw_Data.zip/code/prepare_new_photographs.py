"""Prepare proportional JPEG copies of the nine supplied construction photographs."""
from pathlib import Path
from PIL import Image,ImageOps
import hashlib,json,shutil
root=Path(__file__).resolve().parents[1]
source=root/'picture'; out=root/'figures'/'photographs'/'picture_20261104'
out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=[]
for i in range(1,10):
 src=source/f'picture{i}.jpg'; dest=out/f'picture{i}.jpg'
 with Image.open(src) as original:
  size=original.size; orientation=original.getexif().get(274,1); icc=original.info.get('icc_profile')
  im=ImageOps.exif_transpose(original).convert('RGB'); im.thumbnail((1600,1600),Image.Resampling.LANCZOS)
  options={'format':'JPEG','quality':94,'subsampling':0,'optimize':True}
  if icc:options['icc_profile']=icc
  im.save(dest,**options)
  final=im.size
 for folder in ['revision','revision_zh']:
  shutil.copyfile(dest,root/folder/'figures'/dest.name)
 record.append({'source':str(src.relative_to(root)),'original_dimensions':size,'exif_orientation':orientation,'source_sha256':sha(src),'output':str(dest.relative_to(root)),'output_dimensions':final,'output_sha256':sha(dest),'original_bytes':src.stat().st_size,'output_bytes':dest.stat().st_size,'method':'proportional Lanczos resize; JPEG quality 94, no chroma subsampling; whole image retained'})
(out/'manifest.json').write_text(json.dumps({'items':record},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'count':len(record),'source_bytes':sum(x['original_bytes'] for x in record),'compressed_bytes':sum(x['output_bytes'] for x in record),'dimensions':record[0]['output_dimensions']},indent=2))
