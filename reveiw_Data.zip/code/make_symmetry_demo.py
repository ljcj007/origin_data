"""Build the offline rod-moment symmetry demonstration from the paper's data.

Python 3.10+, Matplotlib. Run from any directory; no web service is required.
The default input is data/square_states.csv beside the code/ directory.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "demonstrations" / "magnetic_symmetry"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_states(data: Path) -> list[dict]:
    with data.open(encoding="utf-8", newline="") as stream:
        rows = [row for row in csv.DictReader(stream) if float(row["beta"]) == 0.0]
    assert len(rows) == 16, "The zero-response data must contain all 16 states."
    assert len({row["pattern"] for row in rows}) == 16
    rows.sort(key=lambda row: tuple(1 if c == "+" else -1 for c in row["pattern"]))
    states = []
    for index, row in enumerate(rows):
        pattern = row["pattern"]
        assert len(pattern) == 4 and set(pattern) <= {"+", "-"}
        signs = [1 if c == "+" else -1 for c in pattern]
        moment = [signs[3] - signs[1], signs[0] - signs[2]]
        c2 = all(signs[i] == signs[(i + 2) % 4] for i in range(4))
        c4 = len(set(signs)) == 1
        assert moment == [float(row["Mrod_x_over_m0"]), float(row["Mrod_y_over_m0"])]
        assert c2 == bool(int(row["joint_C2"]))
        assert c4 == bool(int(row["joint_C4"]))
        states.append({"id": pattern, "signs": signs, "image": f"pattern_{index:02d}.png",
                       "rod_sum_over_m0": moment, "C2": c2, "C4": c4})
    assert sum(s["rod_sum_over_m0"] == [0, 0] for s in states) == 4
    assert sum(s["C4"] for s in states) == 2
    assert sum(s["C2"] for s in states) == 4
    return states


def draw_states(states: list[dict], output: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle, FancyArrowPatch

    positions = [(0.5, 0), (0, 0.5), (-0.5, 0), (0, -0.5)]
    axes = [(0, 1), (-1, 0), (0, -1), (1, 0)]
    labels = [(0.66, 0), (0, 0.66), (-0.66, 0), (0, -0.66)]
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12})
    for state in states:
        fig, ax = plt.subplots(figsize=(4.8, 4.4), dpi=160)
        ax.set_aspect("equal")
        ax.set_xlim(-0.88, 0.88)
        ax.set_ylim(-0.82, 0.82)
        ax.axis("off")
        for x, y in [(-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)]:
            ax.add_patch(Circle((x, y), 0.068, facecolor="#d9dde0", edgecolor="#687580", zorder=3))
        for i, ((x, y), (ex, ey), (lx, ly), sign) in enumerate(zip(positions, axes, labels, state["signs"])):
            ax.plot([x - .43 * ex, x + .43 * ex], [y - .43 * ey, y + .43 * ey],
                    color="#aebbc3", linewidth=9, solid_capstyle="butt", zorder=1)
            ax.add_patch(FancyArrowPatch((x - .27 * sign * ex, y - .27 * sign * ey),
                                        (x + .27 * sign * ex, y + .27 * sign * ey),
                                        arrowstyle="-|>", mutation_scale=25, linewidth=2.4,
                                        color="#165f88", zorder=4))
            ax.text(lx, ly, str(i), ha="center", va="center", fontweight="bold", color="#263d4b")
        ax.text(0, 0, state["id"].replace("-", "−"), ha="center", va="center", fontsize=19,
                fontfamily="DejaVu Sans Mono", color="#263d4b")
        # Coordinate arrows establish the signs of the reported vector components.
        for target, label in [((.23, -.14), "x"), ((.12, -.03), "y")]:
            ax.annotate("", target, (.12, -.14), arrowprops={"arrowstyle": "->", "color": "#687580"})
            ax.text(target[0] + .03, target[1], label, fontsize=9, color="#687580")
        fig.subplots_adjust(left=.025, right=.975, bottom=.025, top=.975)
        fig.savefig(output / state["image"], facecolor="white", dpi=160)
        plt.close(fig)


HTML = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>四根磁棒的磁矩与旋转对称性 | Four-rod symmetry</title>
<style>
:root{color-scheme:light}body{max-width:940px;margin:28px auto;padding:0 18px;font:17px/1.65 system-ui,"Microsoft YaHei",sans-serif;color:#17374a;background:#f5f8fa}h1{font-size:1.65rem;line-height:1.35}section{background:white;border:1px solid #d1dce3;border-radius:10px;padding:22px;margin:18px 0}p{margin:.7em 0}img{display:block;width:480px;max-width:100%;height:auto;margin:auto}label,button,select{font:inherit}button,select{padding:8px 12px;margin:6px 10px 6px 0}button{background:#165f88;color:white;border:0;border-radius:5px;cursor:pointer}select{max-width:100%}#answer{background:#e8f2f8;padding:15px;margin-top:12px}#answer p:first-child{margin-top:0}#answer p:last-child{margin-bottom:0}.secondary{font-size:.94rem;color:#465f70}.toolbar{display:flex;justify-content:flex-end}code{font-family:monospace}a{color:#165f88}noscript{display:block;background:#fff2d3;padding:12px}@media print{.toolbar,button,select{display:none}section{break-inside:avoid}}
</style></head><body><div class="toolbar"><label for="language">语言 / Language <select id="language"><option value="zh">中文</option><option value="en">English</option></select></label></div>
<h1 id="title"></h1><p id="lead"></p>
<section><p id="model"></p><p id="convention"></p><label for="state" id="stateLabel"></label> <select id="state"></select>
<img id="pattern" src="pattern_15.png" alt="四根磁棒的磁矩方向，构型++++" width="768" height="704">
<p id="task"></p><button id="reveal" type="button"></button><div id="answer" hidden aria-live="polite"></div>
<noscript>请启用 JavaScript 以切换构型与显示计算结果。Enable JavaScript to switch states and show the calculations.</noscript></section>
<section><h2 id="discussionTitle"></h2><p id="discussion"></p><p id="scope" class="secondary"></p><p id="dataNote" class="secondary"></p></section>
<script id="model-data" type="application/json">__STATES__</script>
<script>
"use strict";
const states=JSON.parse(document.getElementById("model-data").textContent);
const words={zh:{title:"四根磁棒的磁矩与旋转对称性",lead:"先作预测，再用矢量和与旋转检验核对自己的判断。",model:"四根磁棒位于正方形的边中点，每根棒的磁矩大小均为 m₀。蓝箭头表示磁矩方向，灰球只标出几何顶点；这幅示意图不按器材尺寸比例绘制。",convention:"编号 0、1、2、3 依次为右、上、左、下。正方向依次为向上、向左、向下、向右。符号串按此编号排列：“+”取正方向，“−”取反方向。坐标 x 向右，y 向上。",stateLabel:"选择构型：",task:"根据箭头计算四根磁棒的合磁矩，并判断图样整体旋转 90° 或 180° 后是否与原图重合。旋转时，棒的位置与磁矩矢量须一起旋转。",reveal:"显示计算与旋转检验",discussionTitle:"继续思考",discussion:"比较 ++++ 与 +-+-：它们的合磁矩相同，旋转对称性也相同吗？用你选出的构型说明，单个整体量能否唯一确定局部磁矩图样。",scope:"本演示讨论磁棒的几何位置和磁矩对称性。球的磁响应不参与这里的计算；完整组件的自洽诱导磁矩与能量见论文及配套计算数据。四棒合磁矩为零也不表示任意观测点的磁场为零。",dataNote:"16 个状态取自论文模型数据 square_states.csv 的 β = 0 行；合磁矩和旋转判断另用四个符号独立核对。",moment:"四棒合磁矩 / m₀ = ",rotation90:"旋转 90° 后重合：",rotation180:"旋转 180° 后重合：",yes:"是",no:"否",geometry:"所有构型的几何骨架相同；磁矩图样的旋转对称性取决于箭头方向。",alt:"四根磁棒的磁矩方向，构型 "},en:{title:"Magnetic moments and rotational symmetry of four rods",lead:"Make a prediction, then test it using a vector sum and a rotation.",model:"Four rods sit at the edge centres of a square. Each rod has magnetic moment magnitude m₀. Blue arrows show the moments; grey spheres mark geometric vertices only. The drawing is not to scale.",convention:"Rods 0, 1, 2 and 3 are at the right, top, left and bottom. Their positive directions are up, left, down and right. The sign string follows this order: + selects the positive direction and − reverses it. The x-axis points right and the y-axis up.",stateLabel:"Choose a configuration:",task:"Calculate the sum of the four rod moments. Does the pattern coincide with itself after a 90° or 180° rotation? Rotate the rod positions and the moment vectors together.",reveal:"Show the calculation and rotation tests",discussionTitle:"Explore further",discussion:"Compare ++++ with +-+-: they have the same summed moment, but do they have the same rotational symmetry? Use these configurations to discuss whether one global quantity uniquely determines a local moment pattern.",scope:"This demonstration concerns rod geometry and moment symmetry. It omits the magnetic response of the spheres; the paper and its calculation data treat self-consistent induced moments and energies. Zero summed rod moment does not imply zero field at every observation point.",dataNote:"The 16 states come from the β = 0 rows of square_states.csv. Their summed moments and rotation tests are checked independently from the four signs.",moment:"Sum of rod moments / m₀ = ",rotation90:"Coincides after a 90° rotation: ",rotation180:"Coincides after a 180° rotation: ",yes:"yes",no:"no",geometry:"Every configuration has the same geometric skeleton; the rotational symmetry of the moment pattern depends on the arrows.",alt:"Directions of four rod moments, configuration "}};
const select=document.getElementById("state"),language=document.getElementById("language"),picture=document.getElementById("pattern"),answer=document.getElementById("answer");
states.forEach((r,i)=>{const option=document.createElement("option");option.value=String(i);option.textContent=r.id.replaceAll("-","−");select.appendChild(option)});select.value=String(states.findIndex(r=>r.id==="++++"));
function update(){const r=states[Number(select.value)],w=words[language.value];picture.src=r.image;picture.alt=w.alt+r.id;answer.hidden=true;answer.replaceChildren()}
function translate(){const w=words[language.value];document.documentElement.lang=language.value==="zh"?"zh-CN":"en";document.title=w.title;["title","lead","model","convention","stateLabel","task","reveal","discussionTitle","discussion","scope","dataNote"].forEach(id=>document.getElementById(id).textContent=w[id]);update()}
select.addEventListener("change",update);language.addEventListener("change",translate);
document.getElementById("reveal").addEventListener("click",()=>{const r=states[Number(select.value)],w=words[language.value];answer.replaceChildren();[w.moment+"("+r.rod_sum_over_m0.join(", ")+")",w.rotation90+(r.C4?w.yes:w.no)+"; "+w.rotation180+(r.C2?w.yes:w.no),w.geometry].forEach(text=>{const p=document.createElement("p");p.textContent=text;answer.appendChild(p)});answer.hidden=false});translate();
</script></body></html>
'''


def verify(data: Path, output: Path) -> dict:
    expected = read_states(data)
    source = json.loads((output / "model_source.json").read_text(encoding="utf-8"))
    assert source["states"] == expected
    assert source["data_sha256"] == digest(data)
    assert source["generator_sha256"] == digest(Path(__file__))
    html = (output / "index.html").read_text(encoding="utf-8")
    block = re.search(r'<script id="model-data" type="application/json">(.*?)</script>', html, re.S)
    assert block and json.loads(block.group(1)) == expected
    assert not re.search(r'(?:src|href)=["\x27](?:https?:)?//|\bfetch\s*\(|XMLHttpRequest|\bimport\s*\(', html)
    for state in expected:
        image = output / state["image"]
        assert image.read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
        assert digest(image) == source["images_sha256"][state["image"]]
    for target in re.findall(r'(?:src|href)=["\x27]([^"\x27]+)', html):
        assert (output / target).is_file(), target
    return {"status": "PASS", "states": 16, "zero_rod_moment_states": 4,
            "C2_states": 4, "C4_states": 2, "images": 16,
            "data_and_generator_hashes": "PASS", "local_paths": "PASS",
            "external_dependencies_at_runtime": "NONE",
            "browser_interaction": "NOT_EXECUTED_BY_THIS_CHECK"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data" / "square_states.csv")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--check-only", action="store_true", help="verify existing outputs without writing")
    args = parser.parse_args()
    if not args.check_only:
        states = read_states(args.data)
        args.output.mkdir(parents=True, exist_ok=True)
        draw_states(states, args.output)
        (args.output / "index.html").write_text(HTML.replace("__STATES__", json.dumps(states, separators=(",", ":"))), encoding="utf-8")
        source = {"schema_version": "1.0", "evidence_kind": "IDEAL_MODEL_CALCULATION",
                  "data_file": "data/square_states.csv", "beta": 0,
                  "data_sha256": digest(args.data), "generator_sha256": digest(Path(__file__)),
                  "definition": "Equal rod moments m0 on cyclic tangent axes; spheres mark vertices only.",
                  "images_sha256": {s["image"]: digest(args.output / s["image"]) for s in states}, "states": states}
        (args.output / "model_source.json").write_text(json.dumps(source, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(verify(args.data, args.output), indent=2))


if __name__ == "__main__":
    main()
