"""Reproducible analytical publication figures; no measured observations.

Python 3 with numpy and matplotlib. Run from any working directory.
The copied source CSV is an immutable input to the energy panel.
PDF and SVG artwork is vector; the manuscripts include the standalone PDFs.
"""
from pathlib import Path
import csv, json, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
matplotlib.rcParams.update({
    'font.family':'sans-serif', 'font.sans-serif':['Arial','DejaVu Sans'],
    'font.size':8.5, 'axes.labelsize':9, 'axes.titlesize':9,
    'xtick.labelsize':8, 'ytick.labelsize':8,
    'legend.fontsize':8, 'legend.frameon':False, 'axes.spines.top':False, 'axes.spines.right':False,
    'axes.linewidth':0.7, 'lines.linewidth':1.2,
    'svg.fonttype':'none', 'pdf.fonttype':42,
    'savefig.facecolor':'white', 'figure.facecolor':'white',
})
MM = 1 / 25.4
BLUE='#286b91'; ORANGE='#bc6932'; PURPLE='#75638a'; GRAY='#7b858c'; DARK='#233640'
PALETTE=[BLUE, GRAY, PURPLE, ORANGE]
record=[]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def export(fig, stem, height):
    # Avoid bbox_inches=tight: all exports retain the stated final dimensions.
    for ext in ['png','pdf','svg']:
        fig.savefig(OUT / f'{stem}.{ext}', dpi=400)
    record.append({'stem':stem,'width_mm':150,'height_mm':height,
        'font_pt_min':8,'font_pt_max':11,'raster_dpi':400,
        'vector_formats':['pdf','svg'],
        'sha256':{e:sha(OUT / f'{stem}.{e}') for e in ['png','pdf','svg']}})
    plt.close(fig)

def tag(ax, letter, x=-.04, y=1.06):
    ax.text(x,y,f'({letter})',transform=ax.transAxes,fontweight='bold',fontsize=10,va='top')

def arrow(ax, start, end, color=BLUE, width=1.3, scale=9, z=6):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=scale,
        lw=width,color=color,zorder=z,shrinkA=0,shrinkB=0))

contracts={
 'backend':'Python / matplotlib exclusively',
 'fig1':{'conclusion':'A triangular Bravais lattice with distinct bases constructs triangular, honeycomb and kagome networks.',
         'archetype':'schematic-led composite','panels':['one-site triangular basis','two-site honeycomb basis','three-site kagome basis'],
         'integrity':'Geometry derived analytically; a=19 mm is centre-to-centre rod-ball spacing, not a measured lattice calibration.'},
 'fig2':{'conclusion':'Zero total rod moment does not fix symmetry or energy.',
         'archetype':'schematic-led composite','panels':['uniform circulation C4','alternating C2','four self-consistent energy families'],
         'integrity':'Exact saved point-dipole model results; common energy offset retained. beta=1 is an ideal isolated-sphere polarizability bound used in a self-consistent sphere calculation, not measured iron response.'},
 'fig3':{'conclusion':'Controlled field operations distinguish fixed, freely rotating and linear-induced probe responses.',
         'archetype':'quantitative grid','panels':['whole-field scaling laws','three operation triplets'],
         'integrity':'Explicit normalized equations; quasistatic freely aligned branch and linear induced model. No measured force or learner data.'},
 'export':{'width_mm':150,'fonts_pt':[8,11],'editable_text':True,'captions_inside_graphic':False},
}
(OUT/'figure_contract.json').write_text(json.dumps(contracts,indent=2)+'\n',encoding='utf-8')

def geometry(name):
    sq=np.sqrt(3)
    if name=='Triangular':
        A=np.array([[1,0],[.5,sq/2]]); B=np.array([[0,0]])
    elif name=='Honeycomb':
        A=np.array([[sq,0],[sq/2,1.5]]); B=np.array([[0,0],[sq/2,.5]])
    else:
        A=np.array([[2,0],[1,sq]]); B=np.array([[0,0],[1,0],[.5,sq/2]])
    V=np.array([i*A[0]+j*A[1]+b for i in range(-3,4) for j in range(-3,4) for b in B])
    edges=[]
    for i in range(len(V)):
        for j in range(i):
            if abs(np.linalg.norm(V[i]-V[j])-1)<1e-8:
                edges.append([i,j])
    return A,B,V,edges

def fig1():
    fig=plt.figure(figsize=(150*MM,73*MM))
    names=['Triangular','Honeycomb','Kagome']; data={}
    for k,name in enumerate(names):
        ax=fig.add_axes([.027+.328*k,.17,.306,.68]); ax.set_aspect('equal');ax.axis('off')
        A,B,V,E=geometry(name)
        ax.set_xlim(-.66,3.3);ax.set_ylim(-.65,3.1)
        for i,j in E:
            ax.plot(V[[i,j],0],V[[i,j],1],color='#acb4b9',lw=1.1,zorder=1)
        for p in V:
            ax.add_patch(Circle(p,.072,fc='#e6e9eb',ec=GRAY,lw=.7,zorder=2,clip_on=True))
        ax.add_patch(Polygon([np.zeros(2),A[0],A[0]+A[1],A[1]],closed=True,
                             fc='none',ec=ORANGE,ls=(0,(4,2)),lw=1.2,zorder=3))
        for bi,p in enumerate(B):
            ax.add_patch(Circle(p,.109,fc='#d5e6ef',ec=BLUE,lw=1.2,zorder=5))
            # Indices denote sites of the basis, not moment signs.
            ax.text(p[0]+.14,p[1]+.12,str(bi+1),fontsize=8,color=BLUE,zorder=7)
        o1=np.array([0,-.31]);o2=np.array([-.31,0])
        arrow(ax,o1,A[0]+o1); arrow(ax,o2,A[1]+o2)
        ax.text(*(A[0]/2+o1+[0,-.18]),r'$\mathbf{a}_1$',ha='center',fontsize=9,color=BLUE)
        ax.text(*(A[1]/2+o2+[-.15,.03]),r'$\mathbf{a}_2$',ha='right',fontsize=9,color=BLUE)
        tag(ax,chr(97+k),x=.01,y=1.15)
        ax.text(.5,1.115,name,ha='center',transform=ax.transAxes,fontsize=10)
        ax.text(.5,-.11,f'{len(B)}-site basis',ha='center',transform=ax.transAxes,fontsize=9)
        data[name]={'a_mm':19,'primitive_vectors_over_a':A.tolist(),'basis_positions_over_a':B.tolist(),
                    'vertices_over_a':V.tolist(),'edges':E}
    fig.text(.03,.05,r'$a=19\,\mathrm{mm}$',fontsize=9)
    fig.text(.36,.05,'Blue: basis sites',color=BLUE,fontsize=8.5)
    fig.text(.67,.05,'Dashed: primitive cell',color=ORANGE,fontsize=8.5)
    (OUT/'fig1_geometry.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    export(fig,'fig1_lattice_basis',73)

def square(ax, signs, letter, title, sym):
    ax.set_aspect('equal'); ax.axis('off'); ax.set_xlim(-1.7,1.7);ax.set_ylim(-1.55,1.6)
    corners=np.array([[-1,-1],[1,-1],[1,1],[-1,1]])
    for i in range(4):
        p,q=corners[i],corners[(i+1)%4]
        ax.plot([p[0],q[0]],[p[1],q[1]],lw=6,color='#d6dce0',solid_capstyle='round',zorder=1)
    for p in corners:ax.add_patch(Circle(p,.14,fc='#edf0f2',ec=GRAY,lw=.9,zorder=4))
    pos=np.array([[1,0],[0,1],[-1,0],[0,-1]])
    axes=np.array([[0,1],[-1,0],[0,-1],[1,0]])
    for i,(p,e,s) in enumerate(zip(pos,axes,signs)):
        arrow(ax,p-.51*s*e,p+.51*s*e,color=BLUE if s>0 else ORANGE,scale=10,width=1.8,z=5)
        outward=p*.35
        ax.text(*(p+outward),fr'$e_{i}$: '+('+' if s>0 else '−'),ha='center',va='center',fontsize=8.5)
    ax.text(0,.2,fr'${sym}$',ha='center',fontsize=11)
    ax.text(0,-.25,r'$\mathbf{M}_{\rm rod}=0$',ha='center',fontsize=9)
    tag(ax,letter,x=.01,y=1.11)
    ax.text(.5,1.065,title,ha='center',transform=ax.transAxes,fontsize=9)

def energy_data():
    src=OUT/'energy_states_source.csv'
    rows=list(csv.DictReader(src.open(encoding='utf-8-sig')))
    families=['UNIFORM_CIRCULATION','SINGLE_DIFFERENT_SIGN','CONTIGUOUS_TWO_PLUS','ALTERNATING']
    result=[]
    for fam in families:
        for beta in [0,1]:
            selected=[r for r in rows if r['class']==fam and float(r['beta'])==beta]
            values=np.array([float(r['U_self_consistent_over_Estar']) for r in selected])
            assert np.ptp(values)<1e-10
            result.append({'family':fam,'beta':beta,'state_count':len(selected),'U_over_Estar':values.mean()})
    with (OUT/'fig2_energy.csv').open('w',newline='',encoding='utf-8') as h:
        w=csv.DictWriter(h,fieldnames=list(result[0]));w.writeheader();w.writerows(result)
    return result

def fig2():
    fig=plt.figure(figsize=(150*MM,94*MM))
    ax1=fig.add_axes([.07,.56,.35,.36]); ax2=fig.add_axes([.58,.56,.35,.36])
    square(ax1,[1,1,1,1],'a','Uniform: ++++','C_4')
    square(ax2,[1,-1,1,-1],'b','Alternating: +−+−','C_2')
    ax=fig.add_axes([.12,.13,.52,.31]);tag(ax,'c',x=-.17,y=1.1)
    data=energy_data();families=list(dict.fromkeys(r['family'] for r in data))
    labels=['Uniform (2)','One reversed (8)','Two adjacent + (4)','Alternating (2)']
    styles=['-','--','-.',':']; markers=['o','s','D','^']
    for k,(fam,label) in enumerate(zip(families,labels)):
        vals=[r['U_over_Estar'] for r in data if r['family']==fam]
        ax.plot([0,1],vals,color=PALETTE[k],ls=styles[k],marker=markers[k],ms=4,lw=1.4)
        label_y=vals[1]
        if k==1:label_y=-12.5
        if k==2:label_y=-4.7
        if k in [1,2]:
            ax.plot([1.005,1.045],[vals[1],label_y],color=PALETTE[k],lw=.7,clip_on=False)
        ax.text(1.065,label_y,label,va='center',color=PALETTE[k],fontsize=8.5,clip_on=False)
    ax.axhline(0,color='#c8cdd1',lw=.65,zorder=0)
    ax.set_xlim(-.05,1.03);ax.set_ylim(-34,18);ax.set_yticks([-30,-15,0,15])
    ax.set_xticks([0,1],[r'$\beta=0$',r'$\beta=1$'])
    ax.set_ylabel(r'$U/E_*$');ax.tick_params(direction='out',length=3,width=.7)
    fig.text(.13,.485,'Self-consistent point-dipole energies',fontsize=9)
    fig.text(.13,.045,r'$\beta=1$: ideal sphere bound; common energy zero',fontsize=8.5)
    (OUT/'fig2_square.json').write_text(json.dumps({'centres_over_a':[[.5,0],[0,.5],[-.5,0],[0,-.5]],
        'tangential_axes':[[0,1],[-1,0],[0,-1],[1,0]],'patterns':[[1,1,1,1],[1,-1,1,-1]],
        'symmetry':['C4','C2'],'rod_moment_sum':[0,0]},indent=2)+'\n',encoding='utf-8')
    export(fig,'fig2_symmetry_energy',94)

def fig3():
    fig=plt.figure(figsize=(150*MM,74*MM))
    ax=fig.add_axes([.11,.18,.39,.64]);tag(ax,'a',x=-.2,y=1.16)
    c=np.linspace(-2,2,401)
    fixed=c;free=np.abs(c);induced=c*c
    ax.plot(c,induced,color=PURPLE,ls=':',lw=1.8,label='Induced: $c^2$')
    ax.plot(c,free,color=ORANGE,ls='--',lw=2.1,label='Free: $|c|$')
    ax.plot(c,fixed,color=BLUE,lw=1.2,label='Fixed: $c$')
    ax.axhline(0,color='#bdc6cb',lw=.6,zorder=0);ax.axvline(0,color='#bdc6cb',lw=.6,zorder=0)
    ax.set_xlim(-2.05,2.05);ax.set_ylim(-2.2,4.2);ax.set_xticks([-2,-1,0,1,2]);ax.set_yticks([-2,0,2,4])
    ax.set_xlabel(r'Whole-field scale $c$');ax.set_ylabel(r'Normalized force $F/F_0$')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,1.21),ncol=1,handlelength=2.1,fontsize=8)
    ax.tick_params(direction='out',length=3,width=.7)
    bx=fig.add_axes([.59,.18,.39,.64]);bx.axis('off');tag(bx,'b',x=-.1,y=1.16)
    bx.text(.46,1.095,'Controlled operations',ha='center',fontsize=9,transform=bx.transAxes)
    headers=['Fixed','Free','Induced'];colx=[.34,.60,.88]
    for x,txt,col in zip(colx,headers,[BLUE,ORANGE,PURPLE]):
        bx.text(x,.85,txt,ha='center',color=col,fontsize=8.5,transform=bx.transAxes)
    operations=[('Reverse all',[-1,1,1]),('Double all',[2,2,4]),('Double $B_0$',[1,1,2])]
    for y,(label,vals) in zip([.65,.42,.19],operations):
        bx.text(-.06,y,label,ha='left',fontsize=8.5,transform=bx.transAxes)
        for x,val,col in zip(colx,vals,[BLUE,ORANGE,PURPLE]):
            bx.text(x,y,str(val).replace('-','−'),ha='center',fontweight='bold',color=col,fontsize=10,transform=bx.transAxes)
    for y in [.76,.54,.31,.08]:bx.plot([-.07,1.02],[y,y],transform=bx.transAxes,color='#ced4d8',lw=.6,clip_on=False)
    fig.text(.59,.05,'Entries: normalized force ratios',fontsize=8.5)
    with (OUT/'fig3_scaling.csv').open('w',newline='',encoding='utf-8') as h:
        w=csv.writer(h);w.writerow(['c','fixed','free','induced']);w.writerows(zip(c,fixed,free,induced))
    (OUT/'fig3_operations.json').write_text(json.dumps({'whole_field_scaling':{'fixed':'c','free':'abs(c)','induced':'c^2'},
        'operations':dict(operations),'bias_only_assumption':'B0 dominates induced moment; field gradient unchanged; fixed and free moments unchanged.'},indent=2)+'\n',encoding='utf-8')
    export(fig,'fig3_force_controls',74)

if __name__=='__main__':
    fig1();fig2();fig3()
    (OUT/'export_manifest.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record,indent=2))
