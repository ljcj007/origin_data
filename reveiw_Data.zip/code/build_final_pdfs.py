#!/usr/bin/env python3
"""Compile both manuscripts with XeLaTeX, resolving references before export.

Run from any directory: python code/build_final_pdfs.py
Requires XeLaTeX on PATH, or pass --engine /path/to/xelatex.
The supplied photographs and diagrams are read only.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
JOBS = [('en', 'revision', 'main.tex'), ('zh', 'revision_zh', 'main_zh.tex')]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--engine', default=shutil.which('xelatex'))
    parser.add_argument('--bibtex', default=shutil.which('bibtex'))
    args = parser.parse_args()
    if not args.engine:
        raise SystemExit('XeLaTeX was not found. Install a TeX distribution or use --engine.')
    if not args.bibtex:
        raise SystemExit('BibTeX was not found. Install a TeX distribution or use --bibtex.')
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    build_root = ROOT / 'tmp' / 'pdfs' / ('build_' + stamp)
    build_root.mkdir(parents=True, exist_ok=False)
    output = ROOT / 'output' / 'pdf'
    output.mkdir(parents=True, exist_ok=True)
    assets = {p: digest(p) for _, folder, _ in JOBS
              for p in (ROOT / folder / 'figures').iterdir() if p.is_file()}
    version = subprocess.run([args.engine, '--version'], capture_output=True,
                             text=True, encoding='utf-8', errors='replace', check=True)
    report = {'engine': version.stdout.splitlines()[0], 'built_at': stamp,
              'method': 'local XeLaTeX and BibTeX, isolated auxiliary files, shell escape disabled',
              'build_directory': build_root.relative_to(ROOT).as_posix(), 'manuscripts': []}
    ready = []
    for language, folder, filename in JOBS:
        build = build_root / language
        build.mkdir()
        job = 'release_' + language
        command = [args.engine, '-interaction=nonstopmode', '-halt-on-error',
                   '-file-line-error', '-no-shell-escape', '-jobname=' + job,
                   '-output-directory=' + str(build), filename]
        previous = None
        for run in range(1, 5):
            result = subprocess.run(command, cwd=ROOT / folder, capture_output=True,
                                    text=True, encoding='utf-8', errors='replace')
            (build / f'pass_{run}.txt').write_text(result.stdout + result.stderr, encoding='utf-8')
            if result.returncode:
                raise RuntimeError(f'{language}: XeLaTeX failed; see {build / f"pass_{run}.txt"}')
            log = (build / (job + '.log')).read_text(encoding='utf-8', errors='replace')
            if run == 1:
                bib = subprocess.run([args.bibtex, str(build / job)], cwd=ROOT / folder,
                                     capture_output=True, text=True, encoding='utf-8', errors='replace')
                (build / 'bibtex.txt').write_text(bib.stdout + bib.stderr, encoding='utf-8')
                if bib.returncode or not (build / (job + '.bbl')).is_file():
                    raise RuntimeError(f'{language}: BibTeX failed; see {build / "bibtex.txt"}')
            state = tuple((build / (job + suffix)).read_bytes()
                          if (build / (job + suffix)).exists() else b'' for suffix in ('.aux', '.out'))
            pending = re.search(r'undefined references|Citation .+ undefined|Reference .+ undefined|Rerun to|Label\(s\) may have changed', log)
            if run >= 2 and state == previous and not pending:
                break
            previous = state
        else:
            raise RuntimeError(f'{language}: cross-references did not converge in four passes')
        if re.search(r'Overfull|Missing character|Float too large|LaTeX Error|Package .+ Error', log):
            raise RuntimeError(f'{language}: layout or font error; inspect {build / (job + ".log")}')
        pdf = build / (job + '.pdf')
        if not pdf.is_file() or not pdf.read_bytes().startswith(b'%PDF-'):
            raise RuntimeError(f'{language}: PDF output is missing')
        page_count = re.search(r'\((\d+) pages?\)', log)
        record = {'language': language, 'source': f'{folder}/{filename}',
                  'source_sha256': digest(ROOT / folder / filename), 'passes': run,
                  'pages': int(page_count.group(1)) if page_count else None,
                  'undefined_references': 0, 'overfull_boxes': 0, 'missing_characters': 0,
                  'underfull_hbox_warnings': len(re.findall(r'Underfull \\hbox', log)),
                  'output': f'output/pdf/Magnetic_rod_networks_{language.upper()}.pdf',
                  'manuscript_copy': f'{folder}/{Path(filename).stem}.pdf',
                  'pdf_sha256': digest(pdf)}
        ready.append((pdf, record))
        report['manuscripts'].append(record)
    assert all(digest(p) == value for p, value in assets.items()), 'An image asset changed during compilation'
    report['all_image_assets_unchanged'] = True
    # Publish only after both languages compile successfully.
    for pdf, row in ready:
        shutil.copyfile(pdf, ROOT / row['output'])
        shutil.copyfile(pdf, ROOT / row['manuscript_copy'])
    (output / 'build_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
