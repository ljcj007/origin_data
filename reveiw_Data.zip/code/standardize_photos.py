#!/usr/bin/env python3
"""Conservative, reproducible display preparation of nine construction photographs.

Original JPEGs are read only. The same monotonic gamma curve is applied to
every RGB channel of every photograph. Crops retain the recorded apparatus;
equal-aspect image placement preserves geometry. White padding is page layout.
No segmentation, inpainting, denoising, sharpening or geometry correction occurs.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures' / 'photographs'
GAMMA = 0.62
SIZE = 1000
MARGIN = 55
DISPLAY_MM = 44
BOXES = {
    1: (135,150,675,455), 2: (95,95,535,625), 3: (85,230,460,605),
    4: (50,70,575,780), 5: (0,0,734,521), 6: (0,0,530,707),
    7: (95,0,700,540), 8: (35,115,565,655), 9: (80,160,570,690),
}
NAMES = ['Triangular', 'Honeycomb', 'Kagome', 'Elongated triangular',
         'Snub square', 'Rhombitrihexagonal', 'Square--rhombus',
         'Pentagonal units', 'Triangle--square']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def frame(image):
    """Preserve aspect ratio and centre on a fixed white square canvas."""
    factor = (SIZE-2*MARGIN)/max(image.size)
    target = tuple(round(d*factor) for d in image.size)
    resized = image.resize(target,Image.Resampling.LANCZOS)
    result = Image.new('RGB',(SIZE,SIZE),'white')
    offset = tuple((SIZE-d)//2 for d in target)
    result.paste(resized,offset)
    return result, factor, offset, target

def font(size):
    return ImageFont.truetype(r'C:\Windows\Fonts\arial.ttf',size)

def overview(paths, destination):
    sheet=Image.new('RGB',(1500,1620),'white')
    draw=ImageDraw.Draw(sheet)
    for n,p in enumerate(paths):
        x=(n%3)*500;y=(n//3)*540
        image=Image.open(p).resize((490,490),Image.Resampling.LANCZOS)
        sheet.paste(image,(x+5,y+35))
        draw.text((x+20,y+5),f'{n+1}. {NAMES[n]}',font=font(22),fill='#253b48')
    sheet.save(destination,dpi=(254,254))

def generate():
    OUT.mkdir(parents=True,exist_ok=True)
    # The single common lookup table is recorded, including nonlinear gamma.
    lut=np.rint(255*(np.arange(256,dtype=float)/255)**GAMMA).astype(np.uint8)
    assert np.all(np.diff(lut.astype(int))>=0) and lut[0]==0 and lut[-1]==255
    contract={
        'claim':'Photographs document the connectivity and finite boundaries of constructed rod--sphere networks.',
        'archetype':'three photographic plates, with three clearly separated panels each',
        'backend':'Python, NumPy and Pillow; Matplotlib for PDF plate export',
        'changes':'one common whole-image gamma curve; conservative rectangular cropping; proportional placement on a white square',
        'geometry':'original orientations, perspective and recorded boundaries retained',
        'not_applied':['generative editing','object removal or addition','background replacement','local tonal edits','sharpening','denoising','perspective correction'],
        'scale':'panels are independently framed; no common physical scale or calibrated scale bar',
        'formats':['PNG','LZW TIFF','PDF plates'],
        'canvas_pixels':[SIZE,SIZE], 'main_text_panel_width_mm':DISPLAY_MM,
        'resolution_note':'Canvas pixel count is an export size, not added optical resolution; native effective dpi is recorded for every panel.',
        'policy_url':'https://publishingsupport.iopscience.iop.org/questions/image-manipulation/',
    }
    (OUT/'figure_contract.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
    records=[]; paths=[]
    for i in range(1,10):
        raw=ROOT/'revision'/'figures'/f'word_photo{i}.jpeg'
        src=Image.open(raw).convert('RGB'); raw_hash=digest(raw)
        array=np.asarray(src)
        enhanced=Image.fromarray(lut[array])
        crop=BOXES[i]
        corrected=enhanced.crop(crop)
        panel,factor,offset,target=frame(corrected)
        stem=f'photo_{i:02d}_standard'
        png=OUT/(stem+'.png'); tif=OUT/(stem+'.tif')
        panel.save(png,dpi=(SIZE*25.4/DISPLAY_MM,)*2)
        panel.save(tif,compression='tiff_lzw',dpi=(SIZE*25.4/DISPLAY_MM,)*2)
        # Manuscripts are independently portable with their own figures folder.
        for directory in ('revision','revision_zh'):
            shutil.copyfile(png,ROOT/directory/'figures'/png.name)
        assert digest(raw)==raw_hash
        l,t,r,b=crop
        row={
            'photo':i,'name':NAMES[i-1], 'source':raw.relative_to(ROOT).as_posix(),
            'source_sha256':raw_hash,'source_pixels':list(src.size),
            'crop_ltrb_exclusive':list(crop),'cropped_pixels':[r-l,b-t],
            'gamma_exponent':GAMMA,'gamma_expression':'round(255*(channel/255)^0.62)',
            'same_curve_for_all_RGB_channels_and_all_nine_images':True,
            'rotation_degrees':0,'isotropic_resize_factor':factor,'placed_pixels':target,
            'canvas_offset_xy':offset,'canvas_pixels':[SIZE,SIZE],
            'native_effective_dpi_at_44mm':round(SIZE/factor*25.4/DISPLAY_MM,2),
            'gamma_new_white_clipping_pixels':int(np.sum(np.all(lut[array]==255,axis=2)&~np.all(array==255,axis=2))),
            'source_boundary_note':('Original lower image boundary cuts some network members; full source frame retained.' if i==5 else 'Full source frame retained; outer spheres touch the right image boundary.' if i==6 else 'Crop retains the full photographed apparatus and surrounding background.'),
            'outputs':{p.relative_to(ROOT).as_posix():digest(p) for p in (png,tif)},
        }
        records.append(row);paths.append(png)
    overview(paths,OUT/'overview_standardized.png')
    # Each comparison uses the same crop and scale on both sides.
    comparison=Image.new('RGB',(1600,480*9),'white');draw=ImageDraw.Draw(comparison)
    for i in range(1,10):
        src=Image.open(ROOT/'revision'/'figures'/f'word_photo{i}.jpeg').convert('RGB')
        before=frame(src.crop(BOXES[i]))[0]
        after=Image.open(paths[i-1])
        y=(i-1)*480
        draw.text((24,y+10),f'{i}. {NAMES[i-1]}',font=font(26),fill='#253b48')
        for j,(im,label) in enumerate(((before,'Original tone / same crop'),(after,'Standardized'))):
            x=j*800
            draw.text((x+225,y+45),label,font=font(22),fill='#526672')
            comparison.paste(im.resize((395,395),Image.Resampling.LANCZOS),(x+200,y+78))
    comparison.save(OUT/'before_after.png',dpi=(200,200))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'font.size':9})
    for group,stem in [((1,2,3),'photo_plate_lattices'),((4,5,6),'photo_plate_tilings'),((7,8,9),'photo_plate_motifs')]:
        fig=plt.figure(figsize=(150/25.4,51/25.4),facecolor='white')
        for column,i in enumerate(group):
            ax=fig.add_axes([(column*50+3)/150,3/51,44/150,44/51])
            ax.imshow(Image.open(paths[i-1]),interpolation='none');ax.axis('off')
            fig.text((column*50+4)/150,49/51,f'({chr(97+column)})',ha='left',va='top',weight='bold')
        fig.savefig(OUT/(stem+'.pdf'),dpi=600,metadata={'Title':stem,'CreationDate':None,'ModDate':None})
        plt.close(fig)
    record={'date':'2026-10-26','software':{'numpy':np.__version__,'pillow':Image.__version__},
            'program_sha256':digest(Path(__file__)),'global_gamma_lut':lut.tolist(),
            'evidence':'author-supplied construction photographs; display processing only',
            'images':records}
    (OUT/'processing_manifest.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    check()

def check():
    record=json.loads((OUT/'processing_manifest.json').read_text(encoding='utf-8'))
    assert record['program_sha256']==digest(Path(__file__))
    for row in record['images']:
        assert digest(ROOT/row['source'])==row['source_sha256']
        assert row['gamma_new_white_clipping_pixels']==0
        for name,h in row['outputs'].items():
            path=ROOT/name;assert digest(path)==h
            image=Image.open(path);assert image.mode=='RGB' and image.size==(SIZE,SIZE)
            if path.suffix=='.png':
                for directory in ('revision','revision_zh'):
                    assert digest(ROOT/directory/'figures'/path.name)==h
        # Recompute pixels from the immutable source, crop and documented LUT.
        src=Image.open(ROOT/row['source']).convert('RGB')
        enhanced=Image.fromarray(np.array(record['global_gamma_lut'],dtype=np.uint8)[np.asarray(src)])
        expected=frame(enhanced.crop(row['crop_ltrb_exclusive']))[0]
        actual=Image.open(OUT/f"photo_{row['photo']:02d}_standard.png")
        assert np.array_equal(np.asarray(actual),np.asarray(expected))
    print(json.dumps({'status':'PASS','photos':9,'raw_hashes':'unchanged','recorded_operations_reproduce_every_output_pixel':True,
                      'shared_gamma':GAMMA,'square_canvas':SIZE,
                      'native_effective_dpi_range_at_44mm':[min(r['native_effective_dpi_at_44mm'] for r in record['images']),max(r['native_effective_dpi_at_44mm'] for r in record['images'])]},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args()
    check() if args.check_only else generate()
