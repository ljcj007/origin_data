#!/usr/bin/env python3
"""Finite cylindrical sources with the existing linear point-sphere response.

All values are deterministic model outputs, not measurements. Rod magnetization
is prescribed, uniform and axial. End-face magnetic-charge quadrature replaces
the source point dipoles in both rod-pair energies and sphere-centre fields.
The sphere response is intentionally unchanged, so this is a controlled source-
geometry comparison, not a finite-body solution for iron in contact with NdFeB.

Default: verify committed data. Use --generate to write CSV/JSON model outputs.
Requires Python and NumPy. No historical project files are imported.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import itertools
import json
import numpy as np
import reproduce_physics as point

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'finite_rods'
ELL = 11.0 / 19.0
RHO = 1.65 / 19.0
NR, NT = 12, 48


def disk_offsets(axis, nr, nt, radius=RHO):
    """Normalized area quadrature: Gauss-Legendre in (rho/radius)^2."""
    t, wt = np.polynomial.legendre.leggauss(nr)
    radial = radius * np.sqrt((t + 1) / 2)
    theta = 2 * np.pi * np.arange(nt) / nt
    v = np.array([0.0, 0.0, 1.0])
    u = np.cross(axis, v)
    offsets = (radial[:, None, None] *
               (np.cos(theta)[None, :, None] * u +
                np.sin(theta)[None, :, None] * v)).reshape(-1, 3)
    weights = np.repeat(wt / (2 * nt), nt)
    return offsets, weights


def end_faces(centre, axis, nr=NR, nt=NT, scale=1.0):
    """Source coordinates / a and magnetic charges / (m0/a)."""
    ell = ELL * scale
    offsets, weights = disk_offsets(axis, nr, nt, radius=RHO * scale)
    nodes = np.concatenate([centre + ell * axis / 2 + offsets,
                            centre - ell * axis / 2 + offsets])
    charges = np.concatenate([weights, -weights]) / ell
    return nodes, charges


def field_at(targets, source):
    """B/B*, with B*=mu0*m0/(4*pi*a^3), outside the cylinder."""
    nodes, charges = source
    targets = np.atleast_2d(targets)
    result = np.zeros_like(targets, dtype=float)
    for start in range(0, len(targets), 128):
        d = targets[start:start+128, None, :] - nodes[None, :, :]
        invr3 = np.linalg.norm(d, axis=2) ** -3
        result[start:start+128] = np.einsum('n,bni,bn->bi', charges, d, invr3)
    return result


def pair_energy(source_i, source_j):
    """Cross energy / E*; no self-energy and no double counting."""
    xi, qi = source_i
    xj, qj = source_j
    result = 0.0
    for start in range(0, len(xi), 128):
        distances = np.linalg.norm(xi[start:start+128, None, :] - xj[None, :, :], axis=2)
        result += np.sum(qi[start:start+128, None] * qj[None, :] / distances)
    return float(result)


def matrices(nr=NR, nt=NT, scale=1.0):
    spheres, _, _ = point.matrices()
    sources = [end_faces(c, e, nr, nt, scale)
               for c, e in zip(point.ROD_CENTRES, point.ROD_AXES)]
    fields = np.column_stack([field_at(point.SPHERE_CENTRES, src).ravel()
                              for src in sources])
    couplings = np.zeros((4, 4))
    for i in range(4):
        for j in range(i):
            couplings[i, j] = couplings[j, i] = -pair_energy(sources[i], sources[j])
    return spheres, fields, couplings


def effective(spheres, fields, rods, beta):
    eta = beta * point.ETA_MAX
    response = eta * np.linalg.solve(np.eye(12) - eta * spheres, fields)
    return rods + fields.T @ response, response


def axial_field(z, scale=1.0):
    """Exact external axial cylinder field / B*, same total moment as dipole."""
    ell, rho = ELL * scale, RHO * scale
    z = np.asarray(z, dtype=float)
    plus, minus = z + ell / 2, z - ell / 2
    return 2 / (rho*rho*ell) * (plus / np.hypot(plus, rho) - minus / np.hypot(minus, rho))


def volume_pair_energy(i, j, nr=8, nt=24, nz=12):
    """Independent check: -integral M_i dot B_j dV / E*."""
    offsets, area_weights = disk_offsets(point.ROD_AXES[i], nr, nt)
    z, wz = np.polynomial.legendre.leggauss(nz)
    positions = (point.ROD_CENTRES[i] +
                 z[:, None, None] * ELL * point.ROD_AXES[i] / 2 +
                 offsets[None, :, :]).reshape(-1, 3)
    weights = (wz[:, None] / 2 * area_weights[None, :]).ravel()
    bj = field_at(positions, end_faces(point.ROD_CENTRES[j], point.ROD_AXES[j]))
    return -float(weights @ (bj @ point.ROD_AXES[i]))


def compute():
    sm, hm, qm = matrices()
    sp, hp, qp = point.matrices()
    signs = np.array(list(itertools.product((-1.0, 1.0), repeat=4)))
    u, v = np.ones(4), np.array([1., -1., 1., -1.])
    rows, state_rows = [], []
    max_formula_error = max_rotation_error = max_reversal_error = max_response_residual = 0.0
    all_circulation_minimum = True
    for beta in np.linspace(0, 1, 101):
        kp, _ = effective(sp, hp, qp, beta)
        kf, response = effective(sm, hm, qm, beta)
        gp = -0.5 * (v @ kp @ v - u @ kp @ u)
        gf = -0.5 * (v @ kf @ v - u @ kf @ u)
        rows.append({'beta':float(beta), 'point_gap_over_Estar':float(gp),
                     'finite_gap_over_Estar':float(gf),
                     'finite_minus_point_over_point_percent':float(100 * (gf/gp - 1)),
                     'point_ja':float(kp[0, 1]), 'finite_ja':float(kf[0, 1]),
                     'point_jo':float(kp[0, 2]), 'finite_jo':float(kf[0, 2]),
                     'finite_common_offset_over_Estar':float(-np.trace(kf)/2)})
        for s in signs:
            p = response @ s
            e = -0.5 * float(s @ kf @ s)
            ea = -0.5 * float(s @ qm @ s) - 0.5 * float((hm @ s) @ p)
            adjacent, opposite = point.pair_sums(s)
            efamily = -np.trace(kf)/2 - kf[0, 1]*adjacent - kf[0, 2]*opposite
            max_formula_error = max(max_formula_error, abs(e-ea), abs(e-efamily), abs(gf-8*kf[0, 1]))
            rolled = np.roll(s, 1)
            max_rotation_error = max(max_rotation_error, abs(e+0.5*float(rolled @ kf @ rolled)))
            max_reversal_error = max(max_reversal_error, abs(e+0.5*float((-s) @ kf @ (-s))))
            max_response_residual = max(max_response_residual, float(np.max(np.abs(p-beta*point.ETA_MAX*(hm@s+sm@p)))))
            all_circulation_minimum &= bool(e >= -0.5*float(u@kf@u)-1e-9)
            state_rows.append({'beta':float(beta),'pattern':point.pattern(s),'finite_Ueff_over_Estar':e})

    convergence=[]
    for nr,nt in [(4,12),(8,24),(12,48),(16,64)]:
        s,h,q = matrices(nr,nt)
        k,_ = effective(s,h,q,1.0)
        convergence.append({'radial_nodes':nr,'angular_nodes':nt,
                            'max_H_difference_from_default':float(np.max(np.abs(h-hm))),
                            'max_Q_difference_from_default':float(np.max(np.abs(q-qm))),
                            'gap_beta0':float(8*q[0,1]),'gap_beta1':float(8*k[0,1])})

    contraction=[]
    for scale in [1.,.5,.25,.125,.0625]:
        _,h,q = matrices(8,24,scale)
        contraction.append({'source_dimension_scale':scale,
                            'relative_H_norm_error':float(np.linalg.norm(h-hp)/np.linalg.norm(hp)),
                            'relative_Q_norm_error':float(np.linalg.norm(q-qp)/np.linalg.norm(qp))})

    axial=[]
    for r_mm in np.linspace(9.5,57,191):
        z=r_mm/19; b=float(axial_field(z)); bp=2/z**3
        axial.append({'centre_separation_mm':float(r_mm),'finite_B_over_Bstar':b,
                      'point_B_over_Bstar':float(bp),'finite_over_point':float(b/bp)})
    # end_faces uses in-plane axes, so rotate an x-axis source for this axial check.
    src=end_faces(np.zeros(3),np.array([1.,0.,0.]))
    zs=np.linspace(.5,3,31)
    numerical=field_at(np.column_stack([zs,0*zs,0*zs]),src)[:,0]
    axis_relative_error=float(np.max(np.abs(numerical/axial_field(zs)-1)))
    volume_errors={str((i,j)):abs(volume_pair_energy(i,j)+qm[i,j]) for i,j in [(0,1),(0,2)]}
    smallest_eigenvalue=float(np.linalg.eigvalsh(np.eye(12)-point.ETA_MAX*sm)[0])
    bu, bv = hm@u, hm@v
    at, aa = float(bu[1]), float(bv[0])
    lt, la = 3+1/(2*np.sqrt(2)), 3-1/np.sqrt(2)
    modal_error=float(max(np.max(np.abs(sm@bu-lt*bu)),np.max(np.abs(sm@bv-la*bv))))
    modal_gap_error=0.0
    for row in rows:
        eta=row['beta']*point.ETA_MAX
        gap=8*qm[0,1]+4*eta*(at**2/(1-eta*lt)-aa**2/(1-eta*la))
        modal_gap_error=max(modal_gap_error,abs(gap-row['finite_gap_over_Estar']))
    checks={
        'all_101_sampled_gaps_positive':bool(all(r['finite_gap_over_Estar']>0 for r in rows)),
        'circulation_lowest_of_16_at_all_101_beta_values':all_circulation_minimum,
        'quadratic_energy_and_gap_identity':max_formula_error<2e-10,
        'rotation_energy_invariance':max_rotation_error<2e-10,
        'global_reversal_energy_invariance':max_reversal_error<2e-10,
        'sphere_stationarity':max_response_residual<2e-12,
        'exact_axial_field_agreement':axis_relative_error<2e-10,
        'surface_vs_volume_pair_energy':max(volume_errors.values())<2e-8,
        'refined_quadrature_agreement':max(convergence[-1]['max_H_difference_from_default'],convergence[-1]['max_Q_difference_from_default'])<2e-10,
        'stable_sphere_response_for_interval':smallest_eigenvalue>0,
        'point_limit_convergence':all(contraction[i+1]['relative_H_norm_error']<contraction[i]['relative_H_norm_error'] and contraction[i+1]['relative_Q_norm_error']<contraction[i]['relative_Q_norm_error'] for i in range(4)),
        'point_limit_at_smallest_source_scale':max(contraction[-1]['relative_H_norm_error'],contraction[-1]['relative_Q_norm_error'])<.003,
        'axial_far_field_limit':abs(float(axial_field(100))/(2/100**3)-1)<2e-5,
        'two_mode_gap_identity':modal_error<2e-10 and modal_gap_error<2e-10,
        'positive_and_increasing_gap_on_continuous_beta_interval':qm[0,1]>0 and at>aa>0 and lt>la>0 and 1-point.ETA_MAX*lt>0,
    }
    checks={name:bool(value) for name,value in checks.items()}
    summary={'model':'uniformly magnetized cylindrical rods + self-consistent linear point spheres',
             'data_kind':'deterministic model calculation; no measurements',
             'dimensions_mm':{'rod_length':11,'rod_radius':1.65,'sphere_radius':4,'square_side':19},
             'normalization':{'E_star':'mu0*m0^2/(4*pi*a^3)','B_star':'mu0*m0/(4*pi*a^3)','same_m0_in_both_models':True},
             'sphere_model':'unchanged point response; not a finite-body contact magnetization solution',
             'quadrature':{'radial_variable':'squared normalized disk radius','radial_rule':'Gauss-Legendre','angular_rule':'uniform trapezoidal','default_radial_nodes':NR,'default_angular_nodes':NT},
             'endpoints':[rows[0],rows[-1]], 'axial_contact_centre_field_ratio':axial[0]['finite_over_point'],
             'errors':{'energy_identity':max_formula_error,'rotation':max_rotation_error,'reversal':max_reversal_error,'stationarity':max_response_residual,'axial_relative':axis_relative_error,'surface_volume_absolute':volume_errors},
             'minimum_response_eigenvalue_over_interval':smallest_eigenvalue,
             'continuous_interval_certificate':{'A_t':at,'A_a':aa,'lambda_t':float(lt),'lambda_a':float(la),
                 'formula':'gap/E*=8*q_a+4*eta*(A_t^2/(1-eta*lambda_t)-A_a^2/(1-eta*lambda_a))',
                 'argument':'q_a>0, A_t>A_a>0, lambda_t>lambda_a>0, and both denominators positive on 0<=eta<=(4/19)^3 imply a positive, increasing gap.',
                 'eigenmode_residual':modal_error,'gap_residual':float(modal_gap_error)},
             'contraction_check':'Rod length and radius shrink together at fixed centres and fixed total moment; a mathematical limit, not a physical NdFeB material path.',
             'checks':checks, 'all_checks_passed':bool(all(checks.values()))}
    return {'beta_scan.csv':rows,'square_states.csv':state_rows,'axial_field.csv':axial,
            'quadrature_convergence.csv':convergence,'point_limit.csv':contraction},summary


def compare_saved(path, rows):
    with path.open(encoding='utf-8',newline='') as f:saved=list(csv.DictReader(f))
    if len(saved)!=len(rows):return False
    for a,b in zip(saved,rows):
        if set(a)!=set(b):return False
        for key,value in b.items():
            if isinstance(value,str):
                if a[key]!=value:return False
            elif not np.isclose(float(a[key]),value,rtol=2e-9,atol=2e-10):return False
    return True


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--generate',action='store_true')
    args=parser.parse_args()
    tables,summary=compute()
    if not summary['all_checks_passed']:
        raise SystemExit(json.dumps(summary,indent=2))
    if args.generate:
        DATA.mkdir(parents=True,exist_ok=True)
        for name,rows in tables.items():
            with (DATA/name).open('w',encoding='utf-8',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
        (DATA/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
        names=[*tables,'summary.json']
        manifest={'data_kind':'deterministic normalized model results; no measurements',
                  'generator':'code/finite_rod_comparison.py',
                  'program_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'files':{name:hashlib.sha256((DATA/name).read_bytes()).hexdigest() for name in names}}
        (DATA/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    else:
        assert all(compare_saved(DATA/name,rows) for name,rows in tables.items()),'Saved data mismatch'
        saved=json.loads((DATA/'summary.json').read_text(encoding='utf-8'))
        assert saved['checks']==summary['checks'] and saved['dimensions_mm']==summary['dimensions_mm']
    print(json.dumps({'all_checks_passed':True,'checks':len(summary['checks']),
                      'endpoints':summary['endpoints'],
                      'axial_field_ratio_at_sphere_centre':summary['axial_contact_centre_field_ratio']},indent=2))


if __name__=='__main__':main()
