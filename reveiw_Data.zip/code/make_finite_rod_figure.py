"""Standalone finite-source comparison for the bilingual EJP manuscripts."""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'
STEM='fig4_finite_rods'
contract={
    'conclusion':'Changing only the rod source geometry preserves a positive square-state energy gap while changing its magnitude.',
    'archetype':'quantitative grid',
    'panels':{'a':'Exact isolated axial-cylinder field compared with a dipole of equal total moment.','b':'Self-consistent square-state energy gap for both source descriptions.'},
    'backend':'Python / matplotlib',
    'width_mm':150,'height_mm':76,'font_pt_min':8,
    'data':'Deterministic calculations; no measured data, replicates, statistical tests or error bars.',
    'scope':'Uniformly magnetized fixed cylindrical sources; unchanged linear point-sphere response. Not apparatus calibration.',
    'source_files':['data/finite_rods/axial_field.csv','data/finite_rods/beta_scan.csv'],
    'formats':['pdf','svg','png'],'photos_changed':False,
}
(OUT/'finite_rod_figure_contract.json').write_text(json.dumps(contract,indent=2)+'\n',encoding='utf-8')
def read(name):
    with (ROOT/'data/finite_rods'/name).open(encoding='utf-8',newline='') as f:
        rows=list(csv.DictReader(f))
    return {key:np.array([float(row[key]) for row in rows]) for key in rows[0]}
axial=read('axial_field.csv'); scan=read('beta_scan.csv')
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
 'font.size':8.5,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,
 'legend.fontsize':8,'legend.frameon':False,'axes.spines.top':False,'axes.spines.right':False,
 'axes.linewidth':.7,'lines.linewidth':1.4,'svg.fonttype':'none','pdf.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(150/25.4,76/25.4))
fig.subplots_adjust(left=.1,right=.985,bottom=.22,top=.91,wspace=.4)
blue='#286b91'; orange='#bc6932'; gray='#7b858c'
a,b=axes
a.plot(axial['centre_separation_mm'],axial['finite_over_point'],color=orange)
a.axhline(1,color=gray,ls='--',lw=.9)
a.plot(9.5,axial['finite_over_point'][0],'o',color=orange,ms=4)
a.annotate('Axial contact geometry\n$r=9.5$ mm',xy=(9.5,axial['finite_over_point'][0]),
           xytext=(24,1.78),fontsize=8,arrowprops={'arrowstyle':'-','color':gray,'lw':.7})
a.set(xlim=(8,58),ylim=(.94,2.13),xlabel='Rod-to-sphere centre distance $r$ (mm)',
      ylabel='$B_{\\mathrm{cyl}}/B_{\\mathrm{point}}$')
a.set_xticks([10,20,30,40,50]);a.set_yticks([1,1.25,1.5,1.75,2])
b.plot(scan['beta'],scan['finite_gap_over_Estar'],color=orange,label='Finite cylindrical rods')
b.plot(scan['beta'],scan['point_gap_over_Estar'],color=blue,ls='--',label='Point rods')
for key,color in [('finite_gap_over_Estar',orange),('point_gap_over_Estar',blue)]:
    values=scan[key]
    b.scatter([0,1],[values[0],values[-1]],color=color,s=13,zorder=3)
b.set(xlim=(-.03,1.03),ylim=(0,57),xlabel='Sphere response $\\beta$',
      ylabel='Energy gap $\\Delta U/E_*$')
b.set_xticks([0,.25,.5,.75,1]);b.set_yticks([0,10,20,30,40,50])
b.legend(loc='lower left',bbox_to_anchor=(0,.12),handlelength=1.8)
b.text(.02,51.5,'42.401',color=orange,fontsize=8)
b.text(.98,51.5,'46.694',color=orange,fontsize=8,ha='right')
b.text(.02,28,'33.941',color=blue,fontsize=8)
b.text(.98,28,'36.189',color=blue,fontsize=8,ha='right')
for ax,letter in zip(axes,'ab'):
    ax.text(-.18,1.07,f'({letter})',transform=ax.transAxes,fontweight='bold',fontsize=10,va='top')
for ext in contract['formats']:
    fig.savefig(OUT/f'{STEM}.{ext}',dpi=400,facecolor='white')
plt.close(fig)
for folder in ['revision','revision_zh']:
    shutil.copy2(OUT/f'{STEM}.pdf',ROOT/folder/'figures'/f'{STEM}.pdf')
contract['sha256']={ext:hashlib.sha256((OUT/f'{STEM}.{ext}').read_bytes()).hexdigest() for ext in contract['formats']}
(OUT/'finite_rod_figure_contract.json').write_text(json.dumps(contract,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'figure':STEM,'formats':contract['formats'],'width_mm':150,'height_mm':76}))
