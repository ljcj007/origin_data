# 配套离线演示 / Offline demonstration

直接在浏览器中打开 `magnetic_symmetry/index.html`。页面可切换中文与英文，无需联网、服务器或安装软件。

Open `magnetic_symmetry/index.html` in a browser. The page supports Chinese and English and runs without a network connection or server.

演示包含四根磁棒的全部 16 种正负方向组合。学生先预测杆合磁矩及 90°、180° 旋转后的重合情况，再显示核对结果。所有构型共享同一正方形几何骨架；灰球只标出几何顶点，未在这个演示中计算球的磁响应。完整组件的自洽诱导磁矩与能量由论文和配套数据给出。

The demonstration presents all 16 sign configurations of four rods. Learners predict the summed rod moment and test 90° and 180° rotational symmetry before revealing the result. Spheres mark geometric vertices only. The paper and calculation data provide the self-consistent treatment of induced moments and energies.

## 重建 / Rebuild

在论文工作目录运行：

```text
python code/make_symmetry_demo.py
```

需要 Python 3.10 或更新版本和 Matplotlib。生成器直接读取 `data/square_states.csv` 中的 `beta = 0` 行，不依赖其他旧版程序。它用四个符号独立计算杆合磁矩和旋转条件，与源数据逐条核对，然后生成 HTML、16 张 PNG 和来源记录 `model_source.json`。

The generator requires Python 3.10+ and Matplotlib. It reads the `beta = 0` rows of `data/square_states.csv` and independently checks each vector sum and rotation condition before producing the HTML, 16 PNG images and provenance record.

只检查已有文件，不改写：

```text
python code/make_symmetry_demo.py --check-only
```

检查覆盖 16 个状态、四个零杆合磁矩状态、两个 C4 状态、四个 C2 状态、文件哈希与本地图片路径。不将这个文件核验描述为浏览器交互测试。

The read-only check covers the 16 states, four zero-moment states, two C4 states, four C2 states, file hashes and local image paths. This file check does not execute browser interactions.
