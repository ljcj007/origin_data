#!/usr/bin/env python3
"""Unpack inputs for the pointwise interval-bound calculations."""
from pathlib import Path
from zipfile import ZipFile
base = Path(__file__).resolve().parent
root = base / "原始程序"
with ZipFile(base / "区间计算输入数据.zip") as z:
    for name in z.namelist():
        target = (root / name).resolve()
        if root.resolve() not in target.parents:
            raise ValueError("Invalid data path: " + name)
    z.extractall(root)
for p in ["studies/nonlinear-noise-crossover-20260918/data", "studies/nonlinear-noise-crossover-20260918/verification"]:
    (root / p).mkdir(parents=True, exist_ok=True)
print("计算目录及区间计算输入已准备完毕：", root)
