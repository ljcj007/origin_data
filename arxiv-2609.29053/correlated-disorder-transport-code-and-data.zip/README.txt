Resonance and transport in correlated disordered chains

manuscript/: the manuscript and complete Supplemental Material in a combined PDF and a self-contained TeX source.
code/: three compact computational entry points, 16 research computation scripts, dependencies, instructions, and the compressed inputs required by the interval calculations. See code/README.txt for details.
figures/: five vector PDF figures used in the manuscript.

The manuscript and figures are the October 28, 2026 revision. Run python3 code/prepare_inputs.py to place the two supplied interval-calculation inputs in their expected locations.

To compile the manuscript, change to manuscript/ and run pdflatex -interaction=nonstopmode -halt-on-error paper.tex twice. The source reads figures from the adjacent figures/ directory.

Paper: https://arxiv.org/abs/2609.29053
