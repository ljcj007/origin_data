"""Reproducible full transfer products; no fitting is used by the solver.

Periodic high-pass Gaussian fields are generated at the largest size and then
opened at the contacts. Shorter devices use paired prefixes. The input at a
short prefix need not have an exactly zero discrete Fourier coefficient.
64 independent base fields, reused across lengths, strengths, and error rates,
are 64 independent samples, not 5,376 independent samples.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import time

import numpy as np
import scipy
import numba
import bridge


def sha(a):
    return hashlib.sha256(np.ascontiguousarray(a,dtype='<f8').tobytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples',type=int,default=64)
    parser.add_argument('--max-power',type=int,default=20)
    parser.add_argument('--output',type=Path,default=Path('verification/transport'))
    args=parser.parse_args()
    if args.samples<2 or args.max_power<12:
        parser.error('samples>=2 and max-power>=12 required')
    args.output.mkdir(parents=True,exist_ok=True)
    k,q0=.91,2.4
    strengths=[.03,.05,.08,.12,.2,.3,.4]
    probabilities=[0.,.005,.02,.1]
    lengths=[2**(args.max_power-4),2**(args.max_power-2),2**args.max_power]
    rows=[]; inputs=[]
    t0=time.time()
    for sample in range(args.samples):
        xseed=2026092500+sample
        yseed=2026092600+sample
        x=bridge.gaussian_highpass(lengths[-1],q0,np.random.default_rng(xseed))
        xhash=sha(x)
        # Nested masks provide paired comparisons across p.
        for p in probabilities:
            y=bridge.swap_blocks(x,p,2,np.random.default_rng(yseed))
            inputs.append(dict(sample=sample,p=p,x_seed=xseed,swap_seed=yseed,
                               x_sha256=xhash,y_sha256=sha(y)))
            if not np.array_equal(np.sort(x),np.sort(y)):
                raise AssertionError('The input histogram changed')
            for n in lengths:
                for w in strengths:
                    logt=bridge.log_transmission(y[:n],w,k)
                    if logt>1e-9:
                        raise AssertionError(f'Unphysical logT={logt}')
                    rows.append(dict(sample=sample,N=n,p=p,W=w,k=k,q0=q0,
                                     logT=logt,gamma_N=-logt/(2*n),
                                     gamma_Born=w*w*float(bridge.top_hat_born_coefficient(k,q0,p))))
        if (sample+1)%8==0:
            print(f'{sample+1}/{args.samples} samples; {time.time()-t0:.1f}s',flush=True)
    with (args.output/'raw.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summaries=[]
    for n in lengths:
        for p in probabilities:
            for w in strengths:
                subset=[r for r in rows if r['N']==n and r['p']==p and r['W']==w]
                logt=np.array([r['logT'] for r in subset])
                gs=-logt/(2*n)
                ts=np.exp(logt)
                summaries.append(dict(N=n,p=p,W=w,k=k,q0=q0,samples=len(subset),
                    gamma_mean=float(gs.mean()),gamma_sem=float(gs.std(ddof=1)/np.sqrt(len(gs))),
                    gamma_Born=subset[0]['gamma_Born'],T_mean=float(ts.mean()),T_median=float(np.median(ts)),
                    T_q10=float(np.quantile(ts,.1)),T_q90=float(np.quantile(ts,.9)),
                    logT_median=float(np.median(logt))))
    # Paired finite-length slope removes a length-independent mean boundary term.
    slopes=[]
    for p in probabilities:
        for w in strengths:
            arr=[]
            for sample in range(args.samples):
                rr=[r for r in rows if r['sample']==sample and r['p']==p and r['W']==w]
                lookup={r['N']:r['logT'] for r in rr}
                arr.append(-(lookup[lengths[-1]]-lookup[lengths[-2]])/(2*(lengths[-1]-lengths[-2])))
            a=np.array(arr)
            slopes.append(dict(p=p,W=w,N_low=lengths[-2],N_high=lengths[-1],
                               slope_mean=float(a.mean()),slope_sem=float(a.std(ddof=1)/np.sqrt(len(a))),
                               gamma_Born=w*w*float(bridge.top_hat_born_coefficient(k,q0,p))))
    metadata=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
                  numba=numba.__version__,samples=args.samples,k=k,q0=q0,lengths=lengths,
                  strengths=strengths,probabilities=probabilities,raw_observations=len(rows),
                  wall_seconds=time.time()-t0,inputs=inputs,
                  source_sha256={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()
                                 for name in ['bridge.py','run_transport.py']},
                  limitations=['Finite coherent transmission, not a proof of the infinite-volume limit.',
                               'Small-W ideal signal can be dominated by contacts; no ideal exponent is fitted.',
                               'gamma_Born is a prediction; the full solver never uses it.',
                               'Standard errors refer to independent base samples; rows are paired.',
                               'Histogram checks are exact float-value permutations, not measured tolerance.'])
    for name,data in [('summary.json',summaries),('paired_length_slopes.json',slopes),('metadata.json',metadata)]:
        (args.output/name).write_text(json.dumps(data,indent=2)+'\n')
    print(f'Saved {len(rows)} observations from {args.samples} independent base fields.',flush=True)


if __name__=='__main__':main()
