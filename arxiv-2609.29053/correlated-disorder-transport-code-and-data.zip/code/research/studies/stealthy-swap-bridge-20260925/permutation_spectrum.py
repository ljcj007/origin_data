"""Exact spectrum of independent finite-block permutation channels.

The source need only be stationary with the specified two-point function.
No Gaussian factorization and no independence of the input blocks is used.
This routine is deliberately independent of bridge.pair_swap_spectrum.
"""
from __future__ import annotations
import numpy as np
from numpy.typing import ArrayLike


def spectrum_after_permutations(spectrum: ArrayLike, permutations: ArrayLike,
                                probabilities: ArrayLike) -> dict[str, np.ndarray]:
    s=np.asarray(spectrum,dtype=float)
    perms=np.asarray(permutations)
    prob=np.asarray(probabilities,dtype=float)
    if s.ndim!=1 or np.any(~np.isfinite(s)) or np.any(s<0):
        raise ValueError('spectrum must be a finite nonnegative vector in FFT order')
    if perms.ndim!=2 or not np.issubdtype(perms.dtype,np.integer):
        raise ValueError('permutations must be an integer array of shape (actions,ell)')
    ell=perms.shape[1];n=len(s)
    if ell<2 or n%ell or any(not np.array_equal(np.sort(row),np.arange(ell)) for row in perms):
        raise ValueError('each row must be a permutation, and ell must divide N')
    if len(prob)!=len(perms) or np.any(prob<0) or not np.isclose(prob.sum(),1,atol=1e-14,rtol=0):
        raise ValueError('probabilities must be nonnegative and sum to one')
    if not np.allclose(s,s[(-np.arange(n))%n],atol=1e-13,rtol=1e-12):
        raise ValueError('real stationary input requires an even spectrum')
    mats=np.eye(ell)[perms]
    mean=np.einsum('a,aij->ij',prob,mats)
    c=np.fft.ifft(s).real
    cb=c[(np.arange(ell)[:,None]-np.arange(ell)[None,:])%n]
    residual=np.zeros((ell,ell))
    # Difference form makes the positive-semidefinite structure explicit.
    for p,mat in zip(prob,mats):
        diff=mat-mean
        residual+=p*diff@cb@diff.T
    q=2*np.pi*np.fft.fftfreq(n)
    j=np.arange(ell)
    coherent=np.zeros(n);innovation=np.zeros(n)
    for z,angle in enumerate(q):
        v=np.exp(1j*angle*j)
        innovation[z]=np.real(np.vdot(v,residual@v))/ell
        for m in range(ell):
            u=np.exp(1j*(angle+2*np.pi*m/ell)*j)
            amplitude=np.vdot(v,mean@u)/ell
            coherent[z]+=abs(amplitude)**2*s[(z+m*(n//ell))%n]
    return dict(output=coherent+innovation,coherent=coherent,
                innovation=innovation,residual_covariance=residual,
                input_block_covariance=cb,mean_permutation=mean)
