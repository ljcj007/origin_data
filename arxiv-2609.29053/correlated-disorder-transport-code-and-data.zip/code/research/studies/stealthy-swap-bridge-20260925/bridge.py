"""Local permutations of stationary disorder: exact spectra and transfer checks.

The spectral identities are exact finite-periodic covariance identities.
The Born coefficient is a second-order weak-disorder prediction, not an
unconditional theorem about the infinite-volume Lyapunov exponent.
All energies and disorder strengths use nearest-neighbor hopping = 1.
"""
from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike, NDArray
from numba import njit


def _probability(p: float) -> float:
    p = float(p)
    if not np.isfinite(p) or not 0 <= p <= 1:
        raise ValueError('p must lie in [0,1]')
    return p


def pair_swap_spectrum(spectrum: ArrayLike, p: float) -> NDArray[np.float64]:
    """Exact output spectrum on an even periodic lattice, in FFT order.

    Independently swap each non-overlapping adjacent pair with probability p.
    Randomizing the origin makes the output stationary; its position-averaged
    spectrum is the same for either origin. `spectrum` is E|FFT(X)/sqrt(N)|^2.
    """
    s = np.asarray(spectrum, dtype=float)
    p = _probability(p)
    if s.ndim != 1 or len(s) < 2 or len(s) % 2:
        raise ValueError('spectrum must be a one-dimensional even-length array')
    if np.any(~np.isfinite(s)) or np.any(s < 0):
        raise ValueError('spectrum must be finite and nonnegative')
    if not np.allclose(s, s[(-np.arange(len(s))) % len(s)], atol=1e-13, rtol=1e-12):
        raise ValueError('real input disorder requires an even spectrum')
    q = 2*np.pi*np.fft.fftfreq(len(s))
    d = float(np.mean(s*(1-np.cos(q))))
    return ((1-p+p*np.cos(q))**2*s + p*p*np.sin(q)**2*np.roll(s,len(s)//2)
            + 4*p*(1-p)*d*np.sin(q/2)**2)


def block_innovation_floor(q: ArrayLike, d: float, p: float, ell: int) -> NDArray[np.float64]:
    """Lower floor for one uniform-boundary Bernoulli attempt per length-ell block."""
    p = _probability(p)
    if int(ell) != ell or ell < 2 or not np.isfinite(d) or d < 0:
        raise ValueError('ell must be an integer >=2 and d=C(0)-C(1) >=0')
    return 8*p*(1-p)*d*np.sin(np.asarray(q,dtype=float)/2)**2/ell


def swap_blocks(x: ArrayLike, p: float, ell: int, rng: np.random.Generator) -> NDArray[np.float64]:
    """Make at most one independent adjacent exchange in each block; no wrap-around.

    Returns a new array and never mutates the input. Every complete block's
    multiset, sum, and all single-site empirical moments are preserved.
    """
    y = np.asarray(x,dtype=float).copy()
    p = _probability(p)
    if y.ndim != 1 or ell < 2 or int(ell) != ell or len(y) % ell:
        raise ValueError('input length must be divisible by integer ell>=2')
    nblocks = len(y)//ell
    left = np.arange(nblocks)*ell + rng.integers(0,ell-1,size=nblocks)
    left = left[rng.random(nblocks)<p]
    old = y[left].copy()
    y[left] = y[left+1]
    y[left+1] = old
    return y


def gaussian_highpass(n: int, q0: float, rng: np.random.Generator) -> NDArray[np.float64]:
    """Periodic Gaussian field with S(q)=1{|q|>q0}, not variance-renormalized."""
    if n < 4 or not 0 < q0 < np.pi:
        raise ValueError('n>=4 and 0<q0<pi required')
    q = 2*np.pi*np.fft.fftfreq(n)
    return np.fft.ifft(np.fft.fft(rng.normal(size=n))*(np.abs(q)>q0)).real


def top_hat_born_coefficient(k: ArrayLike, q0: float, p: float) -> NDArray[np.float64]:
    """Full coefficient gamma^(2)/W^2 for paired swaps of top-hat disorder.

    Use away from band edges/center anomalies. The returned quantity remains
    only the Born coefficient even when W is not small.
    """
    p = _probability(p)
    k = np.asarray(k,dtype=float)
    if not 0 < q0 < np.pi or np.any((k<=0)|(k>=np.pi)):
        raise ValueError('0<q0<pi and 0<k<pi required')
    q = (2*k+np.pi)%(2*np.pi)-np.pi
    alias = (q+2*np.pi)%(2*np.pi)-np.pi  # wrap(q+pi)
    s = (np.abs(q)>q0).astype(float)
    sa = (np.abs(alias)>q0).astype(float)
    d = 1-q0/np.pi+np.sin(q0)/np.pi
    sp = ((1-p+p*np.cos(q))**2*s+p*p*np.sin(q)**2*sa
          +4*p*(1-p)*d*np.sin(q/2)**2)
    return sp/(8*np.sin(k)**2)


@njit(cache=True)
def _log_transmission(x: NDArray[np.float64], w: float, k: float) -> float:
    """Rescaled real 2x2 product, converted to the clean-lead rotation basis."""
    c, s = np.cos(k), np.sin(k)
    a,b,d,e = 1.,0.,0.,1.
    logscale = 0.
    for j in range(len(x)):
        z = 2*c+w*x[j]
        aa,bb = z*a-d,z*b-e
        d,e = a,b
        a,b = aa,bb
        if j % 32 == 31:
            scale = max(abs(a),abs(b),abs(d),abs(e))
            a,b,d,e = a/scale,b/scale,d/scale,e/scale
            logscale += np.log(scale)
    # C=[[cos(k),sin(k)],[1,0]], inverse=[[0,1],[1/s,-c/s]].
    r11 = d*c+e
    r12 = d*s
    r21 = ((a*c+b)-c*(d*c+e))/s
    r22 = a-c*d
    lognorm = np.log(r11*r11+r12*r12+r21*r21+r22*r22)+2*logscale
    # T=4/(||C^-1 P C||_F^2+2), avoiding overflow.
    if lognorm > np.log(2.):
        logden = lognorm+np.log1p(2*np.exp(-lognorm))
    else:
        logden = np.log(2.)+np.log1p(np.exp(lognorm)/2)
    return np.log(4.)-logden


def log_transmission(x: ArrayLike, w: float, k: float) -> float:
    """Full coherent Landauer log-transmission, with clean matched leads.

    This is not a Born calculation. Numerical values may have roundoff-sized
    positive logT in the perfectly clean limit; they are deliberately not clipped.
    """
    x = np.ascontiguousarray(x,dtype=float)
    if x.ndim != 1 or not np.all(np.isfinite(x)) or not np.isfinite(w):
        raise ValueError('finite one-dimensional disorder and finite w required')
    if not np.isfinite(k) or not 0 < k < np.pi:
        raise ValueError('k must be in (0,pi), excluding band edges')
    return float(_log_transmission(x,float(w),float(k)))
