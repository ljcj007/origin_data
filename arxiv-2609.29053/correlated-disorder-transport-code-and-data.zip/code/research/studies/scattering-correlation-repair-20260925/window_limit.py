#!/usr/bin/env python3
"""Exact-ensemble check of the finite-resistance correlation budget.

Large N is evaluated by powers of a 3x3 second-moment map, not by generating
N sites, diagonalizing a large Hamiltonian, or reusing bulk gamma as data.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import mpmath as mp
import repair as r


def scan():
    mp.mp.dps=75
    par=r.Parameters();depth=2;p=F(1,5);b=F(8,125)
    coef=r.coefficients(par,depth,p)
    out={'depth':depth,'p':str(p),'b':str(b),'decimal_precision':mp.mp.dps,
         'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'repair_sha256':hashlib.sha256(Path(r.__file__).read_bytes()).hexdigest(),
         'formula':'E=b*N^(-1/4), q=z*N^(-1/2); mean_rho -> (exp(4*(c4*b^4+c2*b^2*z))-1)/2',
         'rows':[]}
    for z in (0,10,100):
        u=r.mpf(coef['c4_mirror']*b**4+coef['c2_independent']*b**2*z)
        limit=mp.expm1(4*u)/2
        for exponent in (16,20,24,28,32):
            N=2**exponent;E=r.mpf(b)/2**(exponent//4);q=F(z,2**(exponent//2))
            rho=r.mean_resistance(par,depth,p,q,E,N)
            relative=abs(rho-limit)/limit
            out['rows'].append({'z':z,'N':N,'E':mp.nstr(E,25),'q':str(q),
                               'mean_rho':mp.nstr(rho,25),'predicted_limit':mp.nstr(limit,25),
                               'relative_difference':mp.nstr(relative,15)})
        assert relative<mp.mpf('0.001')
    return out

if __name__=='__main__':
    result=scan()
    Path('window_limit.json').write_text(json.dumps(result,indent=2)+'\n')
    for row in result['rows']:print(row)
