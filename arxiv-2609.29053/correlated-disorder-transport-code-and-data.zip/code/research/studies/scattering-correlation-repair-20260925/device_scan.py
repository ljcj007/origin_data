#!/usr/bin/env python3
"""Finite-device follow-up: same scaffold and marginal swaps, different pairing.

The deterministic 3x3 moment map is evaluated at two precisions; the separately
implemented Monte Carlo keeps complete 2x2 products and reports raw sample T.
This file does not overwrite the earlier depth-one scan in results.json.
"""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
import numpy as np
import numba
from numba import njit
import repair as r

@njit(cache=True)
def sample_transmission(library,root,inverse,qs,p,nmodules,nsamples,seed):
    np.random.seed(seed)
    nq=len(qs);ell=library.shape[1]
    output=np.empty((nq,nsamples))
    for sample in range(nsamples):
        states=np.zeros((nq,2,2));logs=np.zeros(nq)
        for z in range(nq):states[z,0,0]=1.;states[z,1,1]=1.
        for block in range(nmodules):
            base=int(np.random.random()*2)
            first=0 if np.random.random()>=p else 1+int(np.random.random()*(ell-1))
            other=0 if np.random.random()>=p else 1+int(np.random.random()*(ell-1))
            coin=np.random.random()
            for z in range(nq):
                second=other if coin<qs[z] else first
                # Product reverse(P_second) P_first, no finite-energy approximation.
                x=library[base,first];v=library[base,second]
                a=v[0,0]*x[0,0]-v[1,0]*x[1,0]
                b=v[0,0]*x[0,1]-v[1,0]*x[1,1]
                c=-v[0,1]*x[0,0]+v[1,1]*x[1,0]
                d=-v[0,1]*x[0,1]+v[1,1]*x[1,1]
                s=states[z]
                t00=a*s[0,0]+b*s[1,0];t01=a*s[0,1]+b*s[1,1]
                t10=c*s[0,0]+d*s[1,0];t11=c*s[0,1]+d*s[1,1]
                s[0,0]=t00;s[0,1]=t01;s[1,0]=t10;s[1,1]=t11
                if block%16==15:
                    scale=max(abs(t00),abs(t01),abs(t10),abs(t11))
                    states[z]/=scale;logs[z]+=math.log(scale)
        for z in range(nq):
            flux=root@states[z]@inverse
            frob=flux[0,0]**2+flux[0,1]**2+flux[1,0]**2+flux[1,1]**2
            lognorm=math.log(frob)+2*logs[z]
            output[z,sample]=math.exp(math.log(4.)-np.logaddexp(lognorm,math.log(2.)))
    return output


def scan():
    par=r.Parameters();depth=2;p=F(1,5);qs=(F(0),F(1,100),F(1))
    data={'depth':depth,'swap_attempt_probability':str(p),'parameters':r.encoded(r.asdict(par)),
          'definition_q':'Probability of replacing the mirrored error draw by an independent draw conditional on the same ideal base.',
          'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'repair_sha256':hashlib.sha256(Path(r.__file__).read_bytes()).hexdigest(),
          'versions':{'numpy':np.__version__,'numba':numba.__version__,'mpmath':mp.__version__},
          'finite_moments':[],'precision_rechecks':[]}
    mp.mp.dps=65
    for N in (16384,262144,1048576):
        for E in ('0.001','0.002','0.003'):
            for q in qs:
                rho=r.mean_resistance(par,depth,p,q,E,N)
                data['finite_moments'].append({'N':N,'E':E,'q':str(q),
                    'mean_rho':mp.nstr(rho,28),'Jensen_lower_bound_mean_T':mp.nstr(1/(1+rho),28)})
    for q in qs:
        E='0.002';N=1048576
        mp.mp.dps=65;x=r.mean_resistance(par,depth,p,q,E,N)
        mp.mp.dps=90;y=r.mean_resistance(par,depth,p,q,E,N)
        relative=abs(x-y)/max(abs(y),mp.mpf(1))
        assert relative<mp.mpf('1e-50')
        data['precision_rechecks'].append({'q':str(q),'relative_difference_65_vs_90_digits':mp.nstr(relative,12)})
    mp.mp.dps=70;E='0.002';N=1048576;nsamples=256;seed=20260925
    ell=4*2**depth;library=np.empty((2,ell,2,2))
    for k,base in enumerate(r.seeds(depth)):
        words=[base]
        for j in range(ell-1):
            w=list(base);w[j],w[j+1]=w[j+1],w[j];words.append(tuple(w))
        for j,w in enumerate(words):library[k,j]=np.array(r.word_matrix(w,E,par).tolist(),dtype=float)
    root=np.array(r.lead_root(E,par.K).tolist(),dtype=float)
    values=sample_transmission(library,root,np.linalg.inv(root),np.array([float(q) for q in qs]),
                               float(p),N//(2*ell),nsamples,seed)
    assert np.isfinite(values).all() and values.min()>0 and values.max()<1+1e-9
    data['monte_carlo']={'N':N,'E':E,'independent_samples':nsamples,'shared_controller_across_q':True,
                         'seed':seed,'raw_values':{},'summary':{}}
    for q,array in zip(qs,values):
        rho=1/array-1
        data['monte_carlo']['raw_values'][str(q)]=array.tolist()
        data['monte_carlo']['summary'][str(q)]={'mean_T':float(array.mean()),
           'standard_error_mean_T':float(array.std(ddof=1)/math.sqrt(nsamples)),
           'median_T':float(np.median(array)),'T_quantiles_10_90':np.quantile(array,[.1,.9]).tolist(),
           'mean_rho':float(rho.mean()),'standard_error_mean_rho':float(rho.std(ddof=1)/math.sqrt(nsamples))}
    return data

if __name__=='__main__':
    result=scan()
    Path('device_scan.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['monte_carlo']['summary'],indent=2))
