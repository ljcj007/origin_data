#!/usr/bin/env python3
"""Finite-length ordering-fault transport, with arbitrary-precision moments.

The four-state ensemble is propagated exactly as a 4x4 second-moment map;
there is no Monte Carlo or fitted Lyapunov exponent in this calculation.
An independent full Hamiltonian Green calculation tests the cell embedding.
"""
from pathlib import Path
import hashlib, itertools, json, platform, time
import mpmath as mp
import numpy as np
from scipy.linalg import solve

ROOT=Path(__file__).resolve().parents[1]
mp.mp.dps=65
I=mp.eye(2)
def trace(a):return a[0,0]+a[1,1]
def sqrt_spd(a):return (a+I)/mp.sqrt(trace(a)+2)
def eigs(a):
    d=mp.sqrt((a[0,0]-a[1,1])**2+4*a[0,1]**2)
    return (trace(a)-d)/2,(trace(a)+d)/2
def params(family):
    h=mp.mpf(2);g=mp.mpf('1.2');toff=mp.mpf('.25')
    bare=[mp.exp(-1),mp.mpf(1),mp.exp(1)]
    if family=='identity':t=bare
    elif family=='offset_1':t=[x+1 for x in bare];toff+=1
    elif family=='saturation_half':t=[x/(1+x/2) for x in bare]
    else:raise ValueError(family)
    k=(t[0]*t[1]**2*t[2])**mp.mpf('.25')
    u2=[h*(x-toff)/2 for x in t]
    assert min(u2)>0
    return dict(h=h,g=g,a=toff+2*g*g/h,t=t,k=k,u2=u2)
def cell(j,e,d):
    h,g,a,k,u2=(d[x] for x in ['h','g','a','k','u2'])
    z=e*(1+2*(g*g+u2[j])/(h*h-e*e))
    t=a-2*h*(g*g-u2[j])/(h*h-e*e)
    return mp.matrix([[t/k-z*z/(k*t),-z/t],[z/t,k/t]])
def word(seq,e,d):
    m=mp.eye(2)
    for j in seq:m=cell(j,e,d)*m
    return m
def blocks(r,e,d):
    a,b=word([0,1,1,2],e,d),word([2,1,1,0],e,d)
    ra,rb=a**(2**r),b**(2**r)
    for _ in range(r):a,b=a*b,b*a
    return [a,b,ra,rb]
def coefficients(r,d):
    pref=mp.mpf(1);aa=mp.mpf(0);bb=mp.mpf(0)
    for j in [0,1,1,2]:
        prev=pref;pref*=d['t'][j]/d['k']
        q=1+2*(d['g']**2+d['u2'][j])/d['h']**2
        aa+=q/pref**2;bb+=q*prev**2
    w=(aa+bb)/(2*d['k']);c0=abs(aa-bb)/d['k']
    cr=c0*w**r*2**(r*(r+1)//2)
    return w,c0,cr
def lead(e,k):
    x=e/k
    return sqrt_spd(mp.matrix([[1,x/2],[x/2,1]])/mp.sqrt(1-x*x/4))
def moment_map(matrices,weights):
    return mp.matrix([
        [sum(w*m[i//2,j//2]*m[i%2,j%2] for w,m in zip(weights,matrices))
         for j in range(4)] for i in range(4)])
def evaluate(family,r,e,p,n):
    d=params(family);mats=blocks(r,e,d);weights=[(1-p)/2]*2+[p/2]*2
    mean=sum((w*m for w,m in zip(weights,mats)),mp.zeros(2))
    raw=mp.matrix([[mean[1,0],(mean[1,1]-mean[0,0])/2],
                   [(mean[1,1]-mean[0,0])/2,-mean[0,1]]])
    assert raw[0,0]>0 and mp.det(raw)>0
    qmat=sqrt_spd(raw/mp.sqrt(mp.det(raw)));qi=qmat**-1
    delta=[m-mean for m in mats]
    var=sum((w*(qmat*x*qi).T*(qmat*x*qi) for w,x in zip(weights,delta)),mp.zeros(2))
    detvar=sum(w*mp.det(x) for w,x in zip(weights,delta))
    lo,hi=eigs(var);qlo,qhi=lo-detvar,hi-detvar
    lm=lead(e,d['k']);change=lm*qi
    k2=eigs(change.T*change)[1]**2
    upper=(k2*mp.exp(n*mp.log1p(qhi))-1)/2
    lower=max(mp.mpf(0),(mp.exp(n*mp.log1p(qlo))/k2-1)/2)
    flux=[lm*m*(lm**-1) for m in mats]
    cov=moment_map(flux,weights)**n*mp.matrix([1,0,0,1])
    rho=(cov[0]+cov[3]-2)/4
    assert lower-mp.mpf('1e-42') <= rho <= upper+mp.mpf('1e-42')
    w,c0,cr=coefficients(r,d)
    v=((1-p)*cr**2*e**(2*r+2)+p*(2**r*c0)**2*e**2)/2
    leading_rho=mp.expm1(n*v)/2
    meanprime=qmat*mean*qi
    normalization=mp.norm(meanprime.T*meanprime-mp.det(mean)*I)
    isotropy=mp.norm(var-detvar*I-v*I)
    return dict(family=family,level=r,cells=n*4*2**r,blocks=n,
        energy=float(e),energy_decimal=mp.nstr(e,55),fault_probability=float(p),
        fault_probability_decimal=mp.nstr(p,55),K=float(d['k']),s=float(n*v),
        mean_excess_resistance=float(rho),leading_mean_excess_resistance=float(leading_rho),
        ratio_to_scaling_function=float(rho/leading_rho),
        exact_bound_lower=float(lower),exact_bound_upper=float(upper),
        probability_loss_over_0_1_upper=float(9*upper),q_lower=float(qlo),q_upper=float(qhi),
        basis_condition_squared=float(k2),isotropy_relative_error=float(isotropy/v),
        mean_normalization_error=float(normalization),
        c0=float(c0),cr=float(cr),omega0=float(w))
def dense_transmission(seq,e,d):
    n=len(seq);size=3*n;t=np.zeros((size,size));h,g,a,k=[float(d[x]) for x in ['h','g','a','k']]
    for i,j in enumerate(seq):
        u=float(mp.sqrt(d['u2'][j]));t[i,i]=a
        if i:t[i,i-1]=-k
        t[i,n+i]=g+u;t[i,2*n+i]=g-u
        t[n+i,i]=g-u;t[2*n+i,i]=g+u
        t[n+i,n+i]=h;t[2*n+i,2*n+i]=h
    H=np.block([[np.zeros_like(t),t],[t.T,np.zeros_like(t)]])
    inv=float(e)*np.eye(2*size,dtype=complex)-H
    endpoints=[0,size+n-1]
    selfenergy=(float(e)-1j*np.sqrt(4*k*k-float(e)**2))/2
    inv[endpoints,endpoints]-=selfenergy
    v=solve(inv,np.eye(2*size)[:,endpoints[1]],check_finite=False)
    return float((-2*selfenergy.imag)**2*abs(v[endpoints[0]])**2)
def direct_checks():
    rows=[]
    for family in ['identity','offset_1','saturation_half']:
        d=params(family)
        for seq in [[0,1,1,2],[2,1,1,0]*2,[0,1,1,2,2,1,1,0]]:
            for e in map(mp.mpf,['0','.002','.02']):
                P=word(seq,e,d);lm=lead(e,d['k']);flux=lm*P*(lm**-1)
                transfer=4/(sum(x*x for x in flux)+2)
                full=dense_transmission(seq,e,d)
                error=abs(float(transfer)-full)
                assert error<2e-11
                rows.append(dict(family=family,word=seq,energy=float(e),transfer=float(transfer),full_green=full,error=error))
    return rows
def enumeration_check():
    d=params('identity');e=mp.mpf('.002');p=mp.mpf('.1');n=3
    mats=blocks(1,e,d);weights=[(1-p)/2]*2+[p/2]*2;lm=lead(e,d['k'])
    exact=mp.mpf(0)
    for seq in itertools.product(range(4),repeat=n):
        P=mp.eye(2);weight=mp.mpf(1)
        for j in seq:P=mats[j]*P;weight*=weights[j]
        flux=lm*P*(lm**-1);exact+=weight*(sum(x*x for x in flux)-2)/4
    calc=evaluate('identity',1,e,p,n)
    error=abs(float(exact)-calc['mean_excess_resistance']);assert error<1e-16
    return dict(sequences=4**n,error=error,enumerated_mean_excess_resistance=float(exact))
def main():
    start=time.monotonic();rows=[];finite=[]
    for family in ['identity','offset_1','saturation_half']:
        d=params(family)
        for r in [1,2]:
            w,c0,cr=coefficients(r,d);ell=4*2**r
            for power in [12,16,24,32,40,48]:
                N=2**power;n=N//ell
                e=(mp.mpf('.2')/n/cr**2)**(mp.mpf(1)/(2*r+2))
                for lam in map(mp.mpf,['0','.1','1','5','20']):
                    p=lam*cr**2*e**(2*r)/(2**r*c0)**2
                    if p>1:continue
                    row=evaluate(family,r,e,p,n)
                    row['scaling_parameter_lambda']=float(lam)
                    row['fault_to_ideal_variance_ratio']=float(lam/(1-p)) if p<1 else None
                    rows.append(row)
            for p in map(mp.mpf,['0','.00001','.0001','.001','.01','.1','1']):
                finite.append(evaluate(family,r,mp.mpf('.002'),p,16384//ell))
    # Fixed-length lower-energy examples, evaluated without fitting any exponent.
    probes=[]
    for family in ['identity','offset_1','saturation_half']:
        for r in [1,2]:
            for e in map(mp.mpf,['.0001','.0003','.0005']):
                for p in map(mp.mpf,['.000001','.00001','.0001']):
                    probes.append(evaluate(family,r,e,p,16384//(4*2**r)))
    checks=direct_checks();enumeration=enumeration_check()
    report=dict(arithmetic='mpmath 65 decimal digits; not outward-rounded interval arithmetic',
        physical_parameters=dict(h=2,g=1.2,t_off=.25,alphabet='exp(-1),1,exp(1)',
        nonaffine_map='F(t)=t/(1+t/2); re-embed u²=(h/2)(F(t)-t_off)',
        offset_map='F(t)=t+1; shift a by 1 with u fixed'),
        asymptotic_scaling=rows,finite_device=finite,probe_candidates=probes,
        direct_full_hamiltonian_checks=checks,second_moment_enumeration=enumeration,
        max_green_error=max(x['error'] for x in checks),
        producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        runtime_seconds=time.monotonic()-start,environment=dict(python=platform.python_version(),mpmath=mp.__version__),
        scope='Exact finite ensemble moments and two-sided inequalities evaluated in high precision; asymptotic law is proved separately. Huge N uses logarithmic-cost 4x4 moment propagation, not explicit huge-chain simulation. Independent blocks with balanced four-word faults and matched contacts.')
    (ROOT/'verification/ordering_faults.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(scaling_points=len(rows),finite_points=len(finite),probe_points=len(probes),
        max_green_error=report['max_green_error'],enumeration=enumeration,runtime=report['runtime_seconds'])))
if __name__=='__main__':main()
