#!/usr/bin/env python3
"""Independent interval evaluation of the four-word fault bound.

Only interval 2x2 arithmetic helpers are shared with the prior verifier.
The physical cells, weighted variance, and four-word mixture are rebuilt here.
"""
from pathlib import Path
import json,hashlib
import mpmath
from check_interval_transmission import (iv,I,O,Z,ident,add,sub,scale,mul,tr,
    det,trans,inv,sqrt_spd_detone,maxeig_sym,positive,asfloat,endpoints)
iv.dps=70
ROOT=Path(__file__).resolve().parents[1]
def evaluate(row):
    e=I(row['energy_decimal']);p=I(row['fault_probability_decimal'])
    ts=[iv.exp(-O),O,iv.exp(O)];toff=I('.25');h=I(2);g=I('1.2')
    if row['family']=='offset_1':ts=[x+1 for x in ts];toff+=1
    elif row['family']=='saturation_half':ts=[x/(1+x/2) for x in ts]
    k=(ts[0]*ts[1]**2*ts[2])**I('.25');a=toff+2*g*g/h
    cs=[]
    for t in ts:
        u2=h*(t-toff)/2;z=e*(1+2*(g*g+u2)/(h*h-e*e))
        te=a-2*h*(g*g-u2)/(h*h-e*e)
        assert positive(te)
        cs.append([[te/k-z*z/(k*te),-z/te],[z/te,k/te]])
    def word(seq):
        out=ident()
        for j in seq:out=mul(cs[j],out)
        return out
    aa=word([0,1,1,2]);bb=word([2,1,1,0]);ra=ident();rb=ident()
    for _ in range(2**row['level']):ra=mul(aa,ra);rb=mul(bb,rb)
    for _ in range(row['level']):aa,bb=mul(aa,bb),mul(bb,aa)
    mats=[aa,bb,ra,rb];ws=[(1-p)/2]*2+[p/2]*2
    mean=[[Z,Z],[Z,Z]]
    for w,m in zip(ws,mats):mean=add(mean,scale(m,w))
    raw=[[mean[1][0],(mean[1][1]-mean[0][0])/2],[(mean[1][1]-mean[0][0])/2,-mean[0][1]]]
    assert positive(raw[0][0]) and positive(det(raw))
    qmat=sqrt_spd_detone(scale(raw,1/iv.sqrt(det(raw))));qi=inv(qmat)
    var=[[Z,Z],[Z,Z]];detvar=Z
    for w,m in zip(ws,mats):
        delta=sub(m,mean);dp=mul(mul(qmat,delta),qi)
        var=add(var,scale(mul(trans(dp),dp),w));detvar+=w*det(delta)
    q=maxeig_sym(var)-detvar
    x=e/k;gl=scale([[O,x/2],[x/2,O]],1/iv.sqrt(1-x*x/4));lead=sqrt_spd_detone(gl)
    change=mul(lead,qi);k2=maxeig_sym(mul(trans(change),change))**2
    factor=k2*iv.exp(row['blocks']*iv.log(1+q));failure=I('4.5')*(factor-1)
    assert bool(failure.b<I('.1').a)
    return {k:row[k] for k in ['family','level','cells','blocks','energy_decimal','fault_probability_decimal']}|dict(
        q_interval=asfloat(q),condition_squared_interval=asfloat(k2),
        failure_upper_bound_interval=asfloat(failure),failure_decimal_interval=endpoints(failure))
def main():
    src=ROOT/'verification/ordering_faults.json';data=json.loads(src.read_text())
    candidates=[r for r in data['probe_candidates'] if r['probability_loss_over_0_1_upper']<.098]
    rows=[evaluate(r) for r in candidates]
    report=dict(arithmetic='mpmath.iv outward-rounded intervals',digits=iv.dps,mpmath=mpmath.__version__,
        count=len(rows),records=rows,max_failure_upper_bound=max(r['failure_upper_bound_interval'][1] for r in rows),
        producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
        helper_sha256=hashlib.sha256(Path(__file__).with_name('check_interval_transmission.py').read_bytes()).hexdigest(),
        interpretation='Specified positive E and p, independent composition-preserving ordering faults. Pointwise probability at each reported energy, not a simultaneous-band guarantee. Candidate filtering uses a 0.098 floating bound before independent interval acceptance at 0.1.')
    (ROOT/'verification/ordering_fault_intervals.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'{len(rows)} enclosed four-word failure bounds; maximum {report["max_failure_upper_bound"]:.9f}.')
if __name__=='__main__':main()
