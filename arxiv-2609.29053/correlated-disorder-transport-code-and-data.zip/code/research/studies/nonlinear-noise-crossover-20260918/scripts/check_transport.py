#!/usr/bin/env python3
"""Direct finite six-orbital Green-function checks of zero-energy transport.

The check uses uniform semi-infinite one-channel leads with their exact surface
self-energies; it does not replace them by energy-independent absorbers away
from zero energy.  No previous raw data are changed.
"""
from __future__ import annotations

import hashlib
import json
import platform
import time
from pathlib import Path

import numpy as np
from scipy.linalg import solve

from check_crossover import ExactInverse, PARAMS, ROOT


def full_hamiltonian(t, K, signs, t0=.25):
    params = {**PARAMS, 'K':K, 't0':t0}
    inv = ExactInverse(np.log(np.asarray(t)/K), signs, params)
    T = inv.dense_matrix()
    zero = np.zeros_like(T)
    return np.block([[zero, T], [T.T, zero]])


def direct_scattering(H, n, energy, gamma_left, gamma_right, lead_hopping=2.0):
    """Contact v_a=sqrt(gamma_a J_lead), so Sigma_a(0)=-i gamma_a."""
    if abs(energy)>=2*lead_hopping:
        raise ValueError('Energy must lie strictly inside both lead bands.')
    endpoints = [0, 6*n-3]  # A_1 core and B_N core in the block A/B ordering
    surface = (energy-1j*np.sqrt(4*lead_hopping**2-energy**2))/(2*lead_hopping**2)
    contact2 = np.array([gamma_left, gamma_right])*lead_hopping
    self_energy = contact2*surface
    broadening = -2*np.imag(self_energy)
    inverse_green = energy*np.eye(6*n, dtype=complex)-H
    inverse_green[endpoints, endpoints] -= self_energy
    sources = np.eye(6*n)[:, endpoints]
    columns = solve(inverse_green, sources, assume_a='gen', check_finite=False)
    green = columns[endpoints, :]
    s_matrix = np.eye(2)-1j*np.sqrt(broadening[:, None]*broadening[None, :])*green
    transmission = float(broadening[0]*broadening[1]*abs(green[0,1])**2)
    return dict(transmission=transmission,
                reflection=float(abs(s_matrix[0,0])**2),
                scattering_unitarity_max=float(np.max(abs(s_matrix.conj().T@s_matrix-np.eye(2)))),
                solve_residual_max=float(np.max(abs(inverse_green@columns-sources))))


def sech2(x):
    z = np.exp(-2*abs(x))
    return float(4*z/(1+z)**2)


def block_deltas(orientations, b=.2):
    # Each triangle starts/ends at W=0; the order is one random bit per block.
    positive = np.array([b, -2*b, b])
    negative = -positive
    return np.concatenate([np.r_[positive,negative] if x else np.r_[negative,positive]
                           for x in orientations])


def main():
    start = time.monotonic()
    seed = 260918337
    rng = np.random.default_rng(seed)
    generic = []
    for n in [1,2,3,5,8,13]:
        for repeat in range(8):
            K = float(rng.uniform(.7,1.5))
            t = K*np.exp(rng.uniform(-.6,.6,n))
            gamma = rng.uniform(.4,1.8,2)
            H = full_hamiltonian(t,K,2*rng.integers(0,2,n)-1)
            check = direct_scattering(H,n,0,*gamma)
            mass_sum = float(np.sum(np.log(t/K)))
            shift = float(np.log(K/np.sqrt(np.prod(gamma))))
            predicted = sech2(mass_sum+shift)
            error = abs(check['transmission']-predicted)
            if error>5e-12 or check['scattering_unitarity_max']>5e-12:
                raise AssertionError((n,repeat,error,check))
            generic.append(dict(n=n,repeat=repeat,K=K,gamma_left=float(gamma[0]),gamma_right=float(gamma[1]),
                                mass_sum=mass_sum,contact_shift=shift,predicted=predicted,
                                absolute_error=error,**check))
    maps = [('identity', lambda t:t, .25),
            ('offset_0.3', lambda t:t+.3, .55),
            ('gain_1.7', lambda t:1.7*t, .25),
            ('saturation_0.7', lambda t:t/(1+.7*t), .25),
            ('power_plus_offset', lambda t:t**1.7+.2, .25)]
    block_checks = []
    for count in [1,2,3,5]:
        for sample in range(3):
            orientations = rng.integers(0,2,count)
            delta = block_deltas(orientations)
            n = len(delta)
            signs = 2*rng.integers(0,2,n)-1
            for label, F, t0 in maps:
                t = F(np.exp(delta))
                prototype = F(np.exp(block_deltas([0])))
                K = float(np.exp(np.mean(np.log(prototype))))
                H = full_hamiltonian(t,K,signs,t0)
                check = direct_scattering(H,n,0,K,K)
                mass_sum = float(np.sum(np.log(t/K)))
                if abs(check['transmission']-1)>5e-12 or abs(mass_sum)>1e-13:
                    raise AssertionError((label,count,sample,check,mass_sum))
                # Deliberately mistune the global intercell hopping.  Contacts
                # follow that hopping, isolating bulk drift from contact error.
                eta = .025
                K_wrong = K*np.exp(eta)
                H_wrong = full_hamiltonian(t,K_wrong,signs,t0)
                wrong = direct_scattering(H_wrong,n,0,K_wrong,K_wrong)
                wrong_prediction = sech2(n*eta)
                if abs(wrong['transmission']-wrong_prediction)>5e-12:
                    raise AssertionError('Global calibration control mismatch.')
                block_checks.append(dict(blocks=count,n=n,sample=sample,orientations=orientations.tolist(),
                                         transducer=label,retuned_K=K,mass_sum=mass_sum,**check,
                                         global_log_mistuning=eta,mistuned_transmission=wrong['transmission'],
                                         mistuned_predicted=wrong_prediction))
    # A finite-energy control is retained to delimit the zero-energy statement.
    finite_energy = []
    orientations = [0,1,1,0,1]
    delta = block_deltas(orientations)
    for label,F,t0 in maps:
        t=F(np.exp(delta))
        K=float(np.exp(np.mean(np.log(F(np.exp(block_deltas([0])))))))
        H=full_hamiltonian(t,K,np.ones(len(t)),t0)
        for energy in [0,.005,.02,.05,.1,.2]:
            check=direct_scattering(H,len(t),energy,K,K)
            finite_energy.append(dict(transducer=label,n=len(t),energy=energy,**check))
    output=ROOT/'verification'/'transport.json'
    output.parent.mkdir(parents=True,exist_ok=True)
    dependency=Path(__file__).with_name('check_crossover.py')
    report=dict(seed=seed,lead_hopping=2.0,generic_checks=generic,block_checks=block_checks,
                finite_energy_control=finite_energy,
                max_formula_absolute=max(x['absolute_error'] for x in generic),
                max_block_transmission_error=max(abs(x['transmission']-1) for x in block_checks),
                max_unitarity_error=max(x['scattering_unitarity_max'] for x in generic+block_checks+finite_energy),
                producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                dependency_sha256=hashlib.sha256(dependency.read_bytes()).hexdigest(),
                runtime_seconds=time.monotonic()-start,
                environment=dict(python=platform.python_version(),numpy=np.__version__),
                interpretation=['Transport is for the full finite six-orbital Hamiltonian attached to two ideal one-channel leads.',
                                'Matched contacts mean gamma_left*gamma_right=K^2 at zero energy.',
                                'Exact block transparency is a zero-energy statement after one common scalar critical retuning.',
                                'The block source law has discrete support and finite memory; it is outside the iid full-support controller no-go hypothesis.',
                                'Finite-energy rows are examples only and do not certify a transport bandwidth or finite-temperature conductance.',
                                'The sech-squared chiral conductance formula and random-polymer resonances have established precedents; no novelty is claimed for those facts.'])
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['max_formula_absolute','max_block_transmission_error',
                                          'max_unitarity_error','runtime_seconds']}),flush=True)


if __name__=='__main__':
    main()
