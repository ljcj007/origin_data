#!/usr/bin/env python3
"""Finite-energy diagnostic for the full decorated chain and word hierarchy.

Only the new diagnostic JSON is written.  Exact mediator elimination, direct
full-matrix Green checks, Taylor coefficients, and normalized transfer products
are kept separate.  Finite-chain loss is not presented as an infinite-length
Lyapunov exponent measurement.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import platform
import time
from pathlib import Path

import numpy as np
from scipy.linalg import solve
from scipy.optimize import brentq

from check_crossover import ROOT
from check_transport import direct_scattering, full_hamiltonian

HMED, G, TOFF, JLEAD = 2.0, 1.2, .25, 2.0
ORDER = 8
WORDS = sorted(set(itertools.permutations([-1,0,0,1])))


def retuned_K(offset):
    return float(np.exp(np.array([.25,.5,.25])@np.log(np.exp([-1.,0.,1.])+offset)))


def cell_transfer(q, energy, offset):
    u2=np.exp(q)-TOFF
    alpha=1+2*(G*G+u2)/(HMED*HMED-energy*energy)
    t=TOFF+2*G*G/HMED+offset-2*HMED*(G*G-u2)/(HMED*HMED-energy*energy)
    K=retuned_K(offset)
    return np.array([[t/K-energy*energy*alpha*alpha/(K*t),-energy*alpha/t],
                     [energy*alpha/t,K/t]])


def word_transfer(word,energy,offset):
    result=np.eye(2)
    for q in word:
        result=cell_transfer(q,energy,offset)@result
    return result


def convolution(a,b):
    return np.convolve(a,b)[:ORDER+1]


def matrix_series_product(a,b):
    result=np.zeros_like(a)
    for k in range(ORDER+1):
        for j in range(k+1):
            result[k]+=a[j]@b[k-j]
    return result


def cell_series(q,offset):
    u2=np.exp(q)-TOFF
    alpha=np.zeros(ORDER+1)
    t=np.zeros(ORDER+1)
    alpha[0]=1
    t[0]=TOFF+2*G*G/HMED+offset
    for k in range(0,ORDER+1,2):
        alpha[k]+=2*(G*G+u2)/HMED**(k+2)
        t[k]-=2*(G*G-u2)/HMED**(k+1)
    inverse_t=np.zeros_like(t)
    inverse_t[0]=1/t[0]
    for k in range(1,ORDER+1):
        inverse_t[k]=-sum(t[j]*inverse_t[k-j] for j in range(1,k+1))/t[0]
    K=retuned_K(offset)
    result=np.zeros((ORDER+1,2,2))
    result[:,0,0]=t/K
    result[2:,0,0]-=convolution(convolution(alpha,alpha),inverse_t)[:-2]/K
    result[1:,0,1]=-convolution(alpha,inverse_t)[:-1]
    result[1:,1,0]=convolution(alpha,inverse_t)[:-1]
    result[:,1,1]=K*inverse_t
    return result


def word_series(word,offset):
    result=np.zeros((ORDER+1,2,2));result[0]=np.eye(2)
    for q in word:
        result=matrix_series_product(cell_series(q,offset),result)
    return result


def scattering_from_transfer(matrix,energy,log_scale=0.0,lead_hopping=JLEAD):
    sigma=(energy-1j*np.sqrt(4*lead_hopping*lead_hopping-energy*energy))/(2*lead_hopping)
    f=matrix[...,0,0]-sigma*matrix[...,0,1]+sigma*matrix[...,1,0]-sigma*sigma*matrix[...,1,1]
    log_transmission=2*np.log(-2*np.imag(sigma))-2*(log_scale+np.log(abs(f)))
    # Physical transmission amplitude has an energy-independent sign convention;
    # its phase derivative is independent of that sign.
    phase_amplitude=1j*(-2*np.imag(sigma))/f
    return log_transmission,phase_amplitude


def direct_transmission_amplitude(word,energy,offset,lead_hopping=JLEAD):
    K=retuned_K(offset)
    t=np.exp(word)+offset
    n=len(word)
    hamiltonian=full_hamiltonian(t,K,np.ones(n),TOFF+offset)
    surface=(energy-1j*np.sqrt(4*lead_hopping**2-energy**2))/(2*lead_hopping**2)
    selfenergy=K*lead_hopping*surface
    broadening=-2*np.imag(selfenergy)
    inverse=energy*np.eye(6*n,dtype=complex)-hamiltonian
    left,right=0,6*n-3
    inverse[left,left]-=selfenergy;inverse[right,right]-=selfenergy
    column=solve(inverse,np.eye(6*n)[:,right],check_finite=False)
    return -1j*broadening*column[left]


def hierarchy_words(level):
    a=(-1,0,0,1);b=(1,0,0,-1)
    for _ in range(level):
        a,b=a+b,b+a
    return a,b


def ensemble_products(matrices,blocks,samples,rng):
    result=np.repeat(np.eye(2)[None,:,:],samples,axis=0)
    log_scale=np.zeros(samples)
    choices=rng.integers(0,len(matrices),(blocks,samples))
    for index in range(blocks):
        result=matrices[choices[index]]@result
        if index%16==15:
            scale=np.max(abs(result),axis=(1,2))
            result/=scale[:,None,None];log_scale+=np.log(scale)
    return result,log_scale


def periodic_product(matrix,blocks):
    result=np.eye(2);log_scale=0.
    for _ in range(blocks):
        result=matrix@result
        scale=np.max(abs(result));result/=scale;log_scale+=np.log(scale)
    return result,log_scale


def positive_square_root(matrix):
    values,vectors=np.linalg.eigh(matrix)
    if np.min(values)<=0:
        raise ValueError('Invariant metric is not positive.')
    return (vectors*np.sqrt(values))@vectors.T


def finite_certificate(offset,level,energy,cells=16384,with_second_moment=False):
    """Evaluate exact analytic bounds; floating-point evaluation is not interval arithmetic."""
    a,b=hierarchy_words(level)
    ma,mb=word_transfer(a,energy,offset),word_transfer(b,energy,offset)
    mean=(ma+mb)/2
    difference=(ma-mb)/2
    # C^T G C = det(C) G, stable without subtracting trace(C) from two.
    metric=np.array([[mean[1,0],(mean[1,1]-mean[0,0])/2],
                     [(mean[1,1]-mean[0,0])/2,-mean[0,1]]])
    if energy<0:
        metric=-metric
    metric/=np.sqrt(np.linalg.det(metric))
    Q=positive_square_root(metric)
    Qinv=np.linalg.inv(Q)
    normalized_difference=Q@difference@Qinv
    q=float(np.linalg.norm(normalized_difference,2)**2-np.linalg.det(difference))
    if q < -1e-12:
        raise AssertionError('Negative exact mean-square growth bound.')
    q=max(0.,q)
    K=retuned_K(offset);x=energy/K
    lead_metric=np.array([[1,x/2],[x/2,1]])/np.sqrt(1-x*x/4)
    L=positive_square_root(lead_metric)
    k=float(np.linalg.cond(L@Qinv,2))
    blocks=cells//len(a)
    exponent=2*np.log(k)+blocks*np.log1p(q)
    factor=float(np.exp(exponent))
    loss=.1
    row=dict(offset=float(offset),level=level,energy=float(energy),cells=cells,blocks=blocks,
             lead_hopping=K,contact_hopping=K,q=q,k=k,
             factor=factor,mean_transmission_lower_bound=2/(1+factor),
             inverse_transmission_excess_upper_bound=(factor-1)/2,
             probability_transmission_below_0_9_upper_bound=(1-loss)*(factor-1)/(2*loss),
             mean_normalization_error=float(np.linalg.norm((Q@mean@Qinv).T@(Q@mean@Qinv)-np.linalg.det(mean)*np.eye(2))))
    if with_second_moment:
        # Independent physical flux-coordinate second moment, not a Monte Carlo test.
        Linv=np.linalg.inv(L)
        ua,ub=L@ma@Linv,L@mb@Linv
        map4=(np.kron(ua,ua)+np.kron(ub,ub))/2
        covariance=(np.linalg.matrix_power(map4,blocks)@np.eye(2).reshape(-1)).reshape(2,2)
        trace=float(np.trace(covariance))
        row.update(exact_ensemble_flux_norm_squared=trace,
                   flux_norm_squared_upper_bound=2*factor,
                   exact_ensemble_inverse_transmission_excess=(trace-2)/4,
                   jensen_mean_transmission_lower_bound=4/(trace+2),
                   second_moment_bound_slack=2*factor-trace)
        if trace>2*factor+2e-8:
            raise AssertionError('Independent second moment exceeds analytic bound.')
    return row


def certificate_energy_allowance(offset,level,cells):
    """First numerically found threshold, with a conservative fixed probe energy."""
    failure=.1
    energies=np.geomspace(1e-7,.03,120)
    left=energies[0]
    for right in energies[1:]:
        if finite_certificate(offset,level,right,cells)['probability_transmission_below_0_9_upper_bound']>failure:
            break
        left=right
    else:
        raise AssertionError('Certificate threshold not bracketed.')
    root=brentq(lambda e:finite_certificate(offset,level,e,cells)['probability_transmission_below_0_9_upper_bound']-failure,
                left,right,xtol=1e-13,rtol=1e-12)
    probe=.98*root
    row=finite_certificate(offset,level,probe,cells,with_second_moment=True)
    grid=np.linspace(root/80,root,80)
    sampled=np.array([finite_certificate(offset,level,e,cells)['probability_transmission_below_0_9_upper_bound'] for e in grid])
    row.update(numerical_threshold_energy=float(root),numerical_threshold_energy_over_K=float(root/retuned_K(offset)),
               conservative_probe_energy=float(probe),conservative_probe_energy_over_K=float(probe/retuned_K(offset)),
               target_failure_probability=failure,transmission_loss_threshold=.1,
               sampled_monotonicity_min_increment=float(np.min(np.diff(sampled))),
               sampled_max_bound_up_to_threshold=float(np.max(sampled)),
               interval_sampling_points=80,
               interpretation='The analytic inequality is pointwise at the reported probe energy; root search and monotonicity samples are floating-point diagnostics, not a simultaneous-band or interval-arithmetic certificate.')
    return row


def main():
    start=time.monotonic()
    seed=260919017
    rng=np.random.default_rng(seed)
    offsets=[0.,.2,1.]
    direct_checks=[];delay_checks=[];hierarchies=[];flux_checks=[]
    for offset in offsets:
        K=retuned_K(offset)
        for wi,word in enumerate(WORDS):
            series=word_series(word,offset)
            upper=-series[1,0,1];lower=series[1,1,0]
            delay=(upper+lower-1/JLEAD)/2
            tiny=1e-6
            p=direct_transmission_amplitude(word,tiny,offset)
            m=direct_transmission_amplitude(word,-tiny,offset)
            measured=np.angle(p/m)/(2*tiny)
            if abs(measured-delay)>2e-7:
                raise AssertionError('Transmission delay derivative mismatch.')
            delay_checks.append(dict(offset=offset,word=list(word),first_upper=upper,first_lower=lower,
                                     first_impedance_ratio=float(np.sqrt(upper/lower)),
                                     delay_exact_first_derivative=float(delay),delay_full_green=float(measured),
                                     delay_absolute_error=float(abs(measured-delay))))
            for energy in [0.,.001,.03,.15]:
                transfer=word_transfer(word,energy,offset)
                log_t,_=scattering_from_transfer(transfer,energy)
                H=full_hamiltonian(np.exp(word)+offset,K,np.ones(len(word)),TOFF+offset)
                direct=direct_scattering(H,len(word),energy,K,K)
                error=abs(np.exp(log_t)-direct['transmission'])
                if error>2e-11 or abs(np.linalg.det(transfer)-1)>2e-12:
                    raise AssertionError('Finite-energy transfer normalization failed.')
                direct_checks.append(dict(offset=offset,word_index=wi,energy=energy,
                                          transmission_transfer=float(np.exp(log_t)),
                                          transmission_full_green=direct['transmission'],
                                          absolute_error=float(error),determinant=float(np.linalg.det(transfer))))
        for level in range(3):
            a,b=hierarchy_words(level)
            for energy in [.002,.1]:
                transfer=word_transfer(a,energy,offset)
                x=energy/K
                metric=np.array([[1,x/2],[x/2,1]])/np.sqrt(1-x*x/4)
                ev,vec=np.linalg.eigh(metric)
                L=(vec*np.sqrt(ev))@vec.T
                lead=np.array([[1-x*x,-x],[x,1]])
                rotated=L@lead@np.linalg.inv(L)
                normalized=L@transfer@np.linalg.inv(L)
                value=4/(np.linalg.norm(normalized)**2+2)
                full_green=abs(direct_transmission_amplitude(a,energy,offset,K))**2
                error=abs(value-full_green)
                if error>2e-11 or np.linalg.norm(rotated.T@rotated-np.eye(2))>2e-12:
                    raise AssertionError('Matched-lead flux transmission formula failed.')
                flux_checks.append(dict(offset=offset,level=level,cells=len(a),energy=energy,
                                        lead_hopping=K,contact_hopping=K,
                                        transmission_flux_frobenius=float(value),
                                        transmission_full_green=float(full_green),absolute_error=float(error),
                                        lead_rotation_orthogonality_error=float(np.linalg.norm(rotated.T@rotated-np.eye(2))),
                                        metric_determinant=float(np.linalg.det(metric))))
            sa,sb=word_series(a,offset),word_series(b,offset)
            difference=sa-sb
            norms=[float(np.linalg.norm(x)) for x in difference]
            first=next(k for k,x in enumerate(norms) if x>1e-8)
            if first!=level+1:
                raise AssertionError('AB/BA cancellation order mismatch.')
            mean_first=(sa[1]+sb[1])/2
            aa,bb=-mean_first[0,1],mean_first[1,0]
            q=(bb/aa)**.25
            Q=np.diag([q,1/q])
            normalized=Q@difference[first]@np.linalg.inv(Q)
            symmetry_error=float(np.linalg.norm(normalized-normalized.T))
            c=float(np.max(abs(np.linalg.eigvalsh((normalized+normalized.T)/2))))
            evaluations=[]
            for energy in [.01,.003,.001,.0003,.0001]:
                exact_a=word_transfer(a,energy,offset);exact_b=word_transfer(b,energy,offset)
                normalized_norm=np.linalg.norm(exact_a-exact_b)/energy**first
                series_a=np.einsum('k,kij->ij',energy**np.arange(ORDER+1),sa)
                if energy<=.001 and np.linalg.norm(series_a-exact_a)>2e-10:
                    raise AssertionError('Matrix Taylor series reconstruction failed.')
                evaluations.append(dict(energy=energy,pair_difference_norm=float(np.linalg.norm(exact_a-exact_b)),
                                        ratio_to_leading_power=float(normalized_norm),
                                        leading_coefficient_norm=norms[first],
                                        series_reconstruction_error=float(np.linalg.norm(series_a-exact_a))))
            hierarchies.append(dict(offset=offset,level=level,cells_per_word=len(a),
                                    word_a=list(a),word_b=list(b),leading_difference_order=first,
                                    difference_coefficient_norms=norms,
                                    first_mean_generator=mean_first.tolist(),
                                    leading_pair_difference=difference[first].tolist(),
                                    normalized_difference=normalized.tolist(),
                                    normalized_difference_symmetry_error=symmetry_error,
                                    c_full_difference=c,
                                    proposed_lyapunov_coefficient_per_cell=c*c/(8*len(a)),
                                    proposed_lyapunov_power=2*first,
                                    entropy_rate_nats_per_cell=float(np.log(2)/len(a)),
                                    finite_energy_difference=evaluations))
    products=[];matched_products=[]
    samples=64
    energies=[.0005,.001,.002,.004,.008,.016]
    for offset in offsets:
        for family in ['all_12_words','hierarchy_0','hierarchy_1','hierarchy_2']:
            words=WORDS if family=='all_12_words' else list(hierarchy_words(int(family[-1])))
            cell_length=len(words[0])
            for cells in [4096,16384]:
                blocks=cells//cell_length
                for energy in energies:
                    matrices=np.array([word_transfer(w,energy,offset) for w in words])
                    result,logscale=ensemble_products(matrices,blocks,samples,rng)
                    log_t,_=scattering_from_transfer(result,energy,logscale)
                    if np.max(log_t)>2e-8:
                        raise AssertionError('Transfer product exceeds unit transmission beyond roundoff.')
                    log_t=np.minimum(log_t,0)
                    periodic=[]
                    for matrix in matrices[:2]:
                        m,scale=periodic_product(matrix,blocks)
                        value,_=scattering_from_transfer(m,energy,scale)
                        periodic.append(float(value))
                    norm=np.linalg.svd(result,compute_uv=False)[:,0]
                    growth=(logscale+np.log(norm))/cells
                    products.append(dict(offset=offset,family=family,cells=cells,cells_per_word=cell_length,
                                         blocks=blocks,energy=energy,samples=samples,
                                         mean_log_transmission=float(np.mean(log_t)),
                                         mean_transmission=float(np.mean(np.exp(log_t))),
                                         median_transmission=float(np.exp(np.median(log_t))),
                                         log_transmission_std=float(np.std(log_t,ddof=1)),
                                         transmission_quantiles=np.quantile(np.exp(log_t),[.1,.5,.9]).tolist(),
                                         finite_length_norm_growth_per_cell=float(np.mean(growth)),
                                         norm_growth_standard_error=float(np.std(growth,ddof=1)/np.sqrt(samples)),
                                         periodic_word_log_transmissions=periodic,
                                         raw_log_transmissions=log_t.tolist()))
                    matched_log_t,_=scattering_from_transfer(result,energy,logscale,retuned_K(offset))
                    if np.max(matched_log_t)>2e-8:
                        raise AssertionError('Matched-lead transfer product exceeds unit transmission.')
                    matched_log_t=np.minimum(matched_log_t,0)
                    matched_periodic=[]
                    for matrix in matrices[:2]:
                        m,scale=periodic_product(matrix,blocks)
                        value,_=scattering_from_transfer(m,energy,scale,retuned_K(offset))
                        matched_periodic.append(float(value))
                    matched_products.append(dict(offset=offset,family=family,cells=cells,cells_per_word=cell_length,
                                                  blocks=blocks,energy=energy,samples=samples,
                                                  lead_hopping=retuned_K(offset),contact_hopping=retuned_K(offset),
                                                  mean_log_transmission=float(np.mean(matched_log_t)),
                                                  mean_transmission=float(np.mean(np.exp(matched_log_t))),
                                                  median_transmission=float(np.exp(np.median(matched_log_t))),
                                                  log_transmission_std=float(np.std(matched_log_t,ddof=1)),
                                                  transmission_quantiles=np.quantile(np.exp(matched_log_t),[.1,.5,.9]).tolist(),
                                                  periodic_word_log_transmissions=matched_periodic,
                                                  raw_log_transmissions=matched_log_t.tolist(),
                                                  disorder_samples='Exactly the same transfer products as finite_chain_products.'))
            print(json.dumps(dict(completed_offset=offset,family=family)),flush=True)
    certificate_offsets=[certificate_energy_allowance(float(offset),level,16384)
                         for offset in np.linspace(0,1,11) for level in range(3)]
    certificate_lengths=[certificate_energy_allowance(offset,level,cells)
                         for offset in [0.,1.] for level in range(3)
                         for cells in [256,1024,4096,16384,65536]]
    certificate_asymptotics=[]
    for row in hierarchies:
        power=row['proposed_lyapunov_power']
        leading=row['c_full_difference']**2/2
        for energy in [.0001,.0003,.001]:
            value=finite_certificate(row['offset'],row['level'],energy)
            certificate_asymptotics.append(dict(offset=row['offset'],level=row['level'],energy=energy,
                                               q_over_leading_power=value['q']/energy**power,
                                               expected_limit=leading,
                                               relative_difference=value['q']/energy**power/leading-1))
    report=dict(parameters=dict(d=1,h=HMED,g=G,t_offset=TOFF,lead_hopping=JLEAD),seed=seed,
                offsets=offsets,taylor_order=ORDER,direct_checks=direct_checks,
                word_delay_checks=delay_checks,hierarchies=hierarchies,
                matched_lead_flux_checks=flux_checks,
                finite_chain_products=products,
                matched_energy_ensembles=matched_products,
                finite_device_certificates=dict(offset_scan=certificate_offsets,length_scan=certificate_lengths,
                                                q_asymptotics=certificate_asymptotics,
                                                formula='E T >= 2/[1+k^2(1+q)^n]; Pr(T<.9) <= 4.5[k^2(1+q)^n-1]',
                                                normalization='Leads and contacts K, unlike the Jlead=2 ensemble runs with zero-energy matched contacts.',
                                                exact_second_moment_method='4x4 averaged Kronecker map raised to the number of blocks; no Monte Carlo inference.'),
                max_full_green_transmission_error=max(x['absolute_error'] for x in direct_checks),
                max_full_green_delay_error=max(x['delay_absolute_error'] for x in delay_checks),
                max_matched_lead_flux_error=max(x['absolute_error'] for x in flux_checks),
                producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                dependencies={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                              [Path(__file__).with_name('check_transport.py'),Path(__file__).with_name('check_crossover.py')]},
                runtime_seconds=time.monotonic()-start,
                environment=dict(python=platform.python_version(),numpy=np.__version__),
                interpretation=['The cell transfer is the exact finite-energy mediator Schur complement for |E|<h, not a low-energy Hamiltonian replacement.',
                                'Taylor coefficients are power-series coefficients, not derivatives divided by an unspecified normalization.',
                                'Recursive words obey A_next=A B and B_next=B A in spatial order; their transfer product order is reversed.',
                                'The proposed Lyapunov powers and coefficients require an independent random-product perturbation theorem; finite-chain results alone do not prove them.',
                                'Finite-length norm growth includes contact-independent bounded matrix effects and is not identified with the infinite-length Lyapunov exponent.',
                                'Finite-chain transmission includes exact ideal-lead contacts; periodic reference values distinguish contact/background loss from random order effects.',
                                'Each recursion doubles block length and halves entropy per cell; comparisons retain fixed physical cell counts.',
                                'No pre-existing raw files, plots, or manuscripts are overwritten.'])
    output=ROOT/'verification'/'finite_energy.json'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(seconds=report['runtime_seconds'],chains=len(products)*samples,
                          max_green_error=report['max_full_green_transmission_error'],
                          max_delay_error=report['max_full_green_delay_error'])),flush=True)


if __name__=='__main__':
    main()
