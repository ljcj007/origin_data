#!/usr/bin/env python3
"""Independent exact checks of balanced-word adjacent-swap scattering.

The first derivative is obtained by multiplying degree-one matrix polynomials,
not by importing the production Taylor routines. Fraction arithmetic in a small
algebraic number field keeps the geometric-mean intercell hopping exact. Only
verification/local_swap_obstruction.json is written. No Monte Carlo is used.
"""
from __future__ import annotations

from fractions import Fraction as F
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import time

import mpmath as mp

ROOT = Path(__file__).resolve().parents[1]
H, G = F(2), F(6, 5)


def rational_sqrt(value):
    a, b = math.isqrt(value.numerator), math.isqrt(value.denominator)
    return F(a, b) if a*a == value.numerator and b*b == value.denominator else None


class Field:
    """Positive K with K**4=C; use degree 1/2 when that relation reduces."""
    def __init__(self, c):
        square = rational_sqrt(c)
        fourth = rational_sqrt(square) if square is not None else None
        if fourth is not None:
            self.degree, self.modulus = 1, fourth
        elif square is not None:
            self.degree, self.modulus = 2, square
        else:
            self.degree, self.modulus = 4, c
        self.zero = (F(0),) * self.degree
        self.one = self.num(1)
        self.k = self.mono(1)
        self.k_value = mp.root(mp.mpf(c.numerator)/c.denominator, 4)

    def num(self, value):
        return (F(value),) + (F(0),) * (self.degree - 1)

    def mono(self, power):
        quotient, remainder = divmod(power, self.degree)
        result = list(self.zero)
        result[remainder] = self.modulus**quotient
        return tuple(result)

    def add(self, a, b):
        return tuple(x+y for x, y in zip(a, b))

    def sub(self, a, b):
        return tuple(x-y for x, y in zip(a, b))

    def scale(self, a, value):
        return tuple(x*value for x in a)

    def mul(self, a, b):
        out = [F(0)] * self.degree
        for i, x in enumerate(a):
            if x:
                for j, y in enumerate(b):
                    if y:
                        power, index = divmod(i+j, self.degree)
                        out[index] += x*y*self.modulus**power
        return tuple(out)

    def inv(self, a):
        # Solve the rational multiplication matrix, with no floating algebra.
        columns = [self.mul(a, self.mono(j)) for j in range(self.degree)]
        rows = [[columns[j][i] for j in range(self.degree)] + [F(i == 0)]
                for i in range(self.degree)]
        for j in range(self.degree):
            pivot = next(i for i in range(j, self.degree) if rows[i][j])
            rows[j], rows[pivot] = rows[pivot], rows[j]
            divisor = rows[j][j]
            rows[j] = [x/divisor for x in rows[j]]
            for i in range(self.degree):
                if i != j:
                    factor = rows[i][j]
                    rows[i] = [x-factor*y for x, y in zip(rows[i], rows[j])]
        return tuple(row[-1] for row in rows)

    def divide(self, a, b):
        return self.mul(a, self.inv(b))

    def value(self, a):
        return sum((mp.mpf(x.numerator)/x.denominator)*self.k_value**i
                   for i, x in enumerate(a))

    def record(self, a):
        return {"coefficients_in_K": [str(x) for x in a],
                "value": float(self.value(a))}


def madd(field, a, b):
    return tuple(field.add(x, y) for x, y in zip(a, b))


def msub(field, a, b):
    return tuple(field.sub(x, y) for x, y in zip(a, b))


def mmul(f, a, b):
    return (f.add(f.mul(a[0], b[0]), f.mul(a[1], b[2])),
            f.add(f.mul(a[0], b[1]), f.mul(a[1], b[3])),
            f.add(f.mul(a[2], b[0]), f.mul(a[3], b[2])),
            f.add(f.mul(a[2], b[1]), f.mul(a[3], b[3])))


def determinant(f, matrix):
    return f.sub(f.mul(matrix[0], matrix[3]), f.mul(matrix[1], matrix[2]))


def jet_product(f, a, b):
    return (mmul(f, a[0], b[0]),
            madd(f, mmul(f, a[1], b[0]), mmul(f, a[0], b[1])))


def word_jet(f, levels, alpha, word):
    identity = (f.one, f.zero, f.zero, f.one)
    result = (identity, (f.zero,)*4)
    for index in word:
        t = levels[index]
        c = f.num((alpha+t/H)/t)
        cell = ((f.scale(f.mono(-1), t), f.zero, f.zero,
                 f.scale(f.k, 1/t)),
                (f.zero, f.scale(c, -1), c, f.zero))
        result = jet_product(f, cell, result)
    return result


def signed_chi(f, alpha, a, b):
    bracket = f.add(f.num(alpha*(a+b)+a*b/H), f.scale(f.mono(2), 1/H))
    return f.scale(f.mul(f.mono(-1), bracket), (b-a)/(a*b))


def variance(f, values, weights):
    mean = f.zero
    for x, weight in zip(values, weights):
        mean = f.add(mean, f.scale(x, weight))
    result = f.zero
    for x, weight in zip(values, weights):
        difference = f.sub(x, mean)
        result = f.add(result, f.scale(f.mul(difference, difference), weight))
    return mean, result


def normalized_strain_variance(f, derivatives, weights):
    # a=-G01 and b=G10 already include 1/K; do not divide by K again.
    a = [f.scale(x[1], -1) for x in derivatives]
    b = [x[2] for x in derivatives]
    abar, vara = variance(f, a, weights)
    bbar, varb = variance(f, b, weights)
    cov = f.zero
    for x, y, weight in zip(a, b, weights):
        cov = f.add(cov, f.scale(f.mul(f.sub(x, abar), f.sub(y, bbar)), weight))
    ratio = f.divide(bbar, abar)
    inverse_ratio = f.divide(abar, bbar)
    total = f.scale(f.sub(f.add(f.mul(ratio, vara), f.mul(inverse_ratio, varb)),
                                f.scale(cov, 2)), F(1, 4))
    return total, ratio, inverse_ratio, abar, bbar


def strain_square(f, derivative, ratio, inverse_ratio):
    a, b = f.scale(derivative[1], -1), derivative[2]
    return f.scale(f.sub(f.add(f.mul(ratio, f.mul(a, a)),
                              f.mul(inverse_ratio, f.mul(b, b))),
                        f.scale(f.mul(a, b), 2)), F(1, 4))


def words_of_length(length):
    # Combination construction avoids creating the 8! duplicate permutations.
    n = length//4
    result = []
    for low in itertools.combinations(range(length), n):
        remaining = sorted(set(range(length))-set(low))
        for high in itertools.combinations(remaining, n):
            word = [1]*length
            for i in low:
                word[i] = 0
            for i in high:
                word[i] = 2
            result.append(tuple(word))
    return sorted(result)


def swapped(word, j):
    return word[:j]+(word[j+1], word[j])+word[j+2:]


CONJUGATIONS = [
    (F(1), F(0), F(0), F(1)),
    (F(1), F(2), F(0), F(1)),
    (F(1), F(0), F(-3), F(1)),
    (F(2), F(1), F(1), F(1)),
    (F(1, 3), F(1), F(0), F(3)),
]


def test_alphabet(name, levels, toff):
    f = Field(levels[0]*levels[1]**2*levels[2])
    alpha = 1+2*G*G/H**2-toff/H
    assert all(t >= toff and t > 0 for t in levels)
    identity = (f.one, f.zero, f.zero, f.one)
    counts = {"balanced_words": 0, "adjacent_unequal_swaps": 0,
              "conjugated_strain_checks": 0, "variance_mixtures": 0}
    by_length, mixtures = [], []
    min_chi = math.inf
    max_strain_ratio = 1.0
    for length in (4, 8):
        words = words_of_length(length)
        jets = {word: word_jet(f, levels, alpha, word) for word in words}
        before = dict(counts)
        for wi, word in enumerate(words):
            m0, derivative = jets[word]
            assert m0 == identity
            assert derivative[0] == derivative[3] == f.zero
            assert f.value(derivative[1]) < 0 < f.value(derivative[2])
            counts["balanced_words"] += 1
            for j in range(length-1):
                if word[j] == word[j+1]:
                    continue
                other = swapped(word, j)
                difference = msub(f, jets[other][1], derivative)
                a, b = levels[word[j]], levels[word[j+1]]
                d = signed_chi(f, alpha, a, b)
                chi2 = f.mul(d, d)
                assert determinant(f, difference) == f.scale(chi2, -1)
                assert difference[0] == difference[3] == f.zero
                # Direct entrywise prefix formula, including orientation sign.
                prefix = f.one
                for q in word[:j]:
                    prefix = f.mul(prefix, f.scale(f.mono(-1), levels[q]))
                scale = f.divide(f.scale(f.mono(2), 1/(a*b)), f.mul(prefix, prefix))
                assert difference[1] == f.mul(d, scale)
                assert difference[2] == f.divide(d, scale)
                assert f.value(chi2) > 0
                min_chi = min(min_chi, float(abs(f.value(d))))
                counts["adjacent_unequal_swaps"] += 1
                if length == 4 or wi % 37 == 0:
                    for entries in CONJUGATIONS:
                        q = tuple(f.num(x) for x in entries)
                        qinv = (q[3], f.scale(q[1], -1), f.scale(q[2], -1), q[0])
                        transform = mmul(f, mmul(f, q, difference), qinv)
                        off = f.scale(f.add(transform[1], transform[2]), F(1, 2))
                        omega = f.scale(f.sub(transform[2], transform[1]), F(1, 2))
                        s2 = f.add(f.mul(transform[0], transform[0]), f.mul(off, off))
                        assert f.sub(s2, f.mul(omega, omega)) == chi2
                        max_strain_ratio = max(max_strain_ratio, float(f.value(s2)/f.value(chi2)))
                        counts["conjugated_strain_checks"] += 1
        by_length.append({"length": length,
                          **{key: counts[key]-before[key] for key in before if key != "variance_mixtures"}})
        # Deterministic base and two-base mixture; fixed nontrivial probabilities.
        selected = [words[0], words[len(words)//2]]
        for base_weights in ([F(1), F(0)], [F(1, 3), F(2, 3)]):
            for probability in (F(1, 10), F(1, 2)):
                derivatives, weights, differences, chi2s = [], [], [], []
                for word, weight in zip(selected, base_weights):
                    j = next(i for i in range(length-1) if word[i] != word[i+1])
                    g0, g1 = jets[word][1], jets[swapped(word, j)][1]
                    derivatives.extend([g0, g1])
                    weights.extend([weight*(1-probability), weight*probability])
                    differences.append(msub(f, g1, g0))
                    d = signed_chi(f, alpha, levels[word[j]], levels[word[j+1]])
                    chi2s.append(f.mul(d, d))
                total, ratio, inverse_ratio, abar, bbar = normalized_strain_variance(f, derivatives, weights)
                assert f.value(abar) > 0 and f.value(bbar) > 0
                conditional = f.zero
                lower = f.zero
                conditional_means = []
                for i, weight in enumerate(base_weights):
                    conditional = f.add(conditional, f.scale(
                        strain_square(f, differences[i], ratio, inverse_ratio),
                        weight*probability*(1-probability)))
                    lower = f.add(lower, f.scale(chi2s[i], weight*probability*(1-probability)))
                    conditional_means.append(madd(f, derivatives[2*i], tuple(
                        f.scale(x, probability) for x in differences[i])))
                # Law of total variance with the same global normalization.
                mean_derivative = tuple(sum_field(f, [f.scale(x[j], w)
                    for x, w in zip(conditional_means, base_weights)]) for j in range(4))
                between = sum_field(f, [f.scale(strain_square(f,
                    msub(f, x, mean_derivative), ratio, inverse_ratio), w)
                    for x, w in zip(conditional_means, base_weights)])
                assert total == f.add(conditional, between)
                assert f.value(conditional)-f.value(lower) >= -mp.mpf('1e-60')
                assert f.value(between) >= -mp.mpf('1e-60')
                counts["variance_mixtures"] += 1
                mixtures.append({"length": length, "base_weights": list(map(str, base_weights)),
                    "fault_probability": str(probability), "gamma2": f.record(f.scale(total, F(1, 2*length))),
                    "gamma2_lower_bound": f.record(f.scale(lower, F(1, 2*length))),
                    "strain_variance": f.record(total), "conditional_variance": f.record(conditional),
                    "between_base_variance": f.record(between)})
    return {"name": name, "levels": list(map(str, levels)), "t_off": str(toff),
            "alpha": str(alpha), "field_degree": f.degree,
            "field_relation": f"K^{f.degree}={f.modulus}",
            "K": float(f.k_value), "counts": counts, "by_length": by_length,
            "min_chi": min_chi, "largest_tested_strain_square_over_chi_square": max_strain_ratio,
            "mean_normalized_variance_tests": mixtures}


def sum_field(f, values):
    result = f.zero
    for value in values:
        result = f.add(result, value)
    return result


def independent_disjoint_faults():
    levels = [F(1, 2), F(1), F(2)]
    f = Field(F(1)); alpha = 1+2*G*G/H**2-F(1, 4)/H
    base = (0, 1, 2, 1, 0, 1, 2, 1)
    positions = [0, 2, 4, 6]
    probabilities = [F(1, 5), F(2, 5), F(1, 3), F(3, 7)]
    g0 = word_jet(f, levels, alpha, base)[1]
    differences = [msub(f, word_jet(f, levels, alpha, swapped(base, j))[1], g0)
                   for j in positions]
    derivatives, weights, raw = [], [], []
    for bits in itertools.product((0, 1), repeat=4):
        word = base; weight = F(1)
        affine = g0
        for bit, j, probability, difference in zip(bits, positions, probabilities, differences):
            weight *= probability if bit else 1-probability
            if bit:
                word = swapped(word, j)
                affine = madd(f, affine, difference)
        derivative = word_jet(f, levels, alpha, word)[1]
        assert derivative == affine
        derivatives.append(derivative); weights.append(weight)
        raw.append({"bits": bits, "weight": str(weight), "word": word})
    total, ratio, inverse_ratio, _, _ = normalized_strain_variance(f, derivatives, weights)
    additive = sum_field(f, [f.scale(strain_square(f, difference, ratio, inverse_ratio),
        p*(1-p)) for difference, p in zip(differences, probabilities)])
    lower = sum_field(f, [f.scale(determinant(f, difference), -p*(1-p))
        for difference, p in zip(differences, probabilities)])
    assert total == additive
    assert f.value(total) >= f.value(lower)
    # Repeating the same fair swap gives XOR, not two additive independent strains.
    short = (0, 1, 1, 2)
    short0 = word_jet(f, levels, alpha, short)[1]
    short1 = word_jet(f, levels, alpha, swapped(short, 0))[1]
    twice = [short1 if a ^ b else short0 for a, b in itertools.product((0, 1), repeat=2)]
    twice_variance, r, ri, _, _ = normalized_strain_variance(f, twice, [F(1, 4)]*4)
    one_square = strain_square(f, msub(f, short1, short0), r, ri)
    assert twice_variance == f.scale(one_square, F(1, 4))
    assert twice_variance != f.scale(one_square, F(1, 2))
    return {"disjoint_pair_sample_space": raw, "sample_count": len(raw),
            "variance": f.record(total), "sum_conditional_variances": f.record(additive),
            "prefix_independent_lower_bound": f.record(lower),
            "overlapping_same_swap_counterexample": {
                "probabilities": ["1/2", "1/2"], "variance": f.record(twice_variance),
                "invalid_naive_sum": f.record(f.scale(one_square, F(1, 2))),
                "reason": "Two independent fair swaps on the same bond reduce to one XOR bit."}}


def unretuned_negative_control():
    a, b, k = F(101), F(102), F(96)
    toff = 2*(1+2*G*G/H**2) + (a*b+k*k)/(a+b)
    alpha = 1+2*G*G/H**2-toff/H
    assert toff < a < b and alpha < 0
    bracket = alpha*(a+b)+(a*b+k*k)/H
    assert bracket == 0
    f = Field(k**4)
    levels = [a, b]
    w = (0, 1, 0, 1)
    jw, jv = word_jet(f, levels, alpha, w), word_jet(f, levels, alpha, swapped(w, 0))
    assert jw[1] == jv[1]
    assert jw[0] != (f.one, f.zero, f.zero, f.one)
    return {"levels": [str(a), str(b)], "K": str(k), "t_off": str(toff),
            "alpha": str(alpha), "bracket": str(bracket),
            "word": w, "P0_upper_diagonal": f.record(jw[0][0]),
            "first_derivative_swap_difference_is_zero": True,
            "scope": "Feasible local cells, but intercell K is not the word geometric mean; not a counterexample to balanced words."}


def exponential_alphabet():
    # Independent 80-digit direct matrix product for the manuscript alphabet.
    levels = [mp.exp(-1), mp.mpf(1), mp.exp(1)]
    h, g, toff = mp.mpf(2), mp.mpf(6)/5, mp.mpf(1)/4
    alpha = 1+2*g*g/h**2-toff/h
    max_det_error = mp.mpf(0); max_entry_error = mp.mpf(0)
    total_swaps = 0
    for length in (4, 8):
        words = words_of_length(length)
        jets = {}
        for word in words:
            m0, m1 = mp.eye(2), mp.zeros(2)
            for index in word:
                t = levels[index]; c = (alpha+t/h)/t
                c0, c1 = mp.matrix([[t, 0], [0, 1/t]]), mp.matrix([[0, -c], [c, 0]])
                m1, m0 = c1*m0+c0*m1, c0*m0
            jets[word] = m1
        for word in words:
            for j in range(length-1):
                if word[j] == word[j+1]:
                    continue
                difference = jets[swapped(word, j)]-jets[word]
                a, b = levels[word[j]], levels[word[j+1]]
                chi = (b-a)*(alpha*(a+b)+(a*b+1)/h)/(a*b)
                prefix = mp.fprod(levels[k] for k in word[:j])
                scale = 1/(a*b*prefix**2)
                max_det_error = max(max_det_error, abs(mp.det(difference)+chi**2))
                max_entry_error = max(max_entry_error, abs(difference[0, 1]-chi*scale),
                                      abs(difference[1, 0]-chi/scale))
                total_swaps += 1
    assert max_det_error < mp.mpf('1e-65') and max_entry_error < mp.mpf('1e-65')
    return {"levels": ["exp(-1)", "1", "exp(1)"], "mpmath_decimal_precision": mp.mp.dps,
            "adjacent_unequal_swaps": total_swaps,
            "maximum_determinant_absolute_error": mp.nstr(max_det_error, 20),
            "maximum_entrywise_absolute_error": mp.nstr(max_entry_error, 20)}


def generic_positive_q_graphs():
    """Finite-alphabet graph bound, including exactly silent adjacent pairs."""
    levels = [F(1, 4), F(1, 2), F(2), F(4)]
    # Each word uses each level once, so K=1 exactly.
    f = Field(F(1)); words = list(itertools.permutations(range(4)))
    cases = []
    for name, qvalues in [
        ("two_silent_classes", [F(15, 8), F(3, 2), F(6), F(30)]),
        ("generic_nonaffine_metric", [F(1), F(3), F(2), F(5)]),
    ]:
        identity = (f.one, f.zero, f.zero, f.one)
        jets = {}
        for word in words:
            result = (identity, (f.zero,)*4)
            for index in word:
                t, q = levels[index], qvalues[index]
                cell0 = tuple(map(f.num, (t, F(0), F(0), 1/t)))
                cell1 = tuple(map(f.num, (F(0), -q/t, q/t, F(0))))
                result = jet_product(f, (cell0, cell1), result)
                # Exact analytic transfer with fixed t and Q, including E^2.
                for energy in (F(0), F(1, 100), F(1, 3)):
                    full = tuple(map(f.num, (t-energy**2*q**2/t,
                                               -energy*q/t, energy*q/t, 1/t)))
                    assert determinant(f, full) == f.one
            assert result[0] == identity
            jets[word] = result[1]
        edges = []
        for i, j in itertools.combinations(range(4), 2):
            a, b = levels[i], levels[j]
            d = (qvalues[i]*(b*b-1)-qvalues[j]*(a*a-1))/(a*b)
            edges.append((d*d, i, j))
        weights_by_edge = {(i, j): weight for weight, i, j in edges}
        # Kruskal's complete-graph minimum spanning tree, all exact Fractions.
        parents = list(range(4))
        def find(i):
            while parents[i] != i:
                i = parents[i]
            return i
        tree = []; mst_weight = F(0)
        for weight, i, j in sorted(edges):
            ri, rj = find(i), find(j)
            if ri != rj:
                parents[ri] = rj; tree.append([i, j, str(weight)])
                mst_weight += weight
        assert len(tree) == 3 and mst_weight > 0
        raw_words = []
        swap_count = 0
        for word in words:
            path_weight = F(0)
            for j in range(3):
                edge = tuple(sorted((word[j], word[j+1])))
                chi2 = weights_by_edge[edge]
                difference = msub(f, jets[swapped(word, j)], jets[word])
                assert determinant(f, difference) == f.num(-chi2)
                assert (difference == (f.zero,)*4) == (chi2 == 0)
                path_weight += chi2; swap_count += 1
            assert path_weight >= mst_weight
            raw_words.append({"word": word, "sum_adjacent_chi_square": str(path_weight)})
        mixture_results = []
        for probability in (F(1, 10), F(1, 2)):
            derivatives, weights, differences, chi2s, conditional_means = [], [], [], [], []
            for word in words:
                for j in range(3):
                    g0, g1 = jets[word], jets[swapped(word, j)]
                    diff = msub(f, g1, g0)
                    derivatives.extend([g0, g1])
                    weights.extend([(1-probability)/72, probability/72])
                    differences.append(diff)
                    chi2s.append(weights_by_edge[tuple(sorted((word[j], word[j+1])))])
                    conditional_means.append(madd(f, g0, tuple(f.scale(x, probability) for x in diff)))
            total, ratio, ri, _, _ = normalized_strain_variance(f, derivatives, weights)
            conditional = sum_field(f, [f.scale(strain_square(f, diff, ratio, ri),
                probability*(1-probability)/72) for diff in differences])
            lower_exact = probability*(1-probability)*sum(chi2s)/72
            graph_lower = probability*(1-probability)*mst_weight/3
            average = tuple(sum_field(f, [f.scale(x[j], F(1, 72))
                for x in conditional_means]) for j in range(4))
            between = sum_field(f, [f.scale(strain_square(f,
                msub(f, x, average), ratio, ri), F(1, 72)) for x in conditional_means])
            assert total == f.add(conditional, between)
            assert conditional[0] >= lower_exact >= graph_lower  # K=1: rational comparison.
            mixture_results.append({"fault_probability": str(probability),
                "base_distribution": "uniform over all 24 words",
                "slot_distribution": "uniform over all 3 adjacent slots",
                "gamma2": f.record(f.scale(total, F(1, 8))),
                "conditional_gamma2": f.record(f.scale(conditional, F(1, 8))),
                "mean_chi_gamma2_lower": str(lower_exact/8),
                "MST_gamma2_lower": str(graph_lower/8),
                "total_variance_identity_exact": True})
        cases.append({"name": name, "levels": list(map(str, levels)), "K": "1",
            "Q": list(map(str, qvalues)),
            "f_j=(t_j^2-K^2)/Q_j": [str((t*t-1)/q) for t, q in zip(levels, qvalues)],
            "edges": [{"i": i, "j": j, "chi_square": str(w)} for w, i, j in edges],
            "minimum_spanning_tree": tree, "MST_weight": str(mst_weight),
            "word_count": len(words), "adjacent_swap_checks": swap_count,
            "word_path_weights": raw_words, "fault_mixtures": mixture_results,
            "scope": "Generic positive analytic metric, not asserted to have the specific mediator-affine Q(t)."})
    return cases


def hierarchy_attempted_swap_coefficients():
    """Deterministic first-jet coefficients, no transfer-product sampling."""
    h, g, toff, k = mp.mpf(2), mp.mpf(6)/5, mp.mpf(1)/4, mp.mpf(1)
    alpha = 1+2*g*g/h**2-toff/h
    levels = [mp.exp(-1), mp.mpf(1), mp.exp(1)]
    def derivative(word):
        zero, first = mp.eye(2), mp.zeros(2)
        for index in word:
            t = levels[index]; q = alpha+t/h
            c0 = mp.matrix([[t/k, 0], [0, k/t]])
            c1 = mp.matrix([[0, -q/t], [q/t, 0]])
            first, zero = c1*zero+c0*first, c0*zero
        assert mp.norm(zero-mp.eye(2)) < mp.mpf('1e-75')
        return first
    edge_values = []
    for i, j in itertools.combinations(range(3), 2):
        a, b = levels[i], levels[j]
        chi = abs((b-a)*(alpha*(a+b)+(a*b+k*k)/h)/(k*a*b))
        edge_values.append((chi*chi, i, j))
    mst_edges = sorted(edge_values)[:2]  # Any two edges connect three vertices.
    mst_weight = sum(x[0] for x in mst_edges)
    probabilities = ["0", "0.00001", "0.00003", "0.0001", "0.0003", "0.001",
                     "0.003", "0.01", "0.03", "0.1", "0.3", "0.5"]
    rows, designs = [], []
    a, b = (0, 1, 1, 2), (2, 1, 1, 0)
    for depth in (1, 2):
        a, b = a+b, b+a
        length = len(a)
        ideals = [derivative(a), derivative(b)]
        faults = [derivative(swapped(word, j)) for word in (a, b) for j in range(length-1)]
        noops = sum(word[j] == word[j+1] for word in (a, b) for j in range(length-1))
        designs.append({"depth": depth, "length": length, "ideal_words": [a, b],
            "all_attempt_slots_across_two_words": 2*(length-1),
            "equal_neighbor_noop_slots": noops,
            "probability_of_noop_conditional_on_attempt": str(F(noops, 2*(length-1))),
            "maximum_ideal_first_jet_difference": mp.nstr(mp.norm(ideals[0]-ideals[1]), 30)})
        for probability_text in probabilities:
            p = mp.mpf(probability_text)
            weights = [(1-p)/2]*2+[p/(2*(length-1))]*len(faults)
            generators = ideals+faults
            avals = [-x[0, 1] for x in generators]
            bvals = [x[1, 0] for x in generators]
            abar = mp.fsum(w*x for w, x in zip(weights, avals))
            bbar = mp.fsum(w*x for w, x in zip(weights, bvals))
            vara = mp.fsum(w*(x-abar)**2 for w, x in zip(weights, avals))
            varb = mp.fsum(w*(x-bbar)**2 for w, x in zip(weights, bvals))
            cov = mp.fsum(w*(x-abar)*(y-bbar) for w, x, y in zip(weights, avals, bvals))
            strain_variance = ((bbar/abar)*vara+(abar/bbar)*varb-2*cov)/4
            gamma2 = strain_variance/(2*length)
            floor = p*(1-p)*mst_weight/(2*length*(length-1))
            assert gamma2 >= floor-mp.mpf('1e-65')
            if p == 0:
                assert abs(gamma2) < mp.mpf('1e-145')
            rows.append({"depth": depth, "length": length, "p_sw": float(p),
                "p_sw_exact_decimal": probability_text,
                "gamma2": float(gamma2), "gamma2_mp": mp.nstr(gamma2, 50),
                "MST_gamma2_floor": float(floor), "MST_gamma2_floor_mp": mp.nstr(floor, 50),
                "gamma2_over_p_sw": float(gamma2/p) if p else None,
                "mean_upper_metric": float(abar), "mean_lower_metric": float(bbar)})
    return {"method": "80-digit direct degree-one matrix-polynomial products and exact finite-distribution strain variance; no Monte Carlo",
        "parameters": {"h": "2", "g": "6/5", "t_off": "1/4", "K": "1",
                       "levels": ["exp(-1)", "1", "exp(1)"]},
        "precision_decimal_digits": mp.mp.dps,
        "ensemble": "Choose each ideal A_r/B_r with probability 1/2. With probability p_sw attempt one uniformly chosen internal adjacent swap, including equal-level no-ops; otherwise keep the ideal word.",
        "coefficient_convention": "gamma_cell(E)=Gamma2*E^2+o(E^2); Gamma2=normalized symmetric-strain variance/(2*word_length)",
        "distinct_from_four_word_fault_ensemble": True,
        "MST_weight": float(mst_weight), "MST_weight_mp": mp.nstr(mst_weight, 50),
        "MST_edges": [{"i": i, "j": j, "chi_square_mp": mp.nstr(w, 50)} for w, i, j in mst_edges],
        "designs": designs, "coefficient_rows": rows,
        "zero_probability_policy": "Raw high-precision arithmetic residual is stored, rather than replacing it with an exact zero."}


def main():
    started = time.perf_counter(); mp.mp.dps = 80
    specs = [
        ("reciprocal", [F(1, 2), F(1), F(2)], F(1, 4)),
        ("asymmetric", [F(2, 3), F(3, 2), F(9, 4)], F(1, 4)),
        ("quadratic_field", [F(1, 3), F(2, 5), F(3, 4)], F(1, 4)),
        ("negative_alpha", [F(5), F(6), F(8)], F(4)),
        ("large_negative_alpha", [F(101), F(103), F(107)], F(100)),
        ("common_saturation_c_half", [F(2, 5), F(2, 3), F(1)], F(1, 4)),
        ("common_saturation_c_twentieth", [F(15, 2), F(10), F(12)], F(4)),
        ("common_offset_one", [F(3, 2), F(2), F(3)], F(5, 4)),
    ]
    alphabets = []
    for name, levels, toff in specs:
        result = test_alphabet(name, levels, toff)
        alphabets.append(result)
        print(name, result["counts"], flush=True)
    output = {
        "method": "Exact Fraction arithmetic in Q(K), independent first-order matrix-polynomial multiplication",
        "parameters": {"h": str(H), "g": str(G), "word_lengths": [4, 8],
                       "counts_per_four_cells": [1, 2, 1]},
        "alphabets": alphabets,
        "summary": {key: sum(x["counts"][key] for x in alphabets)
                    for key in alphabets[0]["counts"]},
        "disjoint_independent_faults": independent_disjoint_faults(),
        "unretuned_negative_control": unretuned_negative_control(),
        "exponential_alphabet": exponential_alphabet(),
        "generic_positive_Q_graphs": generic_positive_q_graphs(),
        "hierarchy_attempted_swap_coefficients": hierarchy_attempted_swap_coefficients(),
        "scope": "Finite exact coefficient checks, not a proof of the infinite-volume Lyapunov expansion; no long-chain sampling or old data changes.",
        "provenance": {"script": str(Path(__file__).relative_to(ROOT)),
                       "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                       "python": platform.python_version(), "mpmath": mp.__version__,
                       "external_source_dependencies": [],
                       "runtime_seconds": time.perf_counter()-started},
    }
    target = ROOT/"verification/local_swap_obstruction.json"
    target.write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps(output["summary"]), flush=True)
    print(target, flush=True)


if __name__ == "__main__":
    main()
