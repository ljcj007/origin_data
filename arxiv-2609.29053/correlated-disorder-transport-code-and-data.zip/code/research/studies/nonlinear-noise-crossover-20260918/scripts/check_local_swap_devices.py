#!/usr/bin/env python3
"""Paired finite-device transmission for the actual local-swap ensemble.

The production observable is sampled T, not 1/(1+mean rho). A separate
65-digit 4x4 covariance map supplies exact-ensemble mean rho and its Jensen
lower bound. The fixed-seed controller arrays are shared across energies and
fault probabilities.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import platform
import time

import mpmath as mp
import numpy as np
import scipy
from scipy.linalg import solve

ROOT = Path(__file__).resolve().parents[1]
SEED = 202609180507
H, G, TOFF, K = 2.0, 1.2, .25, 1.0
DEPTH, LENGTH, CELLS, SAMPLES = 2, 16, 16384, 256
PROBABILITIES = [0.0, .001, .01, .1]
ENERGIES = np.linspace(-.006, .006, 61)
LEVELS = np.exp([-1.0, 0.0, 1.0])


def digest(data):
    return hashlib.sha256(data).hexdigest()


def controller_words():
    a, b = (0, 1, 1, 2), (2, 1, 1, 0)
    for _ in range(DEPTH):
        a, b = a+b, b+a
    words = [a, b]
    for base in (a, b):
        for boundary in range(LENGTH-1):
            trial = list(base)
            trial[boundary], trial[boundary+1] = trial[boundary+1], trial[boundary]
            words.append(tuple(trial))
    return words


WORDS = controller_words()


def product(a, b):
    """Broadcasted 2x2 product, explicit entries avoid general BLAS overhead."""
    out = np.empty(np.broadcast_shapes(a.shape, b.shape))
    out[..., 0, 0] = a[..., 0, 0]*b[..., 0, 0]+a[..., 0, 1]*b[..., 1, 0]
    out[..., 0, 1] = a[..., 0, 0]*b[..., 0, 1]+a[..., 0, 1]*b[..., 1, 1]
    out[..., 1, 0] = a[..., 1, 0]*b[..., 0, 0]+a[..., 1, 1]*b[..., 1, 0]
    out[..., 1, 1] = a[..., 1, 0]*b[..., 0, 1]+a[..., 1, 1]*b[..., 1, 1]
    return out


def cell(level, energies):
    u2 = LEVELS[level]-TOFF
    z = energies*(1+2*(G*G+u2)/(H*H-energies*energies))
    t = TOFF+2*G*G/H-2*H*(G*G-u2)/(H*H-energies*energies)
    result = np.empty((len(energies), 2, 2))
    result[:, 0, 0] = t/K-z*z/(K*t)
    result[:, 0, 1] = -z/t
    result[:, 1, 0] = z/t
    result[:, 1, 1] = K/t
    return result


def matrices(energies):
    cells = [cell(j, energies) for j in range(3)]
    library = np.empty((len(energies), len(WORDS), 2, 2))
    for index, word in enumerate(WORDS):
        result = np.broadcast_to(np.eye(2), (len(energies), 2, 2)).copy()
        for letter in word:
            result = product(cells[letter], result)
        library[:, index] = result
    return library


def lead_metric(energies):
    x = energies/(2*K)
    matrix = np.zeros((len(energies), 2, 2))
    matrix[:, 0, 0] = matrix[:, 1, 1] = 1
    matrix[:, 0, 1] = matrix[:, 1, 0] = x
    matrix /= np.sqrt(1-x*x)[:, None, None]
    # This SPD matrix has determinant one, hence its square root is explicit.
    root = (matrix+np.eye(2))/np.sqrt(matrix[:, 0, 0]+matrix[:, 1, 1]+2)[:, None, None]
    inverse = root.copy()
    inverse[:, 0, 1] *= -1; inverse[:, 1, 0] *= -1
    return root, inverse


def propagate(library, indices, energies):
    ne, ns, nb = len(energies), indices.shape[1], indices.shape[0]
    state = np.broadcast_to(np.eye(2), (ne, ns, 2, 2)).copy()
    log_scale = np.zeros((ne, ns))
    energy_index = np.arange(ne)[:, None]
    for block in range(nb):
        state = product(library[energy_index, indices[block][None, :]], state)
        if block % 16 == 15 or block == nb-1:
            scale = np.max(np.abs(state), axis=(-2, -1))
            state /= scale[..., None, None]
            log_scale += np.log(scale)
    lead, inverse = lead_metric(energies)
    flux = product(product(lead[:, None], state), inverse[:, None])
    log_frobenius2 = np.log(np.sum(flux*flux, axis=(-2, -1)))+2*log_scale
    log_transmission = np.log(4.0)-np.logaddexp(log_frobenius2, np.log(2.0))
    raw = np.exp(log_transmission)
    assert np.all(np.isfinite(log_transmission)) and raw.max() < 1+2e-9
    roundoff_excess = float(max(0, raw.max()-1))
    excess_count = int(np.sum(raw > 1))
    transmission = np.minimum(raw, 1.0)
    log_transmission = np.minimum(log_transmission, 0.0)
    center = np.flatnonzero(abs(energies) < 1e-18)
    raw_center_error = float(np.max(abs(raw[center]-1))) if len(center) else None
    return transmission, log_transmission, dict(maximum_roundoff_above_one=roundoff_excess,
        clipped_above_one_count=excess_count, maximum_unclipped_center_T_error=raw_center_error)


def mp_library(energy):
    h, g, toff = mp.mpf(2), mp.mpf('1.2'), mp.mpf('.25')
    levels = [mp.exp(-1), mp.mpf(1), mp.exp(1)]
    cells = []
    for t0 in levels:
        u2 = t0-toff
        z = energy*(1+2*(g*g+u2)/(h*h-energy*energy))
        t = toff+2*g*g/h-2*h*(g*g-u2)/(h*h-energy*energy)
        cells.append(mp.matrix([[t-z*z/t, -z/t], [z/t, 1/t]]))
    result = []
    for word in WORDS:
        matrix = mp.eye(2)
        for letter in word:
            matrix = cells[letter]*matrix
        result.append(matrix)
    metric = mp.matrix([[1, energy/2], [energy/2, 1]])/mp.sqrt(1-energy*energy/4)
    lead = (metric+mp.eye(2))/mp.sqrt(metric[0, 0]+metric[1, 1]+2)
    return result, lead


def exact_mean_rho(energy_text, probability_text, blocks=CELLS//LENGTH):
    energy, probability = mp.mpf(energy_text), mp.mpf(probability_text)
    library, lead = mp_library(energy)
    weights = [(1-probability)/2]*2+[probability/(2*(LENGTH-1))]*(2*(LENGTH-1))
    flux = [lead*x*(lead**-1) for x in library]
    # The linear covariance map S -> sum_w p_w M_w S M_w^T, row-major vectorized.
    operator = mp.zeros(4)
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    operator[2*i+j, 2*k+l] = mp.fsum(
                        w*m[i, k]*m[j, l] for w, m in zip(weights, flux))
    moment = operator**blocks*mp.matrix([1, 0, 0, 1])
    rho = (moment[0]+moment[3]-2)/4
    lower = 1/(1+rho)
    return dict(energy=float(energy), p_sw=float(probability), blocks=blocks,
                mean_excess_resistance=float(rho), mean_excess_resistance_mp=mp.nstr(rho, 55),
                Jensen_mean_T_lower=float(lower), Jensen_mean_T_lower_mp=mp.nstr(lower, 55),
                interpretation='E[T] >= 1/(1+E[rho]); this lower bound is not the ensemble mean transmission.')


def full_green(word, energy):
    """Independent physical six-orbital-per-cell Hamiltonian and lead self-energy."""
    n = len(word); matrix = np.zeros((6*n, 6*n))
    a = TOFF+2*G*G/H
    for index, letter in enumerate(word):
        start = 6*index; u = np.sqrt(LEVELS[letter]-TOFF)
        connections = [(0, 3, a), (0, 4, G+u), (0, 5, G-u),
                       (1, 3, G-u), (2, 3, G+u), (1, 4, H), (2, 5, H)]
        for i, j, value in connections:
            matrix[start+i, start+j] = matrix[start+j, start+i] = value
        if index:
            matrix[start, start-3] = matrix[start-3, start] = -K
    inverse = energy*np.eye(6*n, dtype=complex)-matrix
    sigma = (energy-1j*np.sqrt(4*K*K-energy*energy))/2
    left, right = 0, 6*n-3
    inverse[left, left] -= sigma; inverse[right, right] -= sigma
    rhs = np.zeros(6*n); rhs[right] = 1
    solution = solve(inverse, rhs, check_finite=False)
    return float((-2*sigma.imag)**2*abs(solution[left])**2)


def validation_checks():
    energies = np.array([0.0, .002, .006])
    library = matrices(energies)
    checks = []
    for word_index in [0, 1, 2, 9, 22]:
        transfer, _, _ = propagate(library, np.array([[word_index]]), energies)
        for j, energy in enumerate(energies):
            green = full_green(WORDS[word_index], energy)
            error = abs(green-transfer[j, 0])
            assert error < 2e-11
            checks.append(dict(word_index=word_index, energy=float(energy),
                               transfer=float(transfer[j, 0]), full_green=green, error=error))
    # Exhaust all 32^2 controller-label choices, including coincident no-op words.
    energy, probability = mp.mpf('.002'), mp.mpf('.1')
    library, lead = mp_library(energy)
    weights = [(1-probability)/2]*2+[probability/30]*30
    inverse = lead**-1
    enumerated = mp.mpf(0)
    for i, left in enumerate(library):
        for j, right in enumerate(library):
            flux = lead*right*left*inverse
            rho = (mp.fsum(x*x for x in flux)-2)/4
            enumerated += weights[i]*weights[j]*rho
    mapped = exact_mean_rho('.002', '.1', blocks=2)
    error = abs(enumerated-mp.mpf(mapped['mean_excess_resistance_mp']))
    assert error < mp.mpf('1e-50')
    return dict(full_hamiltonian=checks, maximum_green_error=max(x['error'] for x in checks),
                exact_two_block_enumeration=dict(controller_label_sequences=32**2,
                    enumerated_mean_rho=mp.nstr(enumerated, 55), absolute_error=mp.nstr(error, 20)))


def controller_draws():
    generator = np.random.Generator(np.random.PCG64(SEED))
    shape = (CELLS//LENGTH, SAMPLES)
    base = generator.integers(0, 2, shape, dtype=np.uint8)
    boundary = generator.integers(0, LENGTH-1, shape, dtype=np.uint8)
    coin = generator.random(shape)
    return base, boundary, coin


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--benchmark', action='store_true')
    args = parser.parse_args(); started = time.perf_counter(); mp.mp.dps = 65
    base, boundary, coin = controller_draws()
    bench_energies = ENERGIES[::6]
    begin = time.perf_counter()
    propagate(matrices(bench_energies), base[:128, :64], bench_energies)
    benchmark = time.perf_counter()-begin
    estimate = benchmark*(len(ENERGIES)/len(bench_energies))*(SAMPLES/64)*((CELLS//LENGTH)/128)*4
    print(json.dumps(dict(benchmark_seconds=benchmark, estimated_four_probability_seconds=estimate)), flush=True)
    if args.benchmark:
        return
    library = matrices(ENERGIES)
    summary, run_diagnostics, raw, arrays = [], [], io.StringIO(newline=''), {}
    writer = csv.writer(raw)
    writer.writerow(['sample_id', 'p_sw', 'energy', 'transmission', 'log_transmission',
                     'attempted_swaps', 'effective_unequal_swaps'])
    equal = np.array([[word[j] == word[j+1] for j in range(LENGTH-1)] for word in WORDS[:2]])
    for probability in PROBABILITIES:
        attempt = coin < probability
        indices = np.where(attempt, 2+base.astype(np.int16)*(LENGTH-1)+boundary, base)
        counts = attempt.sum(axis=0)
        effective = (attempt & ~equal[base, boundary]).sum(axis=0)
        begin = time.perf_counter()
        transmission, log_t, diagnostics = propagate(library, indices, ENERGIES)
        duration = time.perf_counter()-begin
        arrays[probability] = (transmission, log_t)
        parity_error = float(np.max(abs(transmission-transmission[::-1])))
        assert parity_error < 2e-11
        center_index = int(np.argmin(abs(ENERGIES)))
        center_error = float(np.max(abs(transmission[center_index]-1)))
        assert center_error < 2e-9
        diagnostics.update(p_sw=probability, runtime_seconds=duration,
                           max_energy_reflection_error=parity_error, max_center_T_error=center_error,
                           selected_controller_indices_sha256=digest(indices.tobytes()),
                           attempted_swaps_by_sample=counts.tolist(),
                           effective_unequal_swaps_by_sample=effective.tolist())
        run_diagnostics.append(diagnostics)
        for j, energy in enumerate(ENERGIES):
            values = transmission[j]
            rho = np.expm1(-log_t[j])
            q10, q50, q90 = np.quantile(values, [.1, .5, .9], method='linear')
            summary.append(dict(p_sw=probability, energy=float(energy), samples=SAMPLES,
                                mean_T=float(np.mean(values)), median_T=float(q50),
                                sample_T_standard_error=float(np.std(values, ddof=1)/np.sqrt(SAMPLES)),
                                realization_q10=float(q10), realization_q90=float(q90),
                                sample_mean_rho=float(np.mean(rho)),
                                sample_rho_standard_error=float(np.std(rho, ddof=1)/np.sqrt(SAMPLES))))
            for i in range(SAMPLES):
                writer.writerow([i, format(probability, '.17g'), format(float(energy), '.17g'),
                                 format(values[i], '.17g'), format(log_t[j, i], '.17g'),
                                 int(counts[i]), int(effective[i])])
        print(f'p_sw={probability:g}: {duration:.3f}s; T(0) max error {center_error:.3g}', flush=True)
    payload = raw.getvalue().encode('utf-8')
    compressed = gzip.compress(payload, compresslevel=9, mtime=0)
    raw_path = ROOT/'data/local_swap_device_samples.csv.gz'
    raw_path.write_bytes(compressed)
    exact = []
    for energy in ['0', '.001', '.002', '.004', '.006']:
        for probability in ['0', '.001', '.01', '.1']:
            row = exact_mean_rho(energy, probability)
            sampled = next(x for x in summary if x['p_sw'] == float(probability)
                           and abs(x['energy']-float(energy)) < 1e-12)
            row.update(sample_mean_T=sampled['mean_T'], sample_mean_rho=sampled['sample_mean_rho'],
                       sample_rho_standard_error=sampled['sample_rho_standard_error'])
            exact.append(row)
    checks = validation_checks()
    # Independent high-precision complete-product spot checks on actual draws.
    mp_checks = []
    for probability, sample_id in [(0.0, 0), (.01, 0), (.1, 17)]:
        mats, lead = mp_library(mp.mpf('.002'))
        state = mp.eye(2)
        for j in range(CELLS//LENGTH):
            index = int(2+int(base[j, sample_id])*(LENGTH-1)+int(boundary[j, sample_id])) if coin[j, sample_id] < probability else int(base[j, sample_id])
            state = mats[index]*state
        flux = lead*state*(lead**-1)
        high_precision = 4/(mp.fsum(x*x for x in flux)+2)
        ei = int(np.argmin(abs(ENERGIES-.002)))
        sampled = arrays[probability][0][ei, sample_id]
        error = abs(float(high_precision)-sampled)
        assert error < 2e-9
        mp_checks.append(dict(p_sw=probability, sample_id=sample_id, energy=.002,
                             float64_T=float(sampled), mp_T=mp.nstr(high_precision, 55), absolute_error=error))
    report = dict(
        parameters=dict(h=H, g=G, t_off=TOFF, K=K, core_a=TOFF+2*G*G/H,
            levels='exp(-1),1,exp(1)', depth=DEPTH, block_length=LENGTH, cells=CELLS,
            blocks=CELLS//LENGTH, independent_samples=SAMPLES, probabilities=PROBABILITIES,
            energy_grid=ENERGIES.tolist(), lead_hopping=K, contact_hopping=K),
        ensemble='Each block chooses ideal A_2/B_2 fairly. With probability p_sw attempt one uniformly selected internal adjacent swap; equal-neighbor selections are no-ops.',
        paired_design=dict(seed=SEED, generator='NumPy PCG64', array_shape=list(base.shape),
            independent_unit='Each of 256 columns is one independently drawn controller sequence.',
            pairing='The complete base-word bits, boundary choices, and uniform fault coins are reused across all probabilities and all energies.',
            base_bits_sha256=digest(base.tobytes()), boundary_draws_sha256=digest(boundary.tobytes()),
            uniform_fault_coins_sha256=digest(coin.tobytes())),
        summaries=summary, exact_ensemble_second_moments=exact, validation=checks,
        high_precision_sample_checks=mp_checks, diagnostics=run_diagnostics,
        raw_samples=dict(path=str(raw_path.relative_to(ROOT)), rows=len(summary)*SAMPLES,
            format='gzip compressed UTF-8 CSV, CRLF line endings', compression='gzip level 9, mtime=0',
            compressed_sha256=digest(compressed), uncompressed_sha256=digest(payload),
            compressed_bytes=len(compressed), uncompressed_bytes=len(payload)),
        uncertainty='10th and 90th realization quantiles use numpy.quantile(method=linear); these are not confidence intervals for the mean.',
        Jensen_boundary='High-precision 1/(1+exact mean rho) is only a Jensen lower bound for ensemble mean T. It does not replace the sampled mean-T curve.',
        arithmetic='Float64 normalized 2x2 products for sampled transmission; 65-digit mpmath 4x4 moment powers, not outward-rounded intervals.',
        benchmark=dict(runtime_seconds=benchmark, estimated_production_seconds=estimate),
        provenance=dict(script=str(Path(__file__).relative_to(ROOT)), script_sha256=digest(Path(__file__).read_bytes()),
            imported_project_producers=[], python=platform.python_version(), numpy=np.__version__,
            scipy=scipy.__version__, mpmath=mp.__version__, runtime_seconds=time.perf_counter()-started))
    destination = ROOT/'verification/local_swap_devices.json'
    destination.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(output=str(destination), rows=report['raw_samples']['rows'],
                         gzip_bytes=len(compressed), runtime_seconds=report['provenance']['runtime_seconds'])), flush=True)


if __name__ == '__main__':
    main()
