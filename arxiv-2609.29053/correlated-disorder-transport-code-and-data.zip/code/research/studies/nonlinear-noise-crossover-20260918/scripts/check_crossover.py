#!/usr/bin/env python3
"""Independent finite-size checks of the exact six-orbital inverse.

No thermodynamic conclusion is inferred from these samples.  Dense and sparse
residuals have the same variance but distinct weak-noise path limits.  Only this
study's data and verification files are written; earlier evidence is untouched.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import os
import platform
import time
from pathlib import Path

import numpy as np
import scipy
from scipy.linalg import solve_banded
from scipy.sparse.linalg import LinearOperator, eigsh

ROOT = Path(__file__).resolve().parents[1]
PARAMS = dict(K=1.0, h=2.0, g=1.2, t0=0.25, d=0.4, fault_amplitude=0.8)


def homogenized_factor(p=PARAMS):
    return ((1 + 2*p['g']**2/p['h']**2 - p['t0']/p['h'])
            * np.cosh(p['d']) + p['K']/p['h'] * np.cosh(p['d']/2)**2)


class ExactInverse:
    """T^-1 in cell-major order; its application requires two bidiagonal solves."""

    def __init__(self, mu, source_signs, p=PARAMS):
        self.mu = np.asarray(mu, dtype=float)
        self.n = len(mu)
        self.p = p
        K, h, g = p['K'], p['h'], p['g']
        self.t = K*np.exp(self.mu)
        amplitude2 = h/2*(self.t-p['t0'])
        if np.min(amplitude2) <= 0:
            raise ValueError('The requested physical source is not real and nonzero.')
        self.u = np.asarray(source_signs)*np.sqrt(amplitude2)
        self.U = np.column_stack((np.ones(self.n), -(g-self.u)/h, -(g+self.u)/h))
        self.V = np.column_stack((np.ones(self.n), -(g+self.u)/h, -(g-self.u)/h))
        self.j = np.array([0.0, 1/h, 1/h])
        self.band = np.zeros((2, self.n))
        self.band[0] = self.t
        self.band[1, :-1] = -K
        self.band_t = np.zeros((2, self.n))
        self.band_t[1] = self.t
        self.band_t[0, 1:] = -K
        self.operator = LinearOperator((3*self.n, 3*self.n), matvec=self.apply,
                                       rmatvec=self.apply_t, dtype=float)
        self.square = LinearOperator((3*self.n, 3*self.n),
                                    matvec=lambda x: self.apply_t(self.apply(x)), dtype=float)

    def apply(self, x):
        x = np.asarray(x).reshape(self.n, 3)
        y = solve_banded((1, 0), self.band, np.sum(self.V*x, axis=1), check_finite=False)
        return (self.U*y[:, None] + self.j*x).ravel()

    def apply_t(self, x):
        x = np.asarray(x).reshape(self.n, 3)
        y = solve_banded((0, 1), self.band_t, np.sum(self.U*x, axis=1), check_finite=False)
        return (self.V*y[:, None] + self.j*x).ravel()

    def frobenius2(self):
        # Sum ||U_i||^2 ||V_j||^2 (M^-1_ij)^2 by the exact scalar recursion.
        alpha = np.sum(self.U**2, axis=1)
        K, h, g = self.p['K'], self.p['h'], self.p['g']
        acc = rank_part = 0.0
        for ai, ti in zip(alpha, self.t):
            acc = (ai+K*K*acc)/(ti*ti)
            rank_part += ai*acc
        cross = np.sum(4*(g*g-self.u*self.u)/(h**3*self.t))
        return float(rank_part + cross + 2*self.n/h**2)

    def dense_matrix(self):
        """Original T, without using its inverse factorization."""
        n, p = self.n, self.p
        T = np.zeros((3*n, 3*n))
        for i, ui in enumerate(self.u):
            sl = slice(3*i, 3*i+3)
            T[sl, sl] = np.array([[p['t0']+2*p['g']**2/p['h'], p['g']+ui, p['g']-ui],
                                  [p['g']-ui, p['h'], 0], [p['g']+ui, 0, p['h']]])
            if i:
                T[3*i, 3*(i-1)] = -p['K']
        return T


def smallest_energies(inv, seed, count=3):
    rng = np.random.default_rng(seed)
    values, vecs = eigsh(inv.square, k=count, which='LA', tol=2e-10,
                        v0=rng.normal(size=3*inv.n), ncv=24, maxiter=2000)
    order = np.argsort(values)[::-1]
    values, vecs = values[order], vecs[:, order]
    residual = max(np.linalg.norm(inv.square@vecs[:, j]-values[j]*vecs[:, j])/values[j]
                   for j in range(count))
    return 1/np.sqrt(values), float(residual)


def scalar_inverse_data(r):
    """Exact Frobenius sum of the scalar inverse, normalized by N^2.

    This discretizes the path-dependent Volterra functional using the SAME
    residual path; the difference between it and the full model tests the
    microscopic homogenization independently of ensemble averaging.
    """
    acc = total = 0.0
    for ri in r:
        acc = np.exp(-2*ri)*(1+acc)
        total += acc
    return float(total/len(r)**2)


def annealed_limit(z):
    if abs(z) < 1e-6:
        return float(0.5 + z/6 + z*z/24 + z**3/120)
    return float((np.expm1(z)-z)/(z*z))


def expected_frobenius2(n, r_values, r_probabilities, p=PARAMS):
    """Exact finite-N expectation, using only a two-state conditional recursion.

    Given w_(i-1), the earlier inverse sum is independent of (w_i, r_i).
    alpha_i = alpha_0 + (K/h) exp(mu_i).  Its multiplication by exp(-2mu_i)
    requires only the residual Laplace transform at -1 and -2, which are
    evaluated from the specified discrete law, not from Monte Carlo samples.
    """
    K, h, g = p['K'], p['h'], p['g']
    rv, rp = np.asarray(r_values), np.asarray(r_probabilities)
    m1, m2 = float(rp@np.exp(-rv)), float(rp@np.exp(-2*rv))
    w = np.array([-p['d']/2, p['d']/2])
    delta = w[None, :]-w[:, None]  # row: previous w, column: new w
    aa = 1+2*g*g/h**2-p['t0']/h
    bb = K/h
    e2 = np.exp(-2*delta)*m2
    ae2 = aa*e2+bb*np.exp(-delta)*m1
    a2e2 = aa*aa*e2+2*aa*bb*np.exp(-delta)*m1+bb*bb
    conditional_s = np.zeros(2)
    rank_part = 0.0
    for _ in range(n):
        rank_part += np.mean(a2e2/K**2 + ae2*conditional_s[:, None])
        conditional_s = np.mean(ae2/K**2 + e2*conditional_s[:, None], axis=0)
    # The constant in 2<R,J> cancels ||J||^2, leaving this positive term.
    cross_and_j = 4*(g*g+h*p['t0']/2)/(h**3*K)*n*np.cosh(p['d']/2)**2*m1
    return float(rank_part+cross_and_j)


def validate_annealed_recursion():
    records = []
    for n in [1, 2, 3]:
        for label, rv, rp in [('dense', [-.2, .2], [.5, .5]),
                               ('sparse', [-.8, 0, .8], [.1, .8, .1])]:
            brute = 0.0
            for wbits in itertools.product([-1, 1], repeat=n+1):
                w = np.asarray(wbits)*PARAMS['d']/2
                for ridx in itertools.product(range(len(rv)), repeat=n):
                    r = np.asarray(rv)[list(ridx)]
                    weight = np.prod(np.asarray(rp)[list(ridx)])/2**(n+1)
                    brute += weight*ExactInverse(np.diff(w)+r, np.ones(n)).frobenius2()
            computed = expected_frobenius2(n, rv, rp)
            relative = abs(computed/brute-1)
            if relative > 1e-12:
                raise AssertionError((n, label, brute, computed))
            records.append(dict(n=n, kind=label, explicit_enumeration=brute,
                                conditional_recursion=computed, relative_error=relative))
    return records


def validate(seed=527611):
    rng = np.random.default_rng(seed)
    records = []
    for n in [2, 3, 5, 9, 15]:
        for repeat in range(4):
            w = (2*rng.integers(0, 2, n+1)-1)*PARAMS['d']/2
            r = rng.uniform(-0.25, 0.25, n)
            inv = ExactInverse(np.diff(w)+r, 2*rng.integers(0, 2, n)-1)
            T = inv.dense_matrix()
            direct = np.linalg.inv(T)
            matrix = np.column_stack([inv.apply(x) for x in np.eye(3*n)])
            energies, eig_res = smallest_energies(inv, seed+n+repeat)
            direct_energies = np.linalg.svd(T, compute_uv=False)[-3:][::-1]
            x, y = rng.normal(size=(2, 3*n))
            item = dict(n=n, repeat=repeat,
                        inverse_relative=np.linalg.norm(matrix-direct)/np.linalg.norm(direct),
                        inverse_identity_max=float(np.max(np.abs(T@matrix-np.eye(3*n)))),
                        transpose_relative=abs(x@inv.apply(y)-inv.apply_t(x)@y)/(1+abs(x@inv.apply(y))),
                        frobenius_relative=abs(inv.frobenius2()-np.sum(direct**2))/np.sum(direct**2),
                        energies_relative=float(np.max(abs(energies/direct_energies-1))),
                        eigen_residual=eig_res)
            if max(item[k] for k in item if k not in ['n', 'repeat']) > 2e-9:
                raise AssertionError(item)
            # Fixed-particle-number Slater ground-state fidelity, using both
            # signs of a staggered mass, independently of the inverse formula.
            full = np.block([[np.zeros_like(T), T], [T.T, np.zeros_like(T)]])
            gamma = np.diag(np.r_[np.ones(3*n), -np.ones(3*n)])
            e, v = np.linalg.eigh(full)
            vg = v[:, :3*n]
            dm = 1e-5*direct_energies[0]
            _, vm = np.linalg.eigh(full+dm*gamma)
            overlap = np.linalg.svd(vg.T@vm[:, :3*n], compute_uv=False)
            chi_fd = -2*np.sum(np.log(overlap))/dm**2
            chi_exact = inv.frobenius2()/4
            # Very small finite differences lose digits; the spectral identity
            # below is the precision check, this is only a coarse sanity check.
            gamma_e = v[:, 3*n:].T@gamma@vg
            denominators = e[3*n:, None]-e[None, :3*n]
            chi_lehmann = np.sum(abs(gamma_e)**2/denominators**2)
            item['fidelity_lehmann_relative'] = float(abs(chi_lehmann/chi_exact-1))
            item['fidelity_finite_difference_relative'] = float(abs(chi_fd/chi_exact-1))
            if item['fidelity_lehmann_relative'] > 2e-10:
                raise AssertionError(item)
            records.append(item)
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples', type=int, default=160)
    parser.add_argument('--sizes', default='128,512,2048')
    parser.add_argument('--rhos', default='0.25,1,4')
    parser.add_argument('--seed', type=int, default=260918031)
    parser.add_argument('--benchmark', action='store_true', help='print timing only; do not write outputs')
    parser.add_argument('--refresh-expectations', action='store_true',
                        help='preserve raw samples; add deterministic expectation checks to their report')
    args = parser.parse_args()
    if args.refresh_expectations:
        check = ROOT/'verification'/'crossover.json'
        data = ROOT/'data'/'crossover_samples.csv'
        report = json.loads(check.read_text())
        if hashlib.sha256(data.read_bytes()).hexdigest() != report['data_sha256']:
            raise AssertionError('Raw data checksum changed before expectation refresh.')
        report['sampling_producer_sha256'] = report.get('sampling_producer_sha256', report['producer_sha256'])
        report['producer_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        report['annealed_recursion_validation'] = validate_annealed_recursion()
        aa = PARAMS['fault_amplitude']
        A = homogenized_factor()
        for group in report['groups']:
            n, rho, kind = group['n'], group['rho'], group['kind']
            if kind == 'protected':
                rv, rp = [0], [1]
            elif kind == 'dense':
                rr = aa*np.sqrt(rho/n)
                rv, rp = [-rr, rr], [.5, .5]
            else:
                rv, rp = [-aa, 0, aa], [rho/(2*n), 1-rho/n, rho/(2*n)]
            group['metric_annealed_finite_n_exact'] = PARAMS['K']**2*expected_frobenius2(n, rv, rp)/(A*A*n*n)
        line = 'Exact finite-N annealed metrics use a two-state recursion checked against exhaustive short-chain enumeration.'
        if line not in report['interpretation']:
            report['interpretation'].append(line)
        check.write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps({'refreshed_expectations':len(report['groups']), 'raw_data_preserved':True}))
        return
    sizes = [int(x) for x in args.sizes.split(',')]
    rhos = [float(x) for x in args.rhos.split(',')]
    start = time.monotonic()
    validation = validate()
    annealed_validation = validate_annealed_recursion()
    A = float(homogenized_factor())
    rows, groups = [], []
    master = np.random.default_rng(args.seed)
    max_residual = 0.0
    for n in sizes:
        cases = [('protected', 0.0)] + [(kind, rho) for rho in rhos for kind in ['dense', 'sparse']]
        for kind, rho in cases:
            group_start = time.monotonic()
            group_rows = []
            for sample in range(args.samples):
                sample_seed = int(master.integers(0, 2**63-1))
                rng = np.random.default_rng(sample_seed)
                w = (2*rng.integers(0, 2, n+1)-1)*PARAMS['d']/2
                signs = 2*rng.integers(0, 2, n)-1
                if kind == 'protected':
                    r = np.zeros(n)
                elif kind == 'dense':
                    r = PARAMS['fault_amplitude']*np.sqrt(rho/n)*(2*rng.integers(0, 2, n)-1)
                else:
                    r = PARAMS['fault_amplitude']*(rng.random(n)<rho/n)*(2*rng.integers(0, 2, n)-1)
                inv = ExactInverse(np.diff(w)+r, signs)
                energies, residual = smallest_energies(inv, sample_seed)
                max_residual = max(max_residual, residual)
                if residual > 1e-7:
                    raise AssertionError(f'Eigenvector residual too large: {residual}')
                scale = A*n/PARAMS['K']
                row = dict(kind=kind, rho=rho, n=n, sample=sample, seed=sample_seed,
                           fault_count=int(np.count_nonzero(r)), residual_sum=float(np.sum(r)),
                           metric=PARAMS['K']**2*inv.frobenius2()/(A*A*n*n),
                           scalar_metric=scalar_inverse_data(r),
                           gap1_scaled=float(scale*energies[0]),
                           gap2_scaled=float(scale*energies[1]),
                           gap3_scaled=float(scale*energies[2]),
                           eigen_residual=residual,
                           source_abs_min=float(np.min(abs(inv.u))),
                           source_abs_max=float(np.max(abs(inv.u))))
                rows.append(row)
                group_rows.append(row)
            metric = np.array([x['metric'] for x in group_rows])
            scalar = np.array([x['scalar_metric'] for x in group_rows])
            gaps = np.array([x['gap1_scaled'] for x in group_rows])
            z = (2*rho*PARAMS['fault_amplitude']**2 if kind == 'dense' else
                 rho*(np.cosh(2*PARAMS['fault_amplitude'])-1) if kind == 'sparse' else 0)
            if kind == 'protected':
                rv, rp = [0], [1]
            elif kind == 'dense':
                rr = PARAMS['fault_amplitude']*np.sqrt(rho/n)
                rv, rp = [-rr, rr], [.5, .5]
            else:
                rv = [-PARAMS['fault_amplitude'], 0, PARAMS['fault_amplitude']]
                rp = [rho/(2*n), 1-rho/n, rho/(2*n)]
            exact_mean = PARAMS['K']**2*expected_frobenius2(n, rv, rp)/(A*A*n*n)
            group = dict(kind=kind, rho=rho, n=n, samples=args.samples,
                         metric_mean=float(np.mean(metric)), metric_median=float(np.median(metric)),
                         metric_std=float(np.std(metric, ddof=1)),
                         metric_mean_standard_error=float(np.std(metric, ddof=1)/np.sqrt(args.samples)),
                         metric_annealed_limit=annealed_limit(z),
                         metric_annealed_finite_n_exact=exact_mean,
                         scalar_metric_mean=float(np.mean(scalar)),
                         median_relative_metric_error=float(np.median(abs(metric/scalar-1))),
                         gap1_quantiles=np.quantile(gaps, [.1,.25,.5,.75,.9]).tolist(),
                         no_fault_samples=int(sum(x['fault_count']==0 for x in group_rows)),
                         no_fault_probability_exact=(1-rho/n)**n if kind == 'sparse' else None,
                         no_fault_probability_limit=float(np.exp(-rho)) if kind == 'sparse' else None,
                         runtime_seconds=time.monotonic()-group_start)
            groups.append(group)
            print(json.dumps(group), flush=True)
    report = dict(parameters={**PARAMS, 'a': PARAMS['t0']+2*PARAMS['g']**2/PARAMS['h'], 'A': A},
                  seed=args.seed, sizes=sizes, rhos=rhos, samples_per_case=args.samples,
                  validation=validation, groups=groups, max_eigen_residual=max_residual,
                  annealed_recursion_validation=annealed_validation,
                  runtime_seconds=time.monotonic()-start,
                  environment=dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                                   platform=platform.platform()),
                  interpretation=['Each row is an independent finite-chain sample, not a proof of convergence.',
                                  'The metric is K^2 ||T^-1||_F^2/(A^2 N^2), equal to scaled staggered-mass fidelity susceptibility.',
                                  'All three gaps are exact finite-model numerical singular values obtained by an inverse eigensolver.',
                                  'No-fault samples include fluctuating microscopic protected w, so their finite-N gap is not an exact atom.',
                                  'The limiting susceptibility means have heavy-tail sensitivity; sample means and standard errors are descriptive only.',
                                  'Exact finite-N annealed metrics use a two-state recursion checked against exhaustive short-chain enumeration.',
                                  'The scalar metric uses the same residual path, isolating finite-N microscopic homogenization error.'])
    report['producer_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if not args.benchmark:
        data = ROOT/'data'/'crossover_samples.csv'
        check = ROOT/'verification'/'crossover.json'
        data.parent.mkdir(parents=True, exist_ok=True)
        check.parent.mkdir(parents=True, exist_ok=True)
        with data.open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        report['data_sha256'] = hashlib.sha256(data.read_bytes()).hexdigest()
        check.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'total_seconds':report['runtime_seconds'], 'rows':len(rows),
                      'max_eigen_residual':max_residual, 'benchmark':args.benchmark}), flush=True)


if __name__ == '__main__':
    main()
