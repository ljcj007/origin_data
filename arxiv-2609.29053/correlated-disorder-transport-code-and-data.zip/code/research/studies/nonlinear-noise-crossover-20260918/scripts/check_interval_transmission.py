#!/usr/bin/env python3
"""Outward-rounded evaluation of pointwise finite-energy probability bounds.

Independent 2x2 implementation; all physical parameters and probe energies are
passed as exact decimal rationals, exp(+/-1) and roots use mpmath intervals.
This validates specified energies, not every energy in a continuous interval.
"""
from pathlib import Path
import json, hashlib
import mpmath
from mpmath import iv
iv.dps=60
ROOT=Path(__file__).resolve().parents[1]
I=lambda x:iv.mpf(str(x))
Z=I(0);O=I(1)
def ident():return [[O,Z],[Z,O]]
def add(a,b):return [[a[i][j]+b[i][j] for j in range(2)] for i in range(2)]
def sub(a,b):return [[a[i][j]-b[i][j] for j in range(2)] for i in range(2)]
def scale(a,s):return [[v*s for v in row] for row in a]
def mul(a,b):return [[sum((a[i][k]*b[k][j] for k in range(2)),Z) for j in range(2)] for i in range(2)]
def tr(a):return a[0][0]+a[1][1]
def det(a):return a[0][0]*a[1][1]-a[0][1]*a[1][0]
def trans(a):return [[a[j][i] for j in range(2)] for i in range(2)]
def inv(a):return scale([[a[1][1],-a[0][1]],[-a[1][0],a[0][0]]],1/det(a))
def sqrt_spd_detone(a):return scale(add(a,ident()),1/iv.sqrt(tr(a)+2))
def maxeig_sym(a):return (tr(a)+iv.sqrt((a[0][0]-a[1][1])**2+4*a[0][1]**2))/2
def positive(x):return bool(x.a>0)
def endpoints(x):return [mpmath.nstr(x.a,68),mpmath.nstr(x.b,68)]
def asfloat(x):return [float(x.a),float(x.b)]
def evaluate(row):
    delta=I(row['offset']);e=I(format(row['conservative_probe_energy'],'.16g'));h=I(2);g=I('1.2');a=I('1.69')+delta
    ts=[iv.exp(-O),O,iv.exp(O)]
    k=((ts[0]+delta)*(ts[1]+delta)**2*(ts[2]+delta))**I('.25')
    cells=[]
    for t in ts:
        u2=h*(t-I('.25'))/2
        zz=e*(1+2*(g*g+u2)/(h*h-e*e))
        tt=a-2*h*(g*g-u2)/(h*h-e*e)
        assert positive(tt)
        cells.append([[(tt*tt-zz*zz)/(k*tt),-zz/tt],[zz/tt,k/tt]])
    def word(seq):
        p=ident()
        for s in seq:p=mul(cells[s],p)
        return p
    a0=word([0,1,1,2]);b0=word([2,1,1,0])
    for _ in range(row['level']):a0,b0=mul(a0,b0),mul(b0,a0)
    mean=scale(add(a0,b0),I('.5'));diff=scale(sub(a0,b0),I('.5'))
    raw=[[mean[1][0],(mean[1][1]-mean[0][0])/2],[(mean[1][1]-mean[0][0])/2,-mean[0][1]]]
    assert positive(raw[0][0]) and positive(det(raw))
    metric=scale(raw,1/iv.sqrt(det(raw)));qmat=sqrt_spd_detone(metric)
    dp=mul(mul(qmat,diff),inv(qmat))
    q=maxeig_sym(mul(trans(dp),dp))-det(diff)
    x=e/k;gl=scale([[O,x/2],[x/2,O]],1/iv.sqrt(1-x*x/4));lead=sqrt_spd_detone(gl)
    change=mul(lead,inv(qmat));stretch=mul(trans(change),change)
    # The exact determinant of change is one, so its condition number squared
    # equals the square of the largest eigenvalue of change^T change.
    k2=maxeig_sym(stretch)**2
    blocks=int(row['blocks']);factor=k2*iv.exp(blocks*iv.log(1+q))
    failure=I('4.5')*(factor-1);meanT=2/(1+factor)
    assert bool(failure.b<I('.1').a), (row['offset'],row['level'],row['cells'],failure)
    assert bool(meanT.a>I('.98').b)
    return {'offset':row['offset'],'level':row['level'],'cells':row['cells'],
            'probe_energy_decimal':format(row['conservative_probe_energy'],'.16g'),
            'energy_over_K':asfloat(e/k),'failure_probability_upper_bound_interval':asfloat(failure),
            'failure_interval_decimal':endpoints(failure),'mean_transmission_lower_bound_interval':asfloat(meanT),
            'q_interval':asfloat(q),'basis_condition_squared_interval':asfloat(k2)}
def main():
    src=ROOT/'verification/finite_energy.json';r=json.loads(src.read_text());records=[]
    for group in ['offset_scan','length_scan']:
        for row in r['finite_device_certificates'][group]:records.append({'group':group,**evaluate(row)})
    out={'arithmetic':'mpmath.iv outward-rounded interval arithmetic','mpmath':mpmath.__version__,
         'decimal_precision':iv.dps,'count':len(records),'all_probability_upper_bounds_below_0_1':True,
         'max_probability_upper_bound':max(v['failure_probability_upper_bound_interval'][1] for v in records),
         'interpretation':'Pointwise-in-energy guarantee, with independent fair superblocks and matched K leads/contacts. Not simultaneous interval transparency.',
         'records':records,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest()}
    (ROOT/'verification/finite_energy_intervals.json').write_text(json.dumps(out,indent=2)+'\n')
    print(f"Interval arithmetic confirmed {len(records)} pointwise bounds; maximum failure bound {out['max_probability_upper_bound']:.9f} < 0.1.")
if __name__=='__main__':main()
