#!/usr/bin/env python3
"""Equal-resource comparison of finite-device ordering schemes.

Recursive AB/BA words are compared with repeated A0 or B0 words at equal
composition and block length. The calculations use the cell transfer, a
full-Hamiltonian Green function, and a uniform mean-mistuning scan.
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import platform
import time
from pathlib import Path

import numpy as np
import scipy
from scipy.linalg import solve

import check_finite_energy as production

ROOT=Path(__file__).resolve().parents[1]
SEED=260918904
SAMPLES=256
H,G,TOFF=2.,1.2,.25


def words(depth,family):
    if family=='recursive':
        return production.hierarchy_words(depth)
    a=(-1,0,0,1);b=a[::-1]
    return a*2**depth,b*2**depth


def transfer(word,energy,offset,log_mean_error=0.):
    answer=np.eye(2)
    change=np.exp(log_mean_error)
    for q in word:
        cell=production.cell_transfer(q,energy,offset).copy()
        cell[0,0]/=change
        cell[1,1]*=change
        answer=cell@answer
    return answer


def independent_green(word,energy,offset,log_mean_error):
    """Direct 6N orbital-major matrix, independently assembled here."""
    n=len(word)
    u=np.sqrt(np.exp(np.asarray(word))-TOFF)
    K=production.retuned_K(offset)*np.exp(log_mean_error)
    a=TOFF+2*G*G/H+offset
    core=a*np.eye(n)-K*np.eye(n,k=-1)
    plus=np.diag(G+u);minus=np.diag(G-u)
    zeros=np.zeros((n,n));identity=np.eye(n)
    chiral=np.block([[core,plus,minus],[minus,H*identity,zeros],[plus,zeros,H*identity]])
    hamiltonian=np.block([[np.zeros_like(chiral),chiral],[chiral.T,np.zeros_like(chiral)]])
    left,right=0,4*n-1
    self_energy=(energy-1j*np.sqrt(4*K*K-energy*energy))/2
    inverse=energy*np.eye(6*n,dtype=complex)-hamiltonian
    inverse[left,left]-=self_energy;inverse[right,right]-=self_energy
    source=np.zeros(6*n,dtype=complex);source[right]=1
    value=solve(inverse,source,check_finite=False)[left]
    return float((-2*self_energy.imag)**2*abs(value)**2)


def ensemble(offset,depth,cells,energy,total_mean_mass,choices):
    """Two families share each random bitstring, giving paired comparisons."""
    log_error=total_mean_mass/cells
    K=production.retuned_K(offset)*np.exp(log_error)
    families=['recursive','repeat']
    matrices=np.array([[transfer(w,energy,offset,log_error) for w in words(depth,f)] for f in families])
    state=np.repeat(np.eye(2)[None,None,:,:],2,axis=0)
    state=np.repeat(state,SAMPLES,axis=1)
    scales=np.zeros((2,SAMPLES))
    for i,bits in enumerate(choices):
        selected=matrices[np.arange(2)[:,None],bits[None,:]]
        state=selected@state
        if i%16==15:
            norm=np.max(abs(state),axis=(2,3))
            state/=norm[:,:,None,None];scales+=np.log(norm)
    logs,_=production.scattering_from_transfer(state,energy,scales,lead_hopping=K)
    if np.max(logs)>3e-8:
        raise AssertionError('Transmission exceeds unity beyond tolerance.')
    return np.minimum(logs,0)


def summarize(logs):
    t=np.exp(logs)
    return dict(mean_transmission=float(np.mean(t)),median_transmission=float(np.median(t)),
                transmission_quantiles_10_50_90=np.quantile(t,[.1,.5,.9]).tolist(),
                median_log_transmission=float(np.median(logs)),
                mean_log_transmission=float(np.mean(logs)),
                sample_fraction_transmission_below_0_9=float(np.mean(t<.9)),
                raw_samples=SAMPLES)


def main():
    started=time.monotonic()
    direct=[]
    for offset in [0.,.2,1.]:
        for depth in [1,2]:
            for family in ['recursive','repeat']:
                for energy in [0.,.002,.03]:
                    word=words(depth,family)[0]
                    log_error=.013
                    K=production.retuned_K(offset)*np.exp(log_error)
                    matrix=transfer(word,energy,offset,log_error)
                    logt,_=production.scattering_from_transfer(matrix,energy,lead_hopping=K)
                    value=independent_green(word,energy,offset,log_error)
                    error=abs(np.exp(logt)-value)
                    if error>3e-11:
                        raise AssertionError('Independent full Hamiltonian check failed.')
                    direct.append(dict(offset=offset,depth=depth,family=family,energy=energy,
                                       cells=len(word),log_mean_error=log_error,
                                       transmission_transfer=float(np.exp(logt)),transmission_full_green=value,
                                       absolute_error=float(error)))

    resources=[]
    for depth in [1,2]:
        for family in ['recursive','repeat']:
            a,b=words(depth,family)
            counts=[a.count(q) for q in [-1,0,1]]
            if counts!=[len(a)//4,len(a)//2,len(a)//4] or sorted(a)!=sorted(b):
                raise AssertionError('Equal-resource composition mismatch.')
            resources.append(dict(depth=depth,family=family,word_a=list(a),word_b=list(b),
                                  cells_per_block=len(a),level_probabilities=[.25,.5,.25],
                                  entropy_nats_per_cell=float(np.log(2)/len(a))))

    jets=[]
    for offset in [0.,.2,1.]:
        seed_a,seed_b=production.hierarchy_words(0)
        seed_difference=production.word_series(seed_a,offset)[1]-production.word_series(seed_b,offset)[1]
        c0=float(np.linalg.norm(seed_difference,2))
        for depth in [1,2]:
            for family in ['recursive','repeat']:
                a,b=words(depth,family)
                difference=production.word_series(a,offset)-production.word_series(b,offset)
                leading=next(j for j,m in enumerate(difference) if np.linalg.norm(m)>1e-8)
                expected=depth+1 if family=='recursive' else 1
                if leading!=expected:
                    raise AssertionError('Equal-resource control has an unexpected jet order.')
                coefficient=float(np.linalg.norm(difference[leading],2)**2/(8*len(a)))
                repeat_prediction=2**depth*c0*c0/32
                if family=='repeat' and abs(coefficient/repeat_prediction-1)>1e-11:
                    raise AssertionError('Repetition Lyapunov coefficient does not match seed formula.')
                jets.append(dict(offset=offset,depth=depth,family=family,
                                 first_pair_difference_power=leading,lyapunov_power_from_binary_lemma=2*leading,
                                 per_cell_leading_coefficient=coefficient,
                                 repetition_prediction=repeat_prediction if family=='repeat' else None))

    csvpath=ROOT/'data'/'equal_resource_ordering_samples.csv'
    csvpath.parent.mkdir(parents=True,exist_ok=True)
    summaries=[];paired=[];joint_grid=[];zero_checks=[];sequence_metadata=[]
    energies=[0.,.0005,.001,.002,.003,.004,.008]
    near_zero_energies=[0.,.000005,.00001,.00002,.00005,.0001,.0005,.001,.002,.003,.004]
    main_offsets=[0.,.2,1.]
    with csvpath.open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['campaign','offset','depth','family','cells','energy','total_mean_mass',
                         'log_mean_error','sample','log_transmission','transmission','sequence_seed'])
        for oi,offset in enumerate(main_offsets):
            for cells in [4096,16384]:
                for depth in [1,2]:
                    block_length=4*2**depth
                    seed_parts=[SEED,oi,cells,depth]
                    seed=np.random.SeedSequence(seed_parts)
                    choices=np.random.default_rng(seed).integers(0,2,(cells//block_length,SAMPLES),dtype=np.uint8)
                    seed_text=':'.join(map(str,seed_parts))
                    sequence_metadata.append(dict(offset=offset,cells=cells,depth=depth,
                                                  seed_entropy=seed_parts,shape=list(choices.shape),
                                                  choices_sha256=hashlib.sha256(choices.tobytes()).hexdigest(),
                                                  reuse='Identical bits within each paired family, energy and mean-error comparison. Columns are independent sequences.'))
                    mass_grid=[-.5,-.3,-.15,0.,.15,.3,.5] if cells==16384 and offset in [0.,1.] else [0.]
                    rectangular=[]
                    for mass in mass_grid:
                        if len(mass_grid)>1:
                            energy_grid=sorted(set(energies+near_zero_energies)) if mass==0 else near_zero_energies
                        else:
                            energy_grid=energies
                        for energy in energy_grid:
                            logs=ensemble(offset,depth,cells,energy,mass,choices)
                            campaign='matched_mean' if mass==0 else 'finite_uniform_mean_error'
                            if energy==0:
                                exact=-2*np.log(np.cosh(mass))
                                maxerror=float(np.max(abs(logs-exact)))
                                if maxerror>5e-8:
                                    raise AssertionError('Zero-energy total-mass identity failed.')
                                zero_checks.append(dict(offset=offset,depth=depth,cells=cells,total_mean_mass=mass,
                                                        exact_transmission=float(np.exp(exact)),max_log_error=maxerror))
                            for fi,family in enumerate(['recursive','repeat']):
                                row=dict(campaign=campaign,offset=offset,depth=depth,family=family,cells=cells,
                                         energy=energy,total_mean_mass=mass,log_mean_error=mass/cells,
                                         cells_per_block=block_length,sequence_seed=seed_parts,
                                         lead_and_contact_hopping=production.retuned_K(offset)*np.exp(mass/cells),
                                         **summarize(logs[fi]))
                                summaries.append(row)
                                for sample,logt in enumerate(logs[fi]):
                                    writer.writerow([campaign,offset,depth,family,cells,energy,mass,mass/cells,
                                                     sample,repr(float(logt)),repr(float(np.exp(logt))),seed_text])
                            paired.append(dict(campaign=campaign,offset=offset,depth=depth,cells=cells,energy=energy,
                                               total_mean_mass=mass,median_log_transmission_gain=float(np.median(logs[0]-logs[1])),
                                               fraction_recursive_transmission_greater=float(np.mean(logs[0]>logs[1]+1e-10)),
                                               fraction_recursive_above_0_9_repeat_below_0_9=float(np.mean((logs[0]>=np.log(.9))&(logs[1]<np.log(.9))))))
                            if abs(mass)<=.3 and energy<=.002:
                                rectangular.append(logs)
                    if len(mass_grid)>1:
                        table=np.stack(rectangular)
                        minimum=np.exp(np.min(table,axis=0))
                        joint_grid.append(dict(offset=offset,depth=depth,cells=cells,
                                               total_mean_mass_grid=[-.3,-.15,0,.15,.3],
                                               energy_grid=[e for e in near_zero_energies if e<=.002],
                                               points=len(rectangular),samples=SAMPLES,
                                               family_results={family:dict(median_minimum_transmission=float(np.median(minimum[fi])),
                                                                           fraction_all_grid_points_at_least_0_9=float(np.mean(minimum[fi]>=.9)))
                                                               for fi,family in enumerate(['recursive','repeat'])},
                                               interpretation='Same sequence evaluated at this finite grid; descriptive Monte Carlo, no continuum-window or probability certificate.'))
                    print(json.dumps(dict(offset=offset,cells=cells,depth=depth,done=True)),flush=True)

    gzpath=csvpath.with_suffix(csvpath.suffix+'.gz')
    with gzpath.open('wb') as dest:
        with gzip.GzipFile(filename='',mode='wb',compresslevel=9,fileobj=dest,mtime=0) as compressed:
            compressed.write(csvpath.read_bytes())
    decompressed=gzip.decompress(gzpath.read_bytes())
    if hashlib.sha256(decompressed).hexdigest()!=hashlib.sha256(csvpath.read_bytes()).hexdigest():
        raise AssertionError('Compressed raw-table byte round trip failed.')
    report=dict(status='PASS',parameters=dict(d=1.,h=H,g=G,t_offset=TOFF),samples_per_point=SAMPLES,
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                production_dependency_sha256=hashlib.sha256(Path(production.__file__).read_bytes()).hexdigest(),
                comparison_design=dict(recursive='Recursive AB/BA sequences',
                                       control='Repeated A0 or B0 sequences',
                                       resources='Matched composition and block length',
                                       use='Finite-device comparison under the same sampling conditions.'),
                resources=resources,formal_jet_checks=jets,independent_full_green_checks=direct,
                max_full_green_error=max(x['absolute_error'] for x in direct),
                zero_energy_mass_checks=zero_checks,max_zero_energy_log_error=max(x['max_log_error'] for x in zero_checks),
                sequence_metadata=sequence_metadata,ensembles=summaries,paired_comparisons=paired,
                finite_grid_joint_response=joint_grid,
                zero_energy_tuning=dict(target_transmission=.9,max_abs_total_mass=float(np.arctanh(np.sqrt(.1))),
                                        log_error_tolerance='atanh(sqrt(.1))/N; identical for recursive and repeated controllers.'),
                raw_csv_path=str(csvpath.relative_to(ROOT)),raw_csv_sha256=hashlib.sha256(csvpath.read_bytes()).hexdigest(),
                raw_csv_encoding='utf-8',raw_csv_line_ending='CRLF',
                raw_csv_gzip_path=str(gzpath.relative_to(ROOT)),raw_csv_gzip_sha256=hashlib.sha256(gzpath.read_bytes()).hexdigest(),
                raw_csv_gzip_bytes=gzpath.stat().st_size,
                compression=dict(format='gzip',mtime=0,embedded_filename='',level=9,
                                 decompressed_sha256=hashlib.sha256(decompressed).hexdigest(),
                                 sample_storage='Raw sample table stored as compressed CSV.'),
                raw_rows=len(summaries)*SAMPLES,runtime_seconds=time.monotonic()-started,
                environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
                limitations=['Fixed-depth finite-sample evidence does not prove Lyapunov asymptotics.',
                             'Each point has 256 independent sequences; energies, uniform errors and paired families share sequences for controlled comparisons.',
                             'Mean-error scan changes one spatially uniform log intercell hopping and rematches ideal leads; it is not a test of arbitrary local implementation errors.',
                             'Finite-grid success is not a continuum-band guarantee, nor a confidence-certified sample probability.',
                             'The hierarchy does not change the 1/N zero-energy mean-calibration tolerance.',
                             'Source sign randomness is not simulated because the eliminated transfer depends only on source squares; source-white-PSD matching assumes independent fair signs in both constructions.',
                             'The sample table and summary describe this finite-device calculation.'])
    dest=ROOT/'verification'/'equal_resource_ordering.json'
    dest.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(output=str(dest),raw_rows=report['raw_rows'],seconds=report['runtime_seconds'],
                         green_error=report['max_full_green_error'],zero_log_error=report['max_zero_energy_log_error'])),flush=True)


if __name__=='__main__':
    main()
