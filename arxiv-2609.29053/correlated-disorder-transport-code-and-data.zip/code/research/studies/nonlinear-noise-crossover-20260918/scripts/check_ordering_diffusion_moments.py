#!/usr/bin/env python3
"""Independent tensor-moment check of the ordering-fault diffusion scale.

Microscopic matrices are reused from check_ordering_faults; both tensor maps,
their trace contractions, and small-system enumeration are built here. This
evaluates moments and their normalization for the specified models.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import platform
import time
from pathlib import Path

import mpmath as mp
import check_ordering_faults as microscopic

ROOT=Path(__file__).resolve().parents[1]
DIGITS=55
mp.mp.dps=DIGITS


def decimal(value):
    return mp.nstr(value,50)


def trace(matrix):
    return matrix[0,0]+matrix[1,1]


def physical_matrices(depth,energy,fault_probability):
    parameters=microscopic.params('identity')
    L=microscopic.lead(energy,parameters['k'])
    inverse=L**-1
    matrices=[L*matrix*inverse for matrix in microscopic.blocks(depth,energy,parameters)]
    weights=[(1-fault_probability)/2]*2+[fault_probability/2]*2
    return parameters,matrices,weights


def tensor_trace_moment(matrices,weights,blocks,rank):
    """E ||P||_F^rank for even rank, using independent tensor indexing."""
    assert rank in [2,4]
    coordinates=list(itertools.product(range(2),repeat=rank))
    operator=mp.matrix([
        [sum(weight*mp.fprod(matrix[a,b] for a,b in zip(output,input_))
             for weight,matrix in zip(weights,matrices)) for input_ in coordinates]
        for output in coordinates])
    # Starting product is identity: tensor of rank/2 identity covariances.
    identity_pairs=lambda coordinate:all(coordinate[j]==coordinate[j+1] for j in range(0,rank,2))
    initial=mp.matrix([int(identity_pairs(coordinate)) for coordinate in coordinates])
    propagated=operator**blocks*initial
    return sum(propagated[j] for j,coordinate in enumerate(coordinates) if identity_pairs(coordinate))


def resistance_moments(matrices,weights,blocks):
    second=tensor_trace_moment(matrices,weights,blocks,2)
    fourth=tensor_trace_moment(matrices,weights,blocks,4)
    return second,fourth,(second-2)/4,(fourth-4*second+4)/16


def enumeration_check():
    depth=1;energy=mp.mpf('.002');probability=mp.mpf('.1');blocks=3
    _,matrices,weights=physical_matrices(depth,energy,probability)
    mean=mp.mpf(0);square=mp.mpf(0);weight_total=mp.mpf(0)
    raw=[]
    for choices in itertools.product(range(4),repeat=blocks):
        product=mp.eye(2);weight=mp.mpf(1)
        for choice in choices:
            product=matrices[choice]*product
            weight*=weights[choice]
        norm_squared=sum(entry*entry for entry in product)
        rho=(norm_squared-2)/4
        mean+=weight*rho;square+=weight*rho*rho;weight_total+=weight
        raw.append(dict(choices=list(choices),probability_decimal=decimal(weight),
                        resistance_decimal=decimal(rho),resistance_squared_decimal=decimal(rho*rho)))
    second,fourth,calculated_mean,calculated_square=resistance_moments(matrices,weights,blocks)
    errors=[abs(mean-calculated_mean),abs(square-calculated_square)]
    assert abs(weight_total-1)<mp.mpf('1e-45')
    assert max(errors)<mp.mpf('1e-45')
    return dict(depth=depth,energy_decimal=decimal(energy),fault_probability_decimal=decimal(probability),
                blocks=blocks,sequences=4**blocks,raw_sequences=raw,
                enumeration_mean_decimal=decimal(mean),enumeration_second_resistance_moment_decimal=decimal(square),
                tensor_mean_decimal=decimal(calculated_mean),tensor_second_resistance_moment_decimal=decimal(calculated_square),
                mean_absolute_error_decimal=decimal(errors[0]),second_moment_absolute_error_decimal=decimal(errors[1]),
                trace_second_moment_decimal=decimal(second),trace_fourth_moment_decimal=decimal(fourth))


def convergence_case(depth,block_power):
    parameters=microscopic.params('identity')
    omega,c0,cr=microscopic.coefficients(depth,parameters)
    blocks=2**block_power
    energy=(mp.mpf('.5')/(blocks*cr**2))**(mp.mpf(1)/(2*depth+2))
    probability=cr**2*energy**(2*depth)/(2**depth*c0)**2
    assert 0<probability<1
    _,matrices,weights=physical_matrices(depth,energy,probability)
    second,fourth,mean,square=resistance_moments(matrices,weights,blocks)
    variance=square-mean*mean
    v=((1-probability)*cr**2*energy**(2*depth+2)
       +probability*(2**depth*c0)**2*energy**2)/2
    s=blocks*v
    limiting_mean=mp.expm1(s)/2
    limiting_square=(mp.exp(3*s)-3*mp.exp(s)+2)/6
    limiting_variance=(2*mp.exp(3*s)-3*mp.exp(2*s)+1)/12
    assert mean>0 and square>mean*mean
    assert abs(limiting_variance-(limiting_square-limiting_mean**2))<mp.mpf('1e-45')
    scalars=dict(energy=energy,fault_probability=probability,scaled_length=s,
                 per_block_variance_scale=v,trace_second_moment=second,trace_fourth_moment=fourth,
                 mean_resistance=mean,second_resistance_moment=square,resistance_variance=variance,
                 diffusion_mean=limiting_mean,diffusion_second_moment=limiting_square,
                 diffusion_variance=limiting_variance,
                 relative_mean_error=mean/limiting_mean-1,
                 relative_second_moment_error=square/limiting_square-1,
                 relative_variance_error=variance/limiting_variance-1,
                 omega0=omega,c0=c0,cr=cr,
                 actual_fault_to_ideal_variance_ratio=1/(1-probability))
    return dict(depth=depth,block_power=block_power,blocks=blocks,cells=blocks*4*2**depth,
                scaling_parameter_lambda=1,
                values={name:float(value) for name,value in scalars.items()},
                decimal_values={name:decimal(value) for name,value in scalars.items()})


def main():
    started=time.monotonic()
    baseline=enumeration_check()
    cases=[convergence_case(depth,power) for depth in [1,2] for power in [20,28]]
    checks=[]
    for depth in [1,2]:
        first,last=[case for case in cases if case['depth']==depth]
        a,b=first['values'],last['values']
        assert b['energy']<a['energy'] and b['fault_probability']<a['fault_probability']
        assert abs(b['relative_mean_error'])<abs(a['relative_mean_error'])
        assert abs(b['relative_second_moment_error'])<abs(a['relative_second_moment_error'])
        checks.append(dict(depth=depth,decreasing_energy=True,decreasing_fault_probability=True,
                           decreasing_first_and_second_moment_error=True,
                           interpretation='Two verified finite points on the specified p-to-zero path; not a numerical proof of convergence.'))
    report=dict(status='PASS',arithmetic=dict(library='mpmath',decimal_digits=DIGITS,
                                             interval_arithmetic=False,serialized_significant_digits=50),
                parameters=dict(calibration='identity',d=1,h=2,g=1.2,t_offset=.25,
                                lead_and_contact_hopping='K=1',depths=[1,2]),
                microscopic_dependency='check_ordering_faults.py: params, lead, blocks, coefficients only; its moment_map/evaluate are not called.',
                generator='L f=(rho+1/2) f_prime + rho(1+rho) f_double_prime/2',
                identities=dict(L_rho='rho+1/2',L_rho_squared='3*rho^2+2*rho',
                                limiting_mean='(exp(s)-1)/2',
                                limiting_second_moment='(exp(3s)-3exp(s)+2)/6',
                                limiting_variance='(2exp(3s)-3exp(2s)+1)/12'),
                path_definition=dict(blocks='n=2^power',
                                     energy='E=(0.5/(n*c_r^2))^(1/(2r+2))',
                                     fault_probability='p=c_r^2 E^(2r)/(2^r c_0)^2 -> 0',
                                     scaled_length='s=n*v=0.5-0.25*p -> 0.5',
                                     actual_ratio='fault variance / attenuated ideal variance = 1/(1-p)'),
                small_system_enumeration=baseline,convergence_cases=cases,finite_point_checks=checks,
                producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                dependencies={Path(microscopic.__file__).name:hashlib.sha256(Path(microscopic.__file__).read_bytes()).hexdigest()},
                environment=dict(python=platform.python_version(),mpmath=mp.__version__),
                runtime_seconds=time.monotonic()-started,
                limitations=['The independent implementation is the 4x4/16x16 tensor map, contraction and 64-word enumeration, not the shared microscopic transfer formulas.',
                             'The four convergence checks have finite corrections, especially the depth-two second moment.',
                             'Moment agreement does not itself prove a diffusion or distributional limit.',
                             'Large lengths use logarithmic-cost tensor powers, not explicit huge-chain sampling.',
                             'The moment calculation uses deterministic enumeration and tensor powers.'])
    destination=ROOT/'verification'/'ordering_diffusion_moments.json'
    destination.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(output=str(destination),enumerated_sequences=baseline['sequences'],
                         convergence_cases=len(cases),seconds=report['runtime_seconds'],
                         max_enumeration_absolute_error=max(float(baseline['mean_absolute_error_decimal']),
                                                            float(baseline['second_moment_absolute_error_decimal'])))))


if __name__=='__main__':
    main()
