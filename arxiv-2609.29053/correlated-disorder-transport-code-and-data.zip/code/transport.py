"""Recursive-chain transmission and exact local-swap ensemble moments.
Production kernels from check_local_swap_devices.py; compact standalone CLI.
"""
from __future__ import annotations
import argparse
import numpy as np
import mpmath as mp

H, G, TOFF, K = 2.0, 1.2, .25, 1.0
DEPTH, LENGTH, CELLS, SAMPLES = 2, 16, 16384, 256
PROBABILITIES = [0.0, .001, .01, .1]
ENERGIES = np.linspace(-.006, .006, 61)
LEVELS = np.exp([-1.0, 0.0, 1.0])


def controller_words():
    a, b = (0, 1, 1, 2), (2, 1, 1, 0)
    for _ in range(DEPTH):
        a, b = a+b, b+a
    words = [a, b]
    for base in (a, b):
        for boundary in range(LENGTH-1):
            trial = list(base)
            trial[boundary], trial[boundary+1] = trial[boundary+1], trial[boundary]
            words.append(tuple(trial))
    return words


WORDS = controller_words()


def product(a, b):
    """Broadcasted 2x2 product, explicit entries avoid general BLAS overhead."""
    out = np.empty(np.broadcast_shapes(a.shape, b.shape))
    out[..., 0, 0] = a[..., 0, 0]*b[..., 0, 0]+a[..., 0, 1]*b[..., 1, 0]
    out[..., 0, 1] = a[..., 0, 0]*b[..., 0, 1]+a[..., 0, 1]*b[..., 1, 1]
    out[..., 1, 0] = a[..., 1, 0]*b[..., 0, 0]+a[..., 1, 1]*b[..., 1, 0]
    out[..., 1, 1] = a[..., 1, 0]*b[..., 0, 1]+a[..., 1, 1]*b[..., 1, 1]
    return out


def cell(level, energies):
    u2 = LEVELS[level]-TOFF
    z = energies*(1+2*(G*G+u2)/(H*H-energies*energies))
    t = TOFF+2*G*G/H-2*H*(G*G-u2)/(H*H-energies*energies)
    result = np.empty((len(energies), 2, 2))
    result[:, 0, 0] = t/K-z*z/(K*t)
    result[:, 0, 1] = -z/t
    result[:, 1, 0] = z/t
    result[:, 1, 1] = K/t
    return result


def matrices(energies):
    cells = [cell(j, energies) for j in range(3)]
    library = np.empty((len(energies), len(WORDS), 2, 2))
    for index, word in enumerate(WORDS):
        result = np.broadcast_to(np.eye(2), (len(energies), 2, 2)).copy()
        for letter in word:
            result = product(cells[letter], result)
        library[:, index] = result
    return library


def lead_metric(energies):
    x = energies/(2*K)
    matrix = np.zeros((len(energies), 2, 2))
    matrix[:, 0, 0] = matrix[:, 1, 1] = 1
    matrix[:, 0, 1] = matrix[:, 1, 0] = x
    matrix /= np.sqrt(1-x*x)[:, None, None]
    # This SPD matrix has determinant one, hence its square root is explicit.
    root = (matrix+np.eye(2))/np.sqrt(matrix[:, 0, 0]+matrix[:, 1, 1]+2)[:, None, None]
    inverse = root.copy()
    inverse[:, 0, 1] *= -1; inverse[:, 1, 0] *= -1
    return root, inverse


def propagate(library, indices, energies):
    ne, ns, nb = len(energies), indices.shape[1], indices.shape[0]
    state = np.broadcast_to(np.eye(2), (ne, ns, 2, 2)).copy()
    log_scale = np.zeros((ne, ns))
    energy_index = np.arange(ne)[:, None]
    for block in range(nb):
        state = product(library[energy_index, indices[block][None, :]], state)
        if block % 16 == 15 or block == nb-1:
            scale = np.max(np.abs(state), axis=(-2, -1))
            state /= scale[..., None, None]
            log_scale += np.log(scale)
    lead, inverse = lead_metric(energies)
    flux = product(product(lead[:, None], state), inverse[:, None])
    log_frobenius2 = np.log(np.sum(flux*flux, axis=(-2, -1)))+2*log_scale
    log_transmission = np.log(4.0)-np.logaddexp(log_frobenius2, np.log(2.0))
    raw = np.exp(log_transmission)
    assert np.all(np.isfinite(log_transmission)) and raw.max() < 1+2e-9
    roundoff_excess = float(max(0, raw.max()-1))
    excess_count = int(np.sum(raw > 1))
    transmission = np.minimum(raw, 1.0)
    log_transmission = np.minimum(log_transmission, 0.0)
    center = np.flatnonzero(abs(energies) < 1e-18)
    raw_center_error = float(np.max(abs(raw[center]-1))) if len(center) else None
    return transmission, log_transmission, dict(maximum_roundoff_above_one=roundoff_excess,
        clipped_above_one_count=excess_count, maximum_unclipped_center_T_error=raw_center_error)


def mp_library(energy):
    h, g, toff = mp.mpf(2), mp.mpf('1.2'), mp.mpf('.25')
    levels = [mp.exp(-1), mp.mpf(1), mp.exp(1)]
    cells = []
    for t0 in levels:
        u2 = t0-toff
        z = energy*(1+2*(g*g+u2)/(h*h-energy*energy))
        t = toff+2*g*g/h-2*h*(g*g-u2)/(h*h-energy*energy)
        cells.append(mp.matrix([[t-z*z/t, -z/t], [z/t, 1/t]]))
    result = []
    for word in WORDS:
        matrix = mp.eye(2)
        for letter in word:
            matrix = cells[letter]*matrix
        result.append(matrix)
    metric = mp.matrix([[1, energy/2], [energy/2, 1]])/mp.sqrt(1-energy*energy/4)
    lead = (metric+mp.eye(2))/mp.sqrt(metric[0, 0]+metric[1, 1]+2)
    return result, lead


def exact_mean_rho(energy_text, probability_text, blocks=CELLS//LENGTH):
    energy, probability = mp.mpf(energy_text), mp.mpf(probability_text)
    library, lead = mp_library(energy)
    weights = [(1-probability)/2]*2+[probability/(2*(LENGTH-1))]*(2*(LENGTH-1))
    flux = [lead*x*(lead**-1) for x in library]
    # The linear covariance map S -> sum_w p_w M_w S M_w^T, row-major vectorized.
    operator = mp.zeros(4)
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    operator[2*i+j, 2*k+l] = mp.fsum(
                        w*m[i, k]*m[j, l] for w, m in zip(weights, flux))
    moment = operator**blocks*mp.matrix([1, 0, 0, 1])
    rho = (moment[0]+moment[3]-2)/4
    lower = 1/(1+rho)
    return dict(energy=float(energy), p_sw=float(probability), blocks=blocks,
                mean_excess_resistance=float(rho), mean_excess_resistance_mp=mp.nstr(rho, 55),
                Jensen_mean_T_lower=float(lower), Jensen_mean_T_lower_mp=mp.nstr(lower, 55),
                interpretation='E[T] >= 1/(1+E[rho]); this lower bound is not the ensemble mean transmission.')


if __name__ == '__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cells',type=int,default=16384)
    ap.add_argument('--samples',type=int,default=256)
    ap.add_argument('--energy',type=float,default=.002)
    ap.add_argument('--swap',type=float,default=.01)
    args=ap.parse_args()
    if args.cells<=0 or args.cells%LENGTH or args.samples<1 or not 0<=args.swap<=1:
        ap.error('cells must be a positive multiple of 16; samples>0 and swap in [0,1]')
    rng=np.random.default_rng(202609180507)
    shape=(args.cells//LENGTH,args.samples)
    base=rng.integers(0,2,size=shape,dtype=np.int8)
    boundary=rng.integers(0,LENGTH-1,size=shape)
    coins=rng.random(shape)
    energies=np.array([0.,args.energy]); library=matrices(energies)
    for name,indices in [('recursive',base),('local swaps',np.where(coins<args.swap,2+base.astype(np.int16)*(LENGTH-1)+boundary,base))]:
        T,_,_=propagate(library,indices,energies)
        print(f'{name}: median T(E)={np.median(T[1]):.6g}; mean={np.mean(T[1]):.6g}; median T(0)={np.median(T[0]):.6g}')
    repeated=[]
    for word in [(0,1,1,2)*4,(2,1,1,0)*4]:
        M=np.broadcast_to(np.eye(2),(len(energies),2,2)).copy()
        for letter in word:M=product(cell(letter,energies),M)
        repeated.append(M)
    control=np.stack(repeated,axis=1)
    T,_,_=propagate(control,base,energies)
    print(f'repeated control: median T(E)={np.median(T[1]):.6g}; mean={np.mean(T[1]):.6g}')
    mp.mp.dps=65
    result=exact_mean_rho(str(args.energy),str(args.swap),args.cells//LENGTH)
    print(f'exact ensemble mean rho={result["mean_excess_resistance"]:.6g}; Jensen mean-T lower bound={result["Jensen_mean_T_lower"]:.6g}')
