Computational code

1. Compact scripts

transport.py: recursive chains, adjacent exchanges, full transmission, and finite-length mean resistance.
repair.py: exact coefficients for mirror-paired errors and finite-device resistance.
stealthy.py: disorder spectra and full transmission before and after swaps.

Each script can be run directly; use --help for options and examples.

2. Research computation scripts

research/studies/nonlinear-noise-crossover-20260918/scripts/
  check_finite_energy.py and check_equal_resource_ordering.py: finite-energy calculations and comparisons of ordering at equal resources.
  check_local_swap_devices.py and check_local_swap_obstruction.py: adjacent swaps, full transmission, and a local-scattering lower bound.
  check_interval_transmission.py and check_ordering_fault_intervals.py: finite-size probability intervals.
  check_ordering_faults.py and check_ordering_diffusion_moments.py: resistance crossover and diffusion scales under whole-block replacement.
  check_transport.py and check_crossover.py: exact models and transfer calculations used by the other scripts.

research/studies/scattering-correlation-repair-20260925/
  repair.py: rational expansions and full transfer calculations.
  device_scan.py: error correlations and paired samples in finite devices.
  window_limit.py: pairing-failure rate as a function of length.

research/studies/stealthy-swap-bridge-20260925/
  bridge.py: local swaps, disorder spectra, and full transmission.
  permutation_spectrum.py: power spectra after general finite-block permutations.
  run_transport.py: full transfer-matrix sampling for stealthy disorder.

3. Installation and execution

Python 3.11 is recommended. From code/, run:

  python3 -m pip install -r requirements.txt
  python3 prepare_inputs.py

The second command creates output directories and extracts the two supplied inputs from interval-input-data.zip into the locations expected by the interval scripts. Other scripts generate their data directly.

Finite-energy interval calculation:
  python3 research/studies/nonlinear-noise-crossover-20260918/scripts/check_interval_transmission.py

Whole-block replacement interval calculation:
  python3 research/studies/nonlinear-noise-crossover-20260918/scripts/check_ordering_fault_intervals.py

Research scripts may perform large computations and write results into their study directories; consult each script and its options before running. Run device_scan.py and window_limit.py from their own directory, since they use the current working directory.

Files beginning with check_ perform numerical, interval, or exact algebraic calculations used in the paper. The supplied scripts can generate additional samples.
