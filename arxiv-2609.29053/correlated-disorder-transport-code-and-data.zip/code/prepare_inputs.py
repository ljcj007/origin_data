#!/usr/bin/env python3
"""Unpack inputs for the pointwise interval-bound calculations."""
from pathlib import Path
from zipfile import ZipFile
base = Path(__file__).resolve().parent
root = base / "research"
with ZipFile(base / "interval-input-data.zip") as z:
    for name in z.namelist():
        target = (root / name).resolve()
        if root.resolve() not in target.parents:
            raise ValueError("Invalid data path: " + name)
    z.extractall(root)
for p in ["studies/nonlinear-noise-crossover-20260918/data", "studies/nonlinear-noise-crossover-20260918/verification"]:
    (root / p).mkdir(parents=True, exist_ok=True)
print("Computation directories and interval inputs are ready:", root)
