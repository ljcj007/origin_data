#!/usr/bin/env python3
"""Exact first/two-jet checks and finite products for correlated local errors.

Fraction arithmetic evaluates the algebraic coefficients, and mpmath
evaluates the unexpanded six-orbital transfer function. The reflection
proxy is computed from the transfer-matrix variance. Finite resistance
is an ensemble second moment evaluated at finite precision.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
import mpmath as mp

Matrix = tuple[F, F, F, F]
Word = tuple[int, ...]

@dataclass(frozen=True)
class Parameters:
    levels: tuple[F, ...] = (F(1,2),F(1),F(2))
    h: F = F(2)
    g: F = F(6,5)
    offset: F = F(1,4)
    K: F = F(1)
    def __post_init__(self):
        if self.h<=0 or self.K<=0 or any(t<=0 or t<self.offset for t in self.levels):
            raise ValueError('Positive feasible cell parameters are required.')


def mpf(x):
    return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)

def eye() -> Matrix:return (F(1),F(0),F(0),F(1))
def zero() -> Matrix:return (F(0),)*4
def add(a:Matrix,b:Matrix)->Matrix:return tuple(x+y for x,y in zip(a,b))
def mul(a:Matrix,b:Matrix)->Matrix:
    return (a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],
            a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3])
def det(a:Matrix)->F:return a[0]*a[3]-a[1]*a[2]

def multiply_jets(a,b):
    """Coefficients of E^0,E^1,E^2 (not derivatives with factorials)."""
    return tuple(tuple(sum(mul(a[j],b[k-j])[i] for j in range(k+1))
                       for i in range(4)) for k in range(3))

@lru_cache(maxsize=None)
def cell_jets(letter:int,par:Parameters):
    t=par.levels[letter];h=par.h;g=par.g;K=par.K
    u2=h*(t-par.offset)/2
    Q=1+2*(g*g+u2)/(h*h)
    t2=-2*(g*g-u2)/(h**3)
    return ((t/K,F(0),F(0),K/t),(F(0),-Q/t,Q/t,F(0)),
            (t2/K-Q*Q/(K*t),F(0),F(0),-K*t2/(t*t)))

@lru_cache(maxsize=None)
def word_jets(word:Word,par:Parameters):
    result=(eye(),zero(),zero())
    for letter in word:result=multiply_jets(cell_jets(letter,par),result)
    return result

@lru_cache(maxsize=None)
def prefix_ab(word:Word,par:Parameters):
    pref=F(1);A=F(0);B=F(0)
    for letter in word:
        t=par.levels[letter];u2=par.h*(t-par.offset)/2
        Q=1+2*(par.g**2+u2)/(par.h**2)
        B+=Q*pref**2
        pref*=t/par.K
        A+=Q/pref**2
    if pref!=1:raise ValueError('Word must be exactly composition balanced.')
    return A,B


def seeds(depth:int)->tuple[Word,Word]:
    if not isinstance(depth,int) or depth<0:raise ValueError('Nonnegative integer depth required.')
    a,b=(0,1,1,2),(2,1,1,0)
    for _ in range(depth):a,b=a+b,b+a
    return a,b

def probability(p):
    p=F(p)
    if not 0<=p<=1:raise ValueError('Probability must belong to [0,1].')
    return p

def fault_law(base:Word,p)->dict[Word,F]:
    p=probability(p);result=defaultdict(F);result[base]+=1-p
    for j in range(len(base)-1):
        w=list(base);w[j],w[j+1]=w[j+1],w[j]
        result[tuple(w)]+=p/(len(base)-1)
    return {w:p for w,p in result.items() if p}

def average_fault_law(depth,p):
    out=defaultdict(F)
    for base in seeds(depth):
        for w,prob in fault_law(base,p).items():out[w]+=prob/2
    return dict(out)

def module_law(depth,p,q)->dict[Word,F]:
    """Same random ideal scaffold (base,reverse(base)) in all protocols.

    q=0: the realized swapped word is mirrored exactly.
    q=1: independent swap draws in the two halves, conditional on base.
    q between: an independent coin selects these two correlation laws.
    Marginal attempts/positions in either half do not change with q.
    """
    q=probability(q);out=defaultdict(F)
    for base in seeds(depth):
        law=fault_law(base,p)
        for w,prob in law.items():
            out[w+w[::-1]]+=(1-q)*prob/2
            for v,pv in law.items():out[w+v[::-1]]+=q*prob*pv/2
    return {w:p for w,p in out.items() if p}

def marginals(law,ell):
    left=defaultdict(F);right=defaultdict(F)
    for word,p in law.items():left[word[:ell]]+=p;right[word[ell:]]+=p
    return dict(left),dict(right)

def quadratic_from_ab(ab,probs,length,K):
    """Gamma_2 per physical cell; all calculations exact for rational inputs."""
    A=sum(p*a for (a,b),p in zip(ab,probs));B=sum(p*b for (a,b),p in zip(ab,probs))
    return sum(p*((B/A)*a*a+(A/B)*b*b-2*a*b)
               for (a,b),p in zip(ab,probs))/(8*K*K*length)

def quadratic_coefficient(law,par):
    words=list(law)
    return quadratic_from_ab([prefix_ab(w,par) for w in words],
                             [law[w] for w in words],len(words[0]),par.K)

def coefficients(par:Parameters,depth:int,swap_probability):
    p=probability(swap_probability);ell=4*2**depth;L=2*ell
    law=average_fault_law(depth,p)
    # Conditional reflection variance is essential: the scaffold is shared.
    v=F(0)
    for base in seeds(depth):
        local=fault_law(base,p)
        c={w:(prefix_ab(w,par)[1]-prefix_ab(w,par)[0])/(2*par.K) for w in local}
        mean=sum(pr*c[w] for w,pr in local.items())
        v+=sum(pr*(c[w]-mean)**2 for w,pr in local.items())/2
    # Mirror module expansion: I+Omega_w E J+E^2(-Omega_w^2 I/2+d_w Z).
    omega={};d={}
    for w in law:
        pair=multiply_jets(word_jets(w[::-1],par),word_jets(w,par))
        omega[w]=pair[1][2]
        d[w]=(pair[2][0]-pair[2][3])/2
    omega_bar=sum(pr*omega[w] for w,pr in law.items())
    d_bar=sum(pr*d[w] for w,pr in law.items())
    c4=sum(pr*(d[w]-omega[w]*d_bar/omega_bar)**2 for w,pr in law.items())/(2*L)
    return {'half_length':ell,'module_length':L,'conditional_reflection_variance':v,
            'c2_independent':v/L,'c2_mirror':quadratic_coefficient(module_law(depth,p,F(0)),par),
            'c4_mirror':c4,'mean_rotation_speed':omega_bar,'mean_second_order_diagonal':d_bar}


def cell_matrix(letter,energy,par):
    E=mpf(energy);h=mpf(par.h);g=mpf(par.g);K=mpf(par.K)
    if abs(E)>=h:raise ValueError('Require |E|<h for auxiliary elimination.')
    u2=h*(mpf(par.levels[letter])-mpf(par.offset))/2
    a=mpf(par.offset)+2*g*g/h
    t=a-2*h*(g*g-u2)/(h*h-E*E)
    z=E*(1+2*(g*g+u2)/(h*h-E*E))
    if t==0:raise ValueError('Transfer hopping vanishes at this energy.')
    return mp.matrix([[t/K-z*z/(K*t),-z/t],[z/t,K/t]])

def word_matrix(word,energy,par):
    cells={a:cell_matrix(a,energy,par) for a in set(word)}
    result=mp.eye(2)
    for a in word:result=cells[a]*result
    return result

def mean_root(mean,energy):
    E=mpf(energy)
    if E==0:raise ValueError('Use the analytic zero-energy coefficients instead.')
    q=(mean-(mean[0,0]+mean[1,1])*mp.eye(2)/2)/E
    if mp.det(q)<=0:raise ValueError('Mean is not elliptic at this energy.')
    J=mp.matrix([[0,-1],[1,0]])
    metric=-J*q/mp.sqrt(mp.det(q))
    if metric[0,0]<=0:raise ValueError('Unexpected rotation orientation.')
    return (metric+mp.eye(2))/mp.sqrt(metric[0,0]+metric[1,1]+2)

def reflection_proxy(par,depth,p,q,energy):
    law=module_law(depth,p,q)
    matrices={w:word_matrix(w,energy,par) for w in law}
    mean=mp.zeros(2)
    for w,prob in law.items():mean+=mpf(prob)*matrices[w]
    root=mean_root(mean,energy);inv=root**-1
    variance=mp.mpf(0)
    for w,prob in law.items():
        M=root*matrices[w]*inv
        variance+=mpf(prob)*((M[0,0]-M[1,1])**2+(M[0,1]+M[1,0])**2)/4
    return variance/(2*(8*2**depth))

def lead_root(energy,K):
    x=mpf(energy)/(2*mpf(K))
    if abs(x)>=1:raise ValueError('Energy outside bare lead band.')
    metric=mp.matrix([[1,x],[x,1]])/mp.sqrt(1-x*x)
    return (metric+mp.eye(2))/mp.sqrt(metric[0,0]+metric[1,1]+2)

def covariance_action(M):
    a,b,c,d=M[0,0],M[0,1],M[1,0],M[1,1]
    return mp.matrix([[a*a,2*a*b,b*b],[a*c,a*d+b*c,b*d],[c*c,2*c*d,d*d]])

def mean_resistance(par,depth,p,q,energy,cells):
    L=8*2**depth
    if cells<=0 or cells%L:raise ValueError('Length must be a positive number of whole modules.')
    law=module_law(depth,p,q);root=lead_root(energy,par.K);inv=root**-1
    moment=mp.zeros(3)
    for w,prob in law.items():
        moment+=mpf(prob)*covariance_action(root*word_matrix(w,energy,par)*inv)
    state=(moment**(cells//L))*mp.matrix([1,0,1])
    return (state[0]+state[2]-2)/4


if __name__ == '__main__':
    ap=argparse.ArgumentParser(description='Exact repair coefficients and finite-device mean resistance.')
    ap.add_argument('--depth',type=int,default=2)
    ap.add_argument('--swap',default='1/5')
    ap.add_argument('--failure',default='0')
    ap.add_argument('--energy',default='0.002')
    ap.add_argument('--cells',type=int,default=1048576)
    ap.add_argument('--digits',type=int,default=65)
    args=ap.parse_args(); mp.mp.dps=args.digits
    par=Parameters();p=F(args.swap);q=F(args.failure)
    c=coefficients(par,args.depth,p)
    for name in ['c2_independent','c2_mirror','c4_mirror']:
        print(f'{name} = {mp.nstr(mpf(c[name]),8)}')
    rho=mean_resistance(par,args.depth,p,q,args.energy,args.cells)
    print('mean excess resistance =',mp.nstr(rho,8))
    print('Jensen lower bound on mean transmission =',mp.nstr(1/(1+rho),8))
