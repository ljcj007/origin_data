# L=2 经典反铁磁 Ising 精确枚举校验

## 约定与范围

本目录验证 POSCAR 最近邻图在 $2\times2$ 周期超胞（$N=20$、$N_b=24$）上的
经典蒙特卡洛实现。统一使用

$$H=+J\sum_{\langle ij\rangle}s_i s_j,\qquad J=1,\quad s_i=\pm1,$$

以及 $M_s=\sum_i\eta_i s_i$。所有 24 条键都连接相反的 $\eta$ 子格，
因此 Wolff 路径等价于对 $\tau_i=\eta_i s_i$ 做铁磁集群更新。

精确枚举覆盖全部 $2^{20}=1,048,576$ 个构型。对照温度为无限系统的精确临界点
$T_c/J=1.004191298134190$；这里的有限 $L=2$ 系综仅用于程序校验，不能再估计热力学相变点。

## 蒙卡协议与判据

Wolff 和 Metropolis 各用 100,000 sweeps 热化，随后采样 256 bins。Wolff 每 bin
20,000 sweeps；局域 Metropolis 为控制连通磁化率的有限-bin 偏差，每 bin 200,000 sweeps。
另保留一个 20,000 sweeps/bin 的 Metropolis 诊断链。随机种子由运行编号和单元编号确定。
误差分别按 1、2、4、8、16-bin 重分块估计，并取最大标准误；Binder 比对每种块长
作 delete-one-block jackknife。预注册的一致性预算为 $4\sigma_{\rm cons}$。

## 结果

| 观测量 | 精确值 | Wolff | $z$ | Metropolis | $z$ |
|---|---:|---:|---:|---:|---:|
| $E/N$ | -1.078674321 | -1.078631992(0.00011) | 0.37 | -1.078759443(8.5e-05) | -1.00 |
| $C/N$ | 0.6196658364 | 0.6196413543(0.00069) | -0.04 | 0.6189952726(0.00043) | -1.56 |
| $\langle|M_s|\rangle/N$ | 0.8871336736 | 0.8871318164(0.00012) | -0.02 | 0.8872625176(0.00011) | 1.13 |
| $\langle M_s^2\rangle/N^2$ | 0.8309995189 | 0.830973498(0.00016) | -0.16 | 0.8311535783(0.00015) | 1.06 |
| $\langle M_s^4\rangle/N^4$ | 0.7670515531 | 0.7669935144(0.0002) | -0.29 | 0.7672092829(0.00017) | 0.92 |
| $U_s$ | 0.6297442991 | 0.6297491276(5.2e-05) | 0.09 | 0.6298054367(4.9e-05) | 1.24 |
| $\chi_u$ | 0.6259450387 | 0.6258559486(0.00016) | -0.55 | 0.624820207(0.00014) | -8.00 |
| $\chi_{s,c}$ | 0.8761948892 | 0.8756670817(0.0012) | -0.44 | 0.8746442872(0.0012) | -1.31 |

结论：原生 Metropolis $\chi_u$ 与精确枚举为 `Disagreement`；其余 15 个原生对照一致，连同单列外推量的最大门控 $|z|=1.559$。
局域 Metropolis 的 $\chi_u$ 在 20,000 sweeps/bin 时为 0.6155512 （$z=-8.59$），延长到 200,000 sweeps/bin 后为 0.62482021（$z=-8.00$）；短链仅作有限-bin 偏差诊断。
按 $\chi_u(n_{\rm bin})=\chi_u(\infty)+a/n_{\rm bin}$ 外推得到 0.6258501(0.00021)，相对精确值 $z=-0.46$，标为 `Agreement`。该外推支持偏差机制，但不是正式源码的原生输出，也不改变原生 `Disagreement`。
`specific_heat_per_site`、两种磁化率是每个 bin 内构造的非线性/连通估计量；
局域更新的原始 $\chi_u$ 即使在 200,000 sweeps/bin 时仍有可分辨偏差，故不纳入主验收；
$1/n_{\rm bin}$ 外推只用于解释该诊断分歧。这些结果只验证本次协议。

## 产物与复现

- `density_of_states.csv`：按 $(E/J,M,M_s)$ 聚合的精确整数态密度。
- `exact.json`：精确热力学量、键表、$\eta$ 和规范。
- `cells/*`：Fortran 输入、原始 bins、摘要、标准输出和清单。
- `comparison.json` 与 `cross-method-check.csv`：保守重分块对照。
- `checksums.sha256.json`：目录内全部产物哈希。

在仓库根目录运行：

```powershell
pwsh -NoProfile -File scripts\run_ising_l2_exact_validation.ps1
python scripts\checksum_ledger.py results\ising_l2_exact_validation_v1 --verify
```

正式 `ising_graph.f90` 未作修改。
