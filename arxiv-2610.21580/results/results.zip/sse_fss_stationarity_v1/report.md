# SSE 有限尺寸数据平稳性审计 v1

状态：**完整报告**。已读取 14/14 个单元；缺失：无。

## 边界

这是独立、只读的探索性诊断，不属于预注册正式分析门。脚本只报告异常线索，不自动排除数据、不自动要求重跑，也不改动 `results/sse_fss_v1`。若完整数据出现需关注项，应结合时间序列、多重比较和物理量相关性人工判断。

## 方法

- 对 7 个正式拟合观测量逐副本比较 bins 1–32 与 33–64。
- 固定 4-bin 连续分块标准误给出主要前后半段 z 值；另以 1、2、4、8-bin 标准误最大值给出保守 z 值。
- 对同一 L 的两个独立副本，用各自保守标准误计算一致性 z 值。
- 同时报告 lag-1 相关和“保守标准误/朴素标准误”阻塞比。
- |z|≥3、|lag-1|≥0.5、阻塞比≥2 只作提示；另列 0.05 族错误率的 Bonferroni 提示。

## 当前极值

- 固定 4-bin 前后半段：cell-0012, L=14, 副本 2, spin_stiffness_cell_average：-3.22704
- 保守前后半段：cell-0006, L=8, 副本 2, spin_stiffness_cell_average：-2.46672
- 保守副本差：L=16, ferrimagnetic_m2：1.57721
- 最大 |lag-1|：cell-0002, L=4, 副本 2, ferrimagnetic_m2：0.280921
- 最大阻塞比：cell-0006, L=8, 副本 2, spin_stiffness_cell_average：1.46804

## 提示计数

- 前后半段名义提示：1；Bonferroni 族内提示：0
- 副本差名义提示：0；Bonferroni 族内提示：0
- lag-1 提示：0；阻塞比提示：0

逐项数值见 `stationarity_cells.csv` 与 `replica_consistency.csv`。14/14 单元到齐后使用相同命令重跑即可，报告状态会自动切换为 `complete_review`。
