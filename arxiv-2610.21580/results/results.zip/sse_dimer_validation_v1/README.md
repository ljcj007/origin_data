# SSE 独立二聚体精确校验

## 目的与边界

本目录用严格可解的自旋 $1/2$ 反铁磁 Heisenberg 二聚体检查
`sse_graph_stiffness_v2.f90` 的能量零点、归一化、磁矩测量和统计误差。
正式源码未作修改。

程序要求 $L_x,L_y\geq2$，所以输入采用 $2\times2$ 超胞，并在每个晶胞内仅放置一条
无平移的键。有限图因此是四个互不耦合的二聚体，$N_d=4$、$N=8$、$N_b=4$。
这是单二聚体配分函数的严格直积，不受周期边界影响；它只校验 SSE 核心和输出归一化，
不校验生产格点的连通性，也不检验非零键平移下的刚度公式。

## 解析结果

约定为

$$
H=J\sum_{d=1}^{N_d}\mathbf S_{d1}\cdot\mathbf S_{d2},\qquad J=1.
$$

每个二聚体有一个 $E_s=-3J/4$ 的单态和三个 $E_t=J/4$ 的三重态，因而

$$
Z_d=e^{3\beta J/4}+3e^{-\beta J/4}
    =e^{-\beta J/4}(e^{\beta J}+3).
$$

令 $x=e^{\beta J}$，则

$$
\frac{E}{N}=\frac{3J}{8}\frac{1-x}{x+3},\qquad
\langle \mathbf S_{\rm tot}^2\rangle=\frac{6N_d}{x+3}.
$$

程序以

$$
m_F^2=\frac{3\langle (S^z_{\rm tot})^2\rangle}{N^2}
     =\frac{\langle\mathbf S_{\rm tot}^2\rangle}{N^2}
$$

输出 `ferrimagnetic_m2`，第二个等号来自有限温 SU(2) 对称性。相应地，
`uniform_susceptibility` 的精确值是 $\beta/(x+3)$。程序的展开阶数归一化为

$$
\frac{E}{N}=-\frac{\langle n\rangle}{\beta N}+\frac{N_bJ}{4N},\qquad
\langle n\rangle=\beta JN_d\frac{x}{x+3}.
$$

若 $A=(x+1)/(x+3)$，则时间片交错磁矩满足
$\langle M_s^2\rangle=N_dA$ 和
$\langle M_s^4\rangle=N_dA+3N_d(N_d-1)A^2$。
这些式子连同子格磁矩和比热的解析值均写入 `exact_comparison.json`。

## 参数与结果

- 参数：$\beta J=2$，128 bins，每 bin 20,000 sweeps，热化 100,000 sweeps。
- 随机种子：`20260904`。
- 误差：对原始 bins 作 1/2/4/8-bin 重分块并取最大标准误。
- 预设门槛：所有线性估计量满足 $|z|\leq4$。
- 结论：通过；八个门控量的最大 $|z|=1.958$。
- 最大单-bin lag-1 绝对值为 0.137；重分块最多把标准误放大 1.080 倍。

关键对照如下：

| 观测量 | SSE | 保守标准误 | 精确值 | $z$ |
|---|---:|---:|---:|---:|
| $E/N$ | -0.230846143 | 0.000265980 | -0.230617297 | -0.860 |
| $m_s^2$ | 0.151626544 | 0.000131832 | 0.151404324 | 1.686 |
| $m_F^2$ | 0.0360636292 | 0.0000516421 | 0.0360956757 | -0.621 |
| $\langle\mathbf S_{\rm tot}^2\rangle$ | 2.30807227 | 0.00330510 | 2.31012325 | -0.621 |
| $m_{A}^{2}$ | 0.187813550 | 0.000160149 | 0.187500000 | 1.958 |
| $m_{B}^{2}$ | 0.187566797 | 0.000134686 | 0.187500000 | 0.496 |
| 子格交叉项 | -0.115562915 | 0.000151437 | -0.115308649 | -1.679 |

比热与 Binder 比是每个 bin 内形成的非线性估计量，存在有限-bin 偏差，故只列作诊断、
不进入统计门槛；它们也分别与精确值相差 0.10 和 0.08 个保守标准误。
逐-bin 的能量—展开阶数、磁化率—均匀磁矩、交错磁矩—子格分解恒等式的最大残差
不超过 $2.8\times10^{-17}$。由于所有键平移为零，五个绕数/刚度输出严格为零。

## 复现

在仓库根目录编译：

```powershell
gfortran -O2 -std=f2008 -Wall -Wextra -o results\sse_dimer_validation_v1\sse_graph_dimer.exe sse_graph_stiffness_v2.f90
```

进入本目录后运行：

```powershell
.\sse_graph_dimer.exe .\sse_graph.in
```

回到仓库根目录解析并验收：

```powershell
python scripts\validate_sse_dimer.py results\sse_dimer_validation_v1 --source sse_graph_stiffness_v2.f90 --executable results\sse_dimer_validation_v1\sse_graph_dimer.exe
python scripts\checksum_ledger.py results\sse_dimer_validation_v1 --verify
```

编译器为 GNU Fortran 8.1.0。正式源码 SHA-256 为
`D918DF52DD5236D125D707C20FFD39B813526C01DC45409EAD89E8ED8F4A58A0`；可执行文件、
输入和图的哈希记录在 `exact_comparison.json` 与 `checksums.sha256.json`。
