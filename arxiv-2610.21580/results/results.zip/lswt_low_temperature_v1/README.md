# LSWT 低温热力学结果

本目录验证 edge-centered honeycomb 亚铁磁体单个 (z=2) Goldstone 分支的低温结果。

- `summary.json`：解析系数、连续积分和完整布里渊区外推；
- `thermodynamics.csv`：完整声学支的有限温布里渊区积分。

默认采用 (J=1)、(S=1/2)、原胞基矢长度 (a=1) 和每原胞五个站点。推导、归一化与 Mermin--Wagner 边界见 `docs/lswt_low_temperature.md`。
