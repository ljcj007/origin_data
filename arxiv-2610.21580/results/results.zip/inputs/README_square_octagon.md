# Square-octagon 海森堡模型 SSE 参考验证版

> 注意：这是根据老师旧代码重建的四子格参考图，不是尚未提供的目标 POSCAR。其均匀最近邻紧束缚谱没有严格平带，因此不能作为新型五格点晶格的最终模型。正式工作流请使用 `README.md`、`lattice_from_poscar.py`、`ising_graph.f90` 和 `sse_graph.f90`。

本程序计算周期性 square-octagon（4-8）晶格上的自旋 \(1/2\) 海森堡模型：

\[
H=\sum_{\langle ij\rangle}\mathbf S_i\cdot\mathbf S_j,
\qquad J_{\square}=J_{\mathrm{link}}=1.
\]

每个晶胞有 4 个自旋、4 条方形内部键和 2 条晶胞间键：

\[
N=4L_xL_y,\qquad N_b=6L_xL_y.
\]

## 编译

```powershell
gfortran -std=f2008 -Wall -Wextra -fcheck=all -O2 `
  sse_square_octagon.f90 -o sse_square_octagon.exe
```

调试时建议把 `-O2` 换成 `-O0 -g`。

## 输入

程序读取 `sse_square_octagon.in`：

```text
Lx Ly beta
nbins msteps isteps
seed
```

- `Lx, Ly`：晶胞数，周期边界下必须为偶数且不小于 2。
- `beta`：逆温度 \(1/T\)，能量单位取 \(J=1\)。
- `nbins`：统计分箱数。
- `msteps`：每个 bin 的测量 sweep 数。
- `isteps`：热化 sweep 数。
- `seed`：正整数随机种子。

也可以在命令行指定其他输入文件：

```powershell
.\sse_square_octagon.exe my_run.in
```

## 输出

- `results_bins.csv`：每个 bin 的原始统计量。
- `results_summary.txt`：均值与标准误差。

第一版输出：

- 每格点能量 `energy_per_site`；
- 每格点比热 `specific_heat_per_site`；
- 交错磁化平方 `staggered_m2`；
- 均匀磁化率 `uniform_susceptibility`；
- 两类键分别贡献的能量；
- 平均展开阶数。

程序启动时会检查：总格点数、总键数、重复键、配位数和二分图条件。

## SSE 数据结构

- `spin(i)`：格点 \(i\) 的 \(2S_i^z=\pm1\)。
- `bonds(:,b)`：第 \(b\) 条键的两个端点。
- `opstring(p)`：SSE 算符串；0 是单位算符，偶数是对角算符，奇数是非对角算符。
- `vertex`：loop update 使用的 linked-vertex 表。

能量估计量为

\[
\frac{E}{N}=-\frac{\langle n\rangle}{\beta N}
+\frac{N_b}{4N},
\]

其中 \(n\) 是非单位算符数量。

## 推荐学习顺序

1. 阅读 `make_lattice`，理解晶胞和键表。
2. 阅读 `diagonal_update`，理解算符插入与删除。
3. 阅读 `loop_update`，理解 linked-vertex 和环翻转。
4. 阅读 `measure` 与 `finish_bin`，理解物理量和误差统计。

正式计算前应先完成 \(L_x=L_y=2\) 的精确对角化对照和 beta 收敛检查。
