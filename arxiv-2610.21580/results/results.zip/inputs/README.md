# POSCAR 格点模型工作流

本目录正在建立一套可追溯工作流：同一个 POSCAR 最近邻图同时供经典 Ising、量子 Heisenberg SSE 和 Bloch 邻接谱使用。

## 当前状态

- `scripts/lattice_from_poscar.py`：报告距离壳层、配位数和二分性，并导出确认后的最近邻图。
- `ising_graph.f90`：读取周期图的经典反铁磁 Ising 程序，支持 Metropolis 与二分图 Wolff 更新。
- `sse_graph.f90`：读取同一周期图的自旋 1/2 反铁磁 Heisenberg SSE 程序。
- `scripts/band_graph.py`：计算最近邻 Bloch 邻接谱并检测严格平带。
- `scripts/plot_poscar_graph.py`：直接使用 POSCAR 原始晶格矢量、五个坐标和周期连边绘图；这是结构图的权威来源。
- `scripts/lswt_super_honeycomb.py`：计算五条线性自旋波带、二次 Goldstone 模式和磁振子平带。
- `scripts/one_magnon_high_field.py`：验证饱和相单磁振子拉普拉斯平带与精确饱和场。
- `scripts/flatband_cls_topology.py`：精确计数有限环面上的六边形紧致局域态、非收缩线态和带接触零模。
- `scripts/lswt_low_temperature.py`：从二次 Goldstone 支计算低温态密度、能量和比热，并用全布里渊区积分复核。
- `scripts/audit_ising_wolff.py`：从 35 个正式单元的原始 bin 严格复算 Binder crossing、重分块误差、时间序列诊断和来源边界。
- `scripts/analyze_ising_universality.py`：在精确临界温度处插值 Wolff 数据，检查二维 Ising 临界指数的一致性和拟合区间敏感性。
- `scripts/analyze_sse_fss.py`：合并正式 SSE 的两个独立副本并核对每个结果工件哈希。
- `scripts/audit_sse_stationarity.py`：独立检查 SSE 前后半段、双副本、lag-1 和阻塞误差，只报告而不自动删点或重跑。
- `scripts/run_sse_fss_fits.ps1`：按冻结的拟合形式运行主外推、子格补充外推和截断敏感性检查。
- `scripts/fetch_sse_fss_completion.ps1`：服务器开放后只读确认正式任务完成，并非覆盖下载最后两个单元。
- `scripts/validate_sse_completion_stage.py`：在暂存区独立验证 14 个返回码、L=16 参数和工件哈希，成功后才允许移动。
- `scripts/run_remote_ed_validation.ps1`：服务器开放后先查负载、进程和 GPU；CPU 空闲时才运行并严格验收目标 `2x2`、`N=20` Heisenberg ED，不安装新软件。
- `scripts/validate_sse_dimer.py`：用独立海森堡二聚体的有限温精确解核对正式 SSE 源码的能量、磁矩和归一化。
- `scripts/peripheral_benchmarks.py`：从零重建方格 Ising、方格 Heisenberg 与方形-八边形基准证据包。
- `scripts/ising_l2_exact.py` 与 `scripts/validate_ising_l2_exact.py`：完整枚举目标图 `L=2` 的全部经典构型，并交叉核对 Wolff/Metropolis。
- `scripts/finalize_sse_fss.ps1`：在 14/14 数据到齐后依次完成严格汇总、拟合、Figure 3 和本地回归测试。
- `scripts/backfill_sse_manuscript.py`：在完整数据、拟合和四格式 Figure 3 全部通过后安全回填 Markdown/LaTeX 论文。
- `scripts/build_manuscript.ps1`：在无网络和无自动装包条件下重建 REVTeX/BibTeX 稿件并检查日志。
- `scripts/audit_local_state.ps1`：不访问网络的一键本地总验收，覆盖测试、账本、JSON、冻结哈希、源码语法与论文状态。
- `scripts/checksum_ledger.py`：为历史或新结果目录生成并核对 SHA-256 文件账本。
- `scripts/figure3_sse.py`：在 14 个正式任务全部验收后生成 SSE 收敛与有限尺寸 Figure 3。
- `docs/research_log.md`：验证记录、物理假说和待确认事项。
- `docs/reference_paper_and_fortran.md`：参考论文、三份旧 Fortran 程序、SSE 原理和学习路径的中文说明。
- `docs/fortran_sse_tutorial.md`：从 Fortran 数组与随机数到 SSE 对角/loop 更新、测量、编译和输出解读的初学者教程。
- `docs/reproducibility.md`：冻结哈希、软件版本、一键收尾命令和自动验收边界。
- `docs/autoresearch_workflow.md`：可迁移到新晶格的阶段状态机、自动推进范围和必须询问的科学决策边界。
- `docs/sse_v2_audit.md`：正式 SSE 源码正确性与已知适用范围。
- `docs/stiffness_normalization.md`：方格子非零绕数、刚度恒等式和仍待外部核验的归一化边界。
- `docs/citation_gap_audit.md`：核心主张的引文缺口、待核验原始出处和材料证据边界。
- `docs/ising_estimator_boundary.md`：记录逐-bin 连通估计量偏差、对当前结论的影响和待选择的 v2 路线。
- `results/ising_tc_wolff_v1`：服务器完成的 35 点 Wolff 临界扫描、原始 bin、清单和 Binder 图。
- `results/ising_tc_wolff_audit_v1`：不改动原始结果的严格重分块复核、保守交点及校验账本。
- `results/ising_tc_wolff_scaling_v1`：固定精确临界温度的磁化与磁化率标度检查，以及仅作描述的 Binder collapse。
- `results/sse_beta_pilot_v2`：服务器完成的 16 点 SSE `beta J/L^2` 收敛扫描及修正后的刚度数据。
- `results/one_magnon_high_field_v1`：高场单磁振子谱界、平带和饱和场的本地验证结果。
- `results/flatband_cls_topology_v1`：有限环面单粒子零模与 CLS 拓扑计数。
- `results/lswt_low_temperature_v1`：二次 Goldstone 模的低温 LSWT 热力学及数值积分复核。
- `results/sse_dimer_validation_v1`：正式 SSE 源码对有限温精确二聚体乘积系的独立基准。
- `results/ising_l2_exact_validation_v1`：目标 Ising 图的 `2^20` 构型精确枚举和两种更新算法对照。
- `results/sse_fss_v1`：正式 SSE 尺寸序列；截至 2026-09-03 23:30 已验收 12/14 个任务，等待服务器开放后取回两个 `L=16` 副本。

`POSCAR (2).vasp` 已确认是五格点 edge-centered honeycomb / super-honeycomb 晶格。笛卡尔和归一化度量都给出 6 条第一近邻键、配位数 `[3,3,2,2,2]` 与 `2:3` 二分子格。正式计算冻结的权威最近邻图为 `graphs/super_honeycomb_poscar.dat`；`results/poscar2/lattice_graph_nn.dat` 是其逐字节相同的 POSCAR 导出副本，两者 SHA-256 均为 `58BE9C1BC747B0B17F45B31216E096E82CEBFB97874B3AAE5ADCC2DFAE1D65FF`。其中心能带宽度为 `3.6e-15 |t|`，即数值精度内严格平带。

结构图 `results/poscar2/lattice_from_poscar.svg` 由 POSCAR 直接生成。早期标准化示意图只表示图同构关系，不再作为晶体坐标依据。

经典反铁磁 Ising 预扫描使用 `L=8,12` 和 `T/J=0.90...1.10`。两条 Binder 曲线在线性插值下交于 `1.00419(145)`；装饰变换给出的精确值为 `1.0041913`。括号内仅是预扫描统计误差，尚未包含有限尺寸漂移。

五尺寸 Metropolis 加密扫描已证明大尺寸临界慢化会制造漂移和伪交叉，故它只作粗定位。最终 Wolff 扫描使用 `L=8...64`；按 1/2/4/8-bin 重分块取最大统计误差后，最大两尺寸 `L=48,64` 的 Binder 交点为 `Tc/J=1.004225(206)`，与精确值 `1.0041913` 一致。该误差不含温度网格与有限尺寸系统误差，因此只作数值验证。

在固定精确值 `Tc/J=1.0041912981` 处，对 `T/J=1.004,1.008` 两点线性插值后，主拟合 `Lmin=8` 得到 `beta/nu=0.12549`，95% 区间 `[0.12378,0.12717]`，以及 `gamma/nu=1.7584`，95% 区间 `[1.7467,1.7698]`；改用 `Lmin=16` 时分别为 `0.12570 [0.12284,0.12863]` 和 `1.7502 [1.7308,1.7700]`。这些结果与二维 Ising 的 `1/8` 和 `7/4` 一致。Binder collapse 只作描述，因为离散目标函数存在平台；温度线性插值、有限尺寸修正和单副本热化历史尚未形成完整系统误差预算，因此不能把本检查称为独立精密测定临界指数。

目标图 `L=2` 的 `2^20` 个 Ising 构型已完整枚举。在同一温度上，Wolff 的 8 个观测量最大偏差为 `0.550 sigma`，Metropolis 除原生均匀磁化率外的 7 个量最大偏差为 `1.559 sigma`。后者因按 bin 构造连通估计量而有可分辨的有限-bin 偏差，严格标为 `Disagreement`；按每-bin sweep 长度的倒数外推后与精确值相差 `-0.461 sigma`，但该外推不冒充正式程序的原生输出，也不覆盖原生不一致。

Heisenberg SSE 的 16 点扫描覆盖 `L=2,4,6,8` 与 `beta J/L^2=0.25,0.5,1,2`。第一版有限尺寸分析采用固定纵横比 `beta J=2L^2`；它由二次 Goldstone 模式和 pilot 趋势支持，但因没有更大 `beta J/L^2` 点，不能表述为每个有限尺寸、每个观测量都已严格达到零温。`L=2` 是明显例外，至少需补到比例 4。该模型是无符号问题的 Lieb--Mattis 亚铁磁体，二维各向同性 SU(2) 情况下有限温临界点仍为零。

线性自旋波结果进一步表明：亚铁磁基态只有一个 `z=2` 的二次 Goldstone 模式，并有一条 `omega/J=1` 的严格 LSWT 磁振子平带。解析式、路径数据和图位于 `results/lswt_super_honeycomb_v1`；“严格平带”目前只指均匀最近邻模型的线性自旋波层级。

有限环面计数进一步给出：`L^2` 个六边形 CLS 只有 `L^2-1` 个线性独立态；两条非收缩线态补全边心零空间，再加一个顶点全局态后，完整零能简并度为 `L^2+2`。低温 LSWT 则预言 `S=1/2` 时 `u_th/(NJ)=0.18138 t^2+o(t^2)`、`C/(NkB)=0.36276 t+o(t)`，其中 `t=kBT/J`。这只是有限相关长度区间的自旋波交叉行为；二维有限温有序矩修正仍有红外对数发散。

同一图在饱和相的单磁振子扇区还有严格的拉普拉斯平带 `lambda=2`，并给出自旋 `1/2` 的精确饱和场 `h_sat/J=2.5`。这是一项已验证的高场扩展，不属于当前零场静态 SSE 协议；第一版只把它作为后续动力学与磁化研究的线索。

## 使用顺序

```powershell
python scripts\lattice_from_poscar.py analyze "POSCAR (2).vasp" --periodic xy
```

确认自旋元素、度量和近邻壳层之后：

```powershell
python scripts\lattice_from_poscar.py build "POSCAR (2).vasp" --periodic xy --metric cartesian --shells 1 --output results\poscar2\lattice_graph_nn.dat
python scripts\band_graph.py results\poscar2\lattice_graph_nn.dat --hoppings 1 --path hexagonal120 --output-dir results\poscar2\bands_nn
```

随后使用相同的 `lattice_graph.dat` 运行 `ising_graph.exe` 和 `sse_graph.exe`。正式相变扫描需要先确认控制参数、扫描区间、尺寸和临界判据。

正式 SSE 数据全部下载后，从仓库根目录执行：

以下 PowerShell 脚本均要求 PowerShell 7（`pwsh`）。

```powershell
pwsh -NoProfile -File scripts\finalize_sse_fss.ps1
```

生成完整 Figure 3 并人工检查拟合质量后，先只读预览论文回填，再显式应用：

```powershell
python scripts\backfill_sse_manuscript.py --check-only
python scripts\backfill_sse_manuscript.py --apply
```

目标 `N=20` ED 的受控入口为：

```powershell
pwsh -NoProfile -File scripts\run_remote_ed_validation.ps1
```

该入口在北京时间 2026-09-04 05:30 前拒绝 SSH，且截止时间不是可改早的命令参数；之后先只读报告容量、主要进程和 GPU。只有五分钟负载低于可用 CPU 数的 80% 才会以单线程数值库运行，否则停止并报告。当前登记的 SciPy 路线没有等价 GPU 后端，因此不会因看到 GPU 就悄悄改变算法。通过容量门后，它再验证服务器已有 NumPy/SciPy、权威图与上传源码的哈希，并核对四个 $S^z$ 扇区、Lieb--Mattis 多重态、总自旋和 Lanczos 残差。

拟合脚本位于相邻 harness 项目，入口会先核对其 SHA-256；脚本内容变化时会停止，而不会用未登记版本继续拟合。

论文 PDF 的离线构建命令为：

```powershell
pwsh -NoProfile -File scripts\build_manuscript.ps1
```

等待正式 SSE 时可运行完整离线预检；正式结果回填后把阶段改为 `final`：

```powershell
pwsh -NoProfile -File scripts\audit_local_state.ps1 -Stage pre-sse
pwsh -NoProfile -File scripts\audit_local_state.ps1 -Stage final -BuildManuscript
```

格式细节见 `docs/lattice_graph_format.md`。
