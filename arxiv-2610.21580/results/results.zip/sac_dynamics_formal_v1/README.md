# Formal SSE--SAC dynamics archive

- `inputs/`: L=6 and L=12 channel definitions, run inputs, and the registered protocol.
- `source/`: adapted graph-SSE, covariance, SAC, and spectrum-averaging Fortran sources.
- `qmc/`: two independent replicas and 64-bin pooled imaginary-time correlations for each size.
- `sac/L6_primary` and `sac/L12_primary`: merged five-channel primary spectra and status tables.
- `sac/sensitivity`: CLS independent-seed, dominant-delta, and rebin/time-thinning spectra.
- `sac_cls_stability.csv/json`: per-momentum moments and case summaries used in the manuscript.
- `validation.json`: exact-dimer end-to-end validation.
- `checksums.sha256.json`: SHA-256 integrity ledger for every other file.

The Γ total-spin channel is conserved and purely elastic. Other Γ channels with nondecaying endpoints are marked failed/unresolved rather than filled with zero intensity.
