"""Independent finite mathematical fixtures; no physical-model output is read.

Rational fixtures define q, nu, X and W exactly. Nonlinear values use mpmath;
this is high-precision validation, NOT directed-rounding interval certification.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import hashlib, json, platform, random, sys
import mpmath as mp
import numpy as np
from scipy.optimize import linprog

mp.mp.dps = 90
ROOT = Path(__file__).resolve().parent
rng = random.Random(20261029)
checks = []
max_residual = mp.mpf(0)
max_by_category = {}

def m(x):
    return mp.mpf(x.numerator)/x.denominator if isinstance(x,Q) else mp.mpf(x)

def eq(name, a, b, tol=mp.mpf('1e-53')):
    global max_residual
    err=abs(a-b); max_residual=max(max_residual,err)
    category=('finite_K_asymptotic_ratio_deviation' if 'strong asymptotic' in name
              else 'double_precision_LP_discrepancy' if 'minimax LP' in name
              else 'high_precision_exact_identity_residual')
    max_by_category[category]=max(max_by_category.get(category,mp.mpf(0)),err)
    ok=err <= tol*(1+abs(a)+abs(b))
    checks.append((name,bool(ok)))
    if not ok: raise AssertionError((name,mp.nstr(a,50),mp.nstr(b,50),mp.nstr(err,20)))

def ge(name,a,b,tol=mp.mpf('1e-50')):
    ok=a+tol*(1+abs(a)+abs(b))>=b
    checks.append((name,bool(ok)))
    if not ok: raise AssertionError((name,mp.nstr(a,40),mp.nstr(b,40)))

def vec(x):return mp.matrix([m(t) for t in x]) if len(x) else mp.matrix(0,1)
def kl(p,q):return mp.fsum(p[i]*mp.log(p[i]/q[i]) for i in range(len(p)))
def entropy(p,nu):return mp.fsum(p[i]*mp.log(p[i]/nu[i]) for i in range(len(p)))
def colnorm(a):return max(abs(v) for v in a) if len(a) else mp.mpf(0)

def affine_solve(q,nu,W):
    """Primal damped Newton, minimizing F on the affine slice."""
    if W.cols==0:return q.copy(),mp.matrix(0,1),0
    tau=mp.matrix(W.cols,1)
    for iteration in range(120):
        p=q+W*tau
        y=vec([mp.log(p[i]/nu[i]) for i in range(len(q))])
        g=W.T*y
        if colnorm(g)<mp.mpf('1e-70'): return p,tau,iteration
        H=W.T*mp.diag([1/pi for pi in p])*W
        step=mp.lu_solve(H,g)
        old=entropy(p,nu); descent=(g.T*step)[0]
        scale=mp.mpf(1)
        for _ in range(400):
            candidate=q+W*(tau-scale*step)
            if min(candidate)>0:
                new=entropy(candidate,nu)
                # At tiny gradients objective cancellation is expected; Newton
                # remains locally safe when the step and positivity are checked.
                if new<=old-mp.mpf('.01')*scale*descent or descent<mp.mpf('1e-130'):
                    break
            scale/=2
        else:raise RuntimeError('line search')
        tau-=scale*step
    raise RuntimeError('primal convergence')

def dual_active(q,nu,X,active):
    """Separate exponential-family moment match on active states."""
    n=len(q); rr=X.cols-1; mass=mp.fsum(q[i] for i in active)
    target=vec([mp.fsum(q[i]*X[i,k+1] for i in active)/mass for k in range(rr)])
    theta=mp.matrix(rr,1)
    def evaluate(th):
        lw=[mp.log(nu[i])+mp.fsum(X[i,k+1]*th[k] for k in range(rr)) for i in active]
        mm=max(lw); weights=[mp.exp(v-mm) for v in lw]; total=mp.fsum(weights)
        prob=[v/total for v in weights]
        means=vec([mp.fsum(prob[j]*X[i,k+1] for j,i in enumerate(active)) for k in range(rr)])
        obj=mm+mp.log(total)-(th.T*target)[0] if rr else mm+mp.log(total)
        return prob,means,obj
    for _ in range(120):
        prob,means,obj=evaluate(theta)
        g=means-target
        if rr==0 or colnorm(g)<mp.mpf('1e-72'):break
        covariance=mp.matrix(rr,rr)
        for k in range(rr):
            for l in range(rr):
                covariance[k,l]=mp.fsum(prob[j]*(X[i,k+1]-means[k])*(X[i,l+1]-means[l]) for j,i in enumerate(active))
        step=mp.lu_solve(covariance,g); desc=(g.T*step)[0]; scale=mp.mpf(1)
        for _ in range(400):
            _,_,new=evaluate(theta-scale*step)
            if new<=obj-mp.mpf('.01')*scale*desc or desc<mp.mpf('1e-130'):break
            scale/=2
        theta-=scale*step
    else:raise RuntimeError('dual convergence')
    out=q.copy()
    for j,i in enumerate(active):out[i]=mass*prob[j]
    return out

def range_envelope(R):
    if abs(R)<mp.mpf('1e-80'):return mp.mpf(0)
    a=-mp.expm1(-R)
    return R/a-1+mp.log(a/R)

def model_from_z(nu,z):
    mm=max(z); w=[nu[i]*mp.exp(z[i]-mm) for i in range(len(nu))]; total=mp.fsum(w)
    return vec([v/total for v in w])

def bracket_checks(label,q,nu,X,W,tau,pX):
    # Make a rational approximate iterate along the exact rational affine slice.
    testr=[Q(mp.nstr(mp.mpf('.73')*t,18)) for t in tau]
    a=q+W*vec(testr)
    ge(label+' positivity',min(a),0)
    for k in range(X.cols):eq(label+' retained moment '+str(k),(X.T*a)[k],(X.T*q)[k])
    y=vec([mp.log(a[i]/nu[i]) for i in range(len(q))])
    # Feature-space Euclidean projection; not a fitted KL optimum.
    z=X*mp.lu_solve(X.T*X,X.T*y)
    pz=model_from_z(nu,z)
    lower=entropy(q,nu)-entropy(a,nu); upper=kl(q,pz)
    width=kl(a,pz); Dmin=kl(q,pX)
    eq(label+' robust bracket identity',upper-lower,width)
    eq(label+' root residual correction',lower,kl(q,a)-(vec(testr).T*W.T*y)[0])
    ge(label+' lower',Dmin,lower);ge(label+' upper',upper,Dmin)
    e=y-z;R=max(e)-min(e)
    eq(label+' logmgf',width,mp.fsum(a[i]*e[i] for i in range(len(q)))+mp.log(mp.fsum(a[i]*mp.exp(-e[i]) for i in range(len(q)))))
    ge(label+' Hoeffding',R*R/8,width);ge(label+' trivial range',R,width)
    ge(label+' sharp range',range_envelope(R),width)
    return {'lower':str(lower),'upper':str(upper),'width':str(width),'R':str(R)}

fixture_rows=[]
for n in range(3,9):
 for rank in range(1,min(3,n-1)+1):
  for rep in range(2):
    raw=[rng.randrange(1,18) for _ in range(n)]; qrat=[Q(a,sum(raw)) for a in raw]
    nurat=[Q(rng.randrange(1,9),rng.randrange(1,7)) for _ in range(n)]
    xx=[Q(i,n-1) for i in range(n)]
    xrat=[[xx[i]**j for j in range(rank)] for i in range(n)]
    basis=[]
    for j in range(rank,n):
        w=[Q(0) for _ in range(n)];w[j]=Q(1)
        for i in range(rank):
            lag=Q(1)
            for k in range(rank):
                if k!=i:lag*=(xx[j]-xx[k])/(xx[i]-xx[k])
            w[i]=-lag
        for k in range(rank):
            assert sum(xrat[i][k]*w[i] for i in range(n))==0
            checks.append(('exact rational anchor annihilation',True))
        assert sum(v!=0 for v in w)<=rank+1
        checks.append(('support <= rank+1',True));basis.append((j,w))
    rng.shuffle(basis)
    q=vec(qrat);nu=vec(nurat);X=mp.matrix([[m(t) for t in row] for row in xrat])
    Vall=mp.matrix([[m(basis[k][1][i]) for k in range(len(basis))] for i in range(n)])
    eigvals,_=mp.eigsy(Vall.T*Vall); sigma2=min(eigvals)
    pX=dual_active(q,nu,X,list(range(n))); Dmin=kl(q,pX)
    previous=q.copy();previousB=mp.mpf(0); layers=[]
    for ell in range(1,len(basis)+1):
        W=mp.matrix([[m(basis[k][1][i]) for k in range(ell)] for i in range(n)])
        p,tau,iterations=affine_solve(q,nu,W)
        dual=dual_active(q,nu,X,list(range(rank))+[z[0] for z in basis[:ell]])
        label=f'n{n}r{rank}rep{rep}l{ell}'
        for i in range(n):eq(label+' independent affine/dual '+str(i),p[i],dual[i])
        B=kl(q,p);eq(label+' entropy',B,entropy(q,nu)-entropy(p,nu))
        eq(label+' increment',B-previousB,kl(previous,p))
        eq(label+' full gap',Dmin-B,kl(p,pX))
        ge(label+' monotone',B,previousB)
        y=vec([mp.log(p[i]/nu[i]) for i in range(n)])
        for c in W.T*y:eq(label+' stationarity',c,0)
        allc=Vall.T*y
        ge(label+' conditioned frame gap',(allc.T*allc)[0]/(4*sigma2),Dmin-B)
        # Independent anchor interpolation: evaluate the polynomial matching y
        # on anchor rows, then compare each residual to its exact circuit.
        XI=mp.matrix([[X[i,j] for j in range(rank)] for i in range(rank)])
        zanchor=X*mp.lu_solve(XI,vec([y[i] for i in range(rank)]))
        ea=y-zanchor
        for k,(idx,_) in enumerate(basis):eq(label+' anchor residual',ea[idx],allc[k])
        eps=max(abs(t) for t in allc)
        ge(label+' anchor residual range',2*eps,max(ea)-min(ea))
        ge(label+' anchor contrast KL gap',eps*eps/2,Dmin-B)
        approx=bracket_checks(label,q,nu,X,W,tau,pX)
        layers.append({'ell':ell,'B':str(B),'Dmin':str(Dmin),'iterations':iterations,'approximate_iterate_bracket':approx})
        previous=p;previousB=B
    eq(label+' finite saturation',previousB,Dmin)
    transform=mp.eye(len(basis))
    for k in range(len(basis)):transform[k,k]=k+2
    if len(basis)>1:transform[0,-1]=mp.mpf('.3')
    reparam,_,_=affine_solve(q,nu,Vall*transform)
    for i in range(n):eq(label+' basis-change invariance',reparam[i],previous[i])
    fixture_rows.append({'n':n,'rank':rank,'rep':rep,'layers':layers})

# Explicit zero-gain/synergy and stale-coordinate example.
q=vec([Q(45,100),Q(45,100),Q(10,100)]);nu=vec([1,1,1]);u=vec([Q(1,2),Q(-1,2),0]);v=vec([Q(1,4),Q(1,4),Q(-1,2)])
w2=vec([Q(1,2),0,Q(-1,2)])
p1,_,_=affine_solve(q,nu,u);p2,_,_=affine_solve(q,nu,w2)
Dmin=kl(q,vec([Q(1,3)]*3));B2=kl(q,p2)
eq('zero standalone gain',kl(q,p1),0);ge('positive synergy',Dmin-B2,mp.mpf('1e-4'))
stale=vec([Q(3625,10000),Q(3625,10000),Q(275,1000)])
ge('stale scalar update violates previous contrast',abs((w2.T*vec([mp.log(x) for x in stale]))[0]),mp.mpf('.01'))
counter={'q':[str(x) for x in q],'B_w1':str(kl(q,p1)),'B_w2':str(B2),'joint_Dmin':str(Dmin),'marginal_w1_after_w2':str(Dmin-B2),'stale_update':[str(x) for x in stale]}
bad_basis=[]
for es in ['.1','.01','.001','.00001','.0000001']:
    eps=mp.mpf(es);vv=(u+eps*v)/(1+eps/2);p,_,_=affine_solve(q,nu,vv)
    contrast=(vv.T*vec([mp.log(x) for x in q]))[0]
    eq('near parallel contrast',contrast,eps*mp.log(mp.mpf('4.5'))/(2*(1+eps/2)))
    B=kl(q,p);bad_basis.append({'epsilon':es,'B_best_single_over_Dmin':str(B/Dmin),'omitted_normalized_contrast':str(contrast)})
ge('bad basis can have tiny best individual fraction',mp.mpf('1e-12'),m(bad_basis[-1]['B_best_single_over_Dmin']))
qa=vec([Q(3,5),Q(2,5)]);aa=vec([Q(2,5),Q(3,5)]);uniform=vec([Q(1,2)]*2)
ge('approximate-root D is not lower',kl(qa,aa),kl(qa,uniform)+mp.mpf('.01'))
eq('safe entropy value at swapped probabilities',entropy(qa,vec([1,1]))-entropy(aa,vec([1,1])),0)
qf=vec([Q(9,10),Q(1,10)]);af=vec([Q(9,10)-Q(1,10**8),Q(1,10)+Q(1,10**8)])
ge('approximate moments can violate lower bound',entropy(qf,vec([1,1]))-entropy(af,vec([1,1])),mp.mpf('1e-9'))

# Sharp range envelope, constructed independently as a Bernoulli model.
range_rows=[]
for rs in ['.001','.1','1','3','10','100']:
    R=mp.mpf(rs); high=1/(-mp.expm1(-R))-1/R
    a=vec([1-high,high]);z=vec([0,-R]);p=model_from_z(a,z)
    eq('sharp two-point range envelope',kl(a,p),range_envelope(R))
    ge('envelope below Hoeffding',R*R/8,range_envelope(R));ge('envelope below R',R,range_envelope(R))
    range_rows.append({'R':rs,'h':str(range_envelope(R))})

# Star asymptotics: independent exact-class calculation, not benchmark import.
star_rows=[]
with mp.workdps(240):
 for count in [4,6,8,16]:
  for ks in ['12','48','96']:
    K=mp.mpf(ks);t=mp.exp(-2*K);b=mp.mpf(2)*(count-2)/(count-1)
    c=[mp.mpf(comb(count,j))/(2 if 2*j==count else 1) for j in range(count//2+1)]
    powers=[mp.mpf(j)*(count-j)/(count-1) for j in range(count//2+1)]
    target=count*t/(1+t)**2
    def pair(z):
        weights=[c[j]*z**powers[j] for j in range(len(c))];total=mp.fsum(weights)
        prob=vec([x/total for x in weights])
        return prob,mp.fsum(prob[j]*powers[j] for j in range(len(c)))
    lo=mp.mpf(0);hi=2*t
    while pair(hi)[1]<target:hi*=2
    for _ in range(720):
        mid=(lo+hi)/2
        if pair(mid)[1]>target:hi=mid
        else:lo=mid
    z=(lo+hi)/2;p,_=pair(z)
    qq=vec([c[j]*(t**j+t**(count-j))/(1+t)**count for j in range(len(c))])
    eq('star target normalized',mp.fsum(qq),1,mp.mpf('1e-200'))
    eq('star pair moment',mp.fsum(p[j]*powers[j] for j in range(len(c))),target,mp.mpf('1e-200'))
    D=kl(qq,p);TV=mp.fsum(abs(qq[j]-p[j]) for j in range(len(c)))/2
    c2=c[2];ratioD=D/(c2*t**b);ratioTV=TV/(b*c2*t**b)
    if ks=='96':
        eq('fixed-m KL strong asymptotic',ratioD,1,mp.mpf('1e-6'))
        eq('fixed-m TV strong asymptotic',ratioTV,1,mp.mpf('1e-6'))
    star_rows.append({'m':count,'K':ks,'Dmin':mp.nstr(D,60),'TV_at_KLopt':mp.nstr(TV,60),'KL_ratio_to_asymptotic':mp.nstr(ratioD,40),'TV_ratio_to_asymptotic':mp.nstr(ratioTV,40)})

# Minimax checked by an independently formulated uniform-approximation LP.
lp_rows=[]
for count in [4,6,8,10,16]:
 for K in [0,.1,.5,1.,3.,12.]:
    ss=np.arange(0,count+1,2,dtype=float);xx=(ss/count)**2
    yy=np.logaddexp(K*ss,-K*ss)-np.log(2.)
    chord=float(np.max(yy-xx*yy[-1]))
    A=np.concatenate([np.column_stack([-xx,-np.ones(len(xx)),-np.ones(len(xx))]),np.column_stack([xx,np.ones(len(xx)),-np.ones(len(xx))])])
    rhs=np.concatenate([-yy,yy])
    fit=linprog([0,0,1],A_ub=A,b_ub=rhs,bounds=[(None,None),(None,None),(0,None)],method='highs')
    if not fit.success:raise RuntimeError(fit.message)
    eq('independent minimax LP',mp.mpf(chord),mp.mpf(2*fit.fun),mp.mpf('1e-10'))
    lp_rows.append({'m':count,'K':K,'chord_delta':chord,'LP_oscillation':2*fit.fun})

result={
 'status':'pass','all_checks_passed':all(ok for _,ok in checks),'check_count':len(checks),
 'independence':'Primal affine-entropy and separately implemented exponential moment matching; no physical benchmark or historical empirical result imports. Chord formula compared with independent uniform-approximation LP.',
 'precision':{'generic_mpmath_dps':90,'star_mpmath_dps':240,'directed_rounding_interval_enclosure':False,'inputs':'exact rational fixtures; nonlinear validation is high precision'},
 'scope_flags':{'new_empirical_effects_computed':False,'approximate_root_D_is_not_treated_as_lower_bound':True,'exact_moment_feasibility_is_required_by_theorem':True,'large_m_uniform_limit_claimed':False,'TV_is_separately_optimized':False},
 'seed':20261029,'fixture_count':len(fixture_rows),'max_recorded_equality_residual':str(max_residual),
 'max_residual_by_category':{k:str(v) for k,v in max_by_category.items()},
 'fixtures':fixture_rows,'counterexample_synergy':counter,'near_parallel_basis':bad_basis,'sharp_range':range_rows,'star_asymptotics':star_rows,'minimax_LP':lp_rows,
 'versions':{'python':sys.version,'platform':platform.platform(),'mpmath':mp.__version__,'numpy':np.__version__},
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
}
out=ROOT/'mathematical_checks.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','check_count','fixture_count','max_recorded_equality_residual']}))
