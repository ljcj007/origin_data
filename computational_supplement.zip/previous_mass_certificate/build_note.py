"""Build the bilingual proof component and standalone HTML, without manuscript edits."""
from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib
import html
import re

ROOT = Path(__file__).resolve().parent
blocks = []

def block(kind, en, zh, tex=None):
    b = {"id": f"MC{len(blocks)+1:03d}", "type":kind, "en":en, "zh":zh}
    if tex is not None:
        b["tex"] = tex
        b["equation"] = {"tex":tex}
    blocks.append(b)

def eq(tex):
    block("eq", "", "", tex)

block("h2", "A mass-aware certificate for target-first KL divergence", "考虑概率质量的目标在前 KL 散度证书")
block("p",
 r"A large logarithmic obstruction can be concentrated on rare states. We therefore convert a sparse contrast into a KL lower bound using the actual target probabilities. The Pythagorean relation used below is classical information-projection geometry, not a new identity [REF:csiszar2004]. The role of the construction is a one-dimensional, mass-aware calculation. All logarithms are natural; KL is measured in nats.",
 r"较大的对数阻碍可能集中在罕见状态上。因此，我们使用实际目标概率，把稀疏对比转换为 KL 下界。下文的勾股关系属于经典信息投影几何，并非新的恒等式 [REF:csiszar2004]。此构造的用途是把计算化为一维，并纳入所涉状态的概率质量。全文使用自然对数，KL 的单位为 nat。")
block("h3", "1. Exact bound for a single logarithmic constraint", "1. 单个对数约束下的精确下界")
block("p",
 r"Let \(n\ge2\), let \(q\in(0,1)^n\) satisfy \(\sum_iq_i=1\), and let \(w\in\mathbb R^n\setminus\{0\}\) satisfy \(\sum_iw_i=0\). For finite \(A\in\mathbb R\), define the positive constrained family below. The target distribution \(q\) is always the first argument of KL. No normalization of \(w\) is required in this proposition.",
 r"设 \(n\ge2\)，\(q\in(0,1)^n\) 且 \(\sum_iq_i=1\)；设非零向量 \(w\in\mathbb R^n\setminus\{0\}\) 满足 \(\sum_iw_i=0\)。对任意有限实数 \(A\)，定义以下严格正概率约束族。KL 的第一个参数始终是目标分布 \(q\)。本命题不要求 \(w\) 具有特定范数。")
eq(r"""\mathcal E_A=\left\{p\in(0,1)^n:\ \sum_i p_i=1,\quad
\sum_iw_i\log\frac{p_i}{q_i}=A\right\},
\qquad D(q\Vert p)=\sum_iq_i\log\frac{q_i}{p_i}.""")
block("p",
 r"Proposition 1. The following open interval is nonempty. There is a unique \(\tau\) in it satisfying the scalar equation below, and \(p^*=q+\tau w\) is a strictly positive normalized probability vector.",
 r"命题 1。以下开区间非空。其中存在唯一的 \(\tau\) 满足下述标量方程，且 \(p^*=q+\tau w\) 为严格正且归一化的概率向量。")
eq(r"""\begin{gathered}
I=(\tau_-,\tau_+),\qquad
\tau_-=\max_{w_i>0}\frac{-q_i}{w_i}<0,\qquad
\tau_+=\min_{w_i<0}\frac{-q_i}{w_i}>0,\\
F(\tau)=\sum_iw_i\log\left(1+\frac{\tau w_i}{q_i}\right)=A.
\end{gathered}""")
block("p",
 r"For every \(p\in\mathcal E_A\), the exact identity below holds. Thus \(B(q,w,A)\) is the minimum of \(D(q\Vert p)\) over this single-constraint family, uniquely attained at \(p^*\). For an original model family \(\mathcal P\subseteq\mathcal E_A\), it is a lower bound. It need not equal the original family's minimum: attained equality requires \(p^*\in\mathcal P\); equality of an unattained infimum requires that feasible model distributions approach \(p^*\).",
 r"对每个 \(p\in\mathcal E_A\)，均有以下精确恒等式。因此，\(B(q,w,A)\) 是该单约束族中 \(D(q\Vert p)\) 的最小值，并仅在 \(p^*\) 处达到。对原始模型族 \(\mathcal P\subseteq\mathcal E_A\)，它是下界，但不一定等于原族的最小误差：若等号被达到，则必须有 \(p^*\in\mathcal P\)；若下确界相等但未被达到，则原族中必须存在趋近 \(p^*\) 的分布序列。")
eq(r"""D(q\Vert p)=D(q\Vert p^*)+D(p^*\Vert p),\qquad
B(q,w,A)=D(q\Vert q+\tau w).""")
block("p",
 r"Proof of existence and uniqueness. A nonzero zero-sum vector has both positive and negative coordinates, so the interval contains zero and has finite endpoints. Normalization follows from \(\sum_iw_i=0\). On the interval the derivative is strictly positive:",
 r"存在唯一性的证明。非零零和向量同时含有正、负分量，故该区间含零且两端有限。归一化由 \(\sum_iw_i=0\) 得到。在区间内，以下导数严格为正：")
eq(r"""F'(\tau)=\sum_i\frac{w_i^2}{q_i+\tau w_i}>0.""")
block("p",
 r"As \(\tau\downarrow\tau_-\), a coordinate with positive \(w_i\) vanishes while all coordinates with negative \(w_i\) stay positive; hence \(F(\tau)\to-\infty\). At the upper endpoint a coordinate with negative \(w_i\) vanishes and \(F(\tau)\to+\infty\). Continuity and strict monotonicity give exactly one solution for every finite \(A\). Its sign is the sign of \(A\). At \(A=0\), \(\tau=0\), \(p^*=q\), and \(B=0\).",
 r"当 \(\tau\downarrow\tau_-\) 时，至少一个 \(w_i>0\) 的分量趋零，而所有 \(w_i<0\) 的分量仍为正，故 \(F(\tau)\to-\infty\)。在上端点，至少一个 \(w_i<0\) 的分量趋零，故 \(F(\tau)\to+\infty\)。连续性和严格单调性说明每个有限 \(A\) 都恰有一解。该解与 \(A\) 同号。当 \(A=0\) 时，\(\tau=0\)、\(p^*=q\)、\(B=0\)。")
block("p",
 r"Proof of the identity and global optimality. The residual after subtracting the two right-hand KL terms is the expression below. It vanishes because \(p\) and \(p^*\) have the same logarithmic contrast. The final KL term is nonnegative, and is zero only when \(p=p^*\). No convexity of \(\mathcal E_A\) is assumed.",
 r"恒等式与全局最优性的证明。从左侧 KL 中减去右侧两项，得到以下残差。由于 \(p\) 与 \(p^*\) 的对数对比相同，残差为零。最后一项 KL 非负，且仅在 \(p=p^*\) 时为零。这里不假设 \(\mathcal E_A\) 为凸集。")
eq(r"""\begin{aligned}
D(q\Vert p)-D(q\Vert p^*)-D(p^*\Vert p)
&=\sum_i(q_i-p_i^*)\log\frac{p_i^*}{p_i}\\
&=-\tau\sum_iw_i\log\frac{p_i^*}{p_i}=0.
\end{aligned}""")
block("p",
 r"Classical attribution. The affine family \(q+\operatorname{span}(w)\) and the corresponding exponential family \(\mathcal E_A\) intersect at \(p^*\). This is the matching linear/exponential-family Pythagorean relation in Csiszár and Shields, Theorem 3.2 and Corollary 3.1, printed p. 442 [REF:csiszar2004]. Their log-base convention changes only the units. The direct calculation above makes the required KL direction explicit.",
 r"经典结果归属。仿射族 \(q+\operatorname{span}(w)\) 与相应指数族 \(\mathcal E_A\) 在 \(p^*\) 处相交。这正是 Csiszár 与 Shields 印刷页 442 的定理 3.2 和推论 3.1 中匹配线性族与指数族的勾股关系 [REF:csiszar2004]。原文的对数底约定只改变单位。上面的直接计算明确了所需的 KL 参数方向。")
block("h3", "2. Exact scaling with the affected probability mass", "2. 与所涉概率质量成比例的精确缩放")
block("p",
 r"Let \(S=\{i:w_i\ne0\}\), \(s=\sum_{i\in S}q_i>0\), and \(r_i=q_i/s\) on \(S\). Put \(\tau=st\). Coordinates outside \(S\) remain exactly equal to \(q_i\); the mass inside \(S\) stays \(s\) because the entries of \(w\) sum to zero. The scalar equation and bound reduce to:",
 r"令 \(S=\{i:w_i\ne0\}\)、\(s=\sum_{i\in S}q_i>0\)，并在 \(S\) 上定义 \(r_i=q_i/s\)。令 \(\tau=st\)。集合 \(S\) 外的概率严格保持为 \(q_i\)；由于 \(w\) 各分量之和为零，\(S\) 内总质量仍为 \(s\)。标量方程和下界化为：")
eq(r"""\sum_{i\in S}w_i\log\left(1+\frac{t w_i}{r_i}\right)=A,
\qquad B(q,w,A)=s\,D(r\Vert r+t w).""")
block("p",
 r"Consequently, keeping \(r,w,A\) fixed makes the exact certificate proportional to \(s\). A global minimum probability is unnecessary. The bound becomes small when the contrast concerns rare states, rather than assigning them a large population-level cost solely because their log probabilities differ greatly.",
 r"因此，在保持 \(r,w,A\) 不变时，精确证书与 \(s\) 成正比。此结果不需要全体状态的最小概率。若对比涉及罕见状态，下界便相应缩小，而不会仅因其对数概率差很大，就赋予其很大的总体误差。")
block("p",
 r"For \(0<s<1\), take \(q=(s/2,s/2,1-s)\) and \(w=(1/2,-1/2,0)\). Direct substitution gives the exact example below. With nonzero fixed \(A\), the bound tends to zero as \(s\to0\), ruling out a universal positive KL bound depending on \(A\) alone, even when \(\|w\|_1=1\).",
 r"对 \(0<s<1\)，取 \(q=(s/2,s/2,1-s)\)、\(w=(1/2,-1/2,0)\)。直接代入得到下述精确例子。在非零 \(A\) 固定时，下界随 \(s\to0\) 而趋零。因此，即使 \(\|w\|_1=1\)，也不存在仅依赖 \(A\) 的普适严格正 KL 下界。")
eq(r"""\begin{gathered}
\tau=s\tanh A,\qquad
p^*=\left(\frac{s}{2}(1+\tanh A),\frac{s}{2}(1-\tanh A),1-s\right),\\
B(q,w,A)=s\log\cosh A.
\end{gathered}""")
block("p",
 r"For fixed positive \(q\) and fixed \(w\), the inverse function theorem at \(A=0\) also gives the local expansion below. It follows from \(F'(0)=C\) and the Taylor expansion of \(-\sum_iq_i\log(1+\tau w_i/q_i)\). The remainder is not uniform as any reference probabilities approach zero.",
 r"对固定的严格正 \(q\) 和固定 \(w\)，在 \(A=0\) 处使用反函数定理，还可得到以下局部展开。它由 \(F'(0)=C\) 以及 \(-\sum_iq_i\log(1+\tau w_i/q_i)\) 的泰勒展开得到。当参考概率趋零时，此余项估计并不一致。")
eq(r"""C=\sum_i\frac{w_i^2}{q_i}>0,\qquad
\tau=\frac{A}{C}+O(A^2),\qquad
B(q,w,A)=\frac{A^2}{2C}+O(A^3).""")
block("h3", "3. A simpler total-variation bound", "3. 较简单的总变差下界")
block("p",
 r"Proposition 2. Assume additionally that \(\|w\|_1=1\), and let \(0<\alpha\le\min_{i\in S}q_i\). For every feasible \(p\), the following bounds hold. The second uses Pinsker's inequality with natural logarithms.",
 r"命题 2。另设 \(\|w\|_1=1\)，并取 \(0<\alpha\le\min_{i\in S}q_i\)。对每个满足约束的 \(p\)，均有以下下界。第二式使用自然对数下的 Pinsker 不等式。")
eq(r"""\operatorname{TV}(q,p)=\frac12\sum_i|q_i-p_i|
\ge\alpha\tanh|A|,\qquad
D(q\Vert p)\ge2\alpha^2\tanh^2 A.""")
block("p",
 r"Proof. Put \(u=\operatorname{TV}(q,p)\), so each \(|p_i-q_i|\le u\). If \(u\ge\alpha\), the first bound is immediate. If \(u<\alpha\), every ratio on \(S\) lies between \(1-u/\alpha\) and \(1+u/\alpha\). The positive and negative parts of \(w\) each have mass \(1/2\). Hence the absolute contrast is at most half the range of the log ratios:",
 r"证明。令 \(u=\operatorname{TV}(q,p)\)，则每个 \(|p_i-q_i|\le u\)。若 \(u\ge\alpha\)，第一式显然成立。若 \(u<\alpha\)，则 \(S\) 上的每个概率比值均介于 \(1-u/\alpha\) 和 \(1+u/\alpha\) 之间。\(w\) 的正、负部分各具有 \(1/2\) 的总质量。因此，对比的绝对值至多为对数比值极差的一半：")
eq(r"""|A|\le\frac12\log\frac{1+u/\alpha}{1-u/\alpha}
=\operatorname{arctanh}(u/\alpha).""")
block("p",
 r"Inverting proves the TV bound, and \(D(q\Vert p)\ge2u^2\) proves the KL bound. The TV inequality is sharp over the stated class: choose \(s=2\alpha\) in the two-coordinate example above, with an unchanged third coordinate when \(\alpha<1/2\), or the two-state simplex when \(\alpha=1/2\). Then \(u=\alpha\tanh|A|\). The Pinsker-derived KL inequality is generally not saturated at finite nonzero \(A\), and is not the exact certificate of Proposition 1.",
 r"取反函数即得 TV 下界，再由 \(D(q\Vert p)\ge2u^2\) 得 KL 下界。TV 不等式在所述对象类中是锐的：在前述双坐标例子中令 \(s=2\alpha\)；若 \(\alpha<1/2\)，保留一个不变的第三坐标；若 \(\alpha=1/2\)，则使用二状态单纯形。此时 \(u=\alpha\tanh|A|\)。由 Pinsker 导出的 KL 不等式一般不会在有限非零 \(A\) 处达到等号，也并非命题 1 的精确证书。")
block("h3", "4. Counterexamples and boundaries", "4. 反例与适用边界")
block("p",
 r"The KL direction cannot be exchanged. For \(q=(0.2,0.3,0.5)\), \(w=(1/2,-1/2,0)\), and \(A=1\), the theorem gives \(p^*=(0.4156265872,0.08437341284,0.5)\). A second feasible point is \(p=(0.5818772220,0.1181227780,0.3)\). The reversed identity below fails. Moreover, another feasible point with total mass \(0.4027604761\) in the first two coordinates has \(D(p\Vert q)=0.1777101470\), below \(D(p^*\Vert q)=0.1969881061\). Thus the theorem's minimizer also cannot be reused for the reversed optimization.",
 r"不能交换 KL 的参数方向。取 \(q=(0.2,0.3,0.5)\)、\(w=(1/2,-1/2,0)\)、\(A=1\)，本定理给出 \(p^*=(0.4156265872,0.08437341284,0.5)\)。另一个可行点为 \(p=(0.5818772220,0.1181227780,0.3)\)。以下颠倒方向的恒等式不成立。此外，保持前两坐标的固定比值、把其总质量改为 \(0.4027604761\) 后，另一可行点的 \(D(p\Vert q)=0.1777101470\)，小于 \(D(p^*\Vert q)=0.1969881061\)。因此，颠倒优化方向时也不能沿用本定理的最优点。")
eq(r"""D(p\Vert q)-D(p\Vert p^*)-D(p^*\Vert q)
=0.07879524244\ne0.""")
block("p",
 r"Strict positivity of \(q\), a nonzero zero-sum \(w\), and finite \(A\) are assumptions. For fixed \(q,w\), letting \(A\to\pm\infty\) sends \(p^*\) to a simplex face and its target-first KL to infinity; every finite \(A\) still has an interior solution. If \(p_i=0\) where \(q_i>0\), target-first KL is infinite, and contrasts involving that zero require a separate definition. No such boundary convention is used here.",
 r"本定理要求 \(q\) 严格正、\(w\) 非零且零和、\(A\) 有限。对固定 \(q,w\)，当 \(A\to\pm\infty\) 时，\(p^*\) 趋向单纯形边界，其目标在前的 KL 趋于无穷；而每个有限 \(A\) 仍有内点解。若 \(q_i>0\) 而 \(p_i=0\)，该方向的 KL 为无穷，涉及该零概率的对比还需要另行定义。这里不使用这类边界约定。")
block("p",
 r"The largest LP log-odds witness need not give the largest mass-aware KL bound. Take the four-state vectors below and the fixed model \(p\propto q e^k\). With only normalization as a control, \(w_R=(1/2,-1/2,0,0)\) maximizes \(w\cdot k\) subject to \(\sum_iw_i=0\) and \(\|w\|_1\le1\). Its contrast is \(A_R=5\). The common-state witness \(w_C=(0,0,1/2,-1/2)\) has the smaller contrast \(A_C=1\).",
 r"最大化 LP 对数比值的证书不一定给出最大的质量加权 KL 下界。取以下四状态向量及固定模型 \(p\propto q e^k\)。仅以归一化作为控制时，\(w_R=(1/2,-1/2,0,0)\) 在 \(\sum_iw_i=0\)、\(\|w\|_1\le1\) 下最大化 \(w\cdot k\)，其对比为 \(A_R=5\)。常见状态证书 \(w_C=(0,0,1/2,-1/2)\) 的对比较小，只有 \(A_C=1\)。")
eq(r"""q=(0.0005,0.0005,0.4995,0.4995),\qquad
k=(5,-5,1,-1).""")
block("p",
 r"Their support masses are \(0.001\) and \(0.999\), respectively. The exact bounds below reverse their ranking. The actual divergence of the specified fixed model is \(0.479797699565\), strictly above both bounds. A score-range LP and a mass-aware KL bound therefore optimize different quantities. This is a mathematical counterexample, not an empirical result.",
 r"二者涉及的参考概率质量分别为 \(0.001\) 和 \(0.999\)。以下精确下界给出了相反的排序。指定固定模型的实际散度为 \(0.479797699565\)，严格大于两个下界。因此，分数极差 LP 与质量加权 KL 下界优化的是不同量。这是数学反例，不是经验数据结果。")
eq(r"""\begin{aligned}
B_R&=0.001\log\cosh5=0.00430689821834,\\
B_C&=0.999\log\cosh1=0.433347049653.
\end{aligned}""")
block("h3", "5. Application to a hidden Ising hub", "5. 隐藏 Ising 中心自旋的应用")
block("p",
 r"For four visible spins coupled equally with dimensionless strength \(J\) to a hidden hub, eliminating the hub gives visible weight \(2\cosh(JM)\), where \(M=\sum_i\sigma_i\). Classes \(|M|=(4,2,0)\) have degeneracies \(g=(2,8,6)\), pair statistic \(H=(M^2-4)/2=(6,0,-2)\), and target class masses \(Q_c\propto g_c\cosh(J|M_c|)\). The symmetric zero-field pair family is \(P_c(\theta)\propto g_c e^{\theta H_c}\). With \(w=(1/8,-1/2,3/8)\), both \(w\cdot\mathbf1\) and \(w\cdot H\) vanish.",
 r"四个可见自旋以相同无量纲强度 \(J\) 耦合到一个隐藏中心自旋时，消去中心得到可见权重 \(2\cosh(JM)\)，其中 \(M=\sum_i\sigma_i\)。三个磁化类 \(|M|=(4,2,0)\) 的简并度为 \(g=(2,8,6)\)，二体统计量为 \(H=(M^2-4)/2=(6,0,-2)\)，目标类概率为 \(Q_c\propto g_c\cosh(J|M_c|)\)。对称零场二体族为 \(P_c(\theta)\propto g_c e^{\theta H_c}\)。取 \(w=(1/8,-1/2,3/8)\)，则 \(w\cdot\mathbf1\) 和 \(w\cdot H\) 均为零。")
eq(r"""\begin{gathered}
w\cdot\log(P/g)=0,\qquad
c=w\cdot\log(Q/g)=K_4,\\
K_4=\frac18\log\cosh(4J)-\frac12\log\cosh(2J),\qquad
w\cdot\log(P/Q)=-K_4=A.
\end{gathered}""")
block("p",
 r"For \(J\ne0\), \(K_4<0\): with \(x=\cosh(2J)>1\), one has \(\cosh(4J)=2x^2-1<x^4\), since \((x^2-1)^2>0\). Thus the equation uses \(A=-K_4>0\), with class masses \(Q\) and the displayed degeneracy factors. For three classes, \(\mathbf1,H\) span \(w^\perp\), so the single constraint exactly characterizes the positive symmetric pair family. The relaxation is therefore saturated in this case.",
 r"当 \(J\ne0\) 时，\(K_4<0\)：令 \(x=\cosh(2J)>1\)，由 \((x^2-1)^2>0\) 得 \(\cosh(4J)=2x^2-1<x^4\)。因此，方程应使用 \(A=-K_4>0\)，概率必须取类质量 \(Q\)，并保留上述简并度因子。三个类别时，\(\mathbf1,H\) 张成 \(w^\perp\)，故单约束恰好刻画严格正的对称二体族。在此例中，松弛下界达到等号。")
block("p",
 r"To cover all pairwise models, a symmetry reduction is necessary. An asymmetric pairwise model's aggregated class masses need not satisfy the displayed contrast. For the unrestricted natural parameter \(\theta\), including fields and all pair couplings, the target-first objective below is convex. The target is invariant under permutations and global spin flip. Averaging \(\theta\) over this group cannot increase the objective and gives zero fields and one common coupling. Hence the unrestricted pairwise infimum equals the symmetric-family infimum. Microscopic KL equals class-mass KL within that symmetric family because both distributions are uniform inside each class.",
 r"若要覆盖所有二体模型，必须先进行对称性归约。不对称二体模型聚合后的类概率不一定满足上述对比。对于包含所有外场和二体耦合的无约束自然参数 \(\theta\)，以下目标在前的目标函数是凸的。目标分布在置换和全局自旋翻转下不变。把 \(\theta\) 在该群上平均不会增加目标值，并给出零外场与单一共同耦合。因此，无约束二体族的下确界等于对称子族的下确界。在该对称子族中，两分布在各类内部均匀，故微观 KL 与类概率 KL 相等。")
eq(r"""D(Q_{\rm micro}\Vert P_\theta)=
\log Z(\theta)-\theta\cdot\mathbb E_{Q_{\rm micro}}T+\mathrm{constant},
\qquad T=\big((\sigma_i)_i,(\sigma_i\sigma_j)_{i<j}\big).""")
block("p",
 r"For six or eight visible spins, the same symmetry reduction applies, but there are more than three classes. A three-class witness annihilating \(\mathbf1,H\) still gives a valid single-constraint lower bound; it generally does not characterize the whole pair family and need not saturate. These are analytic applicability statements. The physical benchmark's measured errors must be reported separately.",
 r"对于六个或八个可见自旋，同样的对称性归约仍成立，但类别多于三个。使 \(\mathbf1,H\) 消失的三类证书仍给出有效的单约束下界；它一般不能刻画整个二体族，因而不一定达到等号。这些是解析适用性结论。物理基准实际计算的误差应另行报告。")
block("p",
 r"Physical interpretation. Eliminating the hub generates dependence beyond the pairwise Hamiltonian. A sparse contrast detects the omitted dependence, while the scalar solve assigns the smallest target-first KL cost consistent with that contrast. The cost is weighted by how often the affected classes occur. It distinguishes an unavoidable algebraic discrepancy in rare classes from a discrepancy that substantially changes the equilibrium distribution.",
 r"物理解说。消去中心自旋会产生超出二体哈密顿量的依赖关系。稀疏对比检测被遗漏的依赖，而标量方程求出与该对比相容的最小目标在前 KL 代价。该代价按相关类别出现的概率加权。因此，它区分了罕见类别中不可避免的代数偏差，与显著改变平衡分布的偏差。")
block("h3", "6. Optional extension to several contrasts", "6. 可选的多个对比推广")
block("p",
 r"Proposition 3. Let \(W\in\mathbb R^{n\times d}\), \(1\le d\le n-1\), have full column rank and satisfy \(\mathbf1^\top W=0\). For every \(A\in\mathbb R^d\), a unique \(\tau\) satisfies \(p^*=q+W\tau>0\) and \(W^\top\log(p^*/q)=A\). For every positive normalized \(p\) with the same vector contrast, the same Pythagorean identity holds. Hence \(p^*\) uniquely minimizes \(D(q\Vert p)\) over the multiple-constraint relaxation.",
 r"命题 3。设 \(W\in\mathbb R^{n\times d}\)，\(1\le d\le n-1\)，其列满秩且 \(\mathbf1^\top W=0\)。对每个 \(A\in\mathbb R^d\)，存在唯一 \(\tau\) 满足 \(p^*=q+W\tau>0\) 及 \(W^\top\log(p^*/q)=A\)。对每个严格正且归一化、具有相同向量对比的 \(p\)，同一勾股恒等式成立。因此，\(p^*\) 是该多约束松弛族中 \(D(q\Vert p)\) 的唯一最小化解。")
block("p",
 r"Proof. The closed domain \(K=\{\tau:q+W\tau\ge0\}\) is compact: its image lies in the probability simplex and \(W\) is injective. It has nonempty interior because \(\tau=0\) is strictly feasible. Minimize the following continuous function on \(K\), using \(0\log0=0\).",
 r"证明。闭域 \(K=\{\tau:q+W\tau\ge0\}\) 为紧集，因为其像位于概率单纯形中，且 \(W\) 是单射。该域内部非空，因为 \(\tau=0\) 严格可行。采用 \(0\log0=0\) 的约定，在 \(K\) 上最小化以下连续函数。")
eq(r"""\Phi_A(\tau)=
\sum_i(q_i+(W\tau)_i)\log\frac{q_i+(W\tau)_i}{q_i}
-A^\top\tau.""")
block("p",
 r"A boundary point cannot minimize it. Moving a fraction \(\varepsilon>0\) toward \(\tau=0\) gives each vanishing probability the value \(\varepsilon q_i\). Their leading contribution is \(\varepsilon\log\varepsilon\sum_{i:p_i=0}q_i<0\); the other changes are \(O(\varepsilon)\). Thus the minimizer is interior. Its gradient and positive-definite Hessian are shown below, proving existence of the required root and uniqueness.",
 r"边界点不可能是最小点。朝 \(\tau=0\) 移动比例 \(\varepsilon>0\) 后，每个原先为零的概率变为 \(\varepsilon q_i\)。这些项的主导贡献为 \(\varepsilon\log\varepsilon\sum_{i:p_i=0}q_i<0\)，其余变化为 \(O(\varepsilon)\)。故最小点位于内部。其梯度及正定 Hessian 如下，证明所需方程有解且唯一。")
eq(r"""\nabla\Phi_A=W^\top\log((q+W\tau)/q)-A,\qquad
\nabla^2\Phi_A=W^\top\operatorname{diag}(1/p^*)W\succ0.""")
block("p",
 r"The Pythagorean residual is \(-\tau^\top W^\top\log(p^*/p)=0\). Nonnegativity of the remaining KL term proves the claimed global optimum. This optional extension can combine independent witnesses and strengthen the bound, but requires a multidimensional solve. It is best kept in an appendix rather than displacing the sparse scalar construction. No new information-geometric principle is claimed.",
 r"勾股关系的残差为 \(-\tau^\top W^\top\log(p^*/p)=0\)。剩余 KL 项非负，故得到所述全局最优性。此可选推广可合并独立证书、增强下界，但需要多维求解。宜将其保留在附录，而不替代稀疏标量构造的主线。这里不主张新的信息几何原理。")
block("h3", "7. Reproducibility and scope of the numerical check", "7. 可复现性与数值核查的范围")
block("p",
 r"The accompanying script uses 90-digit mpmath arithmetic, fixed seed 20261029, and a monotone scalar bisection. It does not import physical-model fitting code. Separate feasible points are constructed in logarithmic coordinates; an independent grid checks the three-state minimum; a separate moment-matching solve checks the symmetric four-visible-spin illustration. All 749 arithmetic checks passed, with maximum recorded residual \(9.783\times10^{-73}\). These checks are not an interval proof, an empirical dataset, or a replacement for the analytic proofs.",
 r"附带脚本使用 90 位 mpmath 算术、固定种子 20261029 和单调标量二分法，不导入物理模型拟合代码。另在对数坐标中独立构造可行点，以独立网格核查三状态最小值，再以单独的矩匹配求解核查四可见自旋对称例子。749 项算术检查全部通过，最大记录残差为 \(9.783\times10^{-73}\)。这些检查并非区间证明、经验数据，也不能替代解析证明。")
block("p",
 r"Prior-source access. The mathematical statement and proof anchor in Theorem 3.2, Corollary 3.1, and Eq. (3.2) of Csiszár and Shields were read in the search-index extract of the author-institution PDF, printed p. 442 [REF:csiszar2004]. Direct reopening timed out; no page-image inspection or full-paper reading is claimed. The saved literature evidence and metadata document that access scope.",
 r"先例来源的访问范围。Csiszár 与 Shields 印刷页 442 的定理 3.2、推论 3.1 及式 (3.2) 的数学陈述和证明锚点，实际读取自作者机构 PDF 的搜索索引节录 [REF:csiszar2004]。直接重新打开超时；未声称目验页面图像或阅读全文。已保存的文献证据和元数据记录了这一访问范围。")

payload = {"schema_version":"1.0","created_utc":datetime.now(timezone.utc).isoformat(),
           "title_en":"A probability-mass-aware KL certificate",
           "title_zh":"考虑概率质量的 KL 证书",
           "scope":"Analytic proofs, counterexamples, and numerical mathematical checks; no empirical result.",
           "reference_keys":["csiszar2004"],"blocks":blocks}
(ROOT/"appendix_blocks.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")

style = "body{max-width:1040px;margin:40px auto;padding:0 24px;font:17px/1.65 Georgia,serif;color:#17212b}h1,h2,h3{font-family:system-ui,sans-serif;line-height:1.25}h2{margin-top:34px}h3{margin-top:32px;font-size:22px}.equation{overflow-x:auto;padding:12px 16px;background:#f4f6f8;border-left:3px solid #385f80}.note{font-size:14px;color:#456}a{color:#20547a}"
mathjax = r"""<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>"""
reference = "https://www.renyi.hu/~csiszar/Publications/Information_Theory_and_Statistics%3A_A_Tutorial.pdf"
for lang,filename in [("en","mass_certificate_proof.html"),("zh","mass_certificate_proof_zh.html")]:
    pieces = [f'<!doctype html><html lang="{lang}"><meta charset="utf-8"><title>{payload["title_"+lang]}</title><style>{style}</style>{mathjax}<body>']
    pieces.append('<p class="note">2026-10-29 · <a href="appendix_blocks.json">Bilingual source</a> · <a href="mathematical_check_results.json">Mathematical checks</a> · <a href="verify_mass_certificate.py">Verification script</a></p>')
    for b in blocks:
        if b["type"] == "eq":
            pieces.append(f'<div class="equation" id="{b["id"]}">\\[{html.escape(b["tex"])}\\]</div>')
        else:
            txt = html.escape(b[lang]).replace("[REF:csiszar2004]",f'<a href="{reference}">[Csiszár–Shields 2004, p. 442]</a>')
            pieces.append(f'<{b["type"]} id="{b["id"]}">{txt}</{b["type"]}>')
    pieces.append("</body></html>")
    (ROOT/filename).write_text("\n".join(pieces),encoding="utf-8")

check = json.loads((ROOT/"mathematical_check_results.json").read_text(encoding="utf8"))
facts = {
 "status":"proved_and_numerically_checked",
 "scope":"No manuscript edits; no new empirical effect; derived finite-probability results only.",
 "assumptions":{"n":"integer >=2","q":"strictly positive probability vector","w":"real nonzero; sum(w)=0","A":"finite real","p":"strictly positive probability vector; w dot log(p/q)=A"},
 "KL_direction":"D(q||p), target/reference first",
 "proposition":{
  "positive_interval":"(max_{w_i>0}(-q_i/w_i), min_{w_i<0}(-q_i/w_i))",
  "root":"sum_i w_i log(1+tau*w_i/q_i)=A",
  "root_derivative":"sum_i w_i^2/(q_i+tau*w_i)>0",
  "endpoint_limits":["-infinity","+infinity"],
  "solution":"pstar=q+tau*w",
  "identity":"D(q||p)=D(q||pstar)+D(pstar||p)",
  "unique_minimizer":"pstar over the full positive single-logcontrast relaxation",
  "original_family_limitation":"Only a bound for a subset. Attained equality iff pstar belongs to that family; infimum equality can also occur by approaching pstar.",
  "A_zero":"tau=0; pstar=q; certificate=0"},
 "mass_scaling":{"support":"S={i:w_i!=0}","s":"sum_S q_i","conditional_reference":"r=q_S/s","tau":"s*t","formula":"B=s*D(r||r+t*w)","fixed_for_scaling":["r","w","A"],"global_min_probability_required":False},
 "local_expansion":{"C":"sum_i w_i^2/q_i","formula":"B=A^2/(2*C)+O(A^3)","limit":"A->0 for fixed q,w; not uniform near q_i=0"},
 "simple_bounds":{"extra_assumptions":["||w||1=1","0<alpha<=min_{w_i!=0}q_i"],"TV":"TV(q,p)>=alpha*tanh(abs(A))","KL":"D(q||p)>=2*alpha^2*tanh(A)^2","TV_sharp":True,"KL_generally_saturated":False},
 "multiple_constraints":{"valid":True,"assumptions":"W full column rank, 1^T W=0; q>0; A in R^d","solution":"pstar=q+W*tau; W^T log(pstar/q)=A","existence":"strict convex potential on compact closure; boundary excluded by epsilon log epsilon decrease","recommendation":"optional appendix, not main contribution"},
 "ising_scope":{"class_order":["absM4","absM2","absM0"],"degeneracy":[2,8,6],"H":[6,0,-2],"w":["1/8","-1/2","3/8"],"contrast":"A=-K4; K4=(logcosh(4J))/8-(logcosh(2J))/2","sign":"K4<0 for J!=0","m4_saturation":"positive 3-class common-coupling pair family has exactly this one logconstraint","all_pairwise_bridge":"Group-average natural parameters, using target symmetry and convex target-first KL, reduces unrestricted pairwise infimum to symmetric pair family.","not_claimed":"Asymmetric pairwise class masses need not satisfy the logcontrast.","m6_m8":"same symmetry reduction; one three-class certificate need not saturate"},
 "counterexamples":{"wrong_KL_direction":check["wrong_KL_direction_counterexample"],"LP_witness_vs_KL_witness":check["logodds_vs_mass_aware_witness_counterexample"]},
 "prior_attribution":{"key":"csiszar2004","status":"standard information-projection Pythagorean specialization; not a new identity or global projection theorem","anchor":"Theorem 3.2 / Corollary 3.1, printed p442, Eq3.2","actual_read_scope":"Primary author's institutional PDF search-index theorem/proof excerpt read; direct reopen timed out; no page-image inspection.","evidence":["../literature/web/physical_search1.json","../literature/web/physical_deep6.json"],"url":reference},
 "numerical_check":{"checks":check["check_count"],"passed":check["passed_count"],"maximum_recorded_residual":check["maximum_recorded_residual"],"precision_digits":check["decimal_precision"],"seed":check["seed"],"is_interval_proof":False},
 "physical_explanation_en":next(x["en"] for x in blocks if x["en"].startswith("Physical interpretation.")),
 "physical_explanation_zh":next(x["zh"] for x in blocks if x["en"].startswith("Physical interpretation.")),
 "artifacts":{},
}
for name in ["appendix_blocks.json","mass_certificate_proof.html","mass_certificate_proof_zh.html","verify_mass_certificate.py","mathematical_check_results.json","build_note.py"]:
    facts["artifacts"][name]={"sha256":hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),"bytes":(ROOT/name).stat().st_size}
(ROOT/"mass_certificate.json").write_text(json.dumps(facts,ensure_ascii=False,indent=2),encoding="utf8")

# Structural checks ensure TeX remains literal and unsafe angle brackets are escaped.
assert len({b["id"] for b in blocks}) == len(blocks)
assert all(b["en"] and b["zh"] for b in blocks if b["type"] != "eq")
assert all(b["tex"] == b["equation"]["tex"] for b in blocks if b["type"] == "eq")
for b in blocks:
    for key in ["en","zh","tex"]:
        value=b.get(key,"")
        assert not any(ord(ch)<32 and ch not in "\n\r" for ch in value), (b["id"],key)
assert len(re.findall(r'id="MC\d+"',(ROOT/"mass_certificate_proof.html").read_text(encoding="utf8"))) == len(blocks)
print(json.dumps({"blocks":len(blocks),"equations":sum(b["type"]=="eq" for b in blocks),"status":"built_and_structure_checked","appendix_sha256":facts["artifacts"]["appendix_blocks.json"]["sha256"]},indent=2))
