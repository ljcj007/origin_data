"""Independent finite-probability checks of the single-contrast KL certificate.

This is a mathematical check, not an empirical experiment or a proof substitute.
Only files in this script's own directory are written. No research result is fit.
"""
from __future__ import annotations

import hashlib
import json
import platform
import random
from datetime import datetime, timezone
from pathlib import Path

import mpmath as mp

mp.mp.dps = 90
ROOT = Path(__file__).resolve().parent
SEED = 20261029
rng = random.Random(SEED)
checks = []
errors = {}


def record(name, passed, residual=None):
    checks.append({"name": name, "passed": bool(passed)})
    if residual is not None:
        val = abs(mp.mpf(residual))
        errors[name] = mp.nstr(val, 25)
    if not passed:
        raise AssertionError((name, residual))


def dot(a, b):
    return mp.fsum(x * y for x, y in zip(a, b))


def kl(q, p):
    return mp.fsum(x * mp.log(x / y) for x, y in zip(q, p))


def tv(q, p):
    return mp.fsum(abs(x - y) for x, y in zip(q, p)) / 2


def contrast(q, p, w):
    return mp.fsum(z * mp.log(y / x) for x, y, z in zip(q, p, w))


def normalize(v):
    total = mp.fsum(v)
    return [x / total for x in v]


def simplex_point(q, w, A):
    """Monotone scalar bisection; no optimization library or Ising code imported."""
    if A == 0:
        return mp.mpf(0), list(q), mp.mpf(0)
    lower = max(-x / z for x, z in zip(q, w) if z > 0)
    upper = min(-x / z for x, z in zip(q, w) if z < 0)
    lo, hi = (mp.mpf(0), upper) if A > 0 else (lower, mp.mpf(0))
    best = None
    for _ in range(400):
        mid = (lo + hi) / 2
        if mid == lo or mid == hi:
            break
        p = [x + mid * z for x, z in zip(q, w)]
        f = contrast(q, p, w)
        if best is None or abs(f - A) < best[0]:
            best = (abs(f - A), mid, p)
        if abs(f - A) < mp.mpf("1e-72"):
            break
        if f < A:
            lo = mid
        else:
            hi = mid
    residual, tau, p = best
    return tau, p, residual


random_rows = []
for case in range(60):
    n = 3 + case % 5
    q = normalize([mp.mpf(rng.randint(1, 15)) for _ in range(n)])
    while True:
        integers = [rng.randint(-3, 3) for _ in range(n - 1)]
        integers.append(-sum(integers))
        norm = sum(abs(x) for x in integers)
        if norm:
            break
    w = [mp.mpf(x) / norm for x in integers]
    A = mp.mpf(rng.choice([-1, 1])) * mp.mpf(rng.randint(1, 12)) / 10
    tau, pstar, residual = simplex_point(q, w, A)
    # Generate an independent feasible point in logarithmic coordinates.
    z0 = [mp.mpf(rng.randint(-10, 10)) / 10 for _ in range(n)]
    coeff = (A - dot(w, z0)) / dot(w, w)
    z = [u + coeff * v for u, v in zip(z0, w)]
    p = normalize([x * mp.exp(t) for x, t in zip(q, z)])
    gap = kl(q, p) - kl(q, pstar) - kl(pstar, p)
    alpha = min(x for x, v in zip(q, w) if v)
    t = tv(q, p)
    prefix = f"random_{case:02d}"
    record(prefix + "_root", residual < mp.mpf("1e-60"), residual)
    record(prefix + "_positive", min(pstar) > 0)
    record(prefix + "_normalization", abs(mp.fsum(pstar) - 1) < mp.mpf("1e-80"))
    record(prefix + "_sign", mp.sign(tau) == mp.sign(A))
    record(prefix + "_feasible_independent_point", abs(contrast(q, p, w) - A) < mp.mpf("1e-80"))
    record(prefix + "_identity", abs(gap) < mp.mpf("1e-59"), gap)
    record(prefix + "_lower_bound", kl(q, p) + mp.mpf("1e-59") >= kl(q, pstar))
    record(prefix + "_tv_bound", t + mp.mpf("1e-80") >= alpha * mp.tanh(abs(A)))
    record(prefix + "_kl_bound", kl(q, p) + mp.mpf("1e-80") >= 2 * alpha**2 * mp.tanh(A)**2)
    derivative = mp.fsum(v**2 / x for v, x in zip(w, pstar))
    record(prefix + "_derivative_positive", derivative > 0)
    reverse_tau, reverse_p, _ = simplex_point(q, [-v for v in w], -A)
    record(prefix + "_sign_reparametrization", max(abs(x-y) for x,y in zip(reverse_p,pstar)) < mp.mpf("1e-60"))
    scaled_tau, scaled_p, _ = simplex_point(q, [3*v for v in w], 3*A)
    record(prefix + "_scale_reparametrization", max(abs(x-y) for x,y in zip(scaled_p,pstar)) < mp.mpf("1e-60"))
    if case < 10:
        derivative_numeric = mp.diff(lambda h: contrast(q, [x+h*v for x,v in zip(q,w)], w), tau)
        record(prefix + "_independent_derivative", abs(derivative - derivative_numeric) < mp.mpf("1e-65"))
    random_rows.append({"n": n, "A": str(A), "tau": mp.nstr(tau, 24), "certificate": mp.nstr(kl(q,pstar),24)})

# Exact two-coordinate formula, mass scaling, and sharp TV bound.
mass_rows = []
for s_text in ["0.001", "0.1", "0.9"]:
    s, A = mp.mpf(s_text), mp.mpf("1.3")
    q = [s/2, s/2, 1-s]
    w = [mp.mpf(".5"), mp.mpf("-.5"), mp.mpf(0)]
    tau, pstar, residual = simplex_point(q, w, A)
    exact = s * mp.log(mp.cosh(A))
    record("mass_scaling_" + s_text, abs(kl(q,pstar) - exact) < mp.mpf("1e-60"))
    record("outside_unchanged_" + s_text, pstar[2] == q[2])
    record("tv_sharp_" + s_text, abs(tv(q,pstar) - (s/2)*mp.tanh(A)) < mp.mpf("1e-60"))
    mass_rows.append({"support_mass": s_text, "A": str(A), "bound": mp.nstr(exact,30)})

# A=0 has the exact zero solution.
q = [mp.mpf(".2"), mp.mpf(".3"), mp.mpf(".5")]
w = [mp.mpf(".5"), mp.mpf("-.5"), mp.mpf(0)]
tau0, p0, residual0 = simplex_point(q, w, mp.mpf(0))
record("A_zero", tau0 == 0 and p0 == q and kl(q,p0) == 0)

# Independent scalar feasible family: its free coordinate is the total mass of
# the first two states, not tau or the bisection equation above.
A = mp.mpf(1)
tau, pstar, residual = simplex_point(q, w, A)
ratio = (q[0]/q[1]) * mp.exp(2*A)
def p_at_support_mass(s):
    return [s*ratio/(1+ratio), s/(1+ratio), 1-s]
grid = [p_at_support_mass(mp.mpf(j)/1000) for j in range(1,1000)]
grid_min = min(kl(q,p) for p in grid)
record("independent_grid_minimum_at_original_support_mass", abs(grid_min-kl(q,pstar)) < mp.mpf("1e-60"))
p_other = p_at_support_mass(mp.mpf(".7"))
wrong_gap = kl(p_other,q)-kl(p_other,pstar)-kl(pstar,q)
record("reversed_KL_identity_false", abs(wrong_gap) > mp.mpf(".01"))
within = [pstar[0]/mp.mpf(".5"), pstar[1]/mp.mpf(".5")]
within_q = [mp.mpf(".4"),mp.mpf(".6")]
d = kl(within,within_q)
reverse_optimal_mass = mp.exp(-d)/(1+mp.exp(-d))
reverse_p = p_at_support_mass(reverse_optimal_mass)
record("same_pstar_not_reverse_KL_minimizer", kl(reverse_p,q) < kl(pstar,q))
reverse_example = {
    "q":[str(x) for x in q], "w":[str(x) for x in w], "A":str(A),
    "pstar":[mp.nstr(x,30) for x in pstar],
    "other_feasible_p":[mp.nstr(x,30) for x in p_other],
    "swapped_direction_identity_residual":mp.nstr(wrong_gap,30),
    "reverse_KL_optimal_support_mass":mp.nstr(reverse_optimal_mass,30),
    "reverse_KL_at_pstar":mp.nstr(kl(pstar,q),30),
    "reverse_KL_at_better_feasible_p":mp.nstr(kl(reverse_p,q),30),
}

# Strongest log-odds witness need not give strongest mass-aware KL bound.
epsilon = mp.mpf(".001")
q = [epsilon/2,epsilon/2,(1-epsilon)/2,(1-epsilon)/2]
k = [mp.mpf(5),mp.mpf(-5),mp.mpf(1),mp.mpf(-1)]
actual_p = normalize([x*mp.exp(z) for x,z in zip(q,k)])
rare_w = [mp.mpf(".5"),mp.mpf("-.5"),mp.mpf(0),mp.mpf(0)]
common_w = [mp.mpf(0),mp.mpf(0),mp.mpf(".5"),mp.mpf("-.5")]
rare_bound = epsilon*mp.log(mp.cosh(5))
common_bound = (1-epsilon)*mp.log(mp.cosh(1))
record("LP_and_mass_aware_witness_order_reversed", dot(rare_w,k) > dot(common_w,k) and rare_bound < common_bound)
record("strict_bound_for_smaller_family", kl(q,actual_p) > common_bound)
witness_example = {
    "q":[str(x) for x in q], "score_k":[str(x) for x in k],
    "rare_w":[str(x) for x in rare_w], "common_w":[str(x) for x in common_w],
    "LP_max_abs_A":"5", "common_A":"1",
    "rare_certificate":mp.nstr(rare_bound,30),
    "common_certificate":mp.nstr(common_bound,30),
    "actual_KL_to_normalized_q_exp_k":mp.nstr(kl(q,actual_p),30),
}

# Optional multi-constraint identity: choose an interior affine point, then
# obtain A from it. Construct a second point satisfying the log constraints
# through an independently solved linear algebra problem in log coordinates.
q = mp.matrix([mp.mpf(1)/5]*5)
W = mp.matrix([[1,0],[-1,1],[0,-1],[0,0],[0,0]])
tvec = mp.matrix([mp.mpf(".03"),mp.mpf("-.02")])
pstar = q + W*tvec
Avec = W.T * mp.matrix([mp.log(pstar[i]/q[i]) for i in range(5)])
z0 = mp.matrix([mp.mpf(x)/10 for x in [1,2,-1,4,-3]])
z = z0 + W*mp.lu_solve(W.T*W, Avec-W.T*z0)
p = normalize([q[i]*mp.exp(z[i]) for i in range(5)])
gap = kl(list(q),p)-kl(list(q),list(pstar))-kl(list(pstar),p)
record("multi_constraint_identity", abs(gap) < mp.mpf("1e-80"),gap)

# Three-class star example: independently moment-match the symmetric pair
# family. This checks algebraic applicability; it is not the physical benchmark.
J = mp.mpf(".7")
g = [mp.mpf(2),mp.mpf(8),mp.mpf(6)]
mag = [4,2,0]
H = [mp.mpf(6),mp.mpf(0),mp.mpf(-2)]
w = [mp.mpf(1)/8,-mp.mpf(1)/2,mp.mpf(3)/8]
q = normalize([gg*mp.cosh(J*mm) for gg,mm in zip(g,mag)])
c = dot(w,[mp.log(x/gg) for x,gg in zip(q,g)])
A = -c
tau,pstar,residual = simplex_point(q,w,A)
target_moment = dot(q,H)
lo,hi = mp.mpf(-20),mp.mpf(20)
for _ in range(320):
    theta = (lo+hi)/2
    pair_p = normalize([gg*mp.exp(theta*hh) for gg,hh in zip(g,H)])
    if dot(pair_p,H) < target_moment:
        lo = theta
    else:
        hi = theta
pair_p = normalize([gg*mp.exp(((lo+hi)/2)*hh) for gg,hh in zip(g,H)])
record("m4_w_annihilates_constant_and_pair_stat", mp.fsum(w) == 0 and dot(w,H) == 0)
record("m4_K4_sign", c < 0 and A > 0)
record("m4_exact_pair_projection", max(abs(a-b) for a,b in zip(pair_p,pstar)) < mp.mpf("1e-60"))
m4_example = {"status":"mathematical illustration, not empirical benchmark", "J":str(J),
              "K4":mp.nstr(c,30),"A":mp.nstr(A,30),
              "pair_theta":mp.nstr((lo+hi)/2,30),"bound":mp.nstr(kl(q,pstar),30)}

report = {
    "status":"all_checks_passed", "created_utc":datetime.now(timezone.utc).isoformat(),
    "scope":"Deterministic finite probability arithmetic and counterexamples; not empirical validation or formal proof.",
    "seed":SEED,"python":platform.python_version(),"mpmath":mp.__version__,"decimal_precision":mp.mp.dps,
    "check_count":len(checks),"passed_count":sum(x["passed"] for x in checks),
    "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "maximum_recorded_residual":mp.nstr(max(mp.mpf(x) for x in errors.values()),30),
    "random_cases":random_rows,"mass_scaling_examples":mass_rows,
    "wrong_KL_direction_counterexample":reverse_example,
    "logodds_vs_mass_aware_witness_counterexample":witness_example,
    "m4_sign_and_exactness_illustration":m4_example,
    "checks":checks,"residuals":errors,
}
(ROOT/"mathematical_check_results.json").write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
print(json.dumps({"status":report["status"],"checks":len(checks),"max_residual":report["maximum_recorded_residual"],
                  "counterexample":witness_example,"m4":m4_example},indent=2))
