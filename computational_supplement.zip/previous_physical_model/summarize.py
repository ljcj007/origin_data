"""Compact, precision-preserving downstream files; no model recalculation."""
from pathlib import Path
import csv, hashlib, itertools, json, sys
import mpmath as mp
import numpy as np
import scipy
R=Path(__file__).resolve().parent;O=R/'results'
mp.mp.dps=100
rows=json.loads((O/'grid_details.json').read_text())
certs=json.loads((O/'all_triple_certificates.json').read_text())
primary=json.loads((O/'primary_selfcheck.json').read_text())
ind=json.loads((O/'independent_check.json').read_text())
controls=json.loads((O/'controls.json').read_text())
states=list(itertools.product([-1,1],repeat=4))
with (O/'states_m4_probabilities_decimal.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['J','state_index','s1','s2','s3','s4','abs_S','class_index','q_decimal','p_decimal']);w.writeheader()
    for r in [r for r in rows if r['m']==4]:
        for i,s in enumerate(states):
            c=r['class_abs_S'].index(abs(sum(s)));g=r['class_degeneracy'][c]
            w.writerow({'J':r['J'],'state_index':i,**{f's{k+1}':x for k,x in enumerate(s)},'abs_S':abs(sum(s)),'class_index':c,'q_decimal':mp.nstr(mp.mpf(r['class_Q_decimal'][c])/g,90),'p_decimal':mp.nstr(mp.mpf(r['class_P_decimal'][c])/g,90)})
summary={'status':'pass' if primary['status']==ind['status']=='pass' else 'fail','scope':'Deterministic finite equilibrium model; no empirical fitting or confirmatory inference.','dimensionless_coupling':'J in files = K = beta*J_physical in text','grid_points':len(rows),'J_count':len({r['J'] for r in rows}),'certificates':len(certs),'controls':len(controls),'primary_checks_total':primary['checks_total'],'primary_checks_passed':primary['checks_passed'],'primary_max_absolute_error':primary['max_abs_error'],'independent_checks_total':ind['checks_total'],'independent_checks_passed':ind['checks_passed'],'full_optimization_max_probability_error':max(r['max_probability_error'] for r in ind['full_optimization_runs']),'m4_J12':next(r for r in rows if r['m']==4 and r['J']==12),'m4_weak_J1e5':next(r for r in rows if r['m']==4 and r['J']==.00001),'asymptotics':{'weak':{'K4':'-2 K^4','KL':'2 K^8','TV':'K^4','tau':'2 K^4','delta':'4 K^4'},'strong':{'K4':'-K/2+3 log(2)/8+o(1)','KL':'3 exp(-8K/3)','TV':'4 exp(-8K/3)','tau':'8 exp(-8K/3)','delta':'K-3 log(2)/4+o(1)'},'status':'analytic derivations with independent high-precision numerical checks; no fitted exponent'},'larger_star_bounds':{},'versions':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':mp.__version__}}
for m in [6,8]:
    rr=[r for r in rows if r['m']==m and r['J']>0]
    rmin=min(rr,key=lambda r:mp.mpf(r['best_certificate_ratio_decimal']))
    rmax=max(rr,key=lambda r:mp.mpf(r['best_certificate_ratio_decimal']))
    summary['larger_star_bounds'][str(m)]={'minimum_best_bound_ratio':rmin['best_certificate_ratio'],'minimum_at_J':rmin['J'],'maximum_best_bound_ratio_decimal':rmax['best_certificate_ratio_decimal'],'maximum_at_J':rmax['J'],'scope':'fixed positive J grid, not continuous extrema; single-triple relaxations are generally non-saturated'}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=[]
for p in sorted(R.rglob('*')):
    if p.is_file() and p.name not in ['package_manifest.json'] and '__pycache__' not in p.parts:
        files.append({'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'package_manifest.json').write_text(json.dumps({'files':files,'total_bytes':sum(f['bytes'] for f in files),'protocol_sha256':hashlib.sha256((R/'protocol.json').read_bytes()).hexdigest(),'scope':'physical_model only; no legacy manuscript or data modified'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':summary['status'],'files':len(files),'bytes':sum(f['bytes'] for f in files),'primary_checks':primary['checks_total'],'independent_checks':ind['checks_total']}))
