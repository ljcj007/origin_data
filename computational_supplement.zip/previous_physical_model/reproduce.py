"""Deterministic finite Ising-star calculation. No empirical data or fitting."""
from pathlib import Path
import csv, hashlib, itertools, json, math
import numpy as np
import mpmath as mp

ROOT = Path(__file__).resolve().parent
PROTOCOL = json.loads((ROOT / 'protocol.json').read_text(encoding='utf-8'))
mp.mp.dps = PROTOCOL['computation']['primary_precision_decimal_digits']

def M(x):
    return mp.mpf(str(x))

def number(x):
    return float(x)

def exact(x):
    return mp.nstr(x, 90)

def normalized(logweights):
    z = max(logweights)
    weights = [mp.exp(x-z) for x in logweights]
    norm = mp.fsum(weights)
    return [x/norm for x in weights]

def bisect(f, lo, hi):
    # The strictly increasing function has a unique interior root.
    for _ in range(350):
        mid = (lo+hi)/2
        if f(mid) > 0:
            hi = mid
        else:
            lo = mid
    return (lo+hi)/2

def divergence(q, p):
    return mp.fsum(qi*mp.log(qi/pi) for qi, pi in zip(q, p))

def certificate(Q, g, H, triple):
    a,b,c = triple
    v = [M(0)]*len(Q)
    v[a], v[b], v[c] = M(H[b]-H[c]), M(H[c]-H[a]), M(H[a]-H[b])
    vnorm = mp.fsum(abs(x) for x in v)
    w = [x/vnorm for x in v]
    contrast = mp.fsum(wi*mp.log(qi/gi) for wi, qi, gi in zip(w,Q,g))
    if abs(contrast) < M('1e-85'):
        lam = M(0)
    else:
        lo = max(-qi/wi for qi,wi in zip(Q,w) if wi>0)
        hi = min(-qi/wi for qi,wi in zip(Q,w) if wi<0)
        f = lambda t: mp.fsum(wi*mp.log1p(t*wi/qi) for wi,qi in zip(w,Q)) + contrast
        lam = bisect(f, lo, hi)
    P = [qi+lam*wi for qi,wi in zip(Q,w)]
    bound = divergence(Q,P)
    residual = mp.fsum(wi*mp.log(pi/qi) for wi,pi,qi in zip(w,P,Q)) + contrast
    return {'triple': list(triple), 'w': [number(x) for x in w], 'w_decimal': [exact(x) for x in w],
            'contrast': number(contrast), 'contrast_decimal': exact(contrast),
            'lambda': number(lam), 'lambda_decimal': exact(lam),
            'bound': number(bound), 'bound_decimal': exact(bound),
            'support_q_mass': number(mp.fsum(Q[i] for i in triple)),
            'relaxed_P_decimal': [exact(x) for x in P],
            'constraint_residual': number(abs(residual)),
            '_P': P, '_w': w, '_bound': bound}

def homogeneous(m, Jvalue):
    J = M(Jvalue)
    states = np.array(list(itertools.product([-1,1], repeat=m)), dtype=np.int8)
    magnetizations = states.sum(axis=1)
    S = list(range(m,-1,-2))
    g = [math.comb(m,(m-s)//2)*(1 if s==0 else 2) for s in S]
    H = [(s*s-m)//2 for s in S]
    k = [mp.log(mp.cosh(J*s)) for s in S]
    Q = normalized([mp.log(gi)+ki for gi,ki in zip(g,k)])
    target_H = M(m*(m-1))/2*mp.tanh(J)**2
    def pair_mass(a):
        return normalized([mp.log(gi)+a*hi for gi,hi in zip(g,H)])
    if J==0:
        a = M(0)
    else:
        objective = lambda a: mp.fsum(pi*hi for pi,hi in zip(pair_mass(a),H))-target_H
        a = bisect(objective,M(0),max(M(1),J))
    P = pair_mass(a)
    KL = divergence(Q,P)
    TV = mp.fsum(abs(qi-pi) for qi,pi in zip(Q,P))/2
    class_map = [S.index(abs(int(s))) for s in magnetizations]
    q = [Q[i]/g[i] for i in class_map]
    p = [P[i]/g[i] for i in class_map]
    t2q = mp.fsum(qi*int(s[0]*s[1]) for qi,s in zip(q,states))
    t2p = mp.fsum(pi*int(s[0]*s[1]) for pi,s in zip(p,states))
    t4q = mp.fsum(qi*int(np.prod(s[:4])) for qi,s in zip(q,states))
    t4p = mp.fsum(pi*int(np.prod(s[:4])) for pi,s in zip(p,states))
    a_chebyshev = (k[0]-k[-1])/M(H[0]-H[-1])
    residual = [ki-a_chebyshev*hi for ki,hi in zip(k,H)]
    delta = max(residual)-min(residual)
    certs=[]
    for triple in itertools.combinations(range(len(S)),3):
        c = certificate(Q,g,H,triple)
        c.update({'m':m,'J':Jvalue,'bound_over_KL':number(c['_bound']/KL) if J else None,
                  'bound_over_KL_decimal':exact(c['_bound']/KL) if J else None})
        certs.append(c)
    best = max(certs,key=lambda c:c['_bound'])
    row = {'m':m,'J':Jvalue,'n_states':2**m,'n_classes':len(S),'pair_coupling':number(a),
           'pair_coupling_decimal':exact(a),'KL':number(KL),'KL_decimal':exact(KL),
           'TV':number(TV),'TV_decimal':exact(TV),'target_pair_moment':number(t2q),
           'projected_pair_moment':number(t2p),'target_four_moment':number(t4q),
           'projected_four_moment':number(t4p),'four_moment_bias':number(t4p-t4q),
           'chebyshev_pair_coupling':number(a_chebyshev),'min_log_odds_oscillation':number(delta),
           'best_certificate_bound':best['bound'],'best_certificate_triple':best['triple'],
           'best_certificate_ratio':best['bound_over_KL'],
           'best_certificate_ratio_decimal':best['bound_over_KL_decimal'],
           'best_certificate_mass':best['support_q_mass'],
           'class_abs_S':S,'class_degeneracy':g,'class_H':H,
           'class_Q_decimal':[exact(x) for x in Q], 'class_P_decimal':[exact(x) for x in P]}
    if m==4:
        K4 = mp.log(mp.cosh(4*J))/8-mp.log(mp.cosh(2*J))/2
        row.update({'K4':number(K4),'K4_decimal':exact(K4),'tau_decimal':exact(t4p-t4q),
                    'weak_KL_ratio':number(KL/(2*J**8)) if J else None,
                    'weak_TV_ratio':number(TV/J**4) if J else None,
                    'weak_K4_ratio':number(K4/(-2*J**4)) if J else None,
                    'strong_KL_ratio':number(KL/(3*mp.exp(-8*J/3))) if J else None,
                    'strong_TV_ratio':number(TV/(4*mp.exp(-8*J/3))) if J else None,
                    'strong_delta_additive_error':number(delta-(J-3*mp.log(2)/4))})
    checks={'mass_q': abs(mp.fsum(Q)-1),'mass_p':abs(mp.fsum(P)-1),
            'moment_pair':abs(t2p-t2q),'target_t2':abs(t2q-mp.tanh(J)**2),
            'target_t4':abs(t4q-mp.tanh(J)**4),
            'KL_entropy_difference':abs(KL-(-mp.fsum(pi*mp.log(pi) for pi in p)+mp.fsum(qi*mp.log(qi) for qi in q))),
            'certificate_bound_violation':max([M(0)]+[c['_bound']-KL for c in certs]),
            'certificate_constraint':max(M(c['constraint_residual']) for c in certs)}
    if m==4:
        checks.update({'delta_K4':abs(delta-2*abs(K4)), 'TV_tau':abs(TV-(t4p-t4q)/2),
            'certificate_equals_pair':max(abs(x-y) for x,y in zip(best['_P'],P)),
            'quartic':abs((1-mp.tanh(J)**2)*mp.exp(8*a)-4*mp.tanh(J)**2*mp.exp(2*a)-(1+3*mp.tanh(J)**2)),
            'walsh_K4':abs(mp.fsum(M(int(np.prod(s)))*mp.log(qi) for qi,s in zip(q,states))/16-K4)})
    for c in certs:
        for key in ['_P','_w','_bound']: del c[key]
    return row,certs,states,q,p,{key:number(val) for key,val in checks.items()}

def asymmetric_control(J_values, label):
    Ji = [M(x) for x in J_values]
    states = np.array(list(itertools.product([-1,1],repeat=4)),dtype=np.int8)
    logq = [mp.log(mp.cosh(mp.fsum(j*int(si) for j,si in zip(Ji,s)))) for s in states]
    q = normalized(logq)
    T = [int(np.prod(s)) for s in states]
    w = [M(t)/16 for t in T]
    K4 = mp.fsum(wi*mp.log(qi) for qi,wi in zip(q,w))
    if abs(K4)<M('1e-85'):
        lam=M(0)
    else:
        lo=max(-qi/wi for qi,wi in zip(q,w) if wi>0)
        hi=min(-qi/wi for qi,wi in zip(q,w) if wi<0)
        lam=bisect(lambda z:mp.fsum(wi*mp.log1p(z*wi/qi) for qi,wi in zip(q,w))+K4,lo,hi)
    p=[qi+lam*wi for qi,wi in zip(q,w)]
    subset_list=[sub for k in range(5) for sub in itertools.combinations(range(4),k)]
    coeff_q=[]; coeff_p=[]
    for sub in subset_list:
        signs=[int(np.prod(s[list(sub)])) if sub else 1 for s in states]
        coeff_q.append(mp.fsum(si*mp.log(qi) for si,qi in zip(signs,q))/16)
        coeff_p.append(mp.fsum(si*mp.log(pi) for si,pi in zip(signs,p))/16)
    recovered=normalized([mp.fsum(co*(int(np.prod(s[list(sub)])) if sub else 1) for co,sub in zip(coeff_q,subset_list)) for s in states])
    pair_error=max(abs(mp.fsum((pi-qi)*int(s[i]*s[j]) for pi,qi,s in zip(p,q,states))) for i,j in itertools.combinations(range(4),2))
    row={'label':label,'couplings':[float(x) for x in Ji],'K4':number(K4), 'tau':number(lam),
         'KL':number(divergence(q,p)),'TV':number(mp.fsum(abs(qi-pi) for qi,pi in zip(q,p))/2),
         'four_point_q':number(mp.fsum(qi*t for qi,t in zip(q,T))),
         'four_point_p':number(mp.fsum(pi*t for pi,t in zip(p,T))),
         'four_point_theory':number(mp.fprod(mp.tanh(j) for j in Ji)),
         'pair_moment_error':number(pair_error),
         'pair_model_nonpair_log_coefficient':number(max(abs(co) for co,sub in zip(coeff_p,subset_list) if len(sub)>2)),
         'field_only_KL':number(divergence(q,[M(1)/16]*16)),
         'pair_plus_triples_KL':number(divergence(q,p)),
         'order4_recovery_max_error':number(max(abs(x-y) for x,y in zip(q,recovered))),
         'q_log_walsh_coefficients':[number(x) for x in coeff_q],
         'p_log_walsh_coefficients':[number(x) for x in coeff_p],
         'subsets':[list(x) for x in subset_list]}
    return row,states,q,p

def write_csv(path,rows):
    keys=[]
    for r in rows:
        for key in r:
            if key not in keys: keys.append(key)
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader()
        for r in rows:
            writer.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})

def main():
    out=ROOT/'results';out.mkdir(exist_ok=True)
    rows=[];certs=[];check_rows=[]
    for m in PROTOCOL['visible_sizes']:
        q_array=[];p_array=[]
        for J in PROTOCOL['J_grid']:
            row,cs,states,q,p,checks=homogeneous(m,J)
            rows.append(row);certs.extend(cs)
            check_rows.append({'m':m,'J':J,**checks})
            q_array.append([number(x) for x in q]);p_array.append([number(x) for x in p])
        np.savez_compressed(out/f'states_m{m}.npz',states=states,J=np.array(PROTOCOL['J_grid']),q=np.array(q_array),p=np.array(p_array))
        print(f'm={m}: {len(PROTOCOL["J_grid"])} couplings enumerated',flush=True)
    controls=[];qcontrols=[];pcontrols=[]
    cases=[]
    for j in PROTOCOL['controls']['negative_J']: cases.append(([j]*4,f'negative_{j}'))
    for idx,signs in enumerate(PROTOCOL['controls']['gauge_signs']): cases.append(([.8*s for s in signs],f'gauge_{idx}'))
    for i in range(4):
        for d in [-.2,.2]:
            js=[.8]*4;js[i]=float(M('.8')+M(d));cases.append((js,f'perturb_{i}_{d:+g}'))
    for i,js in enumerate(PROTOCOL['controls']['additional_fixed_couplings']):cases.append((js,f'fixed_{i}'))
    for js,label in cases:
        row,states,q,p=asymmetric_control(js,label);controls.append(row)
        qcontrols.append([number(x) for x in q]);pcontrols.append([number(x) for x in p])
    np.savez_compressed(out/'controls_states.npz',states=states,labels=np.array([r['label'] for r in controls]),couplings=np.array([r['couplings'] for r in controls]),q=np.array(qcontrols),p=np.array(pcontrols))
    write_csv(out/'grid_summary.csv',rows)
    write_csv(out/'all_triple_certificates.csv',certs)
    write_csv(out/'controls.csv',controls)
    (out/'grid_details.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    (out/'all_triple_certificates.json').write_text(json.dumps(certs,indent=2)+'\n',encoding='utf-8')
    (out/'controls.json').write_text(json.dumps(controls,indent=2)+'\n',encoding='utf-8')
    threshold=1e-70
    checkvals=[(r['m'],r['J'],k,v) for r in check_rows for k,v in r.items() if k not in ['m','J']]
    failures=[x for x in checkvals if x[3]>threshold]
    checks={'precision_digits':mp.mp.dps,'threshold':threshold,'checks_total':len(checkvals),'checks_passed':len(checkvals)-len(failures),'failures':failures,'max_abs_error':max(x[3] for x in checkvals),'rows':check_rows,'status':'pass' if not failures else 'fail'}
    (out/'primary_selfcheck.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
    manifest={'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'primary_selfcheck':checks['status'],'grid_rows':len(rows),'certificate_rows':len(certs),'controls':len(controls),'interpretation':'Analytic finite-model characterization, not an empirical experiment.'}
    (out/'run_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(manifest),flush=True)

if __name__=='__main__':main()
