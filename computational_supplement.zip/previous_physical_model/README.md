# Exact equilibrium Ising-star calculations

This directory is self-contained apart from Python packages NumPy, SciPy and mpmath. It contains an analytic model characterization and deterministic computation, not empirical data or a confirmatory experiment. Nothing in the existing manuscripts or poetry datasets is modified.

## Reproduce

From any working directory, run these files with Python 3:

```text
python reproduce.py
python independent_check.py
python build_report.py
python summarize.py
```

The primary calculation takes tens of seconds on the reference machine. The protocol was saved before calculation. Its SHA256 is `da013e5feb8bbbf6f4f199db2931c01d36885460b12f4e40511d74ac2297fffc`.

## Model and notation

The microscopic log Boltzmann weight is `J*h*sum(s_i)`, with every spin ±1. **J in files is dimensionless:** it is `K=beta*J_physical` in the bilingual derivation. The star has one hidden hub and `m=4,6,8` visible spins. Its exact visible distribution is `cosh(J*S)/(2^m*cosh(J)^m)`. Every finite J gives full support.

The approximating family contains **all m fields and all m(m−1)/2 visible pair couplings**. The objective is forward KL `D(q || p)`. Strict convexity and symmetry prove that the homogeneous optimum has zero fields and a common pair coupling. Numerical reduction to one scalar does not mean optimization over an artificially restricted family. The independent audit also optimizes all 10,21,36 parameters directly.

The primary four-visible-spin result uses three magnetization classes, in the order `abs(S)=[4,2,0]`; their degeneracies are `[2,8,6]` and pair sums H are `[6,0,-2]`. `Q` and `P` are **total class masses**, not per-state probabilities. The class witness is `(1/8,-1/2,3/8)`. Its per-state version is `w_s=product(s)/16`. The scalar `tau` equals the projected minus target four-point moment. Thus `P=Q+tau*w` and `TV=abs(tau)/2`.

`min_log_odds_oscillation` is the best possible worst-case state log-odds discrepancy over the complete pairwise family. It is generally attained by a different coupling from the forward-KL optimum. It must not be interpreted as KL, total variation, prediction error, or a statistical test.

## Files and numerical precision

- `protocol.json`: immutable pre-calculation settings and scope.
- `reproduce.py`: 100-digit class enumeration, moment-root solution, all triple certificates and 17 fixed controls.
- `independent_check.py`: a separate implementation that imports no primary functions. Explicit hidden-state enumeration, full-parameter optimization, full-feature Chebyshev LP, independent quartic root, gradient checks and the certificate's global KL identity.
- `results/grid_summary.csv` and `grid_details.json`: all 165 model-grid points. JSON stores 90-digit strings for class probabilities, pair coupling, KL/TV and selected diagnostics.
- `results/states_m4.npz`, `states_m6.npz`, `states_m8.npz`: states in lexicographic `[-1,+1]` order, J grid, and all-state q/p arrays. Rows correspond exactly to the saved J grid. Arrays are **float64**; they cannot preserve a weak-coupling probability difference below machine precision. Recover high-precision state probabilities by dividing the corresponding JSON class mass by its stored degeneracy. This is also what `results/states_m4_probabilities_decimal.csv` exports explicitly for all 880 four-spin rows.
- `results/all_triple_certificates.json/.csv`: all 825 triples, including w, contrast, lambda, relaxed distribution, bound, bound/actual-KL ratio and support mass. The 90-digit ratio distinguishes a number rounded to 1.0 from exact equality. At J=0 the ratio 0/0 is undefined and stored as null.
- `results/controls_states.npz`, `controls.json/.csv`: all 17 fixed heterogeneous, negative-coupling and gauge controls; no instances removed.
- `results/primary_selfcheck.json`, `independent_check.json`: final computational checks. These are consistency checks, not independent scientific replications.
- `results/independent_check_initial_optimizer_tolerance.json`: preserved initial audit. A trust-region optimizer sometimes stopped at roughly 1e-9 probability error due to objective-rounding limits. The final audit refines the full moment equations with their analytic Jacobian, without access to the expected solution and without loosening the check tolerance. Raw solver status flags remain in the report.
- `appendix_blocks.json`: PH001–PH040 bilingual supplementary text with shared TeX equations. `build_report.py` is its generation source.
- `report.html`: readable bilingual report and selected exact-model values.
- `results/summary.json`: compact downstream facts and coverage.

For m=6 or m=8, a class triple is only a one-constraint relaxation. Its bound is valid after establishing equality of the full-family and symmetric-family optima. It is **not** a constraint on the aggregated masses of every asymmetric pairwise distribution. The script enumerates all triples; their maximum is a deterministic strengthening of simultaneously valid bounds.

The exact hidden-spin trace and generated quartic coefficient are classical star-square results. The local literature audit in the parent directory identifies Wallace and Zia (1978), Eqs. 4.63–4.65, and the standard KL Pythagorean identity. This package does not assert novelty of those facts.

## Bounds of this work

The microscopic model is a finite equilibrium cluster. It demonstrates an exact separation between an increasing uniform log-odds obstruction and vanishing mass-weighted errors at strong coupling. It is not a thermodynamic phase-transition study, an experimental validation, a new fit to poetry, or evidence of universal performance. No p values, confidence intervals or model-selection searches are performed.
