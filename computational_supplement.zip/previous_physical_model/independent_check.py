"""Independent enumeration/optimization audit; does not import reproduce.py."""
from pathlib import Path
import csv, hashlib, itertools, json, math
import numpy as np
from scipy.optimize import minimize, linprog, root
from scipy.special import logsumexp
import mpmath as mp

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'
mp.mp.dps=95
checks=[]
def check(name,value,tol,context=None):
    checks.append({'name':name,'error':float(value),'tolerance':tol,'pass':bool(float(value)<=tol),'context':context})
def feature_matrix(states,max_order=2):
    subsets=[sub for degree in range(1,max_order+1) for sub in itertools.combinations(range(states.shape[1]),degree)]
    return np.column_stack([np.prod(states[:,sub],axis=1) for sub in subsets]).astype(float),subsets
def full_opt(q,X,start):
    mu=q@X
    def objective(t):return logsumexp(X@t)-mu@t
    def gradient(t):return np.exp(X@t-logsumexp(X@t))@X-mu
    def hessian(t):
        p=np.exp(X@t-logsumexp(X@t));u=p@X
        return X.T@(p[:,None]*X)-np.outer(u,u)
    result=minimize(objective,start,jac=gradient,hess=hessian,method='trust-exact',options={'gtol':2e-12,'maxiter':1200})
    # At the last few ulps of the objective, the trust-region ratio can lose
    # resolution before the moment equations converge. Refine those equations
    # directly, retaining the original status; no reference to expected p.
    result.trust_success=bool(result.success)
    result.trust_message=str(result.message)
    refinement=root(gradient,result.x,jac=hessian,method='hybr',options={'xtol':1e-11})
    result.refinement_success=bool(refinement.success)
    if np.max(abs(gradient(refinement.x)))<np.max(abs(gradient(result.x))):
        result.x=refinement.x
    p=np.exp(X@result.x-logsumexp(X@result.x))
    return result,p,float(np.max(np.abs(gradient(result.x))))
def kl(a,b):return mp.fsum(x*mp.log(x/y) for x,y in zip(a,b))

def main():
    grid=json.loads((OUT/'grid_details.json').read_text())
    protocol=json.loads((ROOT/'protocol.json').read_text())
    rng=np.random.default_rng(20261029)
    optimization_rows=[]
    for m in [4,6,8]:
        arrays=np.load(OUT/f'states_m{m}.npz')
        states=np.array(list(itertools.product([-1,1],repeat=m)),dtype=int)
        X,subsets=feature_matrix(states)
        check('feature_design_full_rank',abs(np.linalg.matrix_rank(np.column_stack([np.ones(len(states)),X]))-(1+X.shape[1])),0,{'m':m})
        for idx,J in enumerate(arrays['J']):
            row=next(r for r in grid if r['m']==m and r['J']==J)
            # Explicit 2^(m+1) visible-hidden states; no cosh formula.
            microscopic=np.array([J*h*np.sum(s) for s in states for h in [-1,1]])
            joint=np.exp(microscopic-logsumexp(microscopic)).reshape(len(states),2)
            q=joint.sum(axis=1)
            check('hidden_state_enumeration',np.max(abs(q-arrays['q'][idx])),3e-14,{'m':m,'J':J})
            p=arrays['p'][idx]
            check('full_feature_moment_stationarity',np.max(abs((q-p)@X)),5e-14,{'m':m,'J':J})
            # Independent full pairwise Chebyshev LP includes all fields/couplings.
            design=np.column_stack([np.ones(len(states)),X])
            lq=np.log(q)
            A=np.vstack([np.column_stack([design,-np.ones(len(states))]),np.column_stack([-design,-np.ones(len(states))])])
            b=np.concatenate([lq,-lq]);c=np.zeros(design.shape[1]+1);c[-1]=1
            lp=linprog(c,A_ub=A,b_ub=b,bounds=[(None,None)]*design.shape[1]+[(0,None)],method='highs')
            check('full_pairwise_minimax_LP_status',0 if lp.success else 1,0,{'m':m,'J':J})
            if lp.success:check('full_pairwise_minimax_equals_secant',abs(2*lp.fun-row['min_log_odds_oscillation']),3e-7,{'m':m,'J':J})
            if J in [0,.1,.5,1,2,4]:
                for init,start in [('zero',np.zeros(X.shape[1])),('fixed_random',rng.normal(0,.15,X.shape[1]))]:
                    fit,pfit,grad=full_opt(q,X,start)
                    err=np.max(abs(pfit-p))
                    check('unrestricted_optimization_probability',err,2e-8,{'m':m,'J':J,'start':init})
                    optimization_rows.append({'m':m,'J':float(J),'start':init,'optimizer_success':bool(fit.trust_success),'message':fit.trust_message,'moment_root_refinement_success':fit.refinement_success,'iterations':int(fit.nit),'max_probability_error':float(err),'gradient_max':grad,'field_abs_max':float(max(abs(fit.x[:m]))),'pair_coupling_spread':float(np.ptp(fit.x[m:]))})
            if J==.5:
                theta=rng.normal(0,.2,X.shape[1]);mu=q@X
                grad=np.exp(X@theta-logsumexp(X@theta))@X-mu
                step=1e-5
                fd=[]
                for i in range(X.shape[1]):
                    e=np.zeros_like(theta);e[i]=step
                    fd.append((logsumexp(X@(theta+e))-mu@(theta+e)-logsumexp(X@(theta-e))+mu@(theta-e))/(2*step))
                check('finite_difference_full_gradient',np.max(abs(grad-fd)),2e-9,{'m':m})
    # Quartic relation checked via a distinct root algorithm and an explicit
    # four-spin moment expression, without using primary scalar moment roots.
    for row in [r for r in grid if r['m']==4]:
        j=mp.mpf(str(row['J']));u=mp.exp(-2*j);eps=u**(mp.mpf(1)/3)
        polynomial=lambda y:y**4-(1-u)**2*y-eps*(1-u+u*u)
        y=mp.findroot(polynomial,(mp.mpf('.9'),mp.mpf('1.8')),tol=mp.mpf('1e-85'),maxsteps=100)
        x=y/eps;a=mp.log(x)/2
        check('independent_quartic_root',abs(a-mp.mpf(row['pair_coupling_decimal'])),1e-75,{'J':row['J']})
        Z=x**4+4*x+3
        P=[x**4/Z,4*x/Z,3/Z]
        Q=[(1+u**4)/(1+u)**4,4*u*(1+u*u)/(1+u)**4,6*u*u/(1+u)**4]
        check('independent_quartic_KL',abs(kl(Q,P)-mp.mpf(row['KL_decimal'])),1e-75,{'J':row['J']})
        if j>0:check('strict_negative_K4',0 if mp.mpf(row['K4_decimal'])<0 else 1,0,{'J':row['J']})
    certificates=json.loads((OUT/'all_triple_certificates.json').read_text())
    for c in certificates:
        row=next(r for r in grid if r['m']==c['m'] and r['J']==c['J'])
        Q=[mp.mpf(x) for x in row['class_Q_decimal']]
        Ppair=[mp.mpf(x) for x in row['class_P_decimal']]
        w=[mp.mpf(x) for x in c['w_decimal']]
        lam=mp.mpf(c['lambda_decimal'])
        P=[q+lam*t for q,t in zip(Q,w)]
        H=row['class_H'];g=row['class_degeneracy']
        context={'m':c['m'],'J':c['J'],'triple':c['triple']}
        check('w_sum',abs(mp.fsum(w)),1e-80,context)
        check('w_H',abs(mp.fsum(t*h for t,h in zip(w,H))),1e-80,context)
        check('w_L1',abs(mp.fsum(abs(t) for t in w)-1),1e-80,context)
        residual=mp.fsum(t*mp.log(p/gi) for t,p,gi in zip(w,P,g))
        check('certificate_log_constraint',abs(residual),1e-70,context)
        bound=kl(Q,P)
        check('certificate_global_KL_identity',abs(kl(Q,Ppair)-bound-kl(P,Ppair)),1e-70,context)
        check('certificate_lower_bound',max(mp.mpf(0),bound-kl(Q,Ppair)),1e-70,context)
    # Fixed asymmetric/gauge controls: direct full 10-parameter optimization.
    ca=np.load(OUT/'controls_states.npz');states=ca['states'];X,_=feature_matrix(states)
    lookup={tuple(s):i for i,s in enumerate(states)}
    controls=json.loads((OUT/'controls.json').read_text())
    for i,(label,js) in enumerate(zip(ca['labels'],ca['couplings'])):
        q=ca['q'][i];p=ca['p'][i]
        logjoint=np.array([h*np.dot(js,s) for s in states for h in [-1,1]])
        marginal=np.exp(logjoint-logsumexp(logjoint)).reshape(16,2).sum(axis=1)
        check('control_hidden_enumeration',np.max(abs(q-marginal)),2e-15,{'label':str(label)})
        fit,pfit,grad=full_opt(q,X,np.zeros(10))
        check('control_full_pair_optimization',np.max(abs(p-pfit)),2e-9,{'label':str(label)})
        controls[i]['independent_full_optimizer_success']=bool(fit.success)
        controls[i]['independent_full_optimizer_error']=float(np.max(abs(p-pfit)))
        X3,_=feature_matrix(states,3)
        f3,p3,g3=full_opt(q,X3,np.zeros(14))
        check('control_add_triples_no_change',np.max(abs(p-p3)),2e-9,{'label':str(label)})
        check('control_degree4_exact_recovery',controls[i]['order4_recovery_max_error'],1e-75,{'label':str(label)})
        if str(label).startswith('gauge') or str(label).startswith('negative'):
            absjs=abs(js)
            signs=np.where(js<0,-1,1)
            logref=np.array([np.logaddexp(np.dot(absjs,s),-np.dot(absjs,s)) for s in states])
            ref=np.exp(logref-logsumexp(logref))
            expected=np.array([ref[lookup[tuple(s*signs)]] for s in states])
            check('gauge_permutation_of_probability',np.max(abs(q-expected)),2e-15,{'label':str(label)})
    weak=next(r for r in grid if r['m']==4 and r['J']==.00001)
    strong=next(r for r in grid if r['m']==4 and r['J']==12)
    for key in ['weak_KL_ratio','weak_TV_ratio','weak_K4_ratio']:
        check('finite_grid_weak_ratio_'+key,abs(weak[key]-1),1e-7,{'J':.00001,'note':'finite-grid consistency, not limit proof'})
    for key in ['strong_KL_ratio','strong_TV_ratio']:
        check('finite_grid_strong_ratio_'+key,abs(strong[key]-1),.005,{'J':12,'note':'finite-grid consistency, not limit proof'})
    report={'status':'pass' if all(x['pass'] for x in checks) else 'fail','checks_total':len(checks),'checks_passed':sum(x['pass'] for x in checks),'failures':[x for x in checks if not x['pass']],'checks':checks,'full_optimization_runs':optimization_rows,'optimization_success_flags':{'trust_success':sum(x['optimizer_success'] for x in optimization_rows),'root_refinement_success':sum(x['moment_root_refinement_success'] for x in optimization_rows),'total':len(optimization_rows),'note':'Trust optimization and independent moment-root refinement flags are recorded separately from accuracy. Initial objective cancellation stopped trust solves near 1e-9 probability error; archived initial audit retained. Root refinement uses only analytic gradient/Hessian, never the expected solution. Global optimality follows from the mathematical proof, not solver flags.'},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),'no_primary_function_imports':True}
    (OUT/'independent_check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    (OUT/'controls_independent_check.json').write_text(json.dumps(controls,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['status','checks_total','checks_passed','failures','optimization_success_flags']},indent=2))

if __name__=='__main__':main()
