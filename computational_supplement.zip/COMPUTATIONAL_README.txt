COMPUTATIONAL SUPPLEMENT — 12 November 2026

Controlled KL bounds from sparse interaction certificates in finite Gibbs models

This package contains the deterministic finite-Gibbs calculations underlying the
current manuscript. It contains no Tang-poetry or graph-ordering datasets. The
previous research archive is preserved separately by the authors.

REPRODUCE THE SCIENCE
Use Python 3 with NumPy, SciPy, mpmath, pandas and matplotlib; pypdf is also used
by the figure export audit. Working from the unzipped package root:

python -B theory/verify_multicertificate.py
python -B previous_mass_certificate/verify_mass_certificate.py
python -B physical_models/compute_hierarchy.py --part homogeneous
python -B physical_models/compute_hierarchy.py --part asymptotic
python -B physical_models/compute_hierarchy.py --part asymmetric
python -B physical_models/independent_check.py
python -B previous_physical_model/reproduce.py
python -B previous_physical_model/independent_check.py
python -B scripts/plot_retained_physical_figures.py
python -B scripts/plot_multicertificate.py

The individual model READMEs specify grids, precision, state ordering, stored
arrays and additional report-generation commands. Full high-precision reruns
may take substantially longer than reading the included outputs. The present
2026-11-12 revision reuses the frozen scientific outputs; it does not claim new
experiments or a new independent replication. Hash comparisons establish their
preservation. Calculation time fields naturally change on a rerun.

KEY FILES
physical_models/protocol.json: fixed multi-certificate protocol.
physical_models/results/: full hierarchy, stopping gaps and asymptotic outputs.
physical_models/data/asymmetric_arrays.npz: 1024-state ten-spin control.
previous_physical_model/results/: four-, six- and eight-spin controls.
theory/verify_multicertificate.py: finite-dimensional identity checks.
previous_mass_certificate/verify_mass_certificate.py: single-contrast checks.
figures/: four current figures, source tables and vector/raster exports.
COMPUTATIONAL_MANIFEST.json: sizes and SHA-256 digests of package members.

All probabilities refer to exactly specified finite equilibrium models. The
calculations are deterministic; no sampling p values or confidence intervals
are inferred. The floating/high-precision outputs are not outward-rounded
interval-arithmetic certificates. The mathematical bounds assume exact real
arithmetic and exact retained moments.

For homogeneous stars, exact symmetry reduces the full retained-family fit to
magnetization classes. The 64-spin calculation does not enumerate 2^64 states.
For unequal ten-spin couplings the full 1024-state space is enumerated; the
preselected 64 contrasts span only a part of the 968-dimensional kernel.
No generic speed advantage, adaptive-selection convergence rate or
thermodynamic-limit result is claimed by this package.
