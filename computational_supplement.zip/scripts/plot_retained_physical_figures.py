"""Plot the fixed finite-state Ising results. No model fitting or new simulation."""
from pathlib import Path
from itertools import combinations
import json, hashlib
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'
OUT.mkdir(exist_ok=True)
DATA=ROOT/'previous_physical_model/results'
df=pd.read_csv(DATA/'grid_summary.csv').sort_values(['m','J'])
tr=pd.read_csv(DATA/'all_triple_certificates.csv').sort_values(['m','triple','J'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_hash={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in [DATA/'grid_summary.csv',DATA/'all_triple_certificates.csv',ROOT/'previous_physical_model/protocol.json']}
BLUE='#0072B2'; ORANGE='#D55E00'; GREEN='#009E73'; INK='#263746'; GREY='#B7BDC3'
W=178/25.4
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
 'font.size':8.3,'axes.labelsize':8.3,'xtick.labelsize':8,'ytick.labelsize':8,
 'axes.titlesize':8.8,'legend.fontsize':7.9,'legend.frameon':False,'mathtext.fontset':'dejavusans',
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,
 'xtick.major.width':.6,'ytick.major.width':.6,'xtick.major.size':3,'ytick.major.size':3,
 'lines.linewidth':1.4,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
XNAME=r'$K=\beta J_{\mathrm{phys}}$'
exports=[]
def label(ax,s,x=-.15,y=1.08):
    ax.text(x,y,s,transform=ax.transAxes,fontsize=10,fontweight='bold',ha='left',va='bottom',color=INK)
def clean(ax):
    ax.tick_params(direction='out')
    ax.set_axisbelow(True)
def export(fig,name,height_mm):
    for ext in ['pdf','svg','png']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=600)
    fig.savefig(OUT/f'{name}_preview.png',dpi=160)
    pdf=PdfReader(OUT/f'{name}.pdf');box=pdf.pages[0].mediabox
    dims=[float(box.width)/72*25.4,float(box.height)/72*25.4]
    assert abs(dims[0]-178)<.01 and abs(dims[1]-height_mm)<.01,dims
    assert '<text' in (OUT/f'{name}.svg').read_text(encoding='utf8')
    exports.append({'id':name,'dimensions_mm':dims,'font_pt':8.3,'files':[{ 'file':f'{name}.{ext}','sha256':sha(OUT/f'{name}.{ext}')} for ext in ['pdf','svg','png']],'preview':f'{name}_preview.png'})
    plt.close(fig)

# Figure 1: a schematic-led composite. The exact trace and the fit are separate arrows.
f=plt.figure(figsize=(W,108/25.4))
gs=f.add_gridspec(2,2,left=.105,right=.977,bottom=.12,top=.94,hspace=.5,wspace=.32,height_ratios=[1.05,1])
a=f.add_subplot(gs[0,:]);a.set_xlim(0,12);a.set_ylim(0,2.75);a.axis('off');label(a,'a',x=-.075,y=1.02)
def network(ax,cx,cy,complete=False):
    corners=[(cx-.72,cy+.55),(cx+.72,cy+.55),(cx+.72,cy-.55),(cx-.72,cy-.55)]
    edges=combinations(range(4),2) if complete else [(i,4) for i in range(4)]
    coords=corners+[(cx,cy)]
    for i,j in edges:
        ax.plot([coords[i][0],coords[j][0]],[coords[i][1],coords[j][1]],color=ORANGE if complete else BLUE,lw=1.2,zorder=1)
    for i,(x,y) in enumerate(corners):
        ax.add_patch(Circle((x,y),.135,facecolor='white',edgecolor=BLUE,lw=1.15,zorder=3))
        ax.text(x,y,r'$s_'+str(i+1)+'$',ha='center',va='center',fontsize=8,zorder=4)
    if not complete:
        ax.add_patch(Circle((cx,cy),.16,facecolor=INK,edgecolor=INK,zorder=3))
        ax.text(cx,cy,r'$h$',color='white',ha='center',va='center',fontsize=8.3,zorder=4)
network(a,1.35,1.3)
network(a,10.65,1.3,True)
a.text(1.35,2.45,'Pairwise microscopic star',ha='center',fontsize=8.5)
a.text(1.35,.2,r'$h,s_i\in\{-1,+1\}$',ha='center',fontsize=8.2)
a.text(10.65,2.45,'Best visible pairwise model',ha='center',fontsize=8.5)
a.text(10.65,.2,r'$p_K\propto\exp[a^*(K)\sum_{i<j}s_i s_j]$',ha='center',fontsize=7.9)
a.add_patch(FancyArrowPatch((2.45,1.3),(4.15,1.3),arrowstyle='-|>',mutation_scale=10,lw=.9,color=INK))
a.text(3.3,1.66,'Trace over $h$',ha='center',fontsize=7.8)
a.text(6,1.56,r'$q_K(s)\propto2\cosh(K\sum_i s_i)$',ha='center',va='center',fontsize=9)
a.text(6,1.05,'Exact visible marginal',ha='center',fontsize=8.3)
a.text(6,.64,'Pair terms + four-spin term',ha='center',fontsize=7.9,color=INK)
a.add_patch(FancyArrowPatch((7.87,1.3),(9.5,1.3),arrowstyle='-|>',mutation_scale=10,lw=.9,color=ORANGE,linestyle='--'))
a.text(8.7,1.66,'KL projection',ha='center',fontsize=7.8,color=ORANGE)
b=f.add_subplot(gs[1,0]);c=f.add_subplot(gs[1,1]);d4=df[(df.m==4)&(df.J<=4)].copy()
for ax,target,proj,title,ylab,letter in [(b,'target_pair_moment','projected_pair_moment','All two-point moments match',r'$\langle s_i s_j\rangle,\;i\ne j$','b'),(c,'target_four_moment','projected_four_moment','Four-point moments differ',r'$\langle s_1s_2s_3s_4\rangle$','c')]:
    ax.plot(d4.J,d4[target],color=BLUE,label=r'Exact marginal $q_K$',zorder=2)
    if letter=='b':ax.plot(d4.J,d4[proj],color=ORANGE,ls='none',marker='o',ms=3.3,mfc='white',mew=.9,markevery=2,label=r'Pairwise fit $p_K$',zorder=3)
    else:ax.plot(d4.J,d4[proj],color=ORANGE,ls='--',label=r'Pairwise fit $p_K$')
    ax.set(xlabel=XNAME,ylabel=ylab,xlim=(0,4),ylim=(-.03,1.04));ax.set_xticks([0,1,2,3,4]);ax.set_yticks([0,.5,1]);ax.set_title(title,pad=7)
    label(ax,letter);clean(ax)
b.legend(loc='lower right',handlelength=1.5,borderaxespad=.2)
row=d4[d4.J==1].iloc[0]
c.annotate(r'$\Delta C_4=0.0984$'+'\nat $K=1$',xy=(1,row.projected_four_moment),xytext=(1.75,.28),arrowprops={'arrowstyle':'-','color':INK,'lw':.6},fontsize=7.8)
export(f,'fig1_physical_star',108)
d4[['m','J','target_pair_moment','projected_pair_moment','target_four_moment','projected_four_moment','four_moment_bias']].to_csv(OUT/'fig1_physical_star_source.csv',index=False)

# Figure 2: distinct physical error measures never share a dual y axis.
f=plt.figure(figsize=(W,132/25.4))
gs=f.add_gridspec(2,6,left=.10,right=.98,bottom=.11,top=.93,wspace=1.15,hspace=.62,height_ratios=[1,1.05])
axs=[f.add_subplot(gs[0,0:2]),f.add_subplot(gs[0,2:4]),f.add_subplot(gs[0,4:6]),f.add_subplot(gs[1,0:3]),f.add_subplot(gs[1,3:6])]
d=df[df.m==4].copy();overview=d[d.J>=.1]
ax=axs[0];ax.plot(d.J,d.min_log_odds_oscillation,color=BLUE)
ref=d[d.J>=.75];ax.plot(ref.J,ref.J-3*np.log(2)/4,color=INK,ls='--',lw=1,label=r'$K-\frac{3}{4}\ln 2$')
ax.set(xlabel=XNAME,ylabel=r'$\delta(K)$ (nats)',xlim=(0,12),ylim=(0,12));ax.set_xticks([0,4,8,12]);ax.set_yticks([0,4,8,12]);ax.set_title('Worst-case log odds');ax.legend(loc='upper left',fontsize=7.4,handlelength=1.2)
for ax,col,title,ylabel,color in [(axs[1],'KL','Forward KL',r'$D_{\min}(K)$ (nats)',ORANGE),(axs[2],'TV','Total variation',r'$\mathrm{TV}(q_K,p_K)$',GREEN)]:
    ax.semilogy(overview.J,overview[col],color=color)
    ax.set(xlabel=XNAME,ylabel=ylabel,xlim=(0,12),ylim=(1e-15,.2));ax.set_xticks([0,4,8,12]);ax.set_yticks([1e-14,1e-10,1e-6,1e-2]);ax.set_title(title)
weak=d[(d.J>0)&(d.J<=.1)].copy();weak['weak_delta_ratio']=weak.min_log_odds_oscillation/(4*weak.J**4)
ax=axs[3]
for col,color,ls,marker,leg in [('weak_delta_ratio',BLUE,'-','o',r'$\delta/(4K^4)$'),('weak_KL_ratio',ORANGE,'--','s',r'$D_{\min}/(2K^8)$'),('weak_TV_ratio',GREEN,':','^',r'$\mathrm{TV}/K^4$')]:
    ax.semilogx(weak.J,weak[col],color=color,ls=ls,marker=marker,ms=3.4,mfc='white',mew=.8,label=leg)
ax.axhline(1,color=INK,lw=.65,ls=(0,(3,3)))
ax.set(xlabel=XNAME,ylabel='Ratio to weak-coupling limit',xlim=(7e-6,.15),ylim=(.88,1.014));ax.set_xticks([1e-5,1e-3,1e-1]);ax.set_yticks([.9,.95,1]);ax.set_title(r'Weak coupling: $K\rightarrow0$');ax.legend(loc='lower left',fontsize=7.6,handlelength=1.7)
strong=d[d.J>=2];ax=axs[4]
ax.plot(strong.J,strong.strong_KL_ratio,color=ORANGE,ls='--',label=r'$D_{\min}/[3e^{-8K/3}]$')
ax.plot(strong.J,strong.strong_TV_ratio,color=GREEN,ls=':',label=r'$\mathrm{TV}/[4e^{-8K/3}]$')
ax.axhline(1,color=INK,lw=.65,ls=(0,(3,3)))
ax.set(xlabel=XNAME,ylabel='Ratio to strong-coupling limit',xlim=(2,12),ylim=(.4,1.025));ax.set_xticks([2,4,8,12]);ax.set_yticks([.4,.6,.8,1]);ax.set_title(r'Strong coupling: $K\rightarrow\infty$');ax.legend(loc='lower right',fontsize=7.6,handlelength=1.8)
for ax,letter in zip(axs,'abcde'):label(ax,letter,x=-.26 if letter in 'abc' else -.16);clean(ax)
export(f,'fig2_physical_limits',132)
d[['m','J','min_log_odds_oscillation','KL','TV','weak_KL_ratio','weak_TV_ratio','strong_KL_ratio','strong_TV_ratio','strong_delta_additive_error']].to_csv(OUT/'fig2_physical_limits_source.csv',index=False)

# Figure 3: plot all prescribed triples; emphasize their maximum, never a selected subset.
f,axs=plt.subplots(1,2,figsize=(W,79/25.4));f.subplots_adjust(left=.105,right=.98,bottom=.20,top=.83,wspace=.27)
cert_checks=[]
for ax,m,color,letter in zip(axs,[6,8],[BLUE,ORANGE],'ab'):
    dat=df[(df.m==m)&(df.J>0)]
    sub=tr[(tr.m==m)&(tr.J>0)]
    for i,(key,z) in enumerate(sub.groupby('triple',sort=True)):
        ax.plot(z.J,z.bound_over_KL,color=GREY,lw=.65,label='Each three-class certificate' if i==0 else None,zorder=1)
    actual=sub.groupby('J').bound_over_KL.max().reindex(dat.J).to_numpy()
    assert np.allclose(actual,dat.best_certificate_ratio.to_numpy(),rtol=1e-12,atol=1e-14)
    cert_checks.append({'m':m,'triples':sub.triple.nunique(),'positive_K':len(dat),'maximum_error':float(np.max(np.abs(actual-dat.best_certificate_ratio.to_numpy())))})
    ax.plot(dat.J,dat.best_certificate_ratio,color=color,lw=1.85,label=r'Best $B_{\max}/D_{\min}$',zorder=3)
    ax.axhline(1,color=INK,ls='--',lw=1,label=r'$m=4$: exact saturation',zorder=2)
    lo=dat.loc[dat.best_certificate_ratio.idxmin()]
    ax.plot(lo.J,lo.best_certificate_ratio,'o',color=color,ms=4,mfc='white',mew=1,zorder=4)
    ax.annotate(f'{lo.best_certificate_ratio:.3f} at $K={lo.J:g}$',xy=(lo.J,lo.best_certificate_ratio),xytext=(4,.48 if m==6 else .38),arrowprops={'arrowstyle':'-','color':color,'lw':.7},color=color,fontsize=8)
    ax.set(xlabel=XNAME,ylabel=r'Certificate / full KL, $B/D_{\min}$',xlim=(0,12),ylim=(-.015,1.055));ax.set_xticks([0,4,8,12]);ax.set_yticks([0,.25,.5,.75,1])
    ax.set_title(f'$m={m}$ visible spins; {sub.triple.nunique()} triples',pad=7);label(ax,letter);clean(ax)
handles,labels=axs[0].get_legend_handles_labels()
f.legend(handles,labels,loc='upper center',bbox_to_anchor=(.54,.995),ncol=3,fontsize=7.7,handlelength=1.6,columnspacing=1.3,borderaxespad=.1)
export(f,'fig3_physical_certificates',79)
tr[tr.m.isin([6,8])][['m','J','triple','bound','bound_over_KL','support_q_mass']].to_csv(OUT/'fig3_physical_certificates_source.csv',index=False)

checks={'created_utc':datetime.now(timezone.utc).isoformat(),'source_hashes':source_hash,'script_sha256':sha(Path(__file__)),'exports':exports,
 'scientific_checks':{'source_grid_rows':len(df),'positive_K_per_m':{str(m):int(((df.m==m)&(df.J>0)).sum()) for m in [4,6,8]},'max_pair_moment_difference_in_exported_numbers':float(abs(df.target_pair_moment-df.projected_pair_moment).max()),'fig1_K1_four_moment_bias':float(row.four_moment_bias),'certificate_maxima':cert_checks,'no_new_fitting_or_simulation':True,'no_pvalues_intervals_or_errorbars':True},
 'visual_status':'pending individual view_image inspection','backend':'Python/matplotlib','all_original_source_hashes_unchanged':all(sha(ROOT/k)==v for k,v in source_hash.items())}
(OUT/'physical_figure_exports.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'exports':[x['id'] for x in exports],'source_unchanged':checks['all_original_source_hashes_unchanged'],'certificate_checks':cert_checks},ensure_ascii=False))
