"""Plot all fixed protocol cases; no selective omissions or fitted asymptotes."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
R=Path(__file__).resolve().parents[1]; F=R/'figures';F.mkdir(exist_ok=True)
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,'axes.titlesize':9,'axes.labelsize':8,'legend.fontsize':7,'legend.frameon':False,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'lines.linewidth':1.3})
def rows(f):
 with (R/'physical_models/results'/f).open(newline='',encoding='utf8') as h:return list(csv.DictReader(h))
H=rows('homogeneous_layers.csv');A=rows('asymmetric_layers.csv');T=rows('asymptotic_grid.csv')
sizes=[4,6,8,16,32,64];ks=[.25,.5,1,2,4,8]
colors=['#a6bddb','#7b9fca','#567fa8','#37648c','#b77b42','#692f45']
manifest=[]
def save(fig,stem,mm):
 fig.set_size_inches(mm[0]/25.4,mm[1]/25.4)
 for ext in ['pdf','svg','png']:
  p=F/(stem+'.'+ext);fig.savefig(p,dpi=600,facecolor='white')
  manifest.append({'file':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'dimensions_mm':mm})
 plt.close(fig)

fig=plt.figure(layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1,1.05])
ax=fig.add_subplot(gs[0,0]);heat=fig.add_subplot(gs[0,1]);fail=fig.add_subplot(gs[1,:])
for m,c in zip(sizes,colors):
 rs=[r for r in H if int(r['m'])==m and float(r['K'])==.5]
 ax.plot([int(r['rank'])/int(r['kernel_dimension']) for r in rs],[float(r['L_over_Dmin']) for r in rs],'-o',ms=2.1,c=c,label=str(m))
ax.set(xlabel='Selected fraction of class-kernel rank',ylabel=r'$L_\ell/D_{\min}$',xlim=(0,1.025),ylim=(-.02,1.04),title=r'(a) Nested lower bounds, $K=0.5$')
ax.legend(title=r'$m$',ncol=3,loc='lower right',columnspacing=.7,handlelength=1.1)
counts=np.zeros((6,6));fraction=np.zeros((6,6))
for i,m in enumerate(sizes):
 for j,k in enumerate(ks):
  rs=[r for r in H if int(r['m'])==m and float(r['K'])==k]
  stop=next(int(r['rank']) for r in rs if r['stop_rule_met']=='True')
  counts[i,j]=stop;fraction[i,j]=stop/(m//2-1)
heat.imshow(fraction,vmin=0,vmax=1,cmap='Blues',aspect='auto')
for i in range(6):
 for j in range(6):heat.text(j,i,str(int(counts[i,j])),ha='center',va='center',fontsize=8,color='white' if fraction[i,j]>.65 else '#102837')
heat.set(xticks=range(6),xticklabels=[str(k) for k in ks],yticks=range(6),yticklabels=sizes,xlabel=r'Coupling $K$',ylabel=r'Visible size $m$',title='(b) First stopping rank')
heat.text(.5,-.29,r'$U-L\leq10^{-8}+10^{-3}L$',transform=heat.transAxes,ha='center',fontsize=7)
x=np.arange(len(A));lower=np.array([float(r['envelope_lower']) for r in A]);upper=np.array([float(r['envelope_upper']) for r in A]);ref=float(A[0]['Dmin_numerical_reference'])
fail.semilogy(x[1:],lower[1:],'o-',color='#37648c',ms=3,label='Lower envelope')
fail.semilogy(x,upper,'s-',color='#b77b42',ms=3,label='Upper envelope')
fail.axhline(ref,color='#333333',ls='--',lw=1,label='Full-pair numerical reference')
fail.set(xticks=x,xticklabels=[r['rank'] for r in A],xlabel='Selected local contrasts',ylabel='Forward KL (nats)',title='(c) Unequal couplings: converged solves, incomplete certificate space',ylim=(1e-13,.2))
fail.text(.03,.1,'Rank 0 lower bound = 0\nFull kernel dimension = 968',transform=fail.transAxes,fontsize=7)
fail.text(.97,.53,'64 contrasts capture only\n'+f'{float(A[-1]["L_over_Dmin"]):.2g} of the reference error',transform=fail.transAxes,ha='right',fontsize=8)
fail.legend(ncol=3,loc='upper center',bbox_to_anchor=(.5,.83),fontsize=7,handlelength=1.7,columnspacing=1.5)
save(fig,'fig3_multicertificate',(178,142))

fig,axes=plt.subplots(1,2,layout='constrained')
for m,c in zip(sizes,colors):
 rs=[r for r in T if int(r['m'])==m]
 for ax,key in zip(axes,['KL_asymptotic_ratio','TV_asymptotic_ratio']):
  ax.plot([float(r['K']) for r in rs],[float(r[key]) for r in rs],'-o',color=c,ms=3,label=str(m))
for ax in axes:
 ax.axhline(1,c='#888888',ls=':',lw=1);ax.set(xlabel=r'Coupling $K$',xscale='log',xticks=[12,24,48,96],xticklabels=['12','24','48','96'],ylim=(-.02,1.07));ax.xaxis.set_minor_locator(mpl.ticker.NullLocator());ax.grid(axis='y',alpha=.15)
axes[0].set(title='(a) Minimum KL / leading term',ylabel='Asymptotic ratio')
axes[1].set(title='(b) TV at KL projection / leading term')
axes[0].legend(title=r'Fixed $m$',ncol=2,loc='lower right')
axes[1].text(.04,.08,r'$K\to\infty$ at fixed $m$'+'\nNo uniform-in-size limit claimed',transform=axes[1].transAxes,fontsize=8)
save(fig,'fig4_fixed_m_limits',(178,82))
(F/'multicertificate_figure_manifest.json').write_text(json.dumps({'backend':'Python matplotlib','outputs':manifest,'sources':[{'file':str((R/'physical_models/results'/f).relative_to(R)),'sha256':hashlib.sha256((R/'physical_models/results'/f).read_bytes()).hexdigest()} for f in ['homogeneous_layers.csv','asymmetric_layers.csv','asymptotic_grid.csv']]},indent=2),encoding='utf8')
print(json.dumps({'figures':2,'exports':len(manifest)}))
