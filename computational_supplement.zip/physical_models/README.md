# Deterministic multi-certificate physical calculations

This directory is self-contained. It computes explicitly specified finite Gibbs distributions, not observations or hypothesis tests. The parent protocol was frozen before computation. No old research directory is modified.

## Reproduce

Requires Python 3, NumPy, SciPy and mpmath. From this directory:

```text
python -B compute_hierarchy.py --part homogeneous
python -B compute_hierarchy.py --part asymptotic
python -B compute_hierarchy.py --part asymmetric
python -B independent_check.py
python -B summarize.py
python -B build_appendix.py
python -B summarize.py
```

The last summary pass includes the rendered report and appendix in the package inventory. Wall times and script hashes naturally change on reruns. The declared cases, formulas and contrast ordering do not. Calculations do not access prior manuscript directories, network resources or private datasets.

## What is covered

* **Homogeneous stars:** visible sizes 4, 6, 8, 16, 32, 64; fixed K = .25, .5, 1, 2, 4, 8. All 390 prescribed layers, including 36 rank-zero baselines, are included. The magnetization-class reduction covers the complete visible-field/pair family only because symmetry and convexity establish it. The 64-spin case uses 33 classes, not enumeration of 2^64 states.
* **Special shared-anchor solve:** each layer fills the retained-moment kernel on its active support, giving a scalar conditional moment equation. This simplification does not apply to arbitrary sparse contrasts. All full reduced ranks saturate. Partial directions may provide little coverage.
* **Asymmetric control:** one fixed ten-visible-spin hidden hub, K_i = .15, .25, ..., 1.05; all 1024 states. All ten fields and 45 pair coefficients are independent in the comparison. The fixed first 64 lexicographic third finite differences have eight-state supports. Ranks 0,1,2,4,8,16,32,64 are reported. This is an incomplete 64-dimensional slice of a 968-dimensional kernel. It deliberately retains an unfavorable result rather than choosing a better contrast order after observing it.
* **Fixed-size limits:** K = 12,24,48,96 for all six sizes. No regression or fitted exponent is used. Large m approaches the fixed-m formula slowly; at m64,K96 the KL ratio remains about .9840. These are not uniform-in-m or thermodynamic limits.

## Bounds and precision

For any strictly positive, exactly moment-preserving iterate r, the mathematical lower value is L = F(q) - F(r), with F(p) = sum p log(p/nu). A genuine retained-family candidate yields U = D(q||p_theta) and U-L = D(r||p_theta). The familiar B = D(q||r) is recorded separately; it is a lower bound only at the exact logarithmic root. The per-layer upper candidate is a fixed r-weighted least-squares fit to log(r/nu), followed by exact-family normalization. Reference optima are never used by the stopping rule.

The original inequalities assume real arithmetic and exact moments. Main symmetric calculations use 110 decimal digits, asymptotic calculations 360, and independent asymptotic checks 420. The asymmetric case uses float64. These outputs are not outward-rounded certified numerical intervals. Raw cancellation residues, including tiny negative saturated widths, are retained. The combined stopping audit is envelope width <= 1e-8 + 1e-3*lower envelope. A rank-zero stop at very small KL means absolute accuracy, not relative recovery.

## Files

* `protocol.json`: settings, fixed directions, stopping rule and scope.
* `compute_hierarchy.py`: primary calculations. `independent_check.py`: no import of primary functions; different target formula and root variable/algorithm, full-state checks, full-field/pair LPs and independent 55-parameter fit.
* `results/homogeneous_details.json`: full-precision class target/reference probabilities, every relaxed probability, coefficients, sparse basis, fit residuals and costs.
* `results/homogeneous_layers.csv`: all 390 per-layer metrics; `homogeneous_cost_stop.csv`: 36 configuration costs and first stops.
* `results/asymptotic_details.json` / `asymptotic_grid.csv`: all 24 fixed-size asymptotic cases; decimal strings preserve divergences far below ordinary display precision.
* `data/asymmetric_arrays.npz`: explicit states, features, target, reference, all sparse columns, relaxed distributions and indexing. Contains no Python objects or pickle data.
* `results/asymmetric_details.json` / `asymmetric_layers.csv`: all eight ranks, full reference parameters/residuals and upper candidates.
* `results/independent_verification.json`, `homogeneous_checks.json`, `summary.json`: verification coverage and numerical caveats.
* `appendix_blocks.json`: bilingual manuscript-ready methods/results with shared TeX. Theory proofs are supplied separately by the companion theory workstream. `report.html` is a simple text preview, not a typeset manuscript.
* `package_manifest.json`: exact file sizes and SHA-256 hashes.

The single local run's costs are recorded honestly. No speedup over a direct scalar full projection is claimed. Localized certificate supports do not remove the cost of normalized target probabilities, the retained-family partition function or general exponentially large state spaces.
