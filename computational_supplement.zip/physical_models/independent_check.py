"""Independent numerical audit: imports no primary computation functions."""
from pathlib import Path
import csv, hashlib, itertools, json, math, time
import numpy as np
import mpmath as mp
from scipy.optimize import linprog, minimize, root
from scipy.special import logsumexp

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'
SPEC=json.loads((ROOT/'protocol.json').read_text(encoding='utf-8'))
checks=[];independent_rows=[]
def check(name,ok,**extra):checks.append({'check':name,'pass':bool(ok),**extra})
def dkl(a,b):return mp.fsum(x*mp.log(x/y) for x,y in zip(a,b))
def independent_star(m,K,dps=180,steps=650):
    mp.mp.dps=dps;t=mp.exp(-2*K);r=list(range(m//2+1))
    g=[mp.mpf(math.comb(m,j)*(1 if 2*j==m else 2)) for j in r]
    q=[mp.mpf(math.comb(m,j))*(t**j+t**(m-j))/(1+t)**m/(2 if 2*j==m else 1) for j in r]
    exponents=[j*(m-j) for j in r];target=mp.fsum(qi*2*e for qi,e in zip(q,exponents))
    lo=mp.mpf(0);hi=mp.mpf(1)
    for _ in range(steps):
        x=(lo+hi)/2;values=[gi*x**e for gi,e in zip(g,exponents)];z=mp.fsum(values)
        deficit=mp.fsum(v*2*e for v,e in zip(values,exponents))/z
        if deficit>target:hi=x
        else:lo=x
    x=(lo+hi)/2;weights=[gi*x**e for gi,e in zip(g,exponents)];z=mp.fsum(weights);p=[v/z for v in weights]
    return q,p,-mp.log(x)/2,dkl(q,p)

def homogeneous_check():
    data=json.loads((OUT/'homogeneous_details.json').read_text())
    for case in data:
        m=case['m'];K=mp.mpf(str(case['K']));key=[m,case['K']]
        q,p,a,D=independent_star(m,K)
        qstored=list(map(mp.mpf,case['q_decimal']));pstored=list(map(mp.mpf,case['reference_p_decimal']))
        a0=mp.mpf(case['reference_a_decimal']);D0=mp.mpf(case['reference_Dmin_decimal'])
        check('independent_polynomial_projection',max(abs(x-y) for x,y in zip(p,pstored))<mp.mpf('1e-75') and abs(D/D0-1)<mp.mpf('1e-65'),case=key,relative_KL_error=float(abs(D/D0-1)))
        check('independent_hidden_mixture_target',max(abs(x-y) for x,y in zip(q,qstored))<mp.mpf('1e-90'),case=key)
        check('independent_parameter',abs(a-a0)<mp.mpf('1e-75'),case=key)
        H=np.array(case['H'],float);S=np.array(case['S'],float);k=np.logaddexp(float(K)*S,-float(K)*S)-np.log(2.)
        A=np.vstack([np.column_stack([-H,np.zeros(len(H)),-np.ones(len(H))]),np.column_stack([H,np.ones(len(H)),np.zeros(len(H))])])
        lp=linprog([0.,-1.,1.],A_ub=A,b_ub=np.r_[-k,k],bounds=[(None,None)]*3,method='highs')
        delta=float(case['minimax_delta_decimal']);check('independent_minimax_LP',lp.success and abs(lp.fun-delta)<1e-9,case=key,lp_error=abs(lp.fun-delta))
        g=list(map(mp.mpf,case['g']));Hmp=list(map(mp.mpf,case['H']));W=[list(map(mp.mpf,w)) for w in case['basis_decimal']]
        for j,w in enumerate(W):
            check('three_support_null_contrast',sum(v!=0 for v in w)==3 and abs(mp.fsum(w))<mp.mpf('1e-90') and abs(mp.fsum(x*h for x,h in zip(w,Hmp)))<mp.mpf('1e-85'),case=key,rank=j+1)
        previous=mp.mpf(0);previous_r=qstored
        for layer in case['layers']:
            l=layer['rank'];rr=list(map(mp.mpf,layer['r_decimal']));tau=list(map(mp.mpf,layer['tau_decimal']))
            reconstruction=[qstored[i]+mp.fsum(tau[j]*W[j][i] for j in range(l)) for i in range(len(q))]
            check('stored_affine_representation',max(abs(x-y) for x,y in zip(rr,reconstruction))<mp.mpf('1e-85'),case=key,rank=l)
            logq=[mp.log(x/v) for x,v in zip(qstored,g)];logr=[mp.log(x/v) for x,v in zip(rr,g)]
            L=mp.fsum(x*y-u*v for x,y,u,v in zip(qstored,logq,rr,logr));B=dkl(qstored,rr)
            upper_a=mp.mpf(layer['upper_candidate_a_decimal']);weights=[gi*mp.exp(upper_a*h) for gi,h in zip(g,Hmp)];Z=mp.fsum(weights);candidate=[v/Z for v in weights]
            U=dkl(qstored,candidate);rem=dkl(rr,candidate)
            check('independent_bracket_and_identity',L<=D+mp.mpf('1e-75') and U>=D-mp.mpf('1e-75') and abs(U-L-rem)<mp.mpf('1e-75'),case=key,rank=l)
            check('stored_metrics',abs(L-mp.mpf(layer['L_decimal']))<mp.mpf('1e-75') and abs(B-mp.mpf(layer['B_decimal']))<mp.mpf('1e-75') and abs(U-mp.mpf(layer['U_decimal']))<mp.mpf('1e-75'),case=key,rank=l)
            check('nested_entropy_lower',L>=previous-mp.mpf('1e-75'),case=key,rank=l);previous=L
            if l:
                increment=dkl(previous_r,rr)
                previous_entropy=mp.fsum(x*mp.log(x/v) for x,v in zip(previous_r,g))
                current_entropy=mp.fsum(x*mp.log(x/v) for x,v in zip(rr,g))
                check('independent_exact_increment',abs(previous_entropy-current_entropy-increment)<mp.mpf('1e-75'),case=key,rank=l)
            previous_r=rr
        check('full_rank_saturation',abs(previous/D-1)<mp.mpf('1e-65'),case=key)
        if m<=8:
            spins=np.array(list(itertools.product([-1.,1.],repeat=m)));mag=spins.sum(axis=1);hp=(mag*mag-m)/2
            # Sum explicitly over the extra hidden spin, not via the stored class formula.
            joint=np.exp(float(K)*np.r_[mag,-mag]-logsumexp(float(K)*np.r_[mag,-mag]));target=joint[:len(mag)]+joint[len(mag):]
            pair=np.exp(float(a)*hp-logsumexp(float(a)*hp));qclass=[target[np.abs(mag)==s].sum() for s in S]
            check('explicit_joint_state_enumeration',np.max(np.abs(np.array(qclass)-np.array(list(map(float,q)))))<2e-14 and abs(float(np.dot(target,np.log(target/pair)))-float(D))<2e-14,case=key)
            feats=np.column_stack([spins]+[spins[:,i]*spins[:,j] for i,j in itertools.combinations(range(m),2)])
            check('all_fields_all_pairs_moments',np.max(np.abs((target-pair)@feats))<2e-13,case=key)
            kfull=np.logaddexp(float(K)*mag,-float(K)*mag)-np.log(2.)
            rows=len(mag);AA=np.vstack([np.column_stack([-feats,np.zeros(rows),-np.ones(rows)]),np.column_stack([feats,np.ones(rows),np.zeros(rows)])])
            cc=np.r_[np.zeros(feats.shape[1]),-1.,1.]
            full=linprog(cc,A_ub=AA,b_ub=np.r_[-kfull,kfull],bounds=[(None,None)]*len(cc),method='highs')
            check('full_field_pair_minimax_not_reduced',full.success and abs(full.fun-delta)<2e-9,case=key,error=abs(full.fun-delta))
        independent_rows.append({'m':m,'K':case['K'],'reference_KL':float(D),'a':float(a),'seconds_full_primary':case['full_fit_seconds']})
    print('homogeneous independent checks',len(checks),flush=True)

def asymptotic_check():
    for case in json.loads((OUT/'asymptotic_details.json').read_text()):
        m=case['m'];K=mp.mpf(case['K']);q,p,a,D=independent_star(m,K,420,1150)
        Ds=mp.mpf(case['KL_decimal']);ps=list(map(mp.mpf,case['p_decimal']));relative=abs(D/Ds-1)
        check('high_precision_asymptotic_reference',relative<mp.mpf('1e-100'),case=[m,case['K']],relative_KL_error=float(relative))
        check('high_precision_asymptotic_parameter',abs(a-mp.mpf(case['a_decimal']))<mp.mpf('1e-100'),case=[m,case['K']])
    print('asymptotic independent checks',len(checks),flush=True)

def asymmetric_check():
    data=np.load(ROOT/'data/asymmetric_arrays.npz');s=data['states'].astype(float);q=data['q'];W=data['W'];rall=data['r_layers'];X=data['X'];features=data['features']
    K=np.array(SPEC['asymmetric']['hub_couplings']);q2=np.prod(np.exp(s*K)/(2*np.cosh(K)),axis=1)/2+np.prod(np.exp(-s*K)/(2*np.cosh(K)),axis=1)/2
    check('asymmetric_independent_hidden_mixture',np.max(np.abs(q-q2))<2e-16)
    # Exact integer certificate verification, independent of numerical QR.
    Xi=X.astype(np.int64);Wi=(8*W).astype(np.int64)
    check('asymmetric_integer_nullspace',np.all(Xi.T@Wi==0) and np.all(np.count_nonzero(Wi,axis=0)==8))
    pivots=[np.where(np.all(s==np.where(np.isin(np.arange(10),tri),-1,1),axis=1))[0][0] for tri in data['triples']]
    check('asymmetric_independent_pivots',np.array_equal(Wi[pivots],-np.eye(64,dtype=np.int64)))
    target=q@features
    def objective(theta):
        logits=features@theta;z=logsumexp(logits);p=np.exp(logits-z)
        return z-target@theta, p@features-target
    opt=minimize(objective,np.zeros(55),jac=True,method='L-BFGS-B',options={'gtol':1e-12,'ftol':1e-15,'maxiter':3000})
    def gradient(theta):return objective(theta)[1]
    def jac(theta):
        p=np.exp(features@theta-logsumexp(features@theta));mean=p@features;center=features-mean
        return (center.T*p)@center
    refined=root(gradient,opt.x,jac=jac,method='hybr',options={'xtol':1e-11})
    pp=np.exp(features@refined.x-logsumexp(features@refined.x));D=float(q@np.log(q/pp))
    check('asymmetric_full55_independent_fit',np.max(np.abs(gradient(refined.x)))<1e-11 and np.max(np.abs(pp-data['reference_p']))<1e-11,optimizer_success=bool(opt.success),root_success=bool(refined.success),probability_error=float(np.max(np.abs(pp-data['reference_p']))))
    stored=json.loads((OUT/'asymmetric_details.json').read_text());lowerprev=0.
    for row,r in zip(stored['layers'],rall):
        l=row['rank'];L=float(np.sum(q*np.log(q)-r*np.log(r)));B=float(q@np.log(q/r))
        co=np.array(row['upper_candidate_coefficients']);z=X@co;candidate=np.exp(z-logsumexp(z));U=float(q@np.log(q/candidate));rem=float(r@np.log(r/candidate))
        check('asymmetric_independent_bracket',min(r)>0 and abs(r.sum()-1)<1e-13 and np.max(np.abs((r-q)@X))<1e-13 and L<=D+1e-12 and U>=D-1e-12,rank=l)
        check('asymmetric_independent_metrics',max(abs(L-row['L']),abs(B-row['B']),abs(U-row['U']),abs(U-L-rem))<2e-13,rank=l)
        e=np.log(r)-z;R=float(max(e)-min(e));check('asymmetric_residual_bound',rem<=min(R,R*R/8)+1e-12,rank=l)
        check('asymmetric_nested',L>=lowerprev-1e-13,rank=l);lowerprev=L
        if l:
            # Convex objective's tangent bound exposes stationarity; no shared Newton call.
            grad=W[:,:l].T@np.log(r);check('asymmetric_stationarity',max(abs(grad))<2e-10,rank=l)
    check('asymmetric_incomplete_rank',np.linalg.matrix_rank(W)==64 and np.linalg.matrix_rank(X)==56 and 1024-56==968)

if __name__=='__main__':
    started=time.perf_counter();homogeneous_check();asymptotic_check();asymmetric_check()
    result={'status':'pass' if all(c['pass'] for c in checks) else 'fail','checks_total':len(checks),'checks_passed':sum(c['pass'] for c in checks),'checks':checks,
            'seconds':time.perf_counter()-started,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),'numerical_scope':'Independent algorithms and high-precision numerical checks, not outward-rounded interval certification'}
    (OUT/'independent_verification.json').write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    with (OUT/'independent_reference.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(independent_rows[0]));w.writeheader();w.writerows(independent_rows)
    print(result['status'],result['checks_passed'],result['checks_total'],'seconds',result['seconds'],flush=True)
    for c in checks:
        if not c['pass']:print('FAILED',c,flush=True)
