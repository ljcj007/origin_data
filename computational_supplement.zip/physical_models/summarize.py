from pathlib import Path
import csv,hashlib,json,platform,sys
import numpy as np, scipy, mpmath
ROOT=Path(__file__).resolve().parent;O=ROOT/'results'
h=json.loads((O/'homogeneous_details.json').read_text());a=json.loads((O/'asymmetric_details.json').read_text());v=json.loads((O/'independent_verification.json').read_text());c=json.loads((O/'homogeneous_checks.json').read_text())
layers=[l for x in h for l in x['layers']];raw=np.load(ROOT/'data/asymmetric_arrays.npz');W=raw['W'];q=raw['q'];field=raw['states']@raw['hub_couplings'];support=np.any(W!=0,axis=1)
support_masses=[float(q[w!=0].sum()) for w in W.T];logcontrasts=W.T@np.log(q)
cost=[]
for x in h:
    cost.append({'m':x['m'],'K':x['K'],'class_count':len(x['q_decimal']),'kernel_rank':len(x['q_decimal'])-2,'first_stop_rank':x['first_stop_rank'],
                 'Dmin':float(x['reference_Dmin_decimal']),'direct_full_moment_seconds':x['full_fit_seconds'],
                 'all_layer_seconds':sum(l['layer_seconds'] for l in x['layers']),
                 'largest_root_residual':max(l['root_residual'] for l in x['layers']),
                 'largest_H_moment_error':max(l['H_moment_error'] for l in x['layers'])})
with (O/'homogeneous_cost_stop.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(cost[0]));w.writeheader();w.writerows(cost)
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary={'status':'pass' if v['status']=='pass' and c['checks_passed']==c['checks_total'] else 'fail',
         'protocol_sha256':sh(ROOT/'protocol.json'),'homogeneous_configurations':len(h),'homogeneous_layers':len(layers),
         'homogeneous_nonzero_layers':sum(l['rank']>0 for l in layers),'full_kernel_saturations':36,
         'primary_checks':{'passed':c['checks_passed'],'total':c['checks_total']},'independent_checks':{'passed':v['checks_passed'],'total':v['checks_total']},
         'max_homogeneous_root_residual':max(l['root_residual'] for l in layers),'max_homogeneous_moment_error':max(l['H_moment_error'] for l in layers),
         'min_raw_homogeneous_bracket_width':min(l['bracket_width'] for l in layers),
         'numerical_caveat':'Tiny negative raw widths at full saturation are finite-precision cancellation, retained in source tables. No outward-rounded certified enclosure is claimed.',
         'homogeneous_stop_rules':cost,
         'asymmetric':{k:v for k,v in a.items() if k not in ['layers','reference_gradient_history']},
         'asymmetric_last':{k:v for k,v in a['layers'][-1].items() if k not in ['tau','upper_candidate_coefficients']},
         'asymmetric_support_description':{'union_support_count':int(support.sum()),'union_q_mass':float(q[support].sum()),'hub_field_range_on_union':[float(field[support].min()),float(field[support].max())],
                                           'individual_q_mass_range':[min(support_masses),max(support_masses)],'log_contrast_range':[float(logcontrasts.min()),float(logcontrasts.max())],
                                           'label':'Post-computation descriptive support audit of the locked contrasts, without selecting or changing directions'},
         'walltimes':{p.stem:json.loads(p.read_text())['seconds'] for p in sorted(O.glob('run_*.json'))},
         'independent_check_seconds':v['seconds'],
         'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':mpmath.__version__,'platform':platform.platform()},
         'scope':'Exact finite-model mathematics with numerical validation; not empirical inference, not performance benchmarking, and not a generic exponential-state-space speedup'}
(O/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
entries=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name not in ['package_manifest.json'] and '__pycache__' not in str(p):entries.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sh(p)})
(ROOT/'package_manifest.json').write_text(json.dumps({'files':entries,'bytes_total':sum(e['bytes'] for e in entries),'old_roots_modified':False},indent=2),encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['status','homogeneous_layers','primary_checks','independent_checks','asymmetric_support_description','walltimes']},indent=2))
