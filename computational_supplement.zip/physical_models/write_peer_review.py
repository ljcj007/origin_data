from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent;parent=R.parent
paths=['theory/multicertificate_theory.json','components/main_blocks.json','figures/fig3_multicertificate.png','figures/fig4_fixed_m_limits.png']
result={'scope':'Read-only scientific cross-review of general-star proof, N031-N036 and two numerical figures; not a fresh full-manuscript review',
        'sources':[{'path':p,'sha256':hashlib.sha256((parent/p).read_bytes()).hexdigest()} for p in paths],
        'status':'pass_with_wording_clarifications',
        'checks':[{'item':'MT033-MT036 strong-coupling proof','status':'pass','evidence':'Independently expanded ground-relative partition weights. z=t-(b*c2/m)t^b+o(t^b); ground/one-flip KL terms sum to c2*t^b, TV=b*c2*t^b. m4 balanced degeneracy produces c2=3. Numerical independent root cases support all fixed-grid ratios.'},
                  {'item':'MT037-MT039 minimax chord','status':'pass','evidence':'Strict concavity in S^2 and endpoint residual comparison establish the exact oscillation optimum; supnorm is half the oscillation, correctly distinguished. Full-family scope is supplied by parameter averaging under convex oscillation, explicit in main P030.'},
                  {'item':'N031-N036 matched physical objectives','status':'pass','evidence':'The pairwise projection is the forward-KL optimum; TV is evaluated at that same model. Fixed m and nonuniform-in-m scope are explicit. No thermodynamic or critical-exponent claim.'},
                  {'item':'Figure 3 source values','status':'pass','evidence':'K=.5 ratios, first stopping ranks, m10 lower/upper envelopes, 968-dimensional full kernel and tiny captured fraction match saved tables.'},
                  {'item':'Figure 4 source values','status':'pass','evidence':'All fixed K12,24,48,96 and six sizes included. m64 ratios show slow convergence; axes distinguish KL optimum and TV at that projection.'}],
        'wording_clarifications_sent_to_parent':[{'location':'N036 and any analogous scope sentence','suggestion':'Use every fixed even m>=4 instead of every fixed even size, to avoid a literal reading that includes m2, which is exactly pairwise representable.'},
          {'location':'Figure 3b caption','suggestion':'State if color encodes selected fraction of full kernel rank while printed integers are raw first stopping ranks.'},
          {'location':'Rank-zero stopping interpretation','suggestion':'K8 rank-zero stop is driven by absolute tolerance 1e-8; it is not relative recovery of the positive divergence.'}],
        'blocking_mathematical_errors_found':False,
        'numerical_review_paths':['results/homogeneous_checks.json','results/independent_verification.json','results/summary.json']}
(R/'results/peer_theory_main_review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
