"""Locked deterministic model calculation. All preceding versions are read-only."""
from pathlib import Path
import csv, hashlib, itertools, json, math, time
import mpmath as mp
import numpy as np
from scipy.special import logsumexp
from scipy.linalg import cho_factor, cho_solve

ROOT=Path(__file__).resolve().parent
SPEC=json.loads((ROOT/'protocol.json').read_text(encoding='utf-8'))
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
DATA=ROOT/'data'; DATA.mkdir(exist_ok=True)

def dec(x): return mp.nstr(x,mp.mp.dps-8)
def scalar(x): return float(x)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def csvout(p,rows):
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def norm(logv):
    top=max(logv); w=[mp.exp(x-top) for x in logv]; z=mp.fsum(w)
    return [x/z for x in w]
def kl(q,p): return mp.fsum(a*mp.log(a/b) for a,b in zip(q,p))
def ent(q,g): return mp.fsum(a*mp.log(a/b) for a,b in zip(q,g))
def star(m,K):
    S=list(range(m,-1,-2)); H=[(s*s-m)//2 for s in S]
    g=[mp.mpf(math.comb(m,(m-s)//2)*(1 if s==0 else 2)) for s in S]
    q=norm([mp.log(gi)+mp.log(mp.cosh(K*s)) for gi,s in zip(g,S)])
    return S,H,g,q

def moment_tilt(g,H,q,active):
    """Special shared-anchor solution, positive on its support; solve deficit moment."""
    mass=mp.fsum(q[i] for i in active); high=max(H[i] for i in active)
    deficits=[mp.mpf(high-H[i]) for i in active]
    target=mp.fsum(q[i]*d for i,d in zip(active,deficits))/mass
    base=[mp.log(g[i]) for i in active]
    def evaluation(a):
        p=norm([b-a*d for b,d in zip(base,deficits)])
        avg=mp.fsum(x*d for x,d in zip(p,deficits))
        var=mp.fsum(x*(d-avg)**2 for x,d in zip(p,deficits))
        return p,avg,var
    lo=mp.mpf(0);hi=mp.mpf(1)
    while evaluation(hi)[1]>target: hi*=2
    a=(lo+hi)/2; tolerance=mp.power(10,-mp.mp.dps+20); status='max_iterations'
    for it in range(2000):
        p,avg,var=evaluation(a); residual=avg-target
        if abs(residual)<=tolerance*target:
            status='converged';break
        if residual>0:lo=a
        else:hi=a
        proposed=a+residual/var
        a=proposed if lo<proposed<hi else (lo+hi)/2
    result=list(q)
    for i,pi in zip(active,p):result[i]=mass*pi
    return result,a,{'iterations':it+1,'status':status,'relative_moment_residual':scalar(abs(residual)/target),'variance_H_conditional':scalar(var)}

def anchors(H,l):
    n=len(H); W=[]
    for j in range(1,l+1):
        v=[mp.mpf(0)]*n
        v[0]=H[j]-H[-1]; v[j]=H[-1]-H[0];v[-1]=H[0]-H[j]
        size=mp.fsum(abs(x) for x in v);W.append([x/size for x in v])
    return W

def fit_upper(q,r,g,H):
    hmax=max(abs(h) for h in H);h=[mp.mpf(x)/hmax for x in H]
    y=[mp.log(ri/gi) for ri,gi in zip(r,g)]
    eh=mp.fsum(ri*hi for ri,hi in zip(r,h));ey=mp.fsum(ri*yi for ri,yi in zip(r,y))
    variance=mp.fsum(ri*(hi-eh)**2 for ri,hi in zip(r,h))
    slope=mp.fsum(ri*(hi-eh)*(yi-ey) for ri,hi,yi in zip(r,h,y))/variance
    z=[ey+slope*(hi-eh) for hi in h]
    candidate=norm([mp.log(gi)+zi for gi,zi in zip(g,z)])
    e=[yi-zi for yi,zi in zip(y,z)];R=max(e)-min(e)
    return candidate,kl(q,candidate),R,kl(r,candidate),slope/hmax

def homogeneous():
    mp.mp.dps=SPEC['homogeneous']['precision_decimal_digits']
    details=[]; rows=[];checks=[]
    for m in SPEC['homogeneous']['visible_spins']:
      for kval in SPEC['homogeneous']['K_grid']:
        K=mp.mpf(str(kval));S,H,g,q=star(m,K)
        t=time.perf_counter();p,a,reference_solver=moment_tilt(g,H,q,list(range(len(q))))
        reference_seconds=time.perf_counter()-t;D=kl(q,p);tv=mp.fsum(abs(qi-pi) for qi,pi in zip(q,p))/2
        lower_envelope=mp.mpf(0);upper_envelope=mp.inf;previous=mp.mpf(0);first_stop=None
        layers=[]
        for l in range(len(q)-1):
            started=time.perf_counter();active=([0,len(q)-1]+list(range(1,l+1)))
            if l==0:r=list(q);aa=None;solver={'iterations':0,'status':'identity','relative_moment_residual':0.,'variance_H_conditional':None}
            else:r,aa,solver=moment_tilt(g,H,q,active)
            W=anchors(H,l); y=[mp.log(ri/gi) for ri,gi in zip(r,g)]
            tau=[(r[j]-q[j])/W[j-1][j] for j in range(1,l+1)]
            gradient=[mp.fsum(wi*yi for wi,yi in zip(w,y)) for w in W]
            B=kl(q,r);L=ent(q,g)-ent(r,g)
            candidate,U,R,remainder,upper_a=fit_upper(q,r,g,H)
            lower_envelope=max(lower_envelope,mp.mpf(0),L);upper_envelope=min(upper_envelope,U)
            width=upper_envelope-lower_envelope
            stop=width<=mp.mpf('1e-8')+mp.mpf('1e-3')*lower_envelope
            if stop and first_stop is None:first_stop=l
            qh=mp.fsum(qi*h for qi,h in zip(q,H));rh=mp.fsum(ri*h for ri,h in zip(r,H))
            algebra=max(abs(U-L-remainder),abs(B-L-mp.fsum(t*gg for t,gg in zip(tau,gradient))))
            mass_error=abs(mp.fsum(r)-1);moment_error=abs(qh-rh)
            if l:
                Hess=mp.matrix([[mp.fsum(wi*vi/ri for wi,vi,ri in zip(w,v,r)) for v in W] for w in W])
                scale=max(abs(Hess[i,i]) for i in range(l))
                condition=float(np.linalg.cond(np.array([[float(Hess[i,j]/scale) for j in range(l)] for i in range(l)])))
                condition=None if not np.isfinite(condition) else condition
            else:condition=None
            elapsed=time.perf_counter()-started
            record={'m':m,'K':kval,'rank':l,'kernel_dimension':len(q)-2,'active_classes':len(active) if l else 0,
                    'B':scalar(B),'L':scalar(L),'nonnegative_lower':scalar(max(0,L)),'U':scalar(U),'Dmin':scalar(D),
                    'B_over_Dmin':scalar(B/D),'L_over_Dmin':scalar(L/D),'actual_gap':scalar(D-L),
                    'bracket_width':scalar(U-L),'residual_oscillation':scalar(R),'range_bound':scalar(min(R,R*R/8)),
                    'envelope_lower':scalar(lower_envelope),'envelope_upper':scalar(upper_envelope),'envelope_width':scalar(width),'stop_rule_met':bool(stop),
                    'B_minus_L':scalar(B-L),'root_residual':scalar(max([abs(v) for v in gradient],default=mp.mpf(0))),
                    'mass_error':scalar(mass_error),'H_moment_error':scalar(moment_error),'identity_error':scalar(algebra),
                    'condition_sparse_Hessian_float':condition,'layer_seconds':elapsed,'solver_iterations':solver['iterations'],'solver_status':solver['status']}
            rows.append(record)
            layers.append({**record,'r_decimal':[dec(x) for x in r],'tau_decimal':[dec(x) for x in tau],
                           'a_decimal':None if aa is None else dec(aa),'upper_candidate_a_decimal':dec(upper_a),
                           'B_decimal':dec(B),'L_decimal':dec(L),'U_decimal':dec(U),'reference_D_decimal':dec(D),
                           'gradient_decimal':[dec(x) for x in gradient],'solver':solver})
            tol=mp.mpf('1e-75')
            checks.extend([{'case':[m,kval,l],'check':'positive_normalized_moments','pass':bool(min(r)>0 and mass_error<tol and moment_error<tol)},
                           {'case':[m,kval,l],'check':'identities_and_bounds','pass':bool(algebra<tol and L<=D+tol and U>=D-tol and remainder<=min(R,R*R/8)+tol)},
                           {'case':[m,kval,l],'check':'nested','pass':bool(L>=previous-tol)}])
            previous=L
        checks.append({'case':[m,kval],'check':'full_saturation','pass':abs(layers[-1]['L_over_Dmin']-1)<1e-12})
        delta=max(mp.log(mp.cosh(K*s))-mp.mpf(s*s)/(m*m)*mp.log(mp.cosh(K*m)) for s in S)
        details.append({'m':m,'K':kval,'S':S,'H':H,'g':[int(x) for x in g],'q_decimal':[dec(x) for x in q],
                        'reference_p_decimal':[dec(x) for x in p],'reference_a_decimal':dec(a),'reference_Dmin_decimal':dec(D),
                        'reference_TV_decimal':dec(tv),'minimax_delta_decimal':dec(delta),'full_fit_seconds':reference_seconds,
                        'reference_solver':reference_solver,'first_stop_rank':first_stop,'basis_decimal':[[dec(x) for x in w] for w in anchors(H,len(q)-2)],'layers':layers})
        print('homogeneous',m,kval,'layers',len(layers),'stop',first_stop,'KL',float(D),flush=True)
    dump(OUT/'homogeneous_details.json',details);csvout(OUT/'homogeneous_layers.csv',rows)
    dump(OUT/'homogeneous_checks.json',{'checks_total':len(checks),'checks_passed':sum(x['pass'] for x in checks),'checks':checks})
    return details

def asymptotics():
    mp.mp.dps=SPEC['homogeneous']['asymptotic_precision_decimal_digits'];rows=[];details=[]
    for m in SPEC['homogeneous']['visible_spins']:
      for kval in SPEC['homogeneous']['asymptotic_K_grid']:
        started=time.perf_counter();K=mp.mpf(kval);S,H,g,q=star(m,K)
        p,a,solver=moment_tilt(g,H,q,list(range(len(q))))
        D=kl(q,p);TV=mp.fsum(abs(qi-pi) for qi,pi in zip(q,p))/2
        gamma=mp.mpf(4)*(m-2)/(m-1);coef_D=mp.mpf(3 if m==4 else math.comb(m,2));coef_TV=mp.mpf(4 if m==4 else m*(m-2))
        delta=max(mp.log(mp.cosh(K*s))-mp.mpf(s*s)/(m*m)*mp.log(mp.cosh(K*m)) for s in S)
        slope=max(mp.mpf(s)*(m-s)/m for s in S)
        maximizers=[s for s in S if mp.mpf(s)*(m-s)/m==slope];sm=max(maximizers)
        intercept=-mp.log(2)*(1-mp.mpf(sm*sm)/(m*m))
        row={'m':m,'K':kval,'a':float(a),'a_over_K_div_mminus1':float(a/(K/(m-1))),
             'gamma':float(gamma),'KL':float(D),'TV':float(TV),'KL_asymptotic_ratio':float(D/(coef_D*mp.exp(-gamma*K))),
             'TV_asymptotic_ratio':float(TV/(coef_TV*mp.exp(-gamma*K))),
             'minimax_delta':float(delta),'minimax_slope':float(slope),'minimax_intercept':float(intercept),'minimax_asymptotic_difference':float(delta-slope*K-intercept),
             'solver_iterations':solver['iterations'],'solver_status':solver['status'],'seconds':time.perf_counter()-started}
        rows.append(row);details.append({**row,'q_decimal':[dec(x) for x in q],'p_decimal':[dec(x) for x in p],'a_decimal':dec(a),'KL_decimal':dec(D),'TV_decimal':dec(TV),'delta_decimal':dec(delta)})
        print('asymptotic',m,kval,'KLratio',row['KL_asymptotic_ratio'],flush=True)
    csvout(OUT/'asymptotic_grid.csv',rows);dump(OUT/'asymptotic_details.json',details)

def fkl(q,p):return float(np.dot(q,np.log(q/p)))
def fnorm(y):return np.exp(y-logsumexp(y))

def family_fit(features,q):
    target=q@features;theta=np.zeros(features.shape[1]);history=[]
    for it in range(150):
        logp=features@theta; logz=logsumexp(logp);p=np.exp(logp-logz)
        mean=p@features;grad=mean-target;center=features-mean
        Hess=(center.T*p)@center;normgrad=float(np.max(np.abs(grad)))
        history.append(normgrad)
        if normgrad<2e-13:break
        step=np.linalg.solve(Hess,grad);value=logz-target@theta
        factor=1.
        while factor>2**-40:
            trial=theta-factor*step; trialvalue=logsumexp(features@trial)-target@trial
            if trialvalue<=value-1e-4*factor*(grad@step) or normgrad<1e-10:break
            factor/=2
        theta=trial
    return theta,p,history

def entropy_minimize(q,W):
    if W.shape[1]==0:return q.copy(),np.zeros(0),{'iterations':0,'status':'identity','gradient_max':0.}
    # QR is only a change of coordinates within the fixed sparse column space.
    Q,R=np.linalg.qr(W,mode='reduced');eta=np.zeros(W.shape[1]);status='max_iterations'
    for it in range(300):
        r=q+Q@eta; grad=Q.T@np.log(r);maxgrad=float(np.max(np.abs(grad)))
        if maxgrad<=1e-10:status='converged';break
        Hess=(Q.T/r)@Q;step=cho_solve(cho_factor(Hess),grad);dr=-(Q@step)
        factor=min(1.,0.99*float(np.min(-r[dr<0]/dr[dr<0]))) if np.any(dr<0) else 1.
        value=float(r@np.log(r));decrease=float(grad@step)
        while factor>2**-50:
            trial=r+factor*dr
            if np.all(trial>0) and (trial@np.log(trial)<=value-1e-4*factor*decrease or maxgrad<1e-8):break
            factor/=2
        if factor<=2**-50:status='line_search_stalled';break
        eta-=factor*step
    r=q+Q@eta;tau=np.linalg.solve(R,eta)
    return r,tau,{'iterations':it+1,'status':status,'gradient_max':float(np.max(np.abs(W.T@np.log(r))))}

def asymmetric():
    spec=SPEC['asymmetric'];m=spec['visible_spins'];states=np.array(list(itertools.product([-1.,1.],repeat=m)))
    pairs=list(itertools.combinations(range(m),2));features=np.column_stack([states]+[states[:,i]*states[:,j] for i,j in pairs]);X=np.column_stack([np.ones(len(states)),features])
    couplings=np.array(spec['hub_couplings']);field=states@couplings
    q=fnorm(np.logaddexp(field,-field)-np.log(2.))
    started=time.perf_counter();theta,p,fit_history=family_fit(features,q);fit_seconds=time.perf_counter()-started
    D=fkl(q,p); W=np.zeros((len(states),64));triples=list(itertools.combinations(range(m),3))[:64]
    lookup={tuple(row.astype(int)):i for i,row in enumerate(states)}
    for j,tri in enumerate(triples):
        for bits in itertools.product([0,1],repeat=3):
            s=np.ones(m,dtype=int)
            for index,bit in zip(tri,bits):s[index]=-1 if bit else 1
            W[lookup[tuple(s)],j]=(-1.)**sum(bits)/8.
    assert np.max(np.abs(X.T@W))==0.
    details=[];rows=[];rstore=[];lower=0.;upper=math.inf;first_stop=None
    for l in spec['layers']:
        started=time.perf_counter();w=W[:,:l];r,tau,solver=entropy_minimize(q,w)
        B=fkl(q,r);L=float(q@np.log(q)-r@np.log(r))
        rooterror=solver['gradient_max'];A=X*np.sqrt(r)[:,None];zcoef=np.linalg.lstsq(A,np.log(r)*np.sqrt(r),rcond=None)[0]
        z=X@zcoef;candidate=fnorm(z);U=fkl(q,candidate);e=np.log(r)-z;R=float(np.ptp(e));remainder=fkl(r,candidate)
        lower=max(lower,L,0.);upper=min(upper,U);stop=upper-lower<=1e-8+1e-3*lower
        if stop and first_stop is None:first_stop=l
        Hess=(w.T/r)@w if l else np.zeros((0,0));condition=float(np.linalg.cond(Hess)) if l else None
        row={'m':m,'rank':l,'kernel_dimension':1024-56,'B':B,'L':L,'U':U,'Dmin_numerical_reference':D,
             'B_over_Dmin':B/D,'L_over_Dmin':L/D,'actual_gap_reference':D-L,'bracket_width':U-L,
             'envelope_lower':lower,'envelope_upper':upper,'envelope_width':upper-lower,'stop_rule_met':stop,
             'residual_oscillation':R,'range_bound':min(R,R*R/8),'B_minus_L':B-L,
             'root_residual':rooterror,'mass_error':float(abs(r.sum()-1)),'retained_moment_error':float(np.max(np.abs((r-q)@X))),
             'identity_error':abs(U-L-remainder),'stationarity_identity_error':abs(B-L-float(tau@(w.T@np.log(r)))) if l else abs(B-L),
             'condition_sparse_Hessian':condition,'solver_iterations':solver['iterations'],'solver_status':solver['status'],'seconds':time.perf_counter()-started}
        rows.append(row);details.append({**row,'tau':tau.tolist(),'upper_candidate_coefficients':zcoef.tolist()});rstore.append(r)
        print('asymmetric',l,'ratio',L/D,'width',upper-lower,solver['status'],flush=True)
    np.savez_compressed(DATA/'asymmetric_arrays.npz',states=states.astype(np.int8),pairs=np.array(pairs),features=features,X=X,hub_couplings=couplings,q=q,reference_p=p,reference_theta=theta,W=W,triples=np.array(triples),layers=np.array(spec['layers']),r_layers=np.array(rstore))
    dump(OUT/'asymmetric_details.json',{'layers':details,'reference_KL':D,'reference_fit_seconds':fit_seconds,'reference_gradient_history':fit_history,'reference_gradient_max':fit_history[-1],'first_stop_rank':first_stop,
         'state_count':1024,'retained_feature_rank':int(np.linalg.matrix_rank(X)),'certificate_rank':int(np.linalg.matrix_rank(W)),'nullspace_residual':float(np.max(np.abs(X.T@W))),
         'reference_field_max':float(np.max(np.abs(theta[:m]))),'reference_pair_min':float(np.min(theta[m:])),'reference_pair_max':float(np.max(theta[m:])),'note':'All 55 nonconstant parameters were fitted independently. Near-zero fields emerge from global flip symmetry; the 45 pair parameters are not tied.'})
    csvout(OUT/'asymmetric_layers.csv',rows)

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--part',choices=['all','homogeneous','asymptotic','asymmetric'],default='all');args=ap.parse_args()
    print('protocol_sha256',sha(ROOT/'protocol.json'),flush=True)
    started=time.perf_counter()
    if args.part in ('all','homogeneous'):homogeneous()
    if args.part in ('all','asymptotic'):asymptotics()
    if args.part in ('all','asymmetric'):asymmetric()
    dump(OUT/f'run_{args.part}.json',{'protocol_sha256':sha(ROOT/'protocol.json'),'script_sha256':sha(Path(__file__)),'seconds':time.perf_counter()-started,'part':args.part,'numerical_enclosures':'not interval certified'})
